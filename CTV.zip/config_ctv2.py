"""
config_ctv2.py — CTV2 Live Runner Configuration
"""

VERSION = "CFG-2.0"
from datetime import time

# ── EMA / Direction Signal ─────────────────────────────────────
MACD_FAST               = 3
MACD_SLOW               = 15
MACD_SIGNAL             = 9
EMA_DIRECTION_THRESHOLD = 1.5

# ── Entry ──────────────────────────────────────────────────────
SPREAD_WIDTH      = 5.0
MAX_PREMIUM       = 350.0
MAX_SPREAD_WIDTH  = 1.0
MAX_ACTIVE_TRADES = 4
MAX_ENTRY_RETRIES = 3
GAP_OPEN_THRESHOLD = 20.0   # pts from prev close to trigger gap-open entry

# ── Exit ───────────────────────────────────────────────────────
WIN_MOVE                = 5.0
MIN_CONV_CREDIT_PCT     = 1.05
SELL_SLIPPAGE           = 0.95
REVERSAL_CLOSE_MIN_MOVE = 10.0

# ── Park & Risk ────────────────────────────────────────────────
PARK_MAX_MOVE = 15.0

# ── Trading Window ─────────────────────────────────────────────
TRADING_START       = time(10, 0)
TRADING_END         = time(16, 0)
LAST_ENTRY_TIME     = time(14, 0)
PM_BOUNDARY         = time(13, 0)
INTRINSIC_EXIT_TIME = time(14, 30)

# ── Order Pricing ──────────────────────────────────────────────
ENTRY_SLIPPAGE  = 1.05
PREFETCH_RADIUS = 75.0

# ── Data (backtester only) ─────────────────────────────────────
SPX_DATA_DIR = "SPX_3min_bars"
