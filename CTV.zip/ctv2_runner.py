#!/usr/bin/env python3
"""
ctv2_runner.py — CTV2 Live / Paper Trading Runner

ARCHITECTURE
============
Direction : EMA3/EMA15 MACD separation (QualityFilter — ported from backtester)
Entry     : BAG LMT BUY vertical spread  (ask × 1.05, tick-rounded)
Win exit  : Intrabar SPX monitoring via historicalDataUpdate ticks
              → win_target = spx_at_fill ± WIN_MOVE
              → on trigger: request conversion spread quote
              → place LMT SELL at max(bid × 0.95, min_profit_price/100), tick-rounded
Park      : direction flips against trade → state = PARKED
              if time >= 13:00 → place stop LMT SELL vertical at 50% premium × 0.95
              if |bar.close - park_spx| > PARK_MAX_MOVE → force close
Reversal  : opposite direction WIN fill → close PARKED trades in opp direction
              if |_live_spx - ctv_cv| > REVERSAL_CLOSE_MIN_MOVE
Intrinsic : at INTRINSIC_EXIT_TIME → cancel all win/stop orders, sell verticals at bid × 0.95
Chain     : after WIN fill, re-enter using conv_strike as new long_strike if direction viable
CONFIG NOTE
===========
Add to config_ctv2.py:
    PARK_MAX_MOVE = 15.0   # SPX pts from park_spx before force-closing parked trade
"""

from __future__ import annotations

import csv
import json
import signal
import sys
import time
import threading
import traceback
from datetime import datetime, time as dtime
from pathlib import Path
from typing import Optional, Dict, List, Tuple
from dataclasses import dataclass, field
from zoneinfo import ZoneInfo

from ibapi.client import EClient
from ibapi.wrapper import EWrapper
from ibapi.contract import Contract
from ibapi.order import Order
from ibapi.common import TickerId, TickAttrib

import config_ctv2 as cfg
from ctv2_order_manager import CTV2OrderManager
from risk_manager import RiskManager, TradeOutcome as RiskOutcome

try:
    from pushover_alerts import PushoverAlerter
    PUSHOVER_AVAILABLE = True
except ImportError:
    PUSHOVER_AVAILABLE = False

# ── safe fallback for PARK_MAX_MOVE if not yet in config ──────────────────────
PARK_MAX_MOVE       = getattr(cfg, 'PARK_MAX_MOVE',       15.0)
GAP_OPEN_THRESHOLD  = getattr(cfg, 'GAP_OPEN_THRESHOLD',  20.0)

ET = ZoneInfo('America/New_York')


# =============================================================================
# MACD + QualityFilter  (ported verbatim from ctv2_options_backtester.py)
# =============================================================================

class MACD:
    def __init__(self, fast: int, slow: int, signal: int):
        self.af   = 2.0 / (fast   + 1)
        self.as_  = 2.0 / (slow   + 1)
        self.asig = 2.0 / (signal + 1)
        self.ema_fast   = None
        self.ema_slow   = None
        self.ema_signal = None
        self.histogram  = None
        self._buf_fast  = []
        self._buf_slow  = []
        self._warm_fast = False
        self._warm_slow = False
        self._fast_per  = fast
        self._slow_per  = slow

    def update(self, close: float) -> Optional[float]:
        if not self._warm_fast:
            self._buf_fast.append(close)
            if len(self._buf_fast) >= self._fast_per:
                self.ema_fast   = sum(self._buf_fast) / len(self._buf_fast)
                self._warm_fast = True
        else:
            self.ema_fast = close * self.af + self.ema_fast * (1 - self.af)

        if not self._warm_slow:
            self._buf_slow.append(close)
            if len(self._buf_slow) >= self._slow_per:
                self.ema_slow   = sum(self._buf_slow) / len(self._buf_slow)
                self._warm_slow = True
        else:
            self.ema_slow = close * self.as_ + self.ema_slow * (1 - self.as_)

        if not (self._warm_fast and self._warm_slow):
            return None

        macd_line = self.ema_fast - self.ema_slow
        if self.ema_signal is None:
            self.ema_signal = macd_line
        else:
            self.ema_signal = macd_line * self.asig + self.ema_signal * (1 - self.asig)
        self.histogram = macd_line - self.ema_signal
        return self.histogram


class QualityFilter:
    """EMA3/EMA15 MACD direction filter — direct port from backtester.
    Also tracks EMA5 for entry confirmation (EMA3 > EMA5 for UP, < for DOWN).
    """

    _EMA5_K = 2.0 / (5 + 1)   # smoothing factor for EMA5

    def __init__(self):
        self.macd = MACD(cfg.MACD_FAST, cfg.MACD_SLOW, cfg.MACD_SIGNAL)
        self._confirmed_direction: Optional[str] = None
        self._prev_ema3: Optional[float] = None
        self._ema5: Optional[float] = None

    def update(self, close: float) -> dict:
        self.macd.update(close)
        # EMA5: seed on first bar, then smooth
        if self._ema5 is None:
            self._ema5 = close
        else:
            self._ema5 = close * self._EMA5_K + self._ema5 * (1.0 - self._EMA5_K)
        state = self._evaluate()
        self._prev_ema3 = self.macd.ema_fast
        return state

    def _evaluate(self) -> dict:
        ema3  = self.macd.ema_fast
        ema15 = self.macd.ema_slow
        state = {
            'viable': False, 'direction': self._confirmed_direction,
            'direction_change': False, 'separation': None,
            'ema3_slope': 0.0, 'ema5': self._ema5, 'reason': 'WARMUP',
        }
        if ema3 is None or ema15 is None:
            return state

        if self._prev_ema3 is not None:
            state['ema3_slope'] = ema3 - self._prev_ema3

        separation = abs(ema3 - ema15)
        state['separation'] = separation
        raw_dir = 'UP' if ema3 > ema15 else 'DOWN'

        if separation > cfg.EMA_DIRECTION_THRESHOLD and raw_dir != self._confirmed_direction:
            self._confirmed_direction = raw_dir
            state['direction_change'] = True

        state['direction'] = self._confirmed_direction
        state['viable']    = separation > cfg.EMA_DIRECTION_THRESHOLD
        state['reason']    = ('VIABLE' if state['viable']
                              else f'LOW_SEP({separation:.2f}<{cfg.EMA_DIRECTION_THRESHOLD})')
        return state

    def is_viable(self, direction: str) -> bool:
        """Returns True if direction is currently confirmed and separation is above threshold."""
        if self._confirmed_direction != direction:
            return False
        ema3  = self.macd.ema_fast
        ema15 = self.macd.ema_slow
        if ema3 is None or ema15 is None:
            return False
        return abs(ema3 - ema15) > cfg.EMA_DIRECTION_THRESHOLD


# =============================================================================
# Data structures
# =============================================================================

@dataclass
class LiveTrade:
    trade_id:         int
    direction:        str          # 'UP' or 'DOWN'
    right:            str          # 'C' or 'P'
    ctv_cv:           float        # SPX at bar open when entry was signalled
    entry_time:       datetime
    state:            str          # 'PENDING_FILL' | 'ACTIVE' | 'PENDING_WIN_QUOTE'
                                   # | 'PARKED' | 'CLOSING' | 'PENDING_BUTTERFLY'
    long_strike:      float
    short_strike:     float
    conv_strike:      float
    premium_paid:     float        # actual dollars paid (avgFillPrice × 100)
    win_target:       float        # SPX level that triggers win sell
    min_profit_price: float        # min credit dollars (premium_paid × MIN_CONV_CREDIT_PCT)
    entry_order_id:   int
    spx_at_fill:      float = 0.0  # _live_spx at moment of entry fill
    win_order_id:     int   = 0    # set when win sell order placed
    stop_order_id:    int   = 0
    park_spx:         float = 0.0  # SPX price at park event
    is_gap_trade:     bool  = False


@dataclass
class LiveButterfly:
    """
    Post-WIN position: 3-leg butterfly sitting at IBKR.
    System does not manage these intraday — they expire or are swept at 15:30.
    `right` is derived: 'C' if direction == 'UP' else 'P'.
    """
    trade_id:    int
    direction:   str          # 'UP' or 'DOWN'
    long_strike: float        # lowest strike  (+1 leg from original entry)
    short_strike:float        # middle strike  (-2 legs: entry short + WIN short)
    conv_strike: float        # highest strike (+1 leg from WIN conversion buy)
    premium_paid:float        # original entry cost (dollars)
    win_credit:  float        # dollars received for conversion sell
    net_cost:    float        # premium_paid - win_credit
    entry_time:  datetime
    win_time:    Optional[datetime]
    spx_at_fill: float = 0.0  # SPX at original entry fill


@dataclass
class PendingEntry:
    direction:         str
    signal_time:       datetime
    ctv_cv:            float      # bar.close at signal (used for ctv_cv on trade)
    retries:           int  = 0
    mktdata_requested: bool = False
    is_gap_trade:      bool = False


# =============================================================================
# Main application
# =============================================================================

class TradingApp(EWrapper, EClient):
    """
    CTV2 live runner.  Inherits EWrapper + EClient exactly as R10.
    All TWS plumbing is verbatim-R10; trading logic is CTV2.
    """

    VERSION = "CTV2-RUNNER-1.0"

    def __init__(self, mode: str = 'paper'):
        EClient.__init__(self, self)
        self.mode = mode

        self.tz = ET

        # ── Direction detection ───────────────────────────────────────────
        self.quality_filter = QualityFilter()

        # ── Trade state ──────────────────────────────────────────────────
        self.trades:          List[LiveTrade]     = []
        self.butterflies:     List[LiveButterfly] = []
        self.pending_entries: List[PendingEntry]  = []
        self._trade_id_seq:   int = 0

        # ── Position recovery (mid-day restart) ───────────────────────────
        self._recovery_positions: List[dict] = []
        self._recovery_complete:  bool = False

        # ── Market data dispatch ─────────────────────────────────────────
        # ticker_id → {'purpose': str, 'bid': float|None, 'ask': float|None, ...}
        self._mktdata:        Dict[int, dict] = {}
        self._ticker_counter: int = 0

        # ── Order tracking ────────────────────────────────────────────────
        # order_id → 'ENTRY:<trade_id>' | 'WIN:<trade_id>' | 'STOP:<trade_id>'
        #           | 'CLOSE:<trade_id>:<reason>'
        self.pending_orders:  Dict[int, str] = {}
        self._filled_orders:  set = set()   # dedup: IBKR sends Filled multiple times

        # ── IBKR connection state ─────────────────────────────────────────
        self.next_order_id:        Optional[int] = None
        self.connection_ready:     bool = False
        self.live_trading_active:  bool = False

        # ── Contract ID cache ─────────────────────────────────────────────
        self.contract_ids:         Dict[str, int] = {}   # 'C_6750' → conId
        self.contract_id_requests: Dict[int, str] = {}   # reqId → key

        # ── Live SPX price (updated on every historicalDataUpdate tick) ───
        self._live_spx: float = 0.0

        # ── Historical data ───────────────────────────────────────────────
        self.prev_day_bars:           List[dict] = []
        self.prev_day_close_received: bool = False
        self.historical_bars:         List[dict] = []
        self.historical_data_complete:bool = False

        # reqId constants (verbatim R10)
        self.prev_day_close_req_id = 9997
        self.historical_req_id     = 9999

        # ── Live bar buffering (verbatim R10) ────────────────────────────
        self._live_bar_buffer:      Optional[dict] = None
        self._live_bar_time:        Optional[datetime] = None
        self._last_emitted_bar_time:Optional[datetime] = None

        # ── SPX price tracking ────────────────────────────────────────────
        self.last_bar_close: float = 0.0

        # ── Late-day exit flag ────────────────────────────────────────────
        self._intrinsic_done: bool = False
        self._session_done:   bool = False

        # ── Gap-open trade flag ───────────────────────────────────────────
        self._gap_trade_active: bool = False

        # ── Session P&L accumulators (updated on every _log_trade call) ──
        self._session_wins:   int   = 0
        self._session_losses: int   = 0
        self._session_pnl:    float = 0.0

        # ── Live bar watchdog ─────────────────────────────────────────────
        self._last_bar_update_time:  Optional[datetime] = None
        self._resubscribe_in_flight: bool = False
        self._resubscribe_count:     int  = 0
        self._spx_contract:          Optional[Contract] = None
        self.WATCHDOG_STALE_MINS:    int  = 5    # bars are 3 min; 5 min = ~1.5 missed bars
        self.WATCHDOG_MAX_RETRIES:   int  = 3

        # ── Risk management ───────────────────────────────────────────────
        risk_config = {
            'risk_management': {
                'suspension_enabled':    True,
                'max_consecutive_losses': 2,
                'max_daily_losses':       3,
                'restart_flag_file':      'C:\\CTV\\RESTART_TRADING.flag',
            }
        }
        self.risk_mgr = RiskManager(risk_config)

        # ── Pushover alerts ───────────────────────────────────────────────
        self.pushover = None
        if PUSHOVER_AVAILABLE:
            try:
                self.pushover = PushoverAlerter()
            except Exception:
                pass

        # ── CSV trade log ─────────────────────────────────────────────────
        self._init_trade_log()

        # ── Order manager ─────────────────────────────────────────────────
        self.order_manager = CTV2OrderManager(self)

        print(f"\n{'='*60}")
        print(f" CTV2 Runner {self.VERSION} — {mode.upper()} MODE")
        print(f"{'='*60}")
        print(f"[CONFIG] WIN_MOVE            : {cfg.WIN_MOVE} pts")
        print(f"[CONFIG] SPREAD_WIDTH        : {cfg.SPREAD_WIDTH} pts")
        print(f"[CONFIG] MIN_CONV_CREDIT_PCT : {cfg.MIN_CONV_CREDIT_PCT}")
        print(f"[CONFIG] MAX_PREMIUM         : ${cfg.MAX_PREMIUM:.0f}")
        print(f"[CONFIG] TRADING_START       : {cfg.TRADING_START}")
        print(f"[CONFIG] LAST_ENTRY_TIME     : {cfg.LAST_ENTRY_TIME}")
        print(f"[CONFIG] INTRINSIC_EXIT_TIME : {cfg.INTRINSIC_EXIT_TIME}")
        print(f"[CONFIG] PARK_MAX_MOVE       : {PARK_MAX_MOVE} pts")
        print(f"[CONFIG] GAP_OPEN_THRESHOLD  : {GAP_OPEN_THRESHOLD} pts")
        print(f"[CONFIG] REVERSAL_CLOSE      : {cfg.REVERSAL_CLOSE_MIN_MOVE} pts")
        print(f"[CONFIG] MAX_ACTIVE_TRADES   : {cfg.MAX_ACTIVE_TRADES}")
        print(f"[PUSHOVER] {'enabled' if self.pushover else 'disabled'}")
        port = 7497 if mode == 'paper' else 7496
        print(f"[IBKR] Port: {port}")

    # =========================================================================
    # CSV trade log
    # =========================================================================

    def _init_trade_log(self):
        log_dir = Path('logs')
        log_dir.mkdir(exist_ok=True)
        ts  = datetime.now().strftime('%Y%m%d_%H%M%S')
        csv_path = log_dir / f"ctv2_{self.mode}_{ts}.csv"
        self._log_file   = open(csv_path, 'w', newline='')
        self._log_path   = csv_path
        self._log_writer = csv.DictWriter(self._log_file, fieldnames=[
            'record_type',
            'trade_id', 'direction', 'right', 'entry_time',
            'long_strike', 'short_strike', 'conv_strike',
            'ctv_cv', 'premium_paid', 'min_profit_price', 'win_target',
            'spx_at_fill', 'outcome', 'exit_credit', 'net_pnl', 'state_at_close',
        ])
        self._log_writer.writeheader()
        print(f"[CSV ] Trade log: {csv_path}")

    def _log_entry(self, trade: LiveTrade):
        """Write an ENTRY row when a fill is confirmed."""
        self._log_writer.writerow({
            'record_type':      'ENTRY',
            'trade_id':         trade.trade_id,
            'direction':        trade.direction,
            'right':            'C' if trade.direction == 'UP' else 'P',
            'entry_time':       trade.entry_time.isoformat(),
            'long_strike':      trade.long_strike,
            'short_strike':     trade.short_strike,
            'conv_strike':      trade.conv_strike,
            'ctv_cv':           f"{trade.ctv_cv:.2f}",
            'premium_paid':     f"{trade.premium_paid:.2f}",
            'min_profit_price': f"{trade.min_profit_price:.2f}",
            'win_target':       f"{trade.win_target:.2f}",
            'spx_at_fill':      f"{trade.spx_at_fill:.2f}",
            'outcome':          '',
            'exit_credit':      '',
            'net_pnl':          '',
            'state_at_close':   'ACTIVE',
        })
        self._log_file.flush()

    def _log_trade(self, trade: LiveTrade, outcome: str,
                   exit_credit: float, state_at_close: str):
        """Write an EXIT row. outcome = WIN | STOP | INTRINSIC | REVERSAL | PARK_RANGE etc."""
        net = exit_credit - trade.premium_paid
        self._session_pnl += net
        if net >= 0:
            self._session_wins += 1
        else:
            self._session_losses += 1
        self._log_writer.writerow({
            'record_type':      'EXIT',
            'trade_id':         trade.trade_id,
            'direction':        trade.direction,
            'right':            'C' if trade.direction == 'UP' else 'P',
            'entry_time':       trade.entry_time.isoformat(),
            'long_strike':      trade.long_strike,
            'short_strike':     trade.short_strike,
            'conv_strike':      trade.conv_strike,
            'ctv_cv':           f"{trade.ctv_cv:.2f}",
            'premium_paid':     f"{trade.premium_paid:.2f}",
            'min_profit_price': f"{trade.min_profit_price:.2f}",
            'win_target':       f"{trade.win_target:.2f}",
            'spx_at_fill':      f"{trade.spx_at_fill:.2f}",
            'outcome':          outcome,
            'exit_credit':      f"{exit_credit:.2f}",
            'net_pnl':          f"{net:.2f}",
            'state_at_close':   state_at_close,
        })
        self._log_file.flush()

    def _log_butterfly(self, bf: LiveButterfly):
        """Write a BUTTERFLY row at EOD — records the net cost of the structure."""
        self._log_writer.writerow({
            'record_type':      'BUTTERFLY',
            'trade_id':         bf.trade_id,
            'direction':        bf.direction,
            'right':            'C' if bf.direction == 'UP' else 'P',
            'entry_time':       bf.entry_time.isoformat(),
            'long_strike':      bf.long_strike,
            'short_strike':     bf.short_strike,
            'conv_strike':      bf.conv_strike,
            'ctv_cv':           '',
            'premium_paid':     f"{bf.premium_paid:.2f}",
            'min_profit_price': '',
            'win_target':       '',
            'spx_at_fill':      f"{bf.spx_at_fill:.2f}",
            'outcome':          'BUTTERFLY',
            'exit_credit':      f"{bf.win_credit:.2f}",
            'net_pnl':          f"{-bf.net_cost:.2f}",
            'state_at_close':   'BUTTERFLY',
        })
        self._log_file.flush()

    # =========================================================================
    # STATE FILE  (daily JSON — survives mid-day restarts)
    # =========================================================================

    def _state_path(self) -> Path:
        date_str = datetime.now(self.tz).strftime('%Y%m%d')
        return Path('logs') / f'ctv2_state_{date_str}.json'

    def _save_state(self):
        """Write current trades + butterflies to today's state file atomically."""
        def _trade_dict(t: LiveTrade) -> dict:
            return {
                'trade_id':        t.trade_id,
                'direction':       t.direction,
                'long_strike':     t.long_strike,
                'short_strike':    t.short_strike,
                'conv_strike':     t.conv_strike,
                'premium_paid':    t.premium_paid,
                'spx_at_fill':     t.spx_at_fill,
                'ctv_cv':          t.ctv_cv,
                'entry_time':      t.entry_time.isoformat(),
                'win_target':      t.win_target,
                'min_profit_price':t.min_profit_price,
            }
        def _butterfly_dict(b: LiveButterfly) -> dict:
            return {
                'trade_id':    b.trade_id,
                'direction':   b.direction,
                'long_strike': b.long_strike,
                'short_strike':b.short_strike,
                'conv_strike': b.conv_strike,
                'premium_paid':b.premium_paid,
                'win_credit':  b.win_credit,
                'net_cost':    b.net_cost,
                'spx_at_fill': b.spx_at_fill,
                'entry_time':  b.entry_time.isoformat(),
                'win_time':    b.win_time.isoformat() if b.win_time else None,
            }
        try:
            # Only persist filled (not PENDING_FILL) trades
            active_trades = [t for t in self.trades if t.state != 'PENDING_FILL']
            state = {
                'trades':      [_trade_dict(t) for t in active_trades],
                'butterflies': [_butterfly_dict(b) for b in self.butterflies],
            }
            path = self._state_path()
            tmp  = path.with_suffix('.tmp')
            tmp.write_text(json.dumps(state, indent=2))
            tmp.replace(path)
        except Exception as e:
            print(f"[STATE] Save failed: {e}")

    # =========================================================================
    # STRIKE CONFLICT HELPERS
    # =========================================================================

    def _existing_longs(self) -> set:
        """All strikes we are currently net long across trades and butterflies."""
        longs = {t.long_strike for t in self.trades}
        longs |= {b.long_strike  for b in self.butterflies}
        longs |= {b.conv_strike  for b in self.butterflies}
        return longs

    def _existing_shorts(self) -> set:
        """All strikes we are currently net short across trades and butterflies."""
        shorts = {t.short_strike for t in self.trades}
        shorts |= {b.short_strike for b in self.butterflies}
        return shorts

    # =========================================================================
    # POST-WARMUP ENTRY CHECK  (mid-day restart)
    # =========================================================================

    def _post_warmup_entry_check(self):
        """
        Called after warmup completes on a mid-day restart.
        Applies the same EMA3/EMA5 + separation gate as _on_bar_complete.
        Queues an entry immediately if conditions are currently met.
        """
        now = datetime.now(self.tz).time()
        if now < cfg.TRADING_START or now >= cfg.LAST_ENTRY_TIME:
            print("[RESTART] Outside entry window — skipping post-warmup check")
            return

        state       = self.quality_filter._evaluate()
        current_dir = state.get('direction')
        viable      = state.get('viable', False)
        separation  = state.get('separation', 0.0) or 0.0
        ema3        = self.quality_filter.macd.ema_fast or 0.0
        ema5        = state.get('ema5') or 0.0

        print(f"[RESTART] Post-warmup state: dir={current_dir or 'NONE'} "
              f"sep={separation:.2f} EMA3={ema3:.2f} EMA5={ema5:.2f} "
              f"viable={'Y' if viable else 'N'}")

        if current_dir is None or not viable:
            print("[RESTART] No viable direction — waiting for signal")
            return

        ema_confirm = ((current_dir == 'UP'   and ema3 > ema5) or
                       (current_dir == 'DOWN' and ema3 < ema5))
        if not ema_confirm:
            print(f"[RESTART] {current_dir} viable but EMA3/EMA5 not confirmed — waiting")
            return

        if not self._can_open(current_dir):
            print(f"[RESTART] Cannot open {current_dir} — at trade limits or already open")
            return

        if not self.risk_mgr.is_trading_allowed():
            print("[RESTART] Trading suspended — no restart entry")
            return

        print(f"[RESTART] Conditions met — queuing {current_dir} entry")
        self.pending_entries.append(PendingEntry(
            direction  = current_dir,
            signal_time= datetime.now(self.tz),
            ctv_cv     = self.last_bar_close,
        ))

    # =========================================================================
    # POSITION RECOVERY CALLBACKS + HELPERS
    # =========================================================================

    def position(self, account: str, contract: Contract,
                 pos: float, avgCost: float):
        """EWrapper callback — collects positions during recovery."""
        if contract.secType == 'OPT' and contract.symbol == 'SPX':
            self._recovery_positions.append({
                'symbol': contract.symbol,
                'expiry': contract.lastTradeDateOrContractMonth,
                'strike': float(contract.strike),
                'right':  contract.right,
                'qty':    pos,
            })

    def positionEnd(self):
        """EWrapper callback — signals reqPositions is complete."""
        self._recovery_complete = True

    def _alloc_trade_id(self) -> int:
        self._trade_id_seq += 1
        return self._trade_id_seq

    def _reconstruct_trade(self, long_s: float, short_s: float,
                           direction: str, right: str,
                           saved: dict) -> LiveTrade:
        """Build a LiveTrade from IBKR legs + state file metadata."""
        trade_id  = saved.get('trade_id') or self._alloc_trade_id()
        entry_str = saved.get('entry_time')
        entry_time = (datetime.fromisoformat(entry_str).replace(tzinfo=ET)
                      if entry_str else datetime.now(self.tz))
        premium_paid     = float(saved.get('premium_paid', 0.0))
        spx_at_fill      = float(saved.get('spx_at_fill', 0.0))
        conv_strike      = float(saved.get('conv_strike',
                                           short_s + cfg.SPREAD_WIDTH))
        win_target       = float(saved.get('win_target', 0.0))
        min_profit_price = float(saved.get('min_profit_price',
                                           premium_paid * cfg.MIN_CONV_CREDIT_PCT))
        if win_target == 0.0 and spx_at_fill > 0:
            win_target = (spx_at_fill + cfg.WIN_MOVE if direction == 'UP'
                          else spx_at_fill - cfg.WIN_MOVE)
        return LiveTrade(
            trade_id        = trade_id,
            direction       = direction,
            right           = right,
            ctv_cv          = float(saved.get('ctv_cv', spx_at_fill)),
            entry_time      = entry_time,
            state           = 'ACTIVE',
            long_strike     = long_s,
            short_strike    = short_s,
            conv_strike     = conv_strike,
            premium_paid    = premium_paid,
            win_target      = win_target,
            min_profit_price= min_profit_price,
            entry_order_id  = 0,
            spx_at_fill     = spx_at_fill,
        )

    def _reconstruct_butterfly(self, long_s: float, short_s: float,
                               conv_s: float, direction: str,
                               saved: dict) -> LiveButterfly:
        """Build a LiveButterfly from IBKR legs + state file metadata."""
        trade_id   = saved.get('trade_id') or self._alloc_trade_id()
        entry_str  = saved.get('entry_time')
        win_str    = saved.get('win_time')
        entry_time = (datetime.fromisoformat(entry_str).replace(tzinfo=ET)
                      if entry_str else datetime.now(self.tz))
        win_time   = (datetime.fromisoformat(win_str).replace(tzinfo=ET)
                      if win_str else None)
        premium_paid = float(saved.get('premium_paid', 0.0))
        win_credit   = float(saved.get('win_credit',   0.0))
        return LiveButterfly(
            trade_id    = trade_id,
            direction   = direction,
            long_strike = long_s,
            short_strike= short_s,
            conv_strike = conv_s,
            premium_paid= premium_paid,
            win_credit  = win_credit,
            net_cost    = float(saved.get('net_cost',
                                          premium_paid - win_credit)),
            entry_time  = entry_time,
            win_time    = win_time,
            spx_at_fill = float(saved.get('spx_at_fill', 0.0)),
        )

    def _recover_state(self):
        """
        Called at startup after warmup, before live bar subscription.
        1. Load today's state file (metadata: premium, times, targets)
        2. reqPositions() from IBKR (authoritative on what exists)
        3. Cross-reference: IBKR legs → identify structures → hydrate from JSON
        4. Rebuild self.trades and self.butterflies
        """
        from collections import defaultdict
        today_expiry = datetime.now(self.tz).strftime('%Y%m%d')

        # ── Load state file ────────────────────────────────────────────────
        saved_trades      = {}   # (long_s, short_s)          → dict
        saved_butterflies = {}   # (long_s, short_s, conv_s)  → dict
        state_path = self._state_path()
        if state_path.exists():
            try:
                data = json.loads(state_path.read_text())
                for t in data.get('trades', []):
                    key = (float(t['long_strike']), float(t['short_strike']))
                    saved_trades[key] = t
                for b in data.get('butterflies', []):
                    key = (float(b['long_strike']), float(b['short_strike']),
                           float(b['conv_strike']))
                    saved_butterflies[key] = b
                print(f"[RECOVER] State file: {len(saved_trades)} trade(s), "
                      f"{len(saved_butterflies)} butterfly(ies)")
            except Exception as e:
                print(f"[RECOVER] State file unreadable ({e}) — using IBKR only")
        else:
            print("[RECOVER] No state file — will reconstruct from IBKR positions")

        # ── Request positions from IBKR ────────────────────────────────────
        self._recovery_positions = []
        self._recovery_complete  = False
        self.reqPositions()
        timeout, start = 10, time.time()
        while not self._recovery_complete:
            if time.time() - start > timeout:
                print("[RECOVER] Timeout waiting for positions")
                break
            time.sleep(0.1)
        self.cancelPositions()

        # ── Filter to today's SPX options ──────────────────────────────────
        today_legs = [p for p in self._recovery_positions
                      if p['symbol'] == 'SPX' and p['expiry'] == today_expiry]

        if not today_legs:
            print("[RECOVER] No open SPX positions for today — clean start")
            return

        print(f"[RECOVER] {len(today_legs)} SPX option leg(s) found at IBKR")

        # ── Group by right → strike → net qty ─────────────────────────────
        by_right: dict = defaultdict(lambda: defaultdict(float))
        for leg in today_legs:
            by_right[leg['right']][leg['strike']] += leg['qty']

        for right, strike_map in by_right.items():
            direction = 'UP' if right == 'C' else 'DOWN'
            active    = {s: q for s, q in strike_map.items() if q != 0}
            strikes   = sorted(active)

            if len(strikes) == 2:
                # LiveTrade: +1 long / -1 short
                lo, hi = strikes
                if active[lo] == 1 and active[hi] == -1:
                    saved = saved_trades.get((lo, hi), {})
                    trade = self._reconstruct_trade(lo, hi, direction, right, saved)
                    self.trades.append(trade)
                    src = "state file" if saved else "IBKR only"
                    print(f"[RECOVER] LiveTrade #{trade.trade_id} {direction} "
                          f"{int(lo)}/{int(hi)} (from {src})")
                else:
                    print(f"[RECOVER] Unexpected 2-leg {right} {strikes} "
                          f"qty={[active[s] for s in strikes]} — skipped")

            elif len(strikes) == 3:
                # LiveButterfly: +1 / -2 / +1
                s0, s1, s2 = strikes
                if active[s0] == 1 and active[s1] == -2 and active[s2] == 1:
                    # Dedup: skip if this butterfly is already in memory
                    existing_keys = {(b.direction, b.long_strike, b.short_strike, b.conv_strike)
                                     for b in self.butterflies}
                    if (direction, s0, s1, s2) in existing_keys:
                        print(f"[RECOVER] LiveButterfly {direction} "
                              f"{int(s0)}/{int(s1)}/{int(s2)} already in memory — skipped")
                    else:
                        saved = saved_butterflies.get((s0, s1, s2), {})
                        bf    = self._reconstruct_butterfly(s0, s1, s2,
                                                            direction, saved)
                        self.butterflies.append(bf)
                        src = "state file" if saved else "IBKR only"
                        print(f"[RECOVER] LiveButterfly #{bf.trade_id} {direction} "
                              f"{int(s0)}/{int(s1)}/{int(s2)} (from {src})")
                else:
                    print(f"[RECOVER] Unexpected 3-leg {right} {strikes} "
                          f"qty={[active[s] for s in strikes]} — skipped")
            else:
                print(f"[RECOVER] Unrecognized structure: {right} {strikes} — skipped")

        print(f"[RECOVER] Complete — {len(self.trades)} trade(s), "
              f"{len(self.butterflies)} butterfly(ies) restored")

    # =========================================================================
    # LIVE STARTUP SEQUENCE  (verbatim R10 structure)
    # =========================================================================

    def run_live(self):
        port = 7497 if self.mode == 'paper' else 7496
        print(f"\n[IBKR] Connecting to {self.mode.upper()} TWS on port {port}...")
        self.connect('127.0.0.1', port, clientId=1)

        api_thread = threading.Thread(target=self.run, daemon=True)
        api_thread.start()

        # Wait for nextValidId
        timeout, start = 30, time.time()
        while not self.connection_ready:
            if time.time() - start > timeout:
                print("[ERROR] Connection timeout — is TWS running?")
                return
            time.sleep(0.1)
        print(f"[IBKR] Connected — next order ID: {self.next_order_id}")

        spx = self._create_spx_contract()
        self._spx_contract = spx          # stored for watchdog resubscription

        # 1. Fetch previous day bars → warm MACD
        self._fetch_previous_day_bars(spx)

        # 2. Warmup replay (current day bars so far)
        self._request_historical_warmup(spx)

        # 3. Wait for market open if pre-market
        #    Contract cache is centered on last_bar_close — if we cache at 8:45
        #    using pre-market price the range may not cover the actual open.
        #    Wait until 9:30 ET so the first live bar has arrived and
        #    last_bar_close reflects the true market-open price.
        now = datetime.now(self.tz)
        market_open = now.replace(hour=9, minute=30, second=0, microsecond=0)
        if now < market_open:
            wait_secs = (market_open - now).total_seconds()
            print(f"[CACHE] Pre-market — waiting {wait_secs:.0f}s until 09:30 "
                  f"for accurate SPX open price...")
            while datetime.now(self.tz) < market_open:
                time.sleep(1)
            # Give a few seconds for first bar to arrive and update last_bar_close
            time.sleep(5)
            print(f"[CACHE] Market open — proceeding with contract cache "
                  f"(SPX≈{self.last_bar_close:.2f})")

        # 4. Pre-cache contract IDs (synchronous, R7 approach)
        self._precache_contract_ids_sync(spx)

        # 5. Recover open positions on mid-day restart
        self._recover_state()

        # 6. Post-warmup entry check — queue entry if conditions already met
        self._post_warmup_entry_check()

        # 7. Subscribe to live bars
        self._request_live_bars(spx)

        print("\n>>> CTV2 running. Press Ctrl+C to stop. <<<\n")

        # Signal handler
        def _shutdown(sig, frame):
            print("\n[SHUTDOWN] Signal received — exiting cleanly")
            self.disconnect()
            self._log_file.close()
            sys.exit(0)
        signal.signal(signal.SIGINT, _shutdown)

        # Main loop
        while True:
            time.sleep(1)
            self._flush_live_bar_if_complete()
            self._check_late_day_exits()
            self._check_market_close()
            self._check_watchdog()

    # =========================================================================
    # CONTRACT + HISTORICAL HELPERS  (verbatim R10)
    # =========================================================================

    def _create_spx_contract(self) -> Contract:
        c = Contract()
        c.symbol   = "SPX"
        c.secType  = "IND"
        c.currency = "USD"
        c.exchange = "CBOE"
        return c

    def _fetch_previous_day_bars(self, spx: Contract):
        print("[IBKR] Fetching previous day bars to seed EMA3/EMA15...")
        self.prev_day_bars            = []
        self.prev_day_close_received  = False
        self.reqHistoricalData(
            self.prev_day_close_req_id, spx, "", "2 D", "3 mins",
            "TRADES", 1, 1, False, []
        )
        timeout, start = 15, time.time()
        while not self.prev_day_close_received:
            if time.time() - start > timeout:
                print("[IBKR] Timeout waiting for previous day bars")
                break
            time.sleep(0.05)

        if self.prev_day_bars:
            print(f"[IBKR] Previous day request complete ({len(self.prev_day_bars)} bars)")
            for bd in self.prev_day_bars:
                self.quality_filter.update(bd['close'])
            ema3  = self.quality_filter.macd.ema_fast
            ema15 = self.quality_filter.macd.ema_slow
            if ema3 and ema15:
                print(f"[IBKR] EMA seed: EMA3={ema3:.2f} EMA15={ema15:.2f}")
            else:
                print("[IBKR] Could not seed EMAs — will self-warm from current day bars")
        else:
            print("[IBKR] No previous day bars — will self-warm")

    def _request_historical_warmup(self, spx: Contract):
        now = datetime.now(self.tz)
        market_open = now.replace(hour=9, minute=30, second=0, microsecond=0)
        minutes_open = (now - market_open).seconds // 60
        if minutes_open < 3:
            print("[WARMUP] Market just opened — no warmup needed")
            self.live_trading_active = True
            return

        print(f"[WARMUP] Market open {minutes_open} min — requesting historical replay...")
        self.historical_bars          = []
        self.historical_data_complete = False
        self.reqHistoricalData(
            9998, spx, "", "1 D", "3 mins", "TRADES", 1, 1, False, []
        )
        timeout, start = 20, time.time()
        while not self.historical_data_complete:
            if time.time() - start > timeout:
                print("[WARMUP] Timeout waiting for warmup bars")
                break
            time.sleep(0.1)

        if self.historical_bars:
            print(f"[WARMUP] Warmup bars received ({len(self.historical_bars)} bars)")
            print("[WARMUP] Replaying bars through QualityFilter...")
            for bd in self.historical_bars:
                self.quality_filter.update(bd['close'])
                self.last_bar_close = bd['close']
            ema3  = self.quality_filter.macd.ema_fast
            ema15 = self.quality_filter.macd.ema_slow
            sep   = abs(ema3 - ema15) if (ema3 and ema15) else 0.0
            print(f"[WARMUP] Done — EMA3={ema3:.2f} EMA15={ema15:.2f} sep={sep:.2f}")
        else:
            print("[WARMUP] No warmup bars received")

    def _precache_contract_ids_sync(self, spx: Contract):
        """Pre-cache conIds for strikes around current price. Verbatim R10."""
        current_price = self.last_bar_close
        if current_price == 0 and self.historical_bars:
            current_price = self.historical_bars[-1]['close']
        if current_price == 0:
            print("[CACHE] No price available — skipping pre-cache")
            return

        radius     = int(cfg.PREFETCH_RADIUS)
        base       = round(current_price / 5) * 5
        expiry     = datetime.now().strftime('%Y%m%d')
        strikes    = [int(base + o) for o in range(-radius, radius + 5, 5)]
        low_s, hi_s = strikes[0], strikes[-1]

        total = len(strikes) * 2
        print(f"[CACHE] Pre-caching {len(strikes)} strikes × calls+puts = {total} contracts")
        print(f"[CACHE] SPX={current_price:.2f} | Range={low_s}–{hi_s} | Expiry={expiry}")

        requests_sent = 0
        for strike in strikes:
            for right in ["C", "P"]:
                key = f"{right}_{strike}"
                if key in self.contract_ids:
                    continue
                c = Contract()
                c.symbol   = "SPX"
                c.secType  = "OPT"
                c.exchange = "SMART"
                c.currency = "USD"
                c.lastTradeDateOrContractMonth = expiry
                c.strike     = float(strike)
                c.right      = right
                c.multiplier = "100"
                req_id = 5000 + requests_sent
                self.contract_id_requests[req_id] = key
                self.reqContractDetails(req_id, c)
                requests_sent += 1
                time.sleep(0.05)   # 50 ms pacing

        print(f"[CACHE] Sent {requests_sent} requests — waiting for responses...")
        for _ in range(15):
            time.sleep(1)
            cached = len(self.contract_ids)
            pct    = cached / requests_sent * 100 if requests_sent else 100
            print(f"[CACHE] Progress: {cached}/{requests_sent} ({pct:.0f}%)")
            if cached >= requests_sent * 0.9:
                break
        print(f"[CACHE] Complete: {len(self.contract_ids)} contract IDs cached")

    def _request_live_bars(self, spx: Contract):
        print(f"[IBKR] Subscribing to live 3-min SPX bars...")
        self.reqHistoricalData(
            self.historical_req_id, spx, "", "1 D", "3 mins",
            "TRADES", 1, 1, True, []   # keepUpToDate = True
        )
        print(f"[IBKR] Live bar subscription active")

    # =========================================================================
    # LIVE BAR FLUSH  (verbatim R10)
    # =========================================================================

    def _flush_live_bar_if_complete(self):
        """Flush buffered live bar once wall-clock passes its close time + 2s grace."""
        from datetime import timedelta
        if self._live_bar_buffer is None or self._live_bar_time is None:
            return
        if (self._last_emitted_bar_time is not None and
                self._live_bar_time <= self._last_emitted_bar_time):
            self._live_bar_buffer = None
            self._live_bar_time   = None
            return
        close_time = self._live_bar_time + timedelta(minutes=3)
        now        = datetime.now(self.tz)
        if now >= close_time + timedelta(seconds=2):
            print(f"[IBKR] Wall-clock flush: {self._live_bar_time.strftime('%H:%M')}")
            self._last_emitted_bar_time = self._live_bar_time
            self._on_bar_complete(self._live_bar_buffer)
            self._live_bar_buffer = None
            self._live_bar_time   = None

    # =========================================================================
    # IBKR CALLBACKS  (structure verbatim R10; content adapted for CTV2)
    # =========================================================================

    def nextValidId(self, orderId: int):
        super().nextValidId(orderId)
        self.next_order_id  = orderId
        self.connection_ready = True
        print(f"[IBKR] Connected — next order ID: {orderId}")

    def historicalData(self, reqId: int, bar):
        bd = {'date': bar.date, 'open': bar.open, 'high': bar.high,
              'low': bar.low,  'close': bar.close}
        if reqId == self.prev_day_close_req_id:
            self.prev_day_bars.append(bd)
        elif reqId == 9998:
            self.historical_bars.append(bd)
        elif reqId == self.historical_req_id:
            # Historical catchup bars — feed through quality filter, record last close
            self.quality_filter.update(bar.close)
            self.last_bar_close = bar.close

    def historicalDataEnd(self, reqId: int, start: str, end: str):
        if reqId == self.prev_day_close_req_id:
            self.prev_day_close_received = True
        elif reqId == 9998:
            self.historical_data_complete = True
            print(f"[WARMUP] Historical warmup bars received ({len(self.historical_bars)} bars)")
        elif reqId == self.historical_req_id:
            self.live_trading_active = True
            print("[IBKR] Historical catchup complete — live trading ACTIVE")
            self._post_warmup_entry_check()

    def historicalDataUpdate(self, reqId: int, bar):
        """
        Live tick updates when keepUpToDate=True.
        Fires on every SPX tick (~1 second during market hours).
        - Updates _live_spx for intrabar win detection
        - Checks all ACTIVE trades against win_target on every tick
        - Buffers the forming bar; emits previous bar when timestamp advances
        Verbatim R10 buffering logic.
        """
        if reqId != self.historical_req_id:
            return
        self._last_bar_update_time = datetime.now(self.tz)   # watchdog heartbeat
        self._live_spx = bar.close                            # real-time SPX

        # Check win targets on every tick (intrabar win detection)
        if self.live_trading_active:
            self._check_win_targets()

        from datetime import timedelta
        try:
            bar_time = datetime.strptime(bar.date, '%Y%m%d %H:%M:%S').astimezone(ET)
        except Exception:
            return

        incoming = {
            'bar_index': 0, 'bar_start_time': bar_time,
            'open': bar.open, 'high': bar.high, 'low': bar.low, 'close': bar.close,
        }

        if self._live_bar_time is None:
            self._live_bar_time   = bar_time
            self._live_bar_buffer = incoming
        elif bar_time != self._live_bar_time:
            if (self._live_bar_buffer is not None and
                    (self._last_emitted_bar_time is None or
                     self._live_bar_time > self._last_emitted_bar_time)):
                self._last_emitted_bar_time = self._live_bar_time
                self._on_bar_complete(self._live_bar_buffer)
            if (self._last_emitted_bar_time is None or
                    bar_time > self._last_emitted_bar_time):
                self._live_bar_time   = bar_time
                self._live_bar_buffer = incoming
            else:
                self._live_bar_time   = None
                self._live_bar_buffer = None
        else:
            self._live_bar_buffer = incoming

    def contractDetails(self, reqId: int, contractDetails):
        if reqId not in self.contract_id_requests:
            return
        key    = self.contract_id_requests[reqId]
        con_id = contractDetails.contract.conId
        self.contract_ids[key] = con_id
        print(f"[CACHE] {key} → conId={con_id}")

    def contractDetailsEnd(self, reqId: int):
        if reqId in self.contract_id_requests:
            del self.contract_id_requests[reqId]

    def error(self, reqId: int, errorCode: int, errorString: str, advancedOrderRejectJson: str = ""):
        # Suppress benign informational messages
        if errorCode in (2104, 2106, 2158, 2100, 2101, 2103, 2105, 2107, 2108, 2119):
            print(f"[INFO ] IB {errorCode}: {errorString}")
            return
        print(f"[ERROR] reqId={reqId} code={errorCode}: {errorString}")

        # Order rejection — clean up any zombie trade in PENDING_FILL state
        # Error 110 = price variation, 103 = duplicate order, 201 = rejected
        if errorCode in (110, 103, 201) and reqId in self.pending_orders:
            key = self.pending_orders.get(reqId, '')
            if key.startswith('ENTRY:'):
                try:
                    trade_id = int(key.split(':')[1])
                    before   = len(self.trades)
                    self.trades = [t for t in self.trades
                                   if t.trade_id != trade_id]
                    if len(self.trades) < before:
                        print(f"[CLEANUP] Removed zombie trade #{trade_id} "
                              f"(order {reqId} rejected: error {errorCode})")
                    del self.pending_orders[reqId]
                except Exception as e:
                    print(f"[ERROR] Zombie cleanup failed: {e}")

    def tickPrice(self, reqId: int, tickType: int, price: float, attrib):
        """
        Dispatch market data ticks to the correct pending request.
        tickType 1 = BID, 2 = ASK.
        """
        if reqId not in self._mktdata:
            return
        if price <= 0:
            return

        slot = self._mktdata[reqId]
        if tickType == 1:
            slot['bid'] = price
            print(f"[MKT ] ticker={reqId} BID=${price:.2f}")
        elif tickType == 2:
            slot['ask'] = price
            print(f"[MKT ] ticker={reqId} ASK=${price:.2f}")

        if slot['bid'] is None or slot['ask'] is None:
            return   # still waiting for the other side

        # Both sides received — cancel subscription and dispatch
        self.order_manager.cancel_market_data(reqId)
        bid = slot['bid']
        ask = slot['ask']
        mid = (bid + ask) / 2.0

        try:
            if slot['purpose'] == 'ENTRY':
                self._on_entry_quote(slot, bid, ask, mid)
            elif slot['purpose'] == 'WIN_QUOTE':
                self._on_win_quote(slot, bid)
            elif slot['purpose'] == 'CLOSE':
                self._on_close_quote(slot, bid)
            elif slot['purpose'] == 'BUTTERFLY_CONV':
                self._on_butterfly_conv_quote(slot, bid)
        except Exception as e:
            print(f"[ERROR] tickPrice dispatch error: {e}")
            traceback.print_exc()
        finally:
            del self._mktdata[reqId]

    def orderStatus(self, orderId: int, status: str, filled: float, remaining: float,
                    avgFillPrice: float, permId: int, parentId: int, lastFillPrice: float,
                    clientId: int, whyHeld: str, mktCapPrice: float):
        """
        Handle order fills.  All logic wrapped in try/except so an exception
        here never crashes the IB message thread (root cause of Tuesday's failure).
        """
        print(f"[ORDER] ID {orderId}: {status} "
              f"(filled={filled} avg=${avgFillPrice:.2f})")
        if status != "Filled":
            return
        key = self.pending_orders.get(orderId)
        if key is None:
            return
        # IBKR sometimes sends Filled multiple times for the same order.
        # Process only the first callback; ignore duplicates.
        if orderId in self._filled_orders:
            print(f"[ORDER] ID {orderId}: duplicate Filled callback — ignored")
            return
        self._filled_orders.add(orderId)
        try:
            parts    = key.split(':')
            purpose  = parts[0]
            trade_id = int(parts[1])
            trade    = self._find_trade(trade_id)

            if purpose == 'ENTRY':
                self._on_entry_fill(orderId, trade, avgFillPrice)

            elif purpose == 'WIN':
                if trade:
                    credit = avgFillPrice * 100
                    net    = credit - trade.premium_paid
                    sign   = '+' if net >= 0 else ''
                    print(f"[WIN ] #{trade_id} {trade.direction} "
                          f"credit=${credit:.0f} net={sign}${net:.0f}")
                    self._log_trade(trade, 'WIN', credit, trade.state)
                    self.risk_mgr.record_outcome(RiskOutcome.WIN)
                    if trade.stop_order_id:
                        self.cancelOrder(trade.stop_order_id, "")
                    # Capture fields needed for chain before removing trade
                    won_direction   = trade.direction
                    won_conv_strike = trade.conv_strike
                    won_right       = trade.right
                    # Promote to LiveButterfly
                    bf = LiveButterfly(
                        trade_id    = trade.trade_id,
                        direction   = trade.direction,
                        long_strike = trade.long_strike,
                        short_strike= trade.short_strike,
                        conv_strike = trade.conv_strike,
                        premium_paid= trade.premium_paid,
                        win_credit  = credit,
                        net_cost    = trade.premium_paid - credit,
                        entry_time  = trade.entry_time,
                        win_time    = datetime.now(self.tz),
                        spx_at_fill = trade.spx_at_fill,
                    )
                    # Dedup: _filled_orders blocks double callbacks, but guard
                    # against any edge case where the butterfly already exists
                    existing_keys = {(b.direction, b.long_strike, b.short_strike, b.conv_strike)
                                     for b in self.butterflies}
                    if (bf.direction, bf.long_strike, bf.short_strike, bf.conv_strike) in existing_keys:
                        print(f"[WIN ] #{trade_id} butterfly already recorded — skipped duplicate")
                    else:
                        self.butterflies.append(bf)
                    self.trades = [t for t in self.trades if t.trade_id != trade_id]
                    self._save_state()
                    # Reversal close: close opposite PARKED trades
                    self._check_reversal_closes(trade)
                    # Chained re-entry: queue new entry using conv_strike as long
                    self._try_chain_entry(won_direction, won_conv_strike, won_right)
                    # Clear gap trade flag if this was a gap-open trade
                    if trade.is_gap_trade:
                        self._gap_trade_active = False
                        print("[GAP  ] Gap-open trade closed (WIN) — normal signals resuming")

            elif purpose == 'STOP':
                if trade:
                    credit = avgFillPrice * 100
                    net    = credit - trade.premium_paid
                    print(f"[STOP] #{trade_id} {trade.direction} "
                          f"recover=${credit:.0f} net=${net:.0f}")
                    self._log_trade(trade, 'STOP', credit, trade.state)
                    self.risk_mgr.record_outcome(RiskOutcome.LOSS)
                    # Cancel win order
                    if trade.win_order_id:
                        self.cancelOrder(trade.win_order_id, "")
                    self.trades = [t for t in self.trades if t.trade_id != trade_id]
                    self._save_state()
                    # Clear gap trade flag if this was a gap-open trade
                    if trade.is_gap_trade:
                        self._gap_trade_active = False
                        print("[GAP  ] Gap-open trade closed (STOP) — normal signals resuming")

            elif purpose == 'BFLY_CONV':
                reason = parts[2] if len(parts) > 2 else 'BFLY_CONV'
                if trade:
                    conv_credit = avgFillPrice * 100
                    net         = conv_credit - trade.premium_paid
                    sign        = '+' if net >= 0 else ''
                    print(f"[BFLY ] #{trade_id} {trade.direction} "
                          f"converted → butterfly "
                          f"conv_credit=${conv_credit:.0f} net={sign}${net:.0f} "
                          f"reason={reason}")
                    self._log_trade(trade, f'BUTTERFLY_CONV_{reason}',
                                    conv_credit, trade.state)
                    outcome = RiskOutcome.WIN if net >= 0 else RiskOutcome.LOSS
                    self.risk_mgr.record_outcome(outcome)
                    # Promote to LiveButterfly
                    bf = LiveButterfly(
                        trade_id    = trade.trade_id,
                        direction   = trade.direction,
                        long_strike = trade.long_strike,
                        short_strike= trade.short_strike,
                        conv_strike = trade.conv_strike,
                        premium_paid= trade.premium_paid,
                        win_credit  = conv_credit,
                        net_cost    = trade.premium_paid - conv_credit,
                        entry_time  = trade.entry_time,
                        win_time    = datetime.now(self.tz),
                        spx_at_fill = trade.spx_at_fill,
                    )
                    existing_keys = {(b.direction, b.long_strike,
                                      b.short_strike, b.conv_strike)
                                     for b in self.butterflies}
                    if (bf.direction, bf.long_strike,
                            bf.short_strike, bf.conv_strike) not in existing_keys:
                        self.butterflies.append(bf)
                    self.trades = [t for t in self.trades
                                   if t.trade_id != trade_id]
                    self._save_state()
                    if trade.is_gap_trade:
                        self._gap_trade_active = False
                        print("[GAP  ] Gap-open trade butterfly-converted "
                              "— normal signals resuming")

            elif purpose == 'CLOSE':
                reason = parts[2] if len(parts) > 2 else 'CLOSE'
                if trade:
                    credit = avgFillPrice * 100
                    net    = credit - trade.premium_paid
                    print(f"[CLOSE/{reason}] #{trade_id} {trade.direction} "
                          f"recover=${credit:.0f} net=${net:.0f}")
                    self._log_trade(trade, reason, credit, trade.state)
                    outcome = RiskOutcome.WIN if net >= 0 else RiskOutcome.LOSS
                    self.risk_mgr.record_outcome(outcome)
                    self.trades = [t for t in self.trades if t.trade_id != trade_id]
                    self._save_state()
                    # Clear gap trade flag if this was a gap-open trade
                    if trade.is_gap_trade:
                        self._gap_trade_active = False
                        print(f"[GAP  ] Gap-open trade closed ({reason}) — normal signals resuming")

        except Exception as e:
            print(f"[ERROR] orderStatus handler: {e}")
            traceback.print_exc()
        finally:
            if orderId in self.pending_orders:
                del self.pending_orders[orderId]

    # =========================================================================
    # GAP-OPEN ENTRY  (9:30 bar only)
    # =========================================================================

    def _check_gap_open(self, bar: dict):
        """
        Called once on the 9:30 bar.
        If |prev_close - today_open| >= GAP_OPEN_THRESHOLD:
          - prev_close - today_open > 0  → opened lower  → trend_dir = DOWN
          - prev_close - today_open < 0  → opened higher → trend_dir = UP
        Queues an immediate entry if spread net bid/ask < $2.00 (checked in
        _on_entry_quote via is_gap_trade flag).
        """
        if not self.prev_day_bars:
            print("[GAP  ] No prev-day bars available — skipping gap check")
            return

        prev_close  = self.prev_day_bars[-1]['close']
        today_open  = bar['open'] if bar['open'] > 0 else bar['close']
        gap         = prev_close - today_open
        abs_gap     = abs(gap)

        print(f"[GAP  ] prev_close={prev_close:.2f} today_open={today_open:.2f} "
              f"gap={gap:+.2f} threshold={GAP_OPEN_THRESHOLD}")

        if abs_gap < GAP_OPEN_THRESHOLD:
            print(f"[GAP  ] Gap {abs_gap:.2f} pts < threshold {GAP_OPEN_THRESHOLD} "
                  f"— no gap-open trade")
            return

        direction = 'DOWN' if gap > 0 else 'UP'
        print(f"[GAP  ] Gap {abs_gap:.2f} pts >= threshold — direction={direction}")

        if not self._can_open(direction):
            print(f"[GAP  ] Cannot open {direction} — at trade limits or already open")
            return

        if not self.risk_mgr.is_trading_allowed():
            print("[GAP  ] Trading suspended — skipping gap-open entry")
            return

        self._gap_trade_active = True
        print(f"[GAP  ] Queuing {direction} gap-open entry "
              f"(bid/ask gate <$2.00 checked at quote)")
        self.pending_entries.append(PendingEntry(
            direction    = direction,
            signal_time  = bar['bar_start_time'],
            ctv_cv       = today_open,
            is_gap_trade = True,
        ))

    # =========================================================================
    # BAR PROCESSING
    # =========================================================================

    def _on_bar_complete(self, bar: dict):
        """
        Called for every completed 3-min bar.
        Replicates the backtester's run_day loop.
        """
        if not self.live_trading_active:
            return
        if self._session_done:
            return   # market closed — ignore late-arriving bars silently

        ts    = bar['bar_start_time']
        close = bar['close'] if bar['close'] > 0 else bar['open']
        bt    = ts.time()

        self.last_bar_close = close

        # Update direction filter
        state            = self.quality_filter.update(close)
        current_dir      = state.get('direction')
        viable           = state.get('viable', False)
        direction_change = state.get('direction_change', False)
        separation       = state.get('separation', 0.0) or 0.0
        ema3             = self.quality_filter.macd.ema_fast or 0.0
        ema15            = self.quality_filter.macd.ema_slow or 0.0

        print(f"\n{'='*60}")
        print(f"BAR | {ts.strftime('%H:%M')} | "
              f"O={bar['open']:.2f} H={bar['high']:.2f} "
              f"L={bar['low']:.2f} C={close:.2f}")
        ema5 = state.get('ema5') or 0.0
        ema_confirm = ((current_dir == 'UP'   and ema3 > ema5) or
                       (current_dir == 'DOWN' and ema3 < ema5))
        print(f"[SIG ] EMA3={ema3:.2f} EMA5={ema5:.2f} EMA15={ema15:.2f} "
              f"sep={separation:.2f} dir={current_dir or 'NONE'} "
              f"viable={'Y' if viable else 'N'} "
              f"change={'Y' if direction_change else 'N'} "
              f"conf={'Y' if ema_confirm else 'N'}")
        print(f"[POS ] Trades={len(self.trades)} "
              f"Pending={len(self.pending_entries)}")

        # 1. Try to fill pending entries (request market data for each)
        if bt >= cfg.TRADING_START:
            self._try_enter_pending(bar)

        # 1a. Gap-open check — fires on the 9:30 bar only
        if bt == dtime(9, 30):
            self._check_gap_open(bar)

        # 2. Process existing trades: PARK / UNPARK / park-range close
        self._process_trades(bar, current_dir)

        # 3. Cancel pending entries in wrong direction
        if current_dir is not None:
            opp = 'DOWN' if current_dir == 'UP' else 'UP'
            before = len(self.pending_entries)
            self.pending_entries = [p for p in self.pending_entries
                                    if p.direction != opp]
            if len(self.pending_entries) < before:
                print(f"[ENTRY] Cancelled {before - len(self.pending_entries)} "
                      f"pending {opp} entries (direction flip)")

        # 4. New entry signals — suppressed while gap trade is managing position
        if (bt >= cfg.TRADING_START and bt < cfg.LAST_ENTRY_TIME
                and current_dir is not None
                and not self._gap_trade_active):

            if direction_change:
                if self._can_open(current_dir) and ema_confirm:
                    print(f"[ENTRY] Direction change → {current_dir} "
                          f"sep={separation:.2f} — queuing entry")
                    self.pending_entries.append(PendingEntry(
                        direction=current_dir,
                        signal_time=ts,
                        ctv_cv=close,
                    ))
            elif viable:
                if self._can_open(current_dir) and ema_confirm:
                    print(f"[ENTRY] Viable {current_dir} — queuing re-entry")
                    self.pending_entries.append(PendingEntry(
                        direction=current_dir,
                        signal_time=ts,
                        ctv_cv=close,
                    ))

    def _try_enter_pending(self, bar: dict):
        """
        For each pending entry not yet requested, fire a market data request
        for the vertical spread.  tickPrice → _on_entry_quote → _place_entry.
        """
        still_pending = []
        for p in self.pending_entries:
            # Max retries exceeded
            if p.retries >= cfg.MAX_ENTRY_RETRIES:
                print(f"[ENTRY] {p.direction} entry cancelled after "
                      f"{p.retries} retries")
                continue

            # Already waiting for quote on this entry
            if p.mktdata_requested:
                still_pending.append(p)
                continue

            # Block if a trade already exists in this direction or max trades reached.
            # NOTE: do NOT call _can_open here — it checks pending_entries, which
            # includes the entry we are currently processing, causing it to block
            # itself every bar and never request market data.
            if len(self.trades) >= cfg.MAX_ACTIVE_TRADES:
                continue
            if any(t.direction == p.direction for t in self.trades):
                continue

            spx = bar['open'] if bar['open'] > 0 else bar['close']
            long_s, short_s, conv_s = self.order_manager.calc_strikes(spx, p.direction)
            right = 'C' if p.direction == 'UP' else 'P'

            # Strike conflict: new long must not overlap existing shorts,
            # new short must not overlap existing longs (covers butterflies too)
            if long_s in self._existing_shorts() or short_s in self._existing_longs():
                print(f"[SKIP ] {p.direction} {int(long_s)}/{int(short_s)} "
                      f"— strike conflict with open position (SEC rule)")
                continue

            contract = self.order_manager.create_vertical_contract(
                long_s, short_s, right)
            if contract is None:
                p.retries += 1
                still_pending.append(p)
                print(f"[ENTRY] {p.direction} strikes {int(long_s)}/{int(short_s)} "
                      f"— conIds not cached (retry {p.retries})")
                continue

            ticker_id = self._alloc_ticker()
            self._mktdata[ticker_id] = {
                'purpose':    'ENTRY',
                'pending':    p,
                'long_s':     long_s,
                'short_s':    short_s,
                'conv_s':     conv_s,
                'right':      right,
                'ctv_cv':     spx,
                'bid':        None,
                'ask':        None,
            }
            p.mktdata_requested = True
            self.order_manager.request_market_data(contract, ticker_id)
            still_pending.append(p)

        self.pending_entries = still_pending

    def _on_entry_quote(self, slot: dict, bid: float, ask: float, mid: float):
        """Called from tickPrice when bid+ask received for a pending entry."""
        p = slot['pending']

        # Validate spread width
        width = ask - bid
        if width > cfg.MAX_SPREAD_WIDTH:
            p.retries += 1
            p.mktdata_requested = False   # allow retry next bar
            print(f"[ENTRY] {p.direction} spread too wide ${width:.2f} "
                  f"(max ${cfg.MAX_SPREAD_WIDTH}) retry {p.retries}")
            return

        # Gap-open trade: gate on net ask < $2.00 instead of MAX_PREMIUM
        if p.is_gap_trade:
            if ask >= 2.0:
                print(f"[GAP  ] {p.direction} gap-open skipped — "
                      f"net ask ${ask:.2f} >= $2.00 (too expensive)")
                self._gap_trade_active = False
                return
            print(f"[GAP  ] {p.direction} gap-open ask=${ask:.2f} < $2.00 — proceeding")
            from ctv2_order_manager import round_to_tick
            entry_limit = round_to_tick(ask * cfg.ENTRY_SLIPPAGE)
            premium_est = entry_limit * 100
        else:
            # Validate premium cap — use ask × cfg.ENTRY_SLIPPAGE (what we'll actually pay)
            from ctv2_order_manager import round_to_tick
            entry_limit  = round_to_tick(ask * cfg.ENTRY_SLIPPAGE)
            premium_est  = entry_limit * 100
            if premium_est > cfg.MAX_PREMIUM:
                p.retries += 1
                p.mktdata_requested = False
                print(f"[ENTRY] {p.direction} too expensive ${premium_est:.0f} "
                      f"(max ${cfg.MAX_PREMIUM:.0f}) retry {p.retries}")
                return

        # Risk check
        if not self.risk_mgr.is_trading_allowed():
            print(f"[RISK] Trading suspended — skipping {p.direction} entry")
            return

        # Allocate trade_id and create LiveTrade placeholder
        self._trade_id_seq += 1
        trade = LiveTrade(
            trade_id         = self._trade_id_seq,
            direction        = p.direction,
            right            = slot['right'],
            ctv_cv           = slot['ctv_cv'],
            entry_time       = p.signal_time,
            state            = 'PENDING_FILL',
            long_strike      = slot['long_s'],
            short_strike     = slot['short_s'],
            conv_strike      = slot['conv_s'],
            premium_paid     = premium_est,   # estimate; updated on fill
            win_target       = 0.0,           # set on fill from _live_spx
            min_profit_price = 0.0,           # set on fill
            entry_order_id   = self.next_order_id,
            is_gap_trade     = p.is_gap_trade,
        )
        self.trades.append(trade)

        # Place entry order using ask-based pricing
        order_id  = self.next_order_id
        self.next_order_id += 1
        right     = slot['right']
        contract  = self.order_manager.create_vertical_contract(
            trade.long_strike, trade.short_strike, right)
        if contract is None:
            print(f"[ERROR] Cannot create vertical contract for entry — aborting")
            self.trades = [t for t in self.trades if t.trade_id != trade.trade_id]
            return

        order = self.order_manager.create_entry_order(order_id, ask)
        self.pending_orders[order_id] = f"ENTRY:{trade.trade_id}"
        self.placeOrder(order_id, contract, order)

        print(f"[ENTRY] #{trade.trade_id} {trade.direction} "
              f"{int(trade.long_strike)}/{int(trade.short_strike)}/{int(trade.conv_strike)} "
              f"limit=${entry_limit:.2f} (ask=${ask:.2f})")

        # Remove from pending entries
        self.pending_entries = [pe for pe in self.pending_entries
                                if pe is not p]

    def _on_entry_fill(self, order_id: int, trade: Optional[LiveTrade],
                       avg_fill_price: float):
        """Called from orderStatus when entry BAG fills."""
        if trade is None:
            return

        trade.premium_paid     = avg_fill_price * 100
        trade.min_profit_price = trade.premium_paid * cfg.MIN_CONV_CREDIT_PCT
        trade.spx_at_fill      = self._live_spx   # most recent SPX tick
        trade.state            = 'ACTIVE'

        # win_target based on SPX at fill time (not bar close)
        if trade.direction == 'UP':
            trade.win_target = trade.spx_at_fill + cfg.WIN_MOVE
        else:
            trade.win_target = trade.spx_at_fill - cfg.WIN_MOVE

        self._save_state()
        self._log_entry(trade)

        print(f"[FILL] #{trade.trade_id} {trade.direction} "
              f"filled @ ${avg_fill_price:.2f} "
              f"(${trade.premium_paid:.0f} total) "
              f"spx_at_fill={trade.spx_at_fill:.2f} "
              f"win_target={trade.win_target:.2f} "
              f"min_profit=${trade.min_profit_price:.0f}")

    # =========================================================================
    # INTRABAR WIN DETECTION
    # =========================================================================

    def _check_win_targets(self):
        """
        Called on every historicalDataUpdate tick (~1 second).
        Checks all ACTIVE trades — has _live_spx crossed win_target?
        If yes: request live conversion spread quote, mark PENDING_WIN_QUOTE
        so we don't double-trigger.
        """
        if self._live_spx <= 0:
            return
        for trade in self.trades:
            if trade.state != 'ACTIVE':
                continue
            triggered = (
                (trade.direction == 'UP'   and self._live_spx >= trade.win_target) or
                (trade.direction == 'DOWN' and self._live_spx <= trade.win_target)
            )
            if not triggered:
                continue

            # Mark immediately — prevents double-trigger on next tick
            trade.state = 'PENDING_WIN_QUOTE'
            print(f"[WIN ] #{trade.trade_id} {trade.direction} "
                  f"win_target={trade.win_target:.2f} reached "
                  f"(SPX={self._live_spx:.2f}) — requesting conversion quote")

            contract = self.order_manager.create_conversion_contract(
                trade.short_strike, trade.conv_strike, trade.right)
            if contract is None:
                print(f"[ERROR] #{trade.trade_id} conversion contract unavailable "
                      f"— reverting to ACTIVE for retry")
                trade.state = 'ACTIVE'
                continue

            ticker_id = self._alloc_ticker()
            self._mktdata[ticker_id] = {
                'purpose':  'WIN_QUOTE',
                'trade':    trade,
                'bid':      None,
                'ask':      None,
            }
            self.order_manager.request_market_data(contract, ticker_id)

    def _on_win_quote(self, slot: dict, bid: float):
        """
        Called from tickPrice when conversion spread bid received.
        Places win sell at max(bid × 0.95, min_profit_price/100), tick-rounded.
        """
        trade = slot['trade']
        if trade is None:
            return

        win_order_id = self.next_order_id
        self.next_order_id += 1

        contract = self.order_manager.create_conversion_contract(
            trade.short_strike, trade.conv_strike, trade.right)
        if contract is None:
            print(f"[ERROR] #{trade.trade_id} conversion contract unavailable "
                  f"for win sell — reverting to ACTIVE")
            trade.state = 'ACTIVE'
            return

        order = self.order_manager.create_win_sell_order(
            win_order_id, bid, trade.min_profit_price)
        trade.win_order_id = win_order_id
        self.pending_orders[win_order_id] = f"WIN:{trade.trade_id}"
        self.placeOrder(win_order_id, contract, order)
        print(f"[WIN ] #{trade.trade_id} win sell placed order#{win_order_id}")

    # =========================================================================
    # TRADE MANAGEMENT: PARK / UNPARK / PARK-RANGE
    # =========================================================================

    def _process_trades(self, bar: dict, current_dir: Optional[str]):
        """
        For each open trade:
          - ACTIVE + direction flipped  → PARK
          - PARKED + direction restored → UNPARK
          - PARKED + |close - park_spx| > PARK_MAX_MOVE → force close
        """
        close = bar['close'] if bar['close'] > 0 else bar['open']
        now   = datetime.now(self.tz).time()

        for trade in list(self.trades):
            if trade.state in ('CLOSING', 'PENDING_BUTTERFLY'):
                continue

            if trade.state == 'ACTIVE':
                if current_dir is not None and current_dir != trade.direction:
                    self._park_trade(trade, close, now)

            elif trade.state == 'PARKED':
                if current_dir == trade.direction:
                    self._unpark_trade(trade)
                elif trade.park_spx > 0:
                    move = abs(close - trade.park_spx)
                    if move > PARK_MAX_MOVE:
                        print(f"[PARK-RANGE] #{trade.trade_id} {trade.direction} "
                              f"SPX moved {move:.1f} pts from park "
                              f"({trade.park_spx:.2f} → {close:.2f}) — converting to butterfly")
                        self._initiate_butterfly_conversion(trade, 'PARK_RANGE')

    def _park_trade(self, trade: LiveTrade, close: float, now):
        """Park an active trade on direction reversal."""
        trade.state    = 'PARKED'
        trade.park_spx = close
        print(f"[PARK ] #{trade.trade_id} {trade.direction} parked @ SPX {close:.2f}")

        # After PM_BOUNDARY: convert to butterfly instead of placing stop order
        if now >= cfg.PM_BOUNDARY:
            self._initiate_butterfly_conversion(trade, 'PM_CONVERT')

    def _unpark_trade(self, trade: LiveTrade):
        """Direction returned to match trade — unpark it."""
        trade.state = 'ACTIVE'
        print(f"[UNPK ] #{trade.trade_id} {trade.direction} unparked")
        # Cancel stop order if one was placed at parking
        if trade.stop_order_id:
            self.cancelOrder(trade.stop_order_id, "")
            trade.stop_order_id = 0

    def _initiate_close(self, trade: LiveTrade, reason: str):
        """
        Cancel win + stop orders, request market data for vertical,
        then _on_close_quote will place the plain LMT SELL.
        """
        if trade.state == 'CLOSING':
            return
        trade.state = 'CLOSING'

        # Cancel outstanding orders first
        if trade.win_order_id:
            self.cancelOrder(trade.win_order_id, "")
        if trade.stop_order_id:
            self.cancelOrder(trade.stop_order_id, "")

        right    = trade.right
        contract = self.order_manager.create_vertical_contract(
            trade.long_strike, trade.short_strike, right)
        if contract is None:
            print(f"[ERROR] #{trade.trade_id} close failed — vertical conIds missing")
            trade.state = 'PARKED'   # restore so intrinsic can retry
            return

        ticker_id = self._alloc_ticker()
        self._mktdata[ticker_id] = {
            'purpose':  'CLOSE',
            'trade_id': trade.trade_id,
            'reason':   reason,
            'bid':      None,
            'ask':      None,
        }
        self.order_manager.request_market_data(contract, ticker_id)
        print(f"[CLOSE] #{trade.trade_id} {trade.direction} "
              f"reason={reason} — requesting bid/ask")

    def _on_close_quote(self, slot: dict, bid: float):
        """Place plain LMT SELL at bid × cfg.SELL_SLIPPAGE when quote received for close."""
        trade_id = slot['trade_id']
        reason   = slot.get('reason', 'CLOSE')
        trade    = self._find_trade(trade_id)
        if trade is None:
            return

        right    = trade.right
        contract = self.order_manager.create_vertical_contract(
            trade.long_strike, trade.short_strike, right)
        if contract is None:
            print(f"[ERROR] #{trade_id} close order failed — no contract")
            return

        close_order_id = self.next_order_id
        self.next_order_id += 1
        order = self.order_manager.create_close_order(close_order_id, bid)
        self.pending_orders[close_order_id] = f"CLOSE:{trade_id}:{reason}"
        self.placeOrder(close_order_id, contract, order)
        print(f"[CLOSE] #{trade_id} {trade.direction} "
              f"sell @ ${bid * cfg.SELL_SLIPPAGE:.2f} (bid=${bid:.2f}) reason={reason}")

    # =========================================================================
    # REVERSAL CLOSE
    # =========================================================================

    def _check_reversal_closes(self, winning_trade: LiveTrade):
        """
        Called when a WIN_SELL fills.
        Close PARKED trades in opposite direction if distance gate exceeded.
        """
        opp = 'DOWN' if winning_trade.direction == 'UP' else 'UP'
        for trade in self.trades:
            if (trade.state == 'PARKED' and trade.direction == opp):
                dist = abs(self._live_spx - trade.ctv_cv)
                if dist > cfg.REVERSAL_CLOSE_MIN_MOVE:
                    print(f"[RVCLS] #{trade.trade_id} {trade.direction} "
                          f"opp-win={winning_trade.direction} "
                          f"dist={dist:.1f} pts — closing")
                    self._initiate_close(trade, 'REVERSAL')
                else:
                    print(f"[RVCLS] #{trade.trade_id} {trade.direction} "
                          f"skipped — dist={dist:.1f} < "
                          f"{cfg.REVERSAL_CLOSE_MIN_MOVE} pts gate")

    # =========================================================================
    # CHAINED RE-ENTRY AFTER WIN
    # =========================================================================

    def _try_chain_entry(self, direction: str, conv_strike: float, right: str):
        """
        After a WIN fill, attempt a chained re-entry.
        The conv_strike of the completed trade becomes the new long_strike —
        we already own it from the conversion buy leg.

        Fires async from the WIN orderStatus callback.
        Validates entry window, direction still viable, risk, trade limits.
        Then requests market data for the new vertical spread.
        """
        now = datetime.now(self.tz).time()

        # Entry window check
        if now < cfg.TRADING_START or now > cfg.LAST_ENTRY_TIME:
            print(f"[CHAIN] {direction} — outside entry window, no chain")
            return

        # Direction must still be viable
        if not self.quality_filter.is_viable(direction):
            print(f"[CHAIN] {direction} — direction no longer viable, no chain")
            return

        # Risk check
        if not self.risk_mgr.is_trading_allowed():
            print(f"[CHAIN] {direction} — trading suspended, no chain")
            return

        # Trade limits
        if len(self.trades) >= cfg.MAX_ACTIVE_TRADES:
            print(f"[CHAIN] {direction} — max trades reached, no chain")
            return
        if any(t.direction == direction for t in self.trades):
            print(f"[CHAIN] {direction} — trade already open in same direction")
            return

        # Calculate chained strikes — conv_strike becomes new long
        long_s, short_s, conv_s = self.order_manager.calc_chained_strikes(
            conv_strike, direction)

        # Strike conflict: covers open trades and existing butterflies
        if long_s in self._existing_shorts() or short_s in self._existing_longs():
            print(f"[CHAIN] {direction} {int(long_s)}/{int(short_s)} "
                  f"— strike conflict with open position, no chain")
            return

        # Verify contracts are cached
        contract = self.order_manager.create_vertical_contract(long_s, short_s, right)
        if contract is None:
            print(f"[CHAIN] {direction} {int(long_s)}/{int(short_s)} "
                  f"— conIds not cached, no chain")
            return

        ticker_id = self._alloc_ticker()
        self._mktdata[ticker_id] = {
            'purpose':  'ENTRY',
            'pending':  PendingEntry(
                direction         = direction,
                signal_time       = datetime.now(self.tz),
                ctv_cv            = self._live_spx,
                mktdata_requested = True,
            ),
            'long_s':   long_s,
            'short_s':  short_s,
            'conv_s':   conv_s,
            'right':    right,
            'ctv_cv':   self._live_spx,
            'bid':      None,
            'ask':      None,
        }
        self.order_manager.request_market_data(contract, ticker_id)
        print(f"[CHAIN] {direction} {int(long_s)}/{int(short_s)}/{int(conv_s)} "
              f"— chained entry queued (long from conv_strike={int(conv_strike)})")

    # =========================================================================
    # BUTTERFLY CONVERSION  (park range / PM boundary / intrinsic)
    # =========================================================================

    def _initiate_butterfly_conversion(self, trade: LiveTrade, reason: str):
        """
        Convert a distressed LiveTrade into a LiveButterfly by selling the
        conversion spread (short_strike → conv_strike) for whatever bid we can get.
        Replaces both the PM stop-loss order and the park-range force-close.
        Sets state = PENDING_BUTTERFLY so _process_trades ignores it.
        """
        if trade.state == 'PENDING_BUTTERFLY':
            return

        trade.state = 'PENDING_BUTTERFLY'

        # Cancel any outstanding win or stop orders
        if trade.win_order_id:
            self.cancelOrder(trade.win_order_id, "")
        if trade.stop_order_id:
            self.cancelOrder(trade.stop_order_id, "")

        contract = self.order_manager.create_conversion_contract(
            trade.short_strike, trade.conv_strike, trade.right)
        if contract is None:
            print(f"[BFLY ] #{trade.trade_id} conversion contract unavailable "
                  f"— falling back to outright close")
            trade.state = 'PARKED'
            self._initiate_close(trade, reason)
            return

        ticker_id = self._alloc_ticker()
        self._mktdata[ticker_id] = {
            'purpose':  'BUTTERFLY_CONV',
            'trade':    trade,
            'reason':   reason,
            'bid':      None,
            'ask':      None,
        }
        self.order_manager.request_market_data(contract, ticker_id)
        print(f"[BFLY ] #{trade.trade_id} {trade.direction} "
              f"reason={reason} — requesting conversion spread quote")

    def _on_butterfly_conv_quote(self, slot: dict, bid: float):
        """
        Place LMT SELL on the conversion spread at bid × SELL_SLIPPAGE.
        No profit floor — take whatever we can get.
        On fill (orderStatus BFLY_CONV): promote to LiveButterfly, free slot.
        """
        trade  = slot['trade']
        reason = slot.get('reason', 'BFLY_CONV')
        if trade is None:
            return

        if bid <= 0:
            print(f"[BFLY ] #{trade.trade_id} zero bid on conversion spread "
                  f"— falling back to outright close")
            trade.state = 'PARKED'
            self._initiate_close(trade, reason)
            return

        contract = self.order_manager.create_conversion_contract(
            trade.short_strike, trade.conv_strike, trade.right)
        if contract is None:
            print(f"[BFLY ] #{trade.trade_id} conversion contract gone "
                  f"— falling back to outright close")
            trade.state = 'PARKED'
            self._initiate_close(trade, reason)
            return

        bfly_order_id = self.next_order_id
        self.next_order_id += 1

        # Use same sell slippage as win sells — bid × SELL_SLIPPAGE, tick-rounded
        from ctv2_order_manager import round_to_tick
        limit = round_to_tick(bid * cfg.SELL_SLIPPAGE)
        order = self.order_manager.create_win_sell_order(
            bfly_order_id, bid, 0.0)   # 0.0 floor = take whatever we get

        self.pending_orders[bfly_order_id] = f"BFLY_CONV:{trade.trade_id}:{reason}"
        self.placeOrder(bfly_order_id, contract, order)
        print(f"[BFLY ] #{trade.trade_id} {trade.direction} "
              f"conversion sell @ ${limit:.2f} (bid=${bid:.2f}) reason={reason}")

    # =========================================================================
    # LATE-DAY INTRINSIC EXIT
    # =========================================================================

    def _check_late_day_exits(self):
        """
        Called every second from main loop.
        At INTRINSIC_EXIT_TIME: close all open trades at current bid,
        and cancel any orphaned market data subscriptions (e.g. pending
        entry/win/close quotes that never received both bid and ask).
        """
        if self._intrinsic_done:
            return
        now = datetime.now(self.tz).time()
        if now < cfg.INTRINSIC_EXIT_TIME:
            return

        # Cancel all open market data slots — catches any subscriptions that
        # were waiting for a bid or ask that never arrived (e.g. ASK-only ticks
        # on near-worthless spreads late in the day)
        orphaned = list(self._mktdata.keys())
        if orphaned:
            print(f"[INTRINSIC] Cancelling {len(orphaned)} orphaned market data "
                  f"subscription(s): {orphaned}")
            for ticker_id in orphaned:
                try:
                    self.order_manager.cancel_market_data(ticker_id)
                except Exception:
                    pass
            self._mktdata.clear()
            self.pending_entries.clear()

        open_trades = [t for t in self.trades if t.state != 'CLOSING'
                       and t.state != 'PENDING_BUTTERFLY']
        if not open_trades:
            self._intrinsic_done = True
            return

        print(f"\n[INTRINSIC] {cfg.INTRINSIC_EXIT_TIME} — converting "
              f"{len(open_trades)} open trade(s) to butterflies")
        for trade in open_trades:
            self._initiate_butterfly_conversion(trade, 'INTRINSIC')
        self._intrinsic_done = True
        # Print summary now — fills will arrive async and update the CSV,
        # but the session totals so far are useful immediately.
        self._print_eod_summary()

    # =========================================================================
    # END-OF-DAY SUMMARY & MARKET CLOSE
    # =========================================================================

    def _print_eod_summary(self):
        """Print session summary once intrinsic exit is complete."""
        # Log butterfly records — these never go through orderStatus
        for bf in self.butterflies:
            self._log_butterfly(bf)

        total = self._session_wins + self._session_losses
        sign  = '+' if self._session_pnl >= 0 else ''
        risk  = self.risk_mgr.get_status_line()

        print(f"\n{'='*60}")
        print(f" SESSION SUMMARY — {datetime.now(self.tz).strftime('%Y-%m-%d')}")
        print(f"{'='*60}")
        print(f"  Closed trades  : {total}  "
              f"({self._session_wins}W / {self._session_losses}L)")
        print(f"  Open butterflies: {len(self.butterflies)}")
        print(f"  Net P&L        : {sign}${self._session_pnl:.0f}")
        print(f"  Risk status    : {risk}")
        print(f"  Trade log      : {self._log_path}")
        print(f"{'='*60}\n")

    def _check_market_close(self):
        """
        Called every second from main loop.
        At 16:00 ET: print final session summary and mark session done.
        Bars may still trickle in but no signals are evaluated after this point.
        """
        if self._session_done:
            return
        now = datetime.now(self.tz).time()
        if now < dtime(16, 0):
            return

        self._session_done = True
        self._print_eod_summary()
        print("[SESSION] Market closed — CTV2 session complete. "
              "Press Ctrl+C to exit.\n")

    # =========================================================================
    # LIVE BAR WATCHDOG
    # =========================================================================

    def _check_watchdog(self):
        """
        Called every second from main loop.
        Detects when the live bar subscription has gone silent (IB farm blip)
        and automatically resubscribes.

        Error 10182 (Failed to request live updates) kills the keepUpToDate
        subscription — historicalDataUpdate stops firing and the runner stalls.
        This watchdog detects that and resubscribes transparently.
        """
        if not self.live_trading_active:
            return

        # Only watch during market hours
        now    = datetime.now(self.tz)
        now_t  = now.time()
        market_open  = dtime(9, 30)
        market_close = dtime(16, 0)
        if not (market_open <= now_t <= market_close):
            return

        # Not stale yet if we've never received a bar (startup grace period)
        if self._last_bar_update_time is None:
            return

        # Already waiting for a resubscription to complete
        if self._resubscribe_in_flight:
            return

        # Check staleness
        elapsed_secs = (now - self._last_bar_update_time).total_seconds()
        stale_secs   = self.WATCHDOG_STALE_MINS * 60

        if elapsed_secs < stale_secs:
            return

        # ── Subscription is stale ────────────────────────────────────────
        self._resubscribe_count += 1

        if self._resubscribe_count > self.WATCHDOG_MAX_RETRIES:
            msg = (f"[WATCHDOG] CRITICAL: Live bars silent {elapsed_secs/60:.1f} min. "
                   f"Max retries ({self.WATCHDOG_MAX_RETRIES}) exhausted. "
                   f"Manual restart required.")
            print(msg)
            if self.pushover:
                try:
                    self.pushover.send_critical(msg)
                except Exception:
                    pass
            return

        msg = (f"[WATCHDOG] Live bars silent {elapsed_secs/60:.1f} min "
               f"(attempt {self._resubscribe_count}/{self.WATCHDOG_MAX_RETRIES}) "
               f"— resubscribing...")
        print(msg)
        if self.pushover:
            try:
                self.pushover.send_alert(msg)
            except Exception:
                pass

        self._resubscribe_in_flight = True

        try:
            # Cancel the dead subscription
            # cancelHistoricalData is the correct EClient method for keepUpToDate subs
            if hasattr(self, 'cancelHistoricalData'):
                self.cancelHistoricalData(self.historical_req_id)
            time.sleep(2)

            # Clear live bar buffer so we don't emit a stale bar
            self._live_bar_buffer      = None
            self._live_bar_time        = None
            self._last_bar_update_time = None

            # Resubscribe
            if self._spx_contract is not None:
                self._request_live_bars(self._spx_contract)
                print(f"[WATCHDOG] Resubscribed to live bars.")
            else:
                print("[WATCHDOG] ERROR: SPX contract not stored — cannot resubscribe.")
        except Exception as e:
            print(f"[WATCHDOG] Resubscription error: {e}")
        finally:
            self._resubscribe_in_flight = False

    def _find_trade(self, trade_id: int) -> Optional[LiveTrade]:
        for t in self.trades:
            if t.trade_id == trade_id:
                return t
        return None

    def _can_open(self, direction: str) -> bool:
        """True if we can open a new trade in the given direction."""
        if len(self.trades) >= cfg.MAX_ACTIVE_TRADES:
            return False
        for t in self.trades:
            if t.direction == direction:
                return False
        for p in self.pending_entries:
            if p.direction == direction:
                return False
        return True

    def _alloc_ticker(self) -> int:
        self._ticker_counter += 1
        return 4000 + self._ticker_counter


# =============================================================================
# Entry point
# =============================================================================

def main():
    import argparse
    parser = argparse.ArgumentParser(description='CTV2 Live Runner')
    parser.add_argument('--live', action='store_true',
                        help='Use live account (default: paper)')
    args = parser.parse_args()

    mode = 'live' if args.live else 'paper'
    app  = TradingApp(mode=mode)
    app.run_live()


if __name__ == '__main__':
    main()
