import { useState, useCallback } from "react";

const SECTIONS = [
  {
    id: "signal", label: "Signal", accent: "#F0C040",
    params: [
      { key: "MACD_FAST",               label: "EMA Fast",            type: "int",   default: 3,    unit: "bars", desc: "Fast EMA period (EMA3). Controls entry sensitivity." },
      { key: "MACD_SLOW",               label: "EMA Slow",            type: "int",   default: 15,   unit: "bars", desc: "Slow EMA period (EMA15). Sets the trend baseline." },
      { key: "MACD_SIGNAL",             label: "MACD Signal",         type: "int",   default: 9,    unit: "bars", desc: "Signal line period. Informational — not used for entry gating." },
      { key: "EMA_DIRECTION_THRESHOLD", label: "Direction Threshold", type: "float", default: 1.5,  unit: "pts",  desc: "Minimum |EMA3−EMA15| separation to confirm a viable direction. Below this = noise, no entry." },
    ]
  },
  {
    id: "entry", label: "Entry", accent: "#40C8F0",
    params: [
      { key: "SPREAD_WIDTH",      label: "Spread Width",      type: "float", default: 5.0,   unit: "pts",  desc: "Width of the debit vertical spread in strike points." },
      { key: "MAX_PREMIUM",       label: "Max Premium",       type: "float", default: 350.0, unit: "$",    desc: "Skip entry if spread ask×1.05×100 exceeds this dollar amount." },
      { key: "MAX_SPREAD_WIDTH",  label: "Max Bid/Ask Width", type: "float", default: 1.0,   unit: "$/sh", desc: "Skip entry if bid/ask spread on the quote is wider than this per share." },
      { key: "MAX_ACTIVE_TRADES", label: "Max Active Trades", type: "int",   default: 4,     unit: "",     desc: "Maximum simultaneous LiveTrade positions (active + parked). Butterflies excluded." },
      { key: "MAX_ENTRY_RETRIES", label: "Entry Retries",     type: "int",   default: 3,     unit: "",     desc: "Retry count if contract IDs are not yet cached when entry signal fires." },
      { key: "GAP_OPEN_THRESHOLD", label: "Gap Threshold",    type: "float", default: 20.0,  unit: "pts",  desc: "If SPX opens more than this many points from prior close, enter immediately in the gap direction if spread net bid/ask < $2.00." },
    ]
  },
  {
    id: "exit", label: "Exit", accent: "#60E080",
    params: [
      { key: "WIN_MOVE",                label: "Win Move",          type: "float", default: 5.0,  unit: "pts", desc: "SPX points from fill price (spx_at_fill) that triggers the conversion sell." },
      { key: "MIN_CONV_CREDIT_PCT",     label: "Min Conv Credit",   type: "float", default: 1.05, unit: "×",   desc: "Win sell floor = premium_paid × this. 1.05 = must net at least 5% profit on the conversion." },
      { key: "SELL_SLIPPAGE",           label: "Sell Slippage",     type: "float", default: 0.95, unit: "×",   desc: "All exit limits = bid × this. 0.95 accepts up to 5% below current bid to guarantee fill." },
      { key: "REVERSAL_CLOSE_MIN_MOVE", label: "Reversal Close Min",type: "float", default: 10.0, unit: "pts", desc: "A WIN in one direction only closes opposite PARKED trades if SPX has moved this far from their entry." },
    ]
  },
  {
    id: "park", label: "Park & Risk", accent: "#F07040",
    params: [
      { key: "PARK_MAX_MOVE", label: "Park Max Move", type: "float", default: 15.0, unit: "pts", desc: "Force-close a PARKED trade if SPX moves more than this many points from the park price in any direction." },
    ]
  },
  {
    id: "timing", label: "Timing", accent: "#C080F0",
    params: [
      { key: "TRADING_START",       label: "Trading Start",  type: "time", default: "10:00", unit: "ET", desc: "No entries before this time. First bar evaluated is the 10:00 close at 10:03 ET." },
      { key: "LAST_ENTRY_TIME",     label: "Last Entry",     type: "time", default: "14:00", unit: "ET", desc: "No new entries (including chain entries) after this time." },
      { key: "PM_BOUNDARY",         label: "PM Boundary",    type: "time", default: "13:00", unit: "ET", desc: "After this time, newly PARKED trades receive a stop order at 50% of premium paid." },
      { key: "INTRINSIC_EXIT_TIME", label: "Intrinsic Exit", type: "time", default: "14:30", unit: "ET", desc: "All open LiveTrades are converted to butterflies at this time. Butterflies are left to expire naturally." },
    ]
  },
  {
    id: "pricing", label: "Pricing", accent: "#F040A0",
    params: [
      { key: "ENTRY_SLIPPAGE",  label: "Entry Slippage",  type: "float", default: 1.05, unit: "×",   desc: "Entry limit = ask × this. 1.05 guarantees fill at cost of 5% above ask." },
      { key: "PREFETCH_RADIUS", label: "Prefetch Radius", type: "float", default: 75.0, unit: "pts", desc: "Pre-cache contract IDs for all strikes within this many points of current SPX price at open." },
    ]
  },
];

const ALL_PARAMS = SECTIONS.flatMap(s => s.params);

function timeToCode(t) {
  const [h, m] = t.split(":");
  return `time(${parseInt(h)}, ${parseInt(m)})`;
}

function buildConfig(values) {
  const date = new Date().toISOString().split("T")[0];
  return [
    `"""`,
    `config_ctv2.py — CTV2 Live Runner Configuration`,
    `Generated ${date} by CTV2 Config Editor`,
    `"""`,
    ``,
    `VERSION = "CFG-2.0"`,
    `from datetime import time`,
    ``,
    `# ── EMA / Direction Signal ─────────────────────────────────────`,
    `MACD_FAST               = ${values.MACD_FAST}`,
    `MACD_SLOW               = ${values.MACD_SLOW}`,
    `MACD_SIGNAL             = ${values.MACD_SIGNAL}`,
    `EMA_DIRECTION_THRESHOLD = ${values.EMA_DIRECTION_THRESHOLD}`,
    ``,
    `# ── Entry ──────────────────────────────────────────────────────`,
    `SPREAD_WIDTH      = ${values.SPREAD_WIDTH}`,
    `MAX_PREMIUM       = ${values.MAX_PREMIUM}`,
    `MAX_SPREAD_WIDTH  = ${values.MAX_SPREAD_WIDTH}`,
    `MAX_ACTIVE_TRADES = ${values.MAX_ACTIVE_TRADES}`,
    `MAX_ENTRY_RETRIES = ${values.MAX_ENTRY_RETRIES}`,
    `GAP_OPEN_THRESHOLD = ${values.GAP_OPEN_THRESHOLD}`,
    ``,
    `# ── Exit ───────────────────────────────────────────────────────`,
    `WIN_MOVE                = ${values.WIN_MOVE}`,
    `MIN_CONV_CREDIT_PCT     = ${values.MIN_CONV_CREDIT_PCT}`,
    `SELL_SLIPPAGE           = ${values.SELL_SLIPPAGE}`,
    `REVERSAL_CLOSE_MIN_MOVE = ${values.REVERSAL_CLOSE_MIN_MOVE}`,
    ``,
    `# ── Park & Risk ────────────────────────────────────────────────`,
    `PARK_MAX_MOVE = ${values.PARK_MAX_MOVE}`,
    ``,
    `# ── Trading Window ─────────────────────────────────────────────`,
    `TRADING_START       = ${timeToCode(values.TRADING_START)}`,
    `TRADING_END         = time(16, 0)`,
    `LAST_ENTRY_TIME     = ${timeToCode(values.LAST_ENTRY_TIME)}`,
    `PM_BOUNDARY         = ${timeToCode(values.PM_BOUNDARY)}`,
    `INTRINSIC_EXIT_TIME = ${timeToCode(values.INTRINSIC_EXIT_TIME)}`,
    ``,
    `# ── Order Pricing ──────────────────────────────────────────────`,
    `ENTRY_SLIPPAGE  = ${values.ENTRY_SLIPPAGE}`,
    `PREFETCH_RADIUS = ${values.PREFETCH_RADIUS}`,
    ``,
    `# ── Data (backtester only) ─────────────────────────────────────`,
    `SPX_DATA_DIR = "SPX_3min_bars"`,
  ].join("\n");
}

export default function ConfigEditor() {
  const initValues = () => Object.fromEntries(ALL_PARAMS.map(p => [p.key, p.default]));
  const [values, setValues]     = useState(initValues);
  const [active, setActive]     = useState("signal");
  const [modified, setModified] = useState({});
  const [hovered, setHovered]   = useState(null);
  const [copied, setCopied]     = useState(false);
  const [pulse, setPulse]       = useState(null);

  const section  = SECTIONS.find(s => s.id === active);
  const modCount = Object.keys(modified).length;

  const set = useCallback((key, raw, type) => {
    let val = raw;
    if (type === "int")   val = raw === "" ? 0 : parseInt(raw)   || 0;
    if (type === "float") val = raw === "" ? 0 : parseFloat(raw) || 0;
    setValues(v => ({ ...v, [key]: val }));
    setModified(m => ({ ...m, [key]: true }));
    setPulse(key);
    setTimeout(() => setPulse(null), 280);
  }, []);

  const reset    = useCallback((key, def) => {
    setValues(v => ({ ...v, [key]: def }));
    setModified(m => { const n = {...m}; delete n[key]; return n; });
  }, []);

  const resetAll = () => { setValues(initValues()); setModified({}); };

  const copy = () => {
    navigator.clipboard.writeText(buildConfig(values)).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    });
  };

  const configText = buildConfig(values);

  return (
    <div style={{
      height: "100vh", display: "flex", flexDirection: "column",
      background: "#080B0F", color: "#CBD5E1",
      fontFamily: "'IBM Plex Mono','Fira Code','Cascadia Code','Courier New',monospace",
      overflow: "hidden",
    }}>

      {/* Top bar */}
      <div style={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "0 24px", height: 50, flexShrink: 0,
        background: "#0B0F16", borderBottom: "1px solid #161E2C",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <span style={{ fontSize: 15, fontWeight: 700, color: "#F0C040", letterSpacing: "0.03em" }}>CTV2</span>
          <span style={{ fontSize: 9, color: "#1E2E44", letterSpacing: "0.2em" }}>CONFIG EDITOR</span>
          <div style={{ width: 1, height: 16, background: "#161E2C" }} />
          <span style={{ fontSize: 9, color: "#1A2A3C" }}>CFG-2.0  ·  {ALL_PARAMS.length} params  ·  12 legacy removed</span>
          {modCount > 0 && (
            <span style={{
              background: "#F0C04018", border: "1px solid #F0C04040",
              color: "#F0C040", fontSize: 8, fontWeight: 700,
              padding: "2px 7px", borderRadius: 3, letterSpacing: "0.12em",
            }}>{modCount} MODIFIED</span>
          )}
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={resetAll} style={{
            background: "transparent", border: "1px solid #161E2C",
            color: "#2A3C50", padding: "5px 14px", borderRadius: 4,
            fontSize: 9, cursor: "pointer", fontFamily: "inherit", letterSpacing: "0.1em",
          }}>RESET ALL</button>
          <button onClick={copy} style={{
            background: copied ? "#162A1E" : "#0C1E2C",
            border: `1px solid ${copied ? "#40C07060" : "#1A4060"}`,
            color: copied ? "#40C070" : "#40C8F0",
            padding: "5px 18px", borderRadius: 4,
            fontSize: 9, fontWeight: 700, cursor: "pointer",
            fontFamily: "inherit", letterSpacing: "0.1em", transition: "all 0.15s",
          }}>{copied ? "✓  COPIED" : "COPY  config_ctv2.py"}</button>
        </div>
      </div>

      <div style={{ display: "flex", flex: 1, overflow: "hidden" }}>

        {/* Left nav */}
        <div style={{
          width: 150, flexShrink: 0,
          background: "#090C12", borderRight: "1px solid #111926",
          paddingTop: 10,
        }}>
          {SECTIONS.map(s => {
            const n = s.params.filter(p => modified[p.key]).length;
            const isA = s.id === active;
            return (
              <button key={s.id} onClick={() => setActive(s.id)} style={{
                width: "100%", padding: "10px 16px",
                background: isA ? `${s.accent}0C` : "transparent",
                border: "none", borderLeft: `2px solid ${isA ? s.accent : "transparent"}`,
                color: isA ? s.accent : "#223040",
                fontSize: 9, fontWeight: isA ? 700 : 400,
                cursor: "pointer", fontFamily: "inherit",
                letterSpacing: "0.14em", textAlign: "left",
                display: "flex", justifyContent: "space-between", alignItems: "center",
                transition: "all 0.1s",
              }}>
                {s.label.toUpperCase()}
                {n > 0 && (
                  <span style={{
                    background: s.accent, color: "#080B0F",
                    fontSize: 7, fontWeight: 800,
                    padding: "1px 5px", borderRadius: 2,
                  }}>{n}</span>
                )}
              </button>
            );
          })}
        </div>

        {/* Params */}
        <div style={{ flex: 1, overflowY: "auto", padding: "18px 24px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 18 }}>
            <div style={{ width: 3, height: 20, background: section.accent, borderRadius: 2 }} />
            <span style={{ fontSize: 12, fontWeight: 700, color: section.accent, letterSpacing: "0.06em" }}>
              {section.label.toUpperCase()}
            </span>
            <span style={{ fontSize: 9, color: "#1A2C3C" }}>
              — {section.params.length} param{section.params.length !== 1 ? "s" : ""}
            </span>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
            {section.params.map(p => {
              const isMod = !!modified[p.key];
              const isH   = hovered === p.key;
              const isPls = pulse === p.key;
              return (
                <div key={p.key}
                  onMouseEnter={() => setHovered(p.key)}
                  onMouseLeave={() => setHovered(null)}
                  style={{
                    display: "grid", gridTemplateColumns: "1fr auto",
                    alignItems: "start", gap: 16,
                    padding: "11px 14px",
                    background: isPls ? `${section.accent}0A` : isH ? "#0D1420" : "#090D14",
                    border: `1px solid ${isMod ? section.accent + "28" : "#111926"}`,
                    borderRadius: 5, transition: "background 0.12s, border-color 0.12s",
                  }}>

                  <div>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 1 }}>
                      <span style={{ fontSize: 11, fontWeight: 600, color: isMod ? section.accent : "#7090A8" }}>
                        {p.label}
                      </span>
                      {isMod && <span style={{ fontSize: 7, color: section.accent }}>●</span>}
                      <span style={{ fontSize: 8, color: "#162030", letterSpacing: "0.04em" }}>{p.key}</span>
                    </div>
                    {isH && (
                      <div style={{
                        fontSize: 10, color: "#2E4A60", lineHeight: 1.55,
                        fontFamily: "system-ui,sans-serif", marginTop: 5, maxWidth: 480,
                      }}>{p.desc}</div>
                    )}
                  </div>

                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    {p.type === "time" ? (
                      <input type="time" value={values[p.key]}
                        onChange={e => set(p.key, e.target.value, "time")}
                        style={{
                          background: "#060910",
                          border: `1px solid ${isMod ? section.accent + "50" : "#162030"}`,
                          color: isMod ? section.accent : "#607888",
                          padding: "5px 9px", borderRadius: 4,
                          fontSize: 12, fontFamily: "inherit", fontWeight: 700, outline: "none", width: 105,
                        }}
                      />
                    ) : (
                      <input type="number"
                        value={values[p.key]}
                        step={p.type === "int" ? 1 : (p.key.includes("SLIPPAGE") || p.key.includes("PCT")) ? 0.01 : 0.5}
                        onChange={e => set(p.key, e.target.value, p.type)}
                        style={{
                          background: "#060910",
                          border: `1px solid ${isMod ? section.accent + "50" : "#162030"}`,
                          color: isMod ? section.accent : "#607888",
                          padding: "5px 9px", borderRadius: 4,
                          fontSize: 12, fontFamily: "inherit", fontWeight: 700,
                          outline: "none", width: 88, textAlign: "right",
                        }}
                      />
                    )}
                    <span style={{ fontSize: 9, color: "#162030", minWidth: 30 }}>{p.unit}</span>
                    {isMod ? (
                      <button onClick={() => reset(p.key, p.default)} style={{
                        background: "transparent", border: "1px solid #162030",
                        color: "#2A3C50", padding: "3px 7px", borderRadius: 3,
                        fontSize: 8, cursor: "pointer", fontFamily: "inherit",
                        letterSpacing: "0.05em", whiteSpace: "nowrap",
                      }}>↩ {p.default}</button>
                    ) : (
                      <div style={{ width: 56 }} />
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Preview */}
        <div style={{
          width: 310, flexShrink: 0,
          borderLeft: "1px solid #111926", background: "#070A0E",
          display: "flex", flexDirection: "column", overflow: "hidden",
        }}>
          <div style={{
            padding: "10px 14px", borderBottom: "1px solid #111926",
            fontSize: 8, color: "#162030", letterSpacing: "0.18em",
            display: "flex", justifyContent: "space-between",
          }}>
            <span>PREVIEW</span><span style={{ color: "#0D1C28" }}>config_ctv2.py</span>
          </div>
          <pre style={{
            flex: 1, margin: 0, padding: "12px 14px",
            fontSize: 9, lineHeight: 1.8, overflowY: "auto",
            whiteSpace: "pre", fontFamily: "inherit",
          }}>
            {configText.split("\n").map((line, i) => {
              const isCmt = line.trim().startsWith("#") || line.trim().startsWith('"""');
              const eqIdx = line.indexOf("=");
              const key   = eqIdx > 0 ? line.slice(0, eqIdx).trim() : null;
              const isMod = key && modified[key];
              const sec   = isMod && SECTIONS.find(s => s.params.find(p => p.key === key));
              return (
                <span key={i} style={{ display: "block", color:
                  isCmt        ? "#111C28" :
                  isMod        ? sec.accent :
                  line.includes("=") ? "#1A3A50" : "#0A1C28"
                }}>{line || "\u00A0"}</span>
              );
            })}
          </pre>
        </div>

      </div>

      {/* Status bar */}
      <div style={{
        height: 26, flexShrink: 0,
        background: "#090C12", borderTop: "1px solid #111926",
        display: "flex", alignItems: "center", gap: 18,
        padding: "0 24px", fontSize: 8, color: "#162030", letterSpacing: "0.1em",
      }}>
        <span style={{ color: modCount > 0 ? "#F0C040" : "#162030" }}>
          {modCount > 0 ? `${modCount} PARAM${modCount > 1 ? "S" : ""} MODIFIED` : "NO CHANGES"}
        </span>
        <span>·</span><span>HOVER FOR DESCRIPTION</span>
        <span>·</span><span>COPY → SAVE AS  C:\CTV\config_ctv2.py</span>
        <span>·</span><span>RESTART RUNNER AFTER SAVING</span>
      </div>
    </div>
  );
}
