"""
ctv2_order_manager.py - Order Management for CTV2 Live Runner

Handles:
  - SPXW vertical spread entry (BAG BUY)
  - Dynamic win sell on conversion spread (BAG SELL — no PriceCondition)
  - Stop loss for parked positions (LMT SELL)
  - Plain limit sells for intrinsic / reversal / park-range closes

CRITICAL — BAG orders only, no legging in or out.

Entry pricing  : ask × cfg.ENTRY_SLIPPAGE rounded to tick  (guarantees fill, no error 110)
Exit pricing   : max(bid × cfg.SELL_SLIPPAGE, min_profit_price) rounded to tick
All prices rounded to SPX option tick:
    price < $3.00  → $0.05 tick
    price >= $3.00 → $0.10 tick
"""

import math
from typing import Optional, Tuple

from ibapi.contract import Contract, ComboLeg
from ibapi.order import Order

import config_ctv2 as cfg


def round_to_tick(price: float) -> float:
    """
    Round price DOWN to nearest valid SPX option tick.
    < $3.00  → $0.05 tick
    >= $3.00 → $0.10 tick
    Always rounds DOWN (conservative — for entries stays below ask×1.05,
    for sells stays below bid×0.95).
    Uses int(round(x, 8)) to eliminate float drift while ensuring true floor.
    """
    cents = int(round(price * 100, 8))   # eliminate float noise, then truncate = floor
    if price < 3.00:
        tick_cents = 5
    else:
        tick_cents = 10
    return (cents // tick_cents) * tick_cents / 100.0


class CTV2OrderManager:
    """
    Creates and places all orders for the CTV2 live runner.

    Requires client.contract_ids dict to be pre-populated with
    "C_NNNN" → conId and "P_NNNN" → conId mappings before
    any spread contract is created.
    """

    def __init__(self, client):
        self.client = client

    # =========================================================================
    # Contract builders
    # =========================================================================

    def create_vertical_contract(self, long_strike: float, short_strike: float,
                                  right: str) -> Optional[Contract]:
        """
        BAG contract for vertical spread ENTRY (BUY long, SELL short).

        right: 'C' for call spread (UP direction)
               'P' for put  spread (DOWN direction)
        """
        long_key  = f"{right}_{int(long_strike)}"
        short_key = f"{right}_{int(short_strike)}"

        if long_key not in self.client.contract_ids:
            print(f"[OM] Missing conId for long leg: {long_key}")
            return None
        if short_key not in self.client.contract_ids:
            print(f"[OM] Missing conId for short leg: {short_key}")
            return None

        contract          = Contract()
        contract.symbol   = "SPX"
        contract.secType  = "BAG"
        contract.exchange = "SMART"
        contract.currency = "USD"

        long_leg          = ComboLeg()
        long_leg.conId    = self.client.contract_ids[long_key]
        long_leg.ratio    = 1
        long_leg.action   = "BUY"
        long_leg.exchange = "SMART"

        short_leg         = ComboLeg()
        short_leg.conId   = self.client.contract_ids[short_key]
        short_leg.ratio   = 1
        short_leg.action  = "SELL"
        short_leg.exchange = "SMART"

        contract.comboLegs = [long_leg, short_leg]
        print(f"[OM] Vertical contract: BUY {long_key}({long_leg.conId}) "
              f"SELL {short_key}({short_leg.conId})")
        return contract

    def create_conversion_contract(self, short_strike: float, conv_strike: float,
                                    right: str) -> Optional[Contract]:
        """
        BAG contract for conversion spread WIN SELL.
        (SELL short_strike, BUY conv_strike)

        This closes the risk exposure and locks in profit.
        """
        short_key = f"{right}_{int(short_strike)}"
        conv_key  = f"{right}_{int(conv_strike)}"

        if short_key not in self.client.contract_ids:
            print(f"[OM] Missing conId for conversion short leg: {short_key}")
            return None
        if conv_key not in self.client.contract_ids:
            print(f"[OM] Missing conId for conversion long leg: {conv_key}")
            return None

        contract          = Contract()
        contract.symbol   = "SPX"
        contract.secType  = "BAG"
        contract.exchange = "SMART"
        contract.currency = "USD"

        short_leg          = ComboLeg()
        short_leg.conId    = self.client.contract_ids[short_key]
        short_leg.ratio    = 1
        short_leg.action   = "SELL"
        short_leg.exchange = "SMART"

        conv_leg           = ComboLeg()
        conv_leg.conId     = self.client.contract_ids[conv_key]
        conv_leg.ratio     = 1
        conv_leg.action    = "BUY"
        conv_leg.exchange  = "SMART"

        contract.comboLegs = [short_leg, conv_leg]
        print(f"[OM] Conversion contract: SELL {short_key}({short_leg.conId}) "
              f"BUY {conv_key}({conv_leg.conId})")
        return contract

    # =========================================================================
    # Order builders
    # =========================================================================

    def create_entry_order(self, order_id: int, ask_price: float) -> Order:
        """
        LMT BUY for vertical spread entry.
        limit = ask × cfg.ENTRY_SLIPPAGE (ask × 1.05), rounded to tick.
        Using ask (not mid) guarantees fill and avoids error 110.
        """
        limit = round_to_tick(ask_price * cfg.ENTRY_SLIPPAGE)

        order               = Order()
        order.orderId       = order_id
        order.action        = "BUY"
        order.totalQuantity = 1
        order.orderType     = "LMT"
        order.lmtPrice      = limit
        order.tif           = "DAY"
        order.transmit      = True
        order.eTradeOnly    = False
        order.firmQuoteOnly = False

        print(f"[OM] Entry order {order_id}: BUY LMT ${limit:.2f} "
              f"(ask=${ask_price:.2f} × {cfg.ENTRY_SLIPPAGE} → tick-rounded)")
        return order

    def create_win_sell_order(self, order_id: int, bid: float,
                               min_profit_price: float) -> Order:
        """
        Plain LMT SELL for conversion spread win exit.
        No PriceCondition — triggered dynamically when _live_spx crosses win_target.

        limit = max(bid × cfg.SELL_SLIPPAGE, min_profit_price / 100), rounded to tick.
        min_profit_price is in dollars (premium_paid × MIN_CONV_CREDIT_PCT).
        """
        min_per_share  = min_profit_price / 100.0
        bid_based      = bid * cfg.SELL_SLIPPAGE
        limit          = round_to_tick(max(bid_based, min_per_share))

        order               = Order()
        order.orderId       = order_id
        order.action        = "SELL"
        order.totalQuantity = 1
        order.orderType     = "LMT"
        order.lmtPrice      = limit
        order.tif           = "DAY"
        order.transmit      = True
        order.eTradeOnly    = False
        order.firmQuoteOnly = False

        used = 'bid-based' if bid_based >= min_per_share else 'min-profit'
        print(f"[OM] Win sell order {order_id}: SELL LMT ${limit:.2f} "
              f"(bid=${bid:.2f} bid×0.95=${bid_based:.2f} "
              f"min=${min_per_share:.2f} → {used})")
        return order

    def create_stop_order(self, order_id: int, premium_paid: float) -> Order:
        """
        LMT SELL for parked position stop loss.
        limit = (premium_paid × 0.50 / 100) × cfg.SELL_SLIPPAGE, rounded to tick.
        """
        stop_per_share = (premium_paid * 0.50) / 100.0
        limit          = round_to_tick(stop_per_share * cfg.SELL_SLIPPAGE)

        order               = Order()
        order.orderId       = order_id
        order.action        = "SELL"
        order.totalQuantity = 1
        order.orderType     = "LMT"
        order.lmtPrice      = limit
        order.tif           = "DAY"
        order.transmit      = True
        order.eTradeOnly    = False
        order.firmQuoteOnly = False

        print(f"[OM] Stop order {order_id}: SELL LMT ${limit:.2f} "
              f"(50% of ${premium_paid:.0f} = ${stop_per_share:.2f}/sh × {cfg.SELL_SLIPPAGE})")
        return order

    def create_close_order(self, order_id: int, bid: float) -> Order:
        """
        Plain LMT SELL — no conditions.
        Used for: intrinsic exit, reversal close, park-range close.
        limit = bid × cfg.SELL_SLIPPAGE, rounded to tick.
        """
        limit = round_to_tick(bid * cfg.SELL_SLIPPAGE)

        order               = Order()
        order.orderId       = order_id
        order.action        = "SELL"
        order.totalQuantity = 1
        order.orderType     = "LMT"
        order.lmtPrice      = limit
        order.tif           = "DAY"
        order.transmit      = True
        order.eTradeOnly    = False
        order.firmQuoteOnly = False

        print(f"[OM] Close order {order_id}: SELL LMT ${limit:.2f} "
              f"(bid=${bid:.2f} × {cfg.SELL_SLIPPAGE} → tick-rounded)")
        return order

    # =========================================================================
    # Market data
    # =========================================================================

    def request_market_data(self, contract: Contract, ticker_id: int):
        """Request snapshot bid/ask. Results arrive via tickPrice callback."""
        self.client.reqMktData(ticker_id, contract, "", True, False, [])
        print(f"[OM] reqMktData snapshot ticker_id={ticker_id}")

    def cancel_market_data(self, ticker_id: int):
        self.client.cancelMktData(ticker_id)
        print(f"[OM] cancelMktData ticker_id={ticker_id}")

    # =========================================================================
    # Strike calculator
    # =========================================================================

    def calc_strikes(self, spx: float, direction: str) -> Tuple[float, float, float]:
        """
        First-OTM vertical + conversion strikes, $5 increments.
        Returns (long_strike, short_strike, conv_strike).

        UP  (calls): long=ceil(spx/5)*5, short=long+5, conv=short+5
        DOWN (puts): long=floor(spx/5)*5, short=long-5, conv=short-5
        """
        inc = 5.0
        if direction == 'UP':
            long_s  = math.ceil(spx / inc) * inc
            short_s = long_s  + inc
            conv_s  = short_s + inc
        else:
            long_s  = math.floor(spx / inc) * inc
            short_s = long_s  - inc
            conv_s  = short_s - inc
        return long_s, short_s, conv_s

    def calc_chained_strikes(self, conv_strike: float,
                              direction: str) -> Tuple[float, float, float]:
        """
        Strikes for a chained re-entry after a WIN.
        The conv_strike of the completed trade becomes the new long_strike —
        we already own it from the conversion buy leg.

        Returns (long_strike, short_strike, conv_strike).
        """
        inc = 5.0
        long_s  = conv_strike
        if direction == 'UP':
            short_s = long_s + inc
            conv_s  = short_s + inc
        else:
            short_s = long_s - inc
            conv_s  = short_s - inc
        return long_s, short_s, conv_s
