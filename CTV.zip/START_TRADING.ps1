# ============================================================
# START_TRADING.ps1 — CTV2 Trading Runner Launcher
# ============================================================

Set-Location -Path $PSScriptRoot

Write-Host ""
Write-Host "============================================================"
Write-Host "  CTV2 Trading Runner"
Write-Host "============================================================"
Write-Host ""
Write-Host "  [1]  Paper Trading  (port 7497 - safe, no real money)"
Write-Host "  [2]  Live Trading   (port 7496 - REAL MONEY)"
Write-Host "  [Q]  Quit"
Write-Host ""
$mode = Read-Host "  Select mode"

switch ($mode.ToUpper()) {

    "1" {
        Write-Host ""
        Write-Host "  Starting PAPER trading..."
        Write-Host "  Press Ctrl+C to stop cleanly."
        Write-Host ""
        python ctv2_runner.py
    }

    "2" {
        Write-Host ""
        Write-Host "  *** WARNING: LIVE mode uses REAL MONEY ***"
        Write-Host ""
        $confirm = Read-Host "  Type YES to confirm"
        if ($confirm -eq "YES") {
            Write-Host ""
            Write-Host "  Starting LIVE trading..."
            Write-Host "  Press Ctrl+C to stop cleanly."
            Write-Host ""
            python ctv2_runner.py --live
        } else {
            Write-Host "  Cancelled."
        }
    }

    "Q" {
        # Quit — fall through to end
    }

    default {
        Write-Host "  Invalid choice."
    }
}

Write-Host ""
Read-Host "Press Enter to exit"
