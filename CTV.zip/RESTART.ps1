# ============================================================
#  CTV2 RESTART.ps1
#  Clears risk suspension and restarts the live runner.
#  Place this file in C:\CTV
#
#  Usage:
#    Double-click / Run with PowerShell  — restarts in paper mode
#    .\RESTART.ps1 --live                — restarts in live mode
# ============================================================

Set-Location -Path "C:\CTV"

Write-Host ""
Write-Host "============================================================"
Write-Host " CTV2 RESTART"
Write-Host "============================================================"

# Kill any running instance of the runner
Write-Host "[RESTART] Stopping existing runner..."
Get-Process python -ErrorAction SilentlyContinue |
    Where-Object { $_.MainWindowTitle -like "ctv2*" } |
    Stop-Process -Force -ErrorAction SilentlyContinue

# Short wait to ensure process is dead and IBKR order state settles
Start-Sleep -Seconds 3

# Clear the risk suspension flag if present
if (Test-Path "RESTART_TRADING.flag") {
    Write-Host "[RESTART] Clearing risk suspension flag..."
    Remove-Item "RESTART_TRADING.flag" -Force
}

# Touch flag then delete it so risk_manager clears counters on startup
"" | Out-File "RESTART_TRADING.flag" -Encoding ascii
Start-Sleep -Seconds 1

# Relaunch runner
Write-Host "[RESTART] Launching CTV2 runner..."
Write-Host ""

if ($args -contains "--live") {
    Write-Host "[RESTART] Mode: LIVE"
    Start-Process -FilePath "python" -ArgumentList "ctv2_runner.py --live" `
        -WorkingDirectory "C:\CTV"
} else {
    Write-Host "[RESTART] Mode: PAPER"
    Start-Process -FilePath "python" -ArgumentList "ctv2_runner.py" `
        -WorkingDirectory "C:\CTV"
}

Write-Host ""
Write-Host "[RESTART] Done. Runner is starting in a new window."
Write-Host "           Check the new window for connection and recovery status."
Write-Host "============================================================"
Write-Host ""
Read-Host "Press Enter to exit"
