"""
ctv2_auth.py - CTV2 Startup Authorization and Session Polling

Revision: 1.3

CHANGELOG
---------
Rev 1.3: Version gating now reads package version from C:\CTV\VERSION file
         instead of PACKAGE_VERSION in config_ctv2. Eliminates the circular
         dependency where bumping PACKAGE_VERSION in config would itself
         require a version bump. check_auth() parameter renamed revision ->
         pkg_version (float). auth.json min_version uses package number.
Rev 1.2: Removed Cache-Control/Pragma no-cache headers from fetch_auth().
         Those headers bypassed GitHub's CDN on every call, causing HTTP 429
         rate limit errors.
Rev 1.1: Registration alert (UNKNOWN_ID) now uses hardcoded Greg credentials
         so the notification always reaches Greg regardless of whose
         Pushover keys are in the user's config_ctv2.py.
Rev 1.0: Initial implementation.
         - Machine ID: hashed Windows MachineGuid (first 8 chars SHA-256)
         - Remote auth via auth.json hosted on GitHub
         - Startup: unknown ID sends Pushover to Greg + prints registration
           message to user, then exits cleanly
         - Mid-session polling every bar; disable honored at 16:00 ET
         - Local AUTH_DISABLED.flag persists until GitHub confirms re-enabled
         - Fetch failure policy: allow (GitHub outage never blocks trading)
         - Local disable flag always holds regardless of fetch failure

FLOW
----
Startup:
  1. Compute machine ID (hashed Windows GUID)
  2. Check local AUTH_DISABLED.flag - if present, try GitHub to see if
     re-enabled; if still blocked ? exit
  3. Fetch auth.json from GitHub
  4. check_auth() ? ALLOWED / DISABLED / UNKNOWN_ID / VERSION_TOO_OLD
     - UNKNOWN_ID      ? Pushover to Greg + message to user + exit
     - DISABLED / OLD  ? message to user + exit
     - ALLOWED         ? clear local flag if present, return machine_id

In-session (every bar via _check_auth_poll):
  1. Fetch auth.json (5s timeout)
  2. If confirmed disabled ? set _auth_disable_pending, log, continue trading
  3. At 16:00 ET ? write local flag + send Pushover to user
"""

from __future__ import annotations

import hashlib
import http.client
import json
import socket
import sys
import urllib.request
import urllib.error
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any

import config_ctv2 as cfg


# -- Constants ------------------------------------------------------------------

AUTH_JSON_URL   = 'https://raw.githubusercontent.com/gah2208/ctv/main/auth.json'
LOCAL_FLAG_PATH = Path(r'C:\CTV\AUTH_DISABLED.flag')
FETCH_TIMEOUT   = 10   # seconds - startup fetch
POLL_TIMEOUT    = 5    # seconds - in-session poll


# -- Machine ID -----------------------------------------------------------------

def get_machine_id() -> str:
    """
    Returns a stable 8-char hex ID for this machine.
    Windows: SHA-256 of HKLM\\SOFTWARE\\Microsoft\\Cryptography\\MachineGuid.
    Fallback: SHA-256 of hostname (non-Windows / registry failure).
    """
    try:
        import winreg
        key  = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                              r'SOFTWARE\Microsoft\Cryptography')
        guid, _ = winreg.QueryValueEx(key, 'MachineGuid')
        winreg.CloseKey(key)
        return hashlib.sha256(guid.encode()).hexdigest()[:8]
    except Exception:
        hostname = socket.gethostname()
        return hashlib.sha256(hostname.encode()).hexdigest()[:8]


# -- Remote auth fetch ----------------------------------------------------------

def fetch_auth(timeout: int = FETCH_TIMEOUT) -> Optional[Dict[str, Any]]:
    """
    Fetch and parse auth.json from GitHub.
    Returns parsed dict on success, None on any failure (timeout, network, parse).
    Cache-Control headers prevent GitHub from serving a stale cached copy.
    """
    try:
        req = urllib.request.Request(AUTH_JSON_URL)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode('utf-8'))
    except Exception as e:
        print(f"[AUTH ] fetch_auth: {e}")
        return None


# -- Auth evaluation ------------------------------------------------------------

def check_auth(machine_id: str, pkg_version: float,
               auth_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Evaluate auth_data for this machine_id and package version.

    Returns:
        status    : 'ALLOWED' | 'DISABLED' | 'UNKNOWN_ID' | 'VERSION_TOO_OLD'
        allowed   : bool
        reason    : str  (human-readable, empty if ALLOWED)
        user_name : str  (from auth.json 'name' field, or '' if unknown)
    """
    # -- Version gate ------------------------------------------------------
    min_version = float(auth_data.get('min_version', 0))
    if pkg_version < min_version:
        return {
            'status':    'VERSION_TOO_OLD',
            'allowed':   False,
            'reason':    (f"Update required - running package v{pkg_version}, "
                          f"minimum is v{min_version}. "
                          f"Click the Update icon on your desktop."),
            'user_name': '',
        }

    # -- User lookup -------------------------------------------------------
    users = auth_data.get('users', {})
    user  = users.get(machine_id)

    if user is None:
        return {
            'status':    'UNKNOWN_ID',
            'allowed':   False,
            'reason':    'This installation is not registered.',
            'user_name': '',
        }

    user_name = user.get('name', machine_id)

    if not user.get('enabled', False):
        return {
            'status':    'DISABLED',
            'allowed':   False,
            'reason':    user.get('reason', 'Access disabled.'),
            'user_name': user_name,
        }

    return {
        'status':    'ALLOWED',
        'allowed':   True,
        'reason':    '',
        'user_name': user_name,
    }


# -- Local disable flag ---------------------------------------------------------

def write_local_disable_flag(reason: str):
    """Write AUTH_DISABLED.flag with reason and timestamp."""
    try:
        LOCAL_FLAG_PATH.parent.mkdir(parents=True, exist_ok=True)
        LOCAL_FLAG_PATH.write_text(json.dumps({
            'reason':    reason,
            'timestamp': datetime.now().isoformat(),
        }, indent=2))
        print(f"[AUTH ] Disable flag written: {LOCAL_FLAG_PATH}")
    except Exception as e:
        print(f"[AUTH ] Failed to write disable flag: {e}")


def read_local_disable_flag() -> Optional[str]:
    """Returns reason string if flag exists, None otherwise."""
    if not LOCAL_FLAG_PATH.exists():
        return None
    try:
        return json.loads(LOCAL_FLAG_PATH.read_text()).get('reason', 'Access disabled.')
    except Exception:
        return 'Access disabled.'


def clear_local_disable_flag():
    """Remove the local disable flag (called when GitHub confirms re-enabled)."""
    try:
        if LOCAL_FLAG_PATH.exists():
            LOCAL_FLAG_PATH.unlink()
            print(f"[AUTH ] Disable flag cleared - access restored.")
    except Exception as e:
        print(f"[AUTH ] Failed to clear disable flag: {e}")


# -- Pushover helper (user config keys) ----------------------------------------

def _send_pushover(message: str, title: str, priority: int = 1):
    """
    Send Pushover using config_ctv2 credentials.
    Swallows all errors - auth logic must never crash the runner.
    """
    try:
        if not getattr(cfg, 'PUSHOVER_ENABLED', False):
            return
        user_key  = getattr(cfg, 'PUSHOVER_USER_KEY',  '')
        api_token = getattr(cfg, 'PUSHOVER_API_TOKEN', '')
        if not user_key or not api_token:
            return
        import urllib.parse
        conn = http.client.HTTPSConnection('api.pushover.net:443')
        conn.request(
            'POST', '/1/messages.json',
            urllib.parse.urlencode({
                'token':     api_token,
                'user':      user_key,
                'message':   message,
                'title':     title,
                'priority':  priority,
                'timestamp': int(datetime.now().timestamp()),
            }),
            {'Content-type': 'application/x-www-form-urlencoded'},
        )
        resp = conn.getresponse()
        conn.close()
        if resp.status == 200:
            print(f"[AUTH ] Pushover sent: {title}")
        else:
            print(f"[AUTH ] Pushover failed ({resp.status})")
    except Exception as e:
        print(f"[AUTH ] Pushover error: {e}")


# -- Pushover helper (Greg's hardcoded credentials for registration alerts) -----

def _send_pushover_greg(message: str, title: str, priority: int = 1):
    """
    Send Pushover directly to Greg using hardcoded credentials.
    Used for registration requests so the alert always reaches Greg
    regardless of whose Pushover keys are in the user's config.
    """
    try:
        import urllib.parse
        conn = http.client.HTTPSConnection('api.pushover.net:443')
        conn.request(
            'POST', '/1/messages.json',
            urllib.parse.urlencode({
                'token':     'a5pugjws46zsvfz16i7ookntxkoneb',
                'user':      'uck9cc5jyue5oir91izu2ordr6s4uc',
                'message':   message,
                'title':     title,
                'priority':  priority,
                'timestamp': int(datetime.now().timestamp()),
            }),
            {'Content-type': 'application/x-www-form-urlencoded'},
        )
        resp = conn.getresponse()
        conn.close()
        if resp.status == 200:
            print(f"[AUTH ] Registration alert sent to Greg.")
        else:
            print(f"[AUTH ] Registration alert failed ({resp.status})")
    except Exception as e:
        print(f"[AUTH ] Registration alert error: {e}")


# -- Startup checks -------------------------------------------------------------

def _read_package_version() -> float:
    """Read package version from C:\\CTV\\VERSION file. Returns 0.0 on failure."""
    try:
        version_path = Path(__file__).parent / 'VERSION'
        return float(version_path.read_text(encoding='utf-8').strip())
    except Exception:
        return 0.0


def run_startup_checks(mode: str) -> str:
    """
    Full startup authorization sequence.
    Returns machine_id (str) on success.
    Calls sys.exit(1) on any authorization failure.

    Reads package version from C:\\CTV\\VERSION for version gating.
    Called once at the top of TradingApp.run_live().
    """
    pkg_version = _read_package_version()

    machine_id = get_machine_id()
    print(f"[AUTH ] Machine ID : {machine_id}")

    # -- 1. Local disable flag ---------------------------------------------
    local_reason = read_local_disable_flag()
    if local_reason:
        print(f"\n{'='*60}")
        print(f"  CTV2 - ACCESS DISABLED")
        print(f"{'='*60}")
        print(f"  Reason : {local_reason}")
        print(f"  Contact Greg to restore access.")
        print(f"{'='*60}\n")

        # Check GitHub - Greg may have re-enabled since last session
        auth_data = fetch_auth()
        if auth_data is not None:
            result = check_auth(machine_id, pkg_version, auth_data)
            if result['allowed']:
                clear_local_disable_flag()
                print(f"[AUTH ] Access restored - welcome back, "
                      f"{result['user_name']}!")
                return machine_id
        # Fetch failed or still disabled - stay blocked
        sys.exit(1)

    # -- 2. Fetch remote auth ----------------------------------------------
    auth_data = fetch_auth()

    if auth_data is None:
        # GitHub unreachable - allow per fetch_failure_policy
        print(f"[AUTH ] Remote auth unavailable - proceeding "
              f"(fetch failure policy: allow)")
        return machine_id

    # -- 3. Evaluate -------------------------------------------------------
    result = check_auth(machine_id, pkg_version, auth_data)

    if result['status'] == 'UNKNOWN_ID':
        ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print(f"\n{'='*60}")
        print(f"  CTV2 - REGISTRATION REQUIRED")
        print(f"{'='*60}")
        print(f"  Your installation ID has been sent to Greg for approval.")
        print(f"  CTV2 will run once you have been added.")
        print(f"  Installation ID : {machine_id}")
        print(f"{'='*60}\n")

        _send_pushover_greg(
            message=(
                f"New CTV2 registration request\n\n"
                f"ID:   {machine_id}\n"
                f"Mode: {mode.upper()}\n"
                f"Time: {ts}\n\n"
                f"Add this ID to auth.json to authorize."
            ),
            title='CTV2: Registration Request',
            priority=1,
        )
        sys.exit(1)

    if not result['allowed']:
        print(f"\n{'='*60}")
        print(f"  CTV2 - ACCESS DENIED")
        print(f"{'='*60}")
        print(f"  {result['reason']}")
        print(f"{'='*60}\n")
        sys.exit(1)

    print(f"[AUTH ] Authorized - welcome, {result['user_name']}!")
    return machine_id
