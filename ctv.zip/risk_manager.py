"""
risk_manager.py - Risk Management and Trading Suspension (CTV2)

Revision: 1.0

Monitors trade outcomes and suspends trading when thresholds are breached.
Suspension persists until user manually restarts via RESTART.bat.

Cross-Platform Support:
- Windows: Run RESTART.bat in C:\\CTV
- Mac: Run RESTART.command in ~/CTV

Suspension Triggers:
- 2 consecutive losses
- 3 total losses in a day

Reset Behavior:
- Runner restart clears suspension automatically (state file handles open positions)
- Manual restart resets BOTH consecutive and daily loss counts
- No automatic reset at end of day

Usage:
    risk_mgr = RiskManager(config, alerter)
    
    # After each trade exit
    risk_mgr.record_outcome(TradeOutcome.WIN)   # or LOSS
    
    # Before each trade entry
    if risk_mgr.is_trading_allowed():
        # Execute trade
"""

from __future__ import annotations

import platform
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional
from enum import Enum


class TradeOutcome(Enum):
    """Possible trade outcomes"""
    WIN = "WIN"
    LOSS = "LOSS"
    BREAKEVEN = "BREAKEVEN"


class SuspensionReason(Enum):
    """Reasons for trading suspension"""
    NONE = "NONE"
    CONSECUTIVE_LOSSES = "CONSECUTIVE_LOSSES"
    DAILY_LOSSES = "DAILY_LOSSES"


class RiskManager:
    """
    Monitors trading outcomes and enforces risk limits.
    
    Suspends trading when:
    - max_consecutive_losses reached (default: 2)
    - max_daily_losses reached (default: 3)
    
    Resume by restarting the runner via RESTART.bat in C:\\CTV.
    The state file and position recovery handle all open trades automatically.
    """
    
    def __init__(self, config: Dict[str, Any], alerter=None):
        """
        Initialize risk manager.
        
        Args:
            config: Configuration dict with risk_management section
            alerter: Optional LocalAlerter instance for sending alerts
        """
        risk_config = config.get('risk_management', {})
        self.system = platform.system()
        
        # Enable/disable suspension feature
        self.suspension_enabled = risk_config.get('suspension_enabled', False)
        
        # Thresholds
        self.max_consecutive_losses = risk_config.get('max_consecutive_losses', 2)
        self.max_daily_losses = risk_config.get('max_daily_losses', 3)
        
        # Restart mechanism - platform-specific defaults
        if self.system == "Darwin":  # Mac
            default_flag_path = str(Path.home() / "CTV" / "RESTART_TRADING.flag")
        else:  # Windows
            default_flag_path = "C:\\CTV\\RESTART_TRADING.flag"
        
        self.restart_flag_file = Path(
            risk_config.get('restart_flag_file', default_flag_path)
        )
        self.restart_dir = str(self.restart_flag_file.parent)
        
        # Alerter
        self.alerter = alerter
        
        # State
        self.consecutive_losses = 0
        self.daily_losses = 0
        self.daily_wins = 0
        self.trading_suspended = False
        self.suspension_reason = SuspensionReason.NONE
        self.suspension_time: Optional[datetime] = None
        
        # Check if restart flag exists at startup (clear it)
        self._check_restart_flag_on_startup()
        
        print(f"[RISK] Risk Manager initialized (platform: {self.system})")
        print(f"[RISK]   Suspension enabled: {self.suspension_enabled}")
        print(f"[RISK]   Max consecutive losses: {self.max_consecutive_losses}")
        print(f"[RISK]   Max daily losses: {self.max_daily_losses}")
    
    def _check_restart_flag_on_startup(self):
        """Check for restart flag at startup and clear if present"""
        if self.restart_flag_file.exists():
            print(f"[RISK] Found restart flag at startup - clearing")
            self.restart_flag_file.unlink()
    
    def record_outcome(self, outcome: TradeOutcome) -> bool:
        """
        Record a trade outcome and check for suspension triggers.
        
        Args:
            outcome: WIN, LOSS, or BREAKEVEN
            
        Returns:
            True if trading is still allowed, False if suspended
        """
        timestamp = datetime.now().strftime('%H:%M:%S')
        
        if outcome == TradeOutcome.WIN:
            self.daily_wins += 1
            self.consecutive_losses = 0  # Reset streak on win
            print(f"[RISK] {timestamp} WIN recorded. Consecutive losses reset to 0.")
            print(f"[RISK]   Daily: {self.daily_wins}W / {self.daily_losses}L")
            return True
            
        elif outcome == TradeOutcome.LOSS:
            self.daily_losses += 1
            self.consecutive_losses += 1
            print(f"[RISK] {timestamp} LOSS recorded.")
            print(f"[RISK]   Consecutive losses: {self.consecutive_losses}/{self.max_consecutive_losses}")
            print(f"[RISK]   Daily losses: {self.daily_losses}/{self.max_daily_losses}")
            
            # Check consecutive losses threshold
            if self.consecutive_losses >= self.max_consecutive_losses:
                self._suspend_trading(SuspensionReason.CONSECUTIVE_LOSSES)
                return False
            
            # Check daily losses threshold
            if self.daily_losses >= self.max_daily_losses:
                self._suspend_trading(SuspensionReason.DAILY_LOSSES)
                return False
            
            return True
            
        else:  # BREAKEVEN
            # Doesn't count as win or loss, doesn't reset streak
            print(f"[RISK] {timestamp} BREAKEVEN recorded.")
            return True
    
    def _suspend_trading(self, reason: SuspensionReason):
        """
        Suspend trading and send alert.
        
        Args:
            reason: Why trading is being suspended
        """
        self.trading_suspended = True
        self.suspension_reason = reason
        self.suspension_time = datetime.now()
        
        timestamp = self.suspension_time.strftime('%H:%M:%S')
        
        if reason == SuspensionReason.CONSECUTIVE_LOSSES:
            reason_text = f"{self.consecutive_losses} consecutive losses"
        else:
            reason_text = f"{self.daily_losses} losses today"
        
        # Platform-specific restart instructions
        if self.system == "Darwin":
            restart_file = "RESTART.command"
        else:
            restart_file = "RESTART.bat"

        print("\n" + "=" * 60)
        print("!!! TRADING SUSPENDED !!!")
        print("=" * 60)
        print(f"Time: {timestamp}")
        print(f"Reason: {reason_text}")
        print(f"")
        print(f"To resume trading:")
        print(f"  Run {restart_file} in C:\\CTV")
        print("=" * 60 + "\n")
        
        # Send popup alert
        if self.alerter:
            self.alerter.send_suspension_alert(
                reason=reason_text,
                restart_path=self.restart_dir
            )
    
    def is_trading_allowed(self) -> bool:
        """
        Check if trading is currently allowed.
        
        Returns:
            True if trading allowed, False if suspended
        """
        # If suspension is disabled in config, always allow trading
        if not self.suspension_enabled:
            return True
        return not self.trading_suspended
    
    def check_restart_flag(self) -> bool:
        """
        Check for restart flag file and resume trading if found.
        
        Should be called in the main loop (e.g., at start of each bar).
        
        Returns:
            True if trading was just resumed, False otherwise
        """
        if not self.trading_suspended:
            return False
        
        if self.restart_flag_file.exists():
            # Delete the flag file
            self.restart_flag_file.unlink()
            
            # Reset all counters
            self.consecutive_losses = 0
            self.daily_losses = 0
            self.daily_wins = 0
            self.trading_suspended = False
            self.suspension_reason = SuspensionReason.NONE
            
            timestamp = datetime.now().strftime('%H:%M:%S')
            
            print("\n" + "=" * 60)
            print("TRADING RESUMED")
            print("=" * 60)
            print(f"Time: {timestamp}")
            print(f"All loss counters reset to 0")
            print("=" * 60 + "\n")
            
            # Send SMS alert
            if self.alerter:
                self.alerter.send_restart_alert()
            
            return True
        
        return False
    
    def get_status(self) -> Dict[str, Any]:
        """
        Get current risk management status.
        
        Returns:
            Dict with current state
        """
        return {
            'trading_allowed': not self.trading_suspended,
            'suspended': self.trading_suspended,
            'suspension_reason': self.suspension_reason.value,
            'suspension_time': self.suspension_time.isoformat() if self.suspension_time else None,
            'consecutive_losses': self.consecutive_losses,
            'daily_losses': self.daily_losses,
            'daily_wins': self.daily_wins,
            'max_consecutive_losses': self.max_consecutive_losses,
            'max_daily_losses': self.max_daily_losses,
        }
    
    def get_status_line(self) -> str:
        """
        Get one-line status for display.
        
        Returns:
            Status string
        """
        if self.trading_suspended:
            return f"[SUSPENDED: {self.suspension_reason.value}]"
        else:
            return f"[OK: {self.consecutive_losses}/{self.max_consecutive_losses} consec, {self.daily_losses}/{self.max_daily_losses} daily]"


def test_risk_manager():
    """Test risk manager logic"""
    config = {
        'risk_management': {
            'max_consecutive_losses': 2,
            'max_daily_losses': 3,
            'restart_flag_file': '/tmp/RESTART_TRADING.flag'
        }
    }
    
    rm = RiskManager(config)
    
    print("\n--- Testing consecutive losses ---")
    print(f"Status: {rm.get_status_line()}")
    
    rm.record_outcome(TradeOutcome.WIN)
    print(f"After WIN: {rm.get_status_line()}")
    
    rm.record_outcome(TradeOutcome.LOSS)
    print(f"After LOSS 1: {rm.get_status_line()}")
    print(f"Trading allowed: {rm.is_trading_allowed()}")
    
    rm.record_outcome(TradeOutcome.LOSS)
    print(f"After LOSS 2: {rm.get_status_line()}")
    print(f"Trading allowed: {rm.is_trading_allowed()}")
    
    print("\n--- Testing restart ---")
    # Create restart flag
    Path('/tmp/RESTART_TRADING.flag').write_text('RESTART')
    rm.check_restart_flag()
    print(f"After restart: {rm.get_status_line()}")
    print(f"Trading allowed: {rm.is_trading_allowed()}")


if __name__ == '__main__':
    test_risk_manager()
