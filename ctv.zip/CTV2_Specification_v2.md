**CTV2**

**High-Level System Specification**

*Updated --- Phase 1 Migration Complete + Owner Corrections (Rev 2)*

1. System Overview
==================

CTV2 is an automated 0DTE (zero-days-to-expiration) options trading
system written in Python and deployed on Windows. It trades SPXW (S&P
500 weekly index options) butterfly spreads intraday, using an
EMA-separation signal derived from 5-second price ticks aggregated into
3-minute bars. The system connects to Interactive Brokers via IB Gateway
and the ib_insync library.

1.1 Core Strategy Summary
-------------------------

CTV2 watches the separation between a fast EMA (36 bars) and a slow EMA
(180 bars) computed over rolling 3-minute bars of SPX. When the two EMAs
diverge beyond a configurable threshold in a consistent direction, the
system opens a debit vertical spread (two legs: long + short call or
put, $5 wide). If SPX subsequently reaches the short strike ± a
win-target buffer, the runner converts that vertical into a butterfly by
selling an additional spread above/below the short, locking in a credit.
Trades that stall or move adversely are "parked" and may still convert
later or expire worthless. All positions expire same-day (0DTE) on SPXW
options.

1.2 Supported Underlyings
-------------------------

  ------------ ---------------------------------------- ------------------ --------------------------------------------------------------------------------
  **Symbol**   **Contract**                             **Scale Factor**   **Notes**
  SPX          S&P 500 Index Options (full-size)        1.0×               Default. Config values applied at face value.
  XSP          Mini S&P 500 Index Options (1/10 size)   0.1×               ibkr_scale.py divides all index-point and dollar parameters by 10 at runtime.
  ------------ ---------------------------------------- ------------------ --------------------------------------------------------------------------------

1.3 Technology Stack
--------------------

  ----------------- ---------------------------------------------------
  **Component**     **Choice**
  Language          Python 3.10+
  Broker API        Interactive Brokers --- IB Gateway (not full TWS)
  Broker Library    ib_insync (asyncio-native wrapper over ibapi)
  Connection Mode   Paper trading first --- port 7497; live port 7496
  Account Type      Standard margin account
  OS                Windows 10/11 (64-bit)
  Alert Delivery    Pushover
  ----------------- ---------------------------------------------------

2. Module Inventory
===================

All files reside in C:\CTV. The table below describes every Python
module and its role.

  --------------------- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- -------------------
  **File**              **Role**                                                                                                                                                                                                                                                         **Status**
  ctv2_runner.py        Main strategy engine. Contains all EMA logic, entry/exit decisions, butterfly management, park logic, risk suspension, and EOD reporting. Not modified by the IBKR migration.                                                                                    Unchanged
  ibkr_stream.py        Market data stream. Connects to IB Gateway via ib_insync, subscribes to SPX/XSP index ticks, delivers raw price callbacks and feeds SpxBarAggregator. Replaces tradier_stream.py.                                                                              New (Phase 1)
  ibkr_orders.py        All broker interactions. Covers strike calculation, spread quotes, order placement (entry + win-sell), order status polling, position queries, account buying power, expiration lookup, and EOD fill report. Replaces tradier_client.py + tradier_orders.py.   New (Phase 3)
  ibkr_scale.py         Parameter scaling. Reads UNDERLYING from config, computes scale factor (SPX=1.0, XSP=0.1), returns a frozen ScaledConfig dataclass with all 11 scalable parameters at their effective runtime values. Logs each value at startup.                             New (Phase 1)
  spx_bars.py           Bar aggregation. SpxBarAggregator receives every 5-second SPX tick and accumulates them into 3-minute OHLCV bars. Fires on_bar_close(bar) on each completed bar for EMA computation.                                                                           Unchanged
  config_ctv2.py        Central configuration. All strategy parameters, time gates, IB Gateway host/port, and the UNDERLYING selector ('SPX' or 'XSP'). UNDERLYING added in Phase 1.                                                                                                 Updated (Phase 1)
  risk_manager.py       Consecutive-loss and daily-loss suspension logic. Tracks win/loss outcomes; suspends trading if thresholds are breached.                                                                                                                                         Unchanged
  pushover_alerts.py    Mobile push notification client. Sends alerts on entries, fills, exits, and errors via the Pushover API.                                                                                                                                                       Unchanged
  preflight_check.py    Pre-session validation. Verifies IB Gateway connectivity, account permissions, and option data access before the runner starts. (Tradier token checks removed in Phase 4.)                                                                                       Updated (Phase 4)
  --------------------- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- -------------------

3. Data Flow
============

3.1 Market Data Path
--------------------

SPX price data flows from IB Gateway through four stages before
influencing trading decisions:

  ----------------------- ----------------- -----------------------------------------------------------------------------------------------------------------------------------------------------------
  **Stage**               **Module**        **Description**
  1 --- Raw ticks         ibkr_stream.py    IBKRStream subscribes to Index("SPX","CBOE") via reqMktData. Every last-price tick fires two callbacks simultaneously.
  2 --- Live price        ctv2_runner.py    on_spx_tick(price, ts) callback updates self._live_spx --- the real-time SPX price used for intrabar win-target monitoring.
  3 --- Bar aggregation   spx_bars.py       SpxBarAggregator.on_spx_tick(price) accumulates ticks into 5-second sub-bars, then closes each 3-minute bar and calls on_bar_close(bar).
  4 --- EMA signal        ctv2_runner.py    on_bar_close populates a rolling bar buffer and computes EMA36 and EMA180. The separation between them drives entry and butterfly-conversion decisions.
  ----------------------- ----------------- -----------------------------------------------------------------------------------------------------------------------------------------------------------

3.2 Order Placement Path
------------------------

All order activity is routed through IBKROrderManager (ibkr_orders.py)
using IBKR's ComboLeg BAG order format:

  ---------------- ----------------- ---------------------------------------------------------------------------------------------------------------------------------------
  **Stage**        **Module**        **Description**
  Strike calc      ibkr_orders.py    calc_strikes(spx, direction) computes the long and short strikes relative to current SPX. calc_chained_strikes() builds follow-on legs for butterfly conversion.
  Spread quote     ibkr_orders.py    get_spread_quote(direction, long_s, short_s) calls reqMktData on both option legs and returns (bid, ask) for the net spread.
  Entry order      ibkr_orders.py    place_entry() submits a LimitOrder BUY on a 2-leg BAG contract: ComboLeg[0]=long BUY, ComboLeg[1]=short SELL. Price = ask × ENTRY_SLIPPAGE_FACTOR, rounded to tick.
  Win-sell order   ibkr_orders.py    place_win_sell() submits a real LimitOrder SELL on a 2-leg BAG: ComboLeg[0]=short SELL (second short to create -2 center), ComboLeg[1]=conv BUY (far wing). Price = bid × SELL_SLIPPAGE_FACTOR.
  Order polling    ctv2_runner.py    _poll_order_fill() calls get_order(order_id) in a loop until status is "filled" or timeout fires. Returns avg_fill_price for P&L tracking. Works on both paper and live accounts.
  Cancel           ibkr_orders.py    cancel(order_id) calls ib.cancelOrder() and waits for acknowledgement.
  ---------------------------------------------------------------  ---------------------------------------------------------------------------------------------------------------------------------------

4. Trade Lifecycle
==================

4.1 States
----------

Each trade moves through the following states inside ctv2_runner.py:

  -------------------- ---------------------------------------------------------------------------------------------------------------------------------------
  **State**            **Meaning**
  PENDING_ENTRY        Strike and quote computed; entry order submitted; waiting for fill.
  ACTIVE               Entry filled. Runner monitors _live_spx vs. win-target and adverse-move thresholds.
  PARKED               Adverse move detected or EMA reversed. Trade is held but not actively managed until SPX recovers or INTRINSIC_EXIT_TIME is reached.
  PENDING_BUTTERFLY    Win target hit; win-sell (butterfly conversion) order submitted; waiting for fill.
  BUTTERFLY            Butterfly conversion filled. Trade is complete --- outcome recorded as WIN.
  EXPIRED/LOSS         INTRINSIC_EXIT_TIME reached without conversion; position expires or is force-closed. Recorded as LOSS.
  -------------------- ---------------------------------------------------------------------------------------------------------------------------------------

4.2 Entry Conditions
--------------------

-   Trading window: TRADING_START_TIME through LAST_ENTRY_TIME
    (default 10:00--14:00 ET).

-   Trend_dir is defined by the relationship between EMA36 and EMA180
    on a specific schedule. 9:30, 9:33, 9:36 ...at the beginning of each
    fixed 3 minute bar marker. If EMA36 is above EMA180 and outside of
    the noise boundary, the direction is up. Inside the noise boundary
    there is no direction.

-   The 5-second rolling 3-minute bar is used for acceleration gating.
    As long as EMA36(-1) < EMA36(0), the market is accelerating UP.
    As long as it is accelerating UP and EMA36 is above EMA180, we can
    buy long positions in the up direction. This allows us to re-enter
    trades immediately upon recording a win. It also keeps us from
    investing in the wrong long positions when the market is moving
    against us. Visa versa occurs for the DOWN trend_dir.

-   Only 1 active trade at a time. Up to 2 parked trades are possible
    (total 3 positions max).

-   Premium (net debit) must be ≤ MAX_PREMIUM.

-   Bid/ask spread of the net debit must be ≤ MAX_BID_ASK_WIDTH.

-   VIX9D must be < VIX_MAX_ENTRY.

-   Risk suspension: no new entries if consecutive-loss or daily-loss
    limits have been hit (risk_manager.py).

4.3 Win-Target Logic
--------------------

After entry, the runner continuously compares _live_spx to the short
strike of the trade. When SPX reaches short_strike ±
WIN_TARGET_BUFFER, place_win_sell() is called to complete the
butterfly. The credit received from this conversion must exceed
MIN_CONV_CREDIT_PCT × premium_paid to count as a WIN.

4.4 Conversion Spread and IBKR Zero-Risk Filter Workaround
-----------------------------------------------------------

Interactive Brokers rejects orders that create a zero-risk butterfly ---
i.e., when the short sale credit from the conversion leg is greater than
or equal to the long cost, leaving zero or negative net debit (risk-free
arbitrage from the broker's perspective).

**Workaround mechanism:**

The win-sell (butterfly conversion) order uses CONV_SPREAD_WIDTH (default
$10) instead of SPREAD_WIDTH ($5) for the conversion's far leg. This
widens the conversion spread, making it non-zero-risk from IBKR's
perspective.

Immediately after the WIN fill:
- A collapse thread is spawned.
- It places a net-debit BAG order: BUY near_strike / SELL far_strike.
- This order narrows the conversion spread back to SPREAD_WIDTH.
- End result: standard $5-wide butterfly with profit locked in.

**Configuration:**
- CONV_SPREAD_WIDTH = 10.0 (must be > SPREAD_WIDTH of 5.0)
- Collapse thread waits for the WIN fill before placing the collapse order.

4.5 Park Logic
--------------

A trade is parked when SPX moves adversely by more than
ACTIVE_ADVERSE_MOVE points from the entry short-strike side, or when
the EMA36/EMA180 signal reverses. Parked trades are re-evaluated on each
bar close. The park-conversion EMA threshold is tiered by VIX9D:

  ---------------------------------------------- ------------------------------------
  **VIX9D Range**                                **Park Convert Threshold**
  < VIX_BREAK_LOW (18.0)                         PARK_CONVERT_EMA_LOW (4.0 pts)
  VIX_BREAK_LOW -- VIX_BREAK_HIGH (18--25)       PARK_CONVERT_EMA_MID (5.0 pts)
  > VIX_BREAK_HIGH (25.0)                        PARK_CONVERT_EMA_HIGH (6.0 pts)
  ---------------------------------------------- ------------------------------------

4.6 Forced Exit
---------------

At INTRINSIC_EXIT_TIME (default 14:30 ET), any trade still in ACTIVE
or PARKED state is forced to convert. If SPX cannot yield a profitable
butterfly at that point, the trade is closed for a loss.

5. Module Detail
================

5.1 ibkr_stream.py --- IBKRStream
----------------------------------

IBKRStream runs in a dedicated daemon thread with its own asyncio event
loop. It connects to IB Gateway at 127.0.0.1:7497 (paper) or 127.0.0.1:7496
(live) using ib_insync with clientId=1. On connection it qualifies an Index
contract for the configured underlying (SPX or XSP) on CBOE, then calls
reqMktData to receive real-time last-price ticks.

Every tick fires two downstream callbacks on the stream thread:

-   on_spx_tick(price, ts) --- notifies the runner of the raw price
    for intrabar monitoring.

-   spx_aggregator.on_spx_tick(price) --- feeds SpxBarAggregator for
    bar construction.

Public interface (identical to the old TradierStream):

> start() --- launches the daemon thread and initiates connection
>
> stop() --- disconnects and terminates the thread
>
> reset_bars() --- clears accumulated bar state (called at session
> start)
>
> last_spx --- property: most recent SPX last-price

5.2 ibkr_orders.py --- IBKROrderManager
----------------------------------------

IBKROrderManager is a single class. It holds its own IB() connection
(clientId=2) separate from the stream's clientId=1. Both clients
connect to the same IB Gateway server; the gateway supports multiple
simultaneous connections.

The runner instantiates this class in __init__ and assigns it to both
self.order_manager and self.client so all existing call sites satisfy
without further changes:

> self.order_manager = IBKROrderManager()
>
> self.client = self.order_manager

Key methods and their IBKR mechanism:

  -------------------------------------- ----------------------------------------------------------------------------------------------------------------
  **Method**                             **IBKR Mechanism**
  calc_strikes(spx, direction)           Pure arithmetic --- computes long/short strikes at SPREAD_WIDTH from current SPX, rounded to nearest integer.
  calc_chained_strikes(...)              Pure arithmetic --- computes the conversion (far wing) strike for butterfly completion.
  get_spread_quote(dir, long, short)     Calls reqMktData on both legs; returns (net_bid, net_ask) for the spread.
  place_entry(...)                       Submits LimitOrder BUY on a 2-leg BAG (ComboLeg); returns order_id. Sends real order to IBKR paper or live account.
  place_win_sell(...)                    Submits LimitOrder SELL on a 2-leg BAG for butterfly conversion; returns order_id. Sends real order to IBKR account.
  cancel(order_id)                       Calls ib.cancelOrder() and waits for acknowledgement.
  get_order(order_id)                    Calls reqOpenOrders; returns {status, avg_fill_price} in Tradier-compatible dict shape.
  get_todays_expiration(live)            Determines the SPXW expiration date for today's session using calendar logic.
  get_option_buying_power()              Queries IBKR account values for available option buying power float. Retries up to 5 times with 2-second delays waiting for IB Gateway to sync account data.
  get_positions()                        Calls reqPositions(); returns raw positions list.
  get_eod_report(today)                  Calls reqExecutions(); returns fill records for the session, replacing the old Tradier CSV report.
  -------------------------------------- ----------------------------------------------------------------------------------------------------------------

**Real Trading Mode (both paper and live):**

When LIVE_TRADING=False, orders are sent to the IBKR paper trading account
(port 7497). When LIVE_TRADING=True, orders are sent to the IBKR live account
(port 7496). In both cases, place_entry() and place_win_sell() send genuine
orders to IBKR and _poll_order_fill() polls the actual order status from IBKR.
There is no synthetic fill path or -1 sentinel value.

Round-to-tick utility: round_to_tick(price) rounds an option price to
the nearest $0.05 increment (SPXW options trade in $0.05 ticks).
Exported from ibkr_orders.py and imported by ctv2_runner.py.

5.3 ibkr_scale.py --- ScaledConfig
-----------------------------------

ibkr_scale.py provides a single public function:
build_scaled_config(). The runner calls this once in __init__ and
stores the result as self.cfg. The function:

-   Reads UNDERLYING from config_ctv2.

-   Sets scale = 1.0 for SPX, scale = 0.1 for XSP.

-   Returns a frozen ScaledConfig dataclass containing all 11 scalable
    parameters at their effective runtime values.

-   Logs every scaled value at startup for auditability.

The 11 scalable parameters (index-point or option-dollar denominated):

+---------------------------+-----------------------------------------+
| **Parameter**             | **Description**                         |
+---------------------------+-----------------------------------------+
| EMA_DIRECTION_THRESHOLD   | Minimum EMA36/EMA180 separation to      |
|                           | trigger entry                           |
+---------------------------+-----------------------------------------+
| SPREAD_WIDTH              | Strike distance between long and short  |
|                           | legs (entry butterfly)                  |
+---------------------------+-----------------------------------------+
| CONV_SPREAD_WIDTH         | Strike distance for conversion (far     |
|                           | wing) --- used to avoid IBKR zero-risk  |
|                           | rejection. Must be > SPREAD_WIDTH.      |
+---------------------------+-----------------------------------------+
| WIN_TARGET_BUFFER         | SPX distance from short strike to       |
|                           | trigger butterfly conversion            |
+---------------------------+-----------------------------------------+
| PARK_CONVERT_EMA_LOW      | Park re-entry EMA threshold when VIX9D  |
|                           | is low                                  |
+---------------------------+-----------------------------------------+
| PARK_CONVERT_EMA_MID      | Park re-entry EMA threshold when VIX9D  |
|                           | is mid                                  |
+---------------------------+-----------------------------------------+
| PARK_CONVERT_EMA_HIGH     | Park re-entry EMA threshold when VIX9D  |
|                           | is high                                 |
+---------------------------+-----------------------------------------+
| ACTIVE_ADVERSE_MOVE       | Adverse SPX move from short strike that |
|                           | triggers parking                        |
+---------------------------+-----------------------------------------+
| MAX_PREMIUM               | Maximum net debit acceptable for an     |
|                           | entry                                   |
+---------------------------+-----------------------------------------+
| MAX_BID_ASK_WIDTH         | Maximum net spread bid/ask width        |
|                           | acceptable for an entry                 |
+---------------------------+-----------------------------------------+

Non-scalable parameters (VIX thresholds, time gates, counts, flags,
slippage percentages) continue to be read directly from config_ctv2 as
cfg.PARAM.

5.4 spx_bars.py --- SpxBarAggregator
-------------------------------------

SpxBarAggregator receives individual SPX last-price ticks and constructs
5-second sub-bars, which are then aggregated into 3-minute OHLCV bars.
On each 3-minute bar close, it calls on_bar_close(bar) which is wired
to the runner's EMA computation logic. This module is entirely
unchanged by the IBKR migration --- it is tick-source agnostic.

5.5 ctv2_runner.py --- Main Runner
-----------------------------------

ctv2_runner.py is the central strategy engine. It is entirely unchanged
by the IBKR migration except for three import lines and the constructor
wiring:

  ------------------------------------------------------------------ -----------------------------------------------------------------------------------
  **Import (old)**                                                   **Import (new)**
  from tradier_stream import TradierStream                            from ibkr_stream import IBKRStream as TradierStream
  from tradier_client import TradierClient                            from ibkr_orders import IBKROrderManager as TradierClient
  from tradier_orders import TradierOrderManager, round_to_tick       from ibkr_orders import IBKROrderManager as TradierOrderManager, round_to_tick
  ------------------------------------------------------------------ -----------------------------------------------------------------------------------

All strategy logic --- EMA computation, bar-close callbacks, entry
gating, win-target monitoring, park state machine, butterfly conversion,
EOD reporting, and risk suspension --- lives in ctv2_runner.py and was
not touched.

**Connection Architecture:**

IBKROrderManager is instantiated in TradingApp.__init__ (not in run_live).
This ensures the order connection is ready from startup. The stream 
(IBKRStream) connects later in run_live() after the warmup period.

6. Configuration Reference
==========================

All parameters live in config_ctv2.py. A graphical Config Editor
(CONFIG_EDITOR.bat) exposes the most common parameters. UNDERLYING must
be set directly in the file.

  -------------- --------------------------- ------------- -----------------------------------------------
  **Category**   **Parameter**               **Default**   **Notes**
  Underlying     UNDERLYING                  SPX           SPX or XSP. Drives ibkr_scale.py factor.
  IB Gateway     IB_HOST                     127.0.0.1     
  IB Gateway     IB_PORT_PAPER               7497          Paper trading port
  IB Gateway     IB_PORT_LIVE                7496          Live trading port (future)
  IB Gateway     LIVE_TRADING                False         False = paper account; True = live account
  Signal         EMA_FAST_BARS               36            Number of 3-min bars for fast EMA
  Signal         EMA_SLOW_BARS               180           Number of 3-min bars for slow EMA
  Signal         EMA_DIRECTION_THRESHOLD     1.5 pts       Scalable
  Entry          SPREAD_WIDTH                5.0 pts       Scalable. Entry butterfly spread width.
  Entry          CONV_SPREAD_WIDTH           10.0 pts      Scalable. Conversion spread width (must be > SPREAD_WIDTH). Used for IBKR zero-risk workaround.
  Entry          MAX_PREMIUM                 $200          Scalable
  Entry          MAX_BID_ASK_WIDTH           $1.00         Scalable
  Entry          MAX_ACTIVE_TRADES           1             Only 1 active trade at a time
  Entry          POSITION_SIZE               1             Contracts per trade. If < 1, fraction of buying power.
  Entry          VIX_MAX_ENTRY               35.0          
  Entry          ENTRY_TIMEOUT_MIN           15            Minutes before unfilled entry is cancelled
  Exit           WIN_TARGET_BUFFER           1.0 pts       Scalable
  Exit           MIN_CONV_CREDIT_PCT         1.05          Minimum credit as multiple of premium paid
  Exit           ENTRY_SLIPPAGE_FACTOR       1.05          Entry limit = ask × factor
  Exit           SELL_SLIPPAGE_FACTOR        0.95          Win-sell limit = bid × factor
  Park           PARK_CONVERT_EMA_LOW        4.0 pts       Scalable
  Park           PARK_CONVERT_EMA_MID        5.0 pts       Scalable
  Park           PARK_CONVERT_EMA_HIGH       6.0 pts       Scalable
  Park           VIX_BREAK_LOW               18.0          VIX9D below this = use LOW threshold
  Park           VIX_BREAK_HIGH              25.0          VIX9D above this = use HIGH threshold
  Park           ACTIVE_ADVERSE_MOVE         10.0 pts      Scalable
  Timing         TRADING_START_TIME          10:00 ET      
  Timing         LAST_ENTRY_TIME             14:00 ET      
  Timing         PM_BOUNDARY                 13:00 ET      
  Timing         INTRINSIC_EXIT_TIME         14:30 ET      
  -------------- --------------------------- ------------- -----------------------------------------------

7. IBKR Migration Status
========================

CTV2 has been fully migrated from the Tradier REST/WebSocket API to
Interactive Brokers via IB Gateway and ib_insync. The migration was
structured in four phases:

  ----------- ----------------------------------------------------------------------------------------------------------------------------------- ----------------------------------------
  **Phase**   **Scope**                                                                                                                           **Status**
  Phase 1     ibkr_stream.py (market data), ibkr_scale.py (parameter scaling), config UNDERLYING                                                Complete
  Phase 2     ibkr_client.py --- get_positions, get_todays_expiration, get_option_buying_power, get_quote, get_order, get_eod_report           Complete (merged into ibkr_orders.py)
  Phase 3     ibkr_orders.py --- strike calc, spread quotes, ComboLeg order placement, cancel. IBKROrderManager consolidates phases 2+3.       Complete
  Phase 4     Runner import swap, stream constructor cleanup, preflight update, Tradier module deletion                                          Complete
  ----------- ----------------------------------------------------------------------------------------------------------------------------------- ----------------------------------------

No Tradier fallback exists. The system connects exclusively to IB Gateway.

7.1 Connection Architecture
---------------------------

Two independent ib_insync IB() connections are maintained
simultaneously against the same IB Gateway server:

  ------------------ -------------- ---------------------------------- ------------------------------------------------------
  **Client**         **clientId**   **Thread**                         **Role**
  IBKRStream         1              Daemon thread (own asyncio loop)   Real-time SPX market data ticks
  IBKROrderManager   2              Main thread / order threads        All order management, account queries, position data
  ------------------ -------------- ---------------------------------- ------------------------------------------------------

IBKROrderManager is instantiated in TradingApp.__init__ for immediate
availability. IBKRStream is started in run_live() after warmup completes.

8. Key Design Decisions
=======================

  ----------------------------------------------- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  **Decision**                                    **Rationale**
  ib_insync over raw ibapi                        Asyncio-native; cleaner callback model; simpler synchronous API surface for order management from non-async threads.
  Two IB() connections (stream + orders)          Avoids contention between continuous tick delivery and blocking order/account calls. IB Gateway natively supports multiple simultaneous clients.
  IBKROrderManager consolidates client + orders   Eliminates the TradierClient → TradierOrderManager constructor chain. Single object; single connection; simpler lifecycle.
  ibkr_scale.py as standalone module             Scaling logic is isolated --- not embedded in runner or config. Runner reads from ScaledConfig exclusively for scalable params; config file always stores canonical SPX values.
  Runner logic untouched                         EMA math, state machine, entry/exit --- zero diff from the Tradier version. Reduces regression risk; the migration is purely an infrastructure swap.
  Real trading on both paper and live accounts    No synthetic mode. Both LIVE_TRADING=False (paper) and True (live) send real orders to IBKR and poll actual fills. Enables full integration testing with genuine order fills.
  CONV_SPREAD_WIDTH workaround                   Interactive Brokers rejects zero-risk conversions. Wider conversion spread avoids rejection; collapse thread narrows it back post-fill.
  SPXW 0DTE only                                 Same-day expiration eliminates overnight risk. All trades open and close within a single session; no position carry.
  ----------------------------------------------- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

9. Removed / Deprecated Features
=================================

**Gap-Open Logic (Removed):**
- GAP_OPEN_THRESHOLD parameter has been removed from ibkr_scale.py and config_ctv2.py.
- _check_gap_open() function no longer exists.
- All entry signals come exclusively from EMA separation logic.
- No gap-based entry suppression or trading suspension.

**Preview/Synthetic Mode (Removed):**
- The -1 sentinel value for place_entry() and place_win_sell() no longer exists.
- Paper mode (LIVE_TRADING=False) sends genuine orders to IBKR's paper account and polls real fills.
- Live mode (LIVE_TRADING=True) sends genuine orders to IBKR's live account and polls real fills.
- All order fills are from IBKR --- no synthetic simulation path.

10. Buying Power and Position Sizing
=====================================

**get_option_buying_power():**

When querying available option buying power from IBKR, the method retries
up to 5 times with 2-second delays between attempts, waiting for IB Gateway
to sync account data from the broker. This accounts for occasional latency
in account updates.

**POSITION_SIZE Configuration:**

When POSITION_SIZE >= 1, it is interpreted as the number of contracts to
trade per entry.

When POSITION_SIZE < 1 (e.g., 0.05), it is interpreted as a fraction of
available buying power. In this case, the effective contract count is:

    contracts = floor(available_buying_power × POSITION_SIZE / per_contract_cost)

This allows automatic position scaling based on real-time account equity.
