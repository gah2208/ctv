@echo off
REM ============================================================
REM  RESTART.bat - CTV2 Restart Trading Launcher
REM  Revision: 1.0
REM  Calls RESTART.ps1 via PowerShell.
REM  This file must exist in C:\CTV for the shortcut to work.
REM ============================================================
powershell.exe -ExecutionPolicy Bypass -NoProfile -File "C:\CTV\RESTART.ps1"
pause
