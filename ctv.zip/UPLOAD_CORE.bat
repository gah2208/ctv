@echo off
:: UPLOAD_CORE.bat
:: Revision: 1.0
:: Packages the 6 most frequently changed files into upload_core.zip.
:: Use this for sessions involving ibkr_orders, ibkr_stream, or ctv2_runner.
::
:: Files included:
::   ibkr_orders.py       - Order management (changes almost every session)
::   ibkr_stream.py       - Market data stream
::   ctv2_runner.py       - Main runner
::   version_check.ps1    - Version manifest  (always needed)
::   VERSION              - Version number     (always needed)
::   CHANGELOG.md         - Change log        (always needed)

cd /d C:\CTV

echo Building upload_core.zip...
powershell -NoProfile -Command ^
    "Compress-Archive -Force -Path @('ibkr_orders.py','ibkr_stream.py','ctv2_runner.py','version_check.ps1','VERSION','CHANGELOG.md') -DestinationPath 'upload_core.zip'"

if %errorlevel%==0 (
    echo Done. Opening folder...
    explorer /select,"C:\CTV\upload_core.zip"
) else (
    echo ERROR: zip failed.
    pause
)
