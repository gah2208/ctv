# ============================================================
#  config_editor.ps1 - Launch CTV2 Config Editor  v1.1
#  Place this file in C:\CTV
#
#  v1.1 - Added version header
# ============================================================

Set-Location -Path "C:\CTV"
python ctv2_config_editor.py
