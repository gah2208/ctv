# Copyright (c) Gregory Howard 2026  All rights reserved
"""
ibkr_orders.py - Order Management for CTV2 (IBKR / ib_insync)
==============================================================
Replaces tradier_client.py + tradier_orders.py.  Provides
IBKROrderManager, a single class that covers everything the runner
needs from both the old TradierClient and TradierOrderManager layers:

  - Strike calculation (calc_strikes, calc_chained_strikes)
  - Spread quotes  (get_spread_quote)
  - Order placement (place_entry, place_win_sell, cancel)
  - Order status polling (get_order)
  - Account / position queries (get_positions, get_option_buying_power)
  - Session setup (get_todays_expiration, set_expiration)
  - EOD accounting (get_eod_report)

Connection
----------
  Connects to IB Gateway at 127.0.0.1:7497 (paper) with clientId=2.
  IBKRStream uses clientId=1.  Both connect to the same gateway server;
  IB Gateway supports multiple simultaneous client connections.

  IBKROrderManager owns a dedicated daemon thread (_loop_thread) that
  runs asyncio.loop.run_forever().  All ib_insync API calls are
  dispatched to this thread via _run_on_loop() / _call_on_loop() so
  that ib_insync's internal util.getLoop() always returns the correct
  event loop regardless of which thread calls a public method.

  IBKRStream runs its own independent asyncio loop in a separate daemon
  thread (clientId=1).  The two IB() instances are completely
  independent and never share state.

Combo (BAG) orders
------------------
  Vertical spread entry:
    Order.action = 'BUY'    (paying a net debit)
    ComboLeg[0]: long_strike  -> BUY
    ComboLeg[1]: short_strike -> SELL
    lmtPrice = debit_per_share (positive)

  Win-sell / butterfly conversion:
    Order.action = 'SELL'   (receiving a net credit)
    ComboLeg[0]: short_strike -> SELL  (add second short to complete -2 center)
    ComboLeg[1]: conv_strike  -> BUY   (buy far wing)
    lmtPrice = credit_per_share (positive, minimum we will accept)

Revision history
----------------
Rev 16: Gateway reconnect handling. Connection management moved from a
       one-shot connectAsync in __init__ to a persistent _connect_forever
       coroutine running on the loop thread. On any disconnect (daily
       11:45 PM restart, Sunday weekly restart, manual gateway close,
       or multi-day holiday weekend) the coroutine logs once, waits
       _RECONNECT_DELAY seconds, and retries. Handles up to 5 days of
       gateway downtime without killing the process. _connected
       threading.Event added so __init__ blocks until the first
       successful connection. _gateway_down flag tracks reconnect state.
       _account_subscribed reset to False on reconnect so
       reqAccountUpdates re-subscribes after gateway comes back.
Rev 15: Option symbol corrected from SPXW to SPX with tradingClass=SPXW
       in _option() and precache_contracts(). IBKR requires symbol=SPX
       for all SPX index options; tradingClass=SPXW distinguishes the
       weekly series from the standard monthly (tradingClass=SPX).
       Using symbol=SPXW directly is not a valid security definition
       and caused Error 200 on every contract qualification attempt.
Rev 14: Dedicated event loop thread introduced.  IBKROrderManager now
       owns a daemon thread (_loop_thread) that calls loop.run_forever().
       All ib_insync API calls are dispatched to this thread via
       _run_on_loop() (for coroutines) and _call_on_loop() (for sync
       callables).  This is the correct threading model for ib_insync:
       util.getLoop() returns the calling thread's event loop, so every
       ib_insync call must originate from the thread that owns the loop.
       Calling any ib.* method from the runner's bar-processing thread
       was silently using the wrong (or no) event loop, causing the
       'Client object has no attribute loop' crash and making every
       previous workaround (client.loop, IB.loop, run_coroutine_threadsafe
       with a stale loop reference) inherently unreliable.
       nest_asyncio.apply(self._loop) called in _run_loop() to patch the
       new loop explicitly - ib_insync's import-time nest_asyncio.apply()
       only patches the default loop, not loops created afterward.  Without
       this, ib.sleep() and reqAccountUpdates() raise 'This event loop is
       already running' when called from within a _call_on_loop coroutine.
       Changes:
         - __init__: creates asyncio.new_event_loop(), starts daemon
           thread, connects via connectAsync dispatched to the loop.
         - _run_loop(): new - sets event loop, signals ready, runs forever.
         - _run_on_loop(coro, timeout): new - run_coroutine_threadsafe wrapper.
         - _call_on_loop(func, *args, timeout): new - wraps sync callable
           as coroutine, dispatches via _run_on_loop.
         - _qualify_contracts(): rewritten using qualifyContractsAsync
           dispatched via _run_on_loop. No loop attribute access.
         - _snapshot_quotes(): rewritten as async coroutine using
           asyncio.sleep (not ib.sleep), dispatched via _run_on_loop.
         - place_entry / place_win_sell / place_collapse: placeOrder +
           sleep(0) wrapped in _call_on_loop.
         - cancel(): full body wrapped in _call_on_loop.
         - get_order(): full body wrapped in _call_on_loop.
         - _start_account_subscription(): reqAccountUpdates dispatched
           to loop thread via background thread + _call_on_loop.
         - get_option_buying_power(): sleep(1) wrapped in _call_on_loop.
         - get_todays_expiration() live: reqSecDefOptParams wrapped in
           _call_on_loop.
         - disconnect(): ib.disconnect() on loop thread, then loop.stop().
Rev 13: _qualify_contracts() loop access fixed. self._ib.loop replaced
       with self._ib.client.loop - IB.loop property was removed in newer
       ib_insync versions, causing 'IB object has no attribute loop' on
       every get_spread_quote call and blocking all entries.
Rev 12: reqAccountUpdates() moved to a daemon thread via
       _start_account_subscription(). ib_insync documents reqAccountUpdates
       as blocking - it calls _run() and waits for full account + portfolio
       data before returning. Running it on the main thread froze startup
       at [TDCL] Option buying power. Background thread lets it complete
       while the runner continues initialising.
Rev 11: reqAccountUpdates() moved out of __init__ entirely. Called lazily
       on first get_option_buying_power() invocation, by which time the
       event loop is fully running. Calling it in __init__ blocked startup
       even without time.sleep() because the event loop is not yet stable
       immediately after connect().
Rev 10: reqAccountUpdates() made fire-and-forget. Removed time.sleep(2)
       that blocked startup after connection - caused consistent lockup
       at [OM  ] IBKROrderManager connected. Data arrives async;
       get_option_buying_power() pumps the event loop when needed.
Rev 9: reqAccountUpdates() subscription added in __init__ (fixes $0 buying
       power at startup). disconnect() method added for clean shutdown.
       Preview/synthetic mode parameters removed from place_entry,
       place_win_sell, place_collapse. Constructor accepts client_id param
       (replaces hardcoded _CLIENT_ID constant).
Rev 8: _qualify_contracts() helper added.  Replaces all direct calls to
       self._ib.qualifyContracts() which raised 'event loop already
       running' when invoked from the runner's bar-processing thread.
       The helper uses asyncio.run_coroutine_threadsafe to submit
       qualifyContractsAsync to the already-running ib_insync loop and
       blocks for the result - safe to call from any thread.  Fixes
       precache_contracts, _option, and get_todays_expiration (live).
Rev 7: get_todays_expiration() rewritten.  Paper mode short-circuits
       immediately (no IBKR call) - validation is advisory-only in paper
       and contract queries triggered Error 200.  Live mode uses
       reqSecDefOptParams on the SPX index conId to retrieve the full set
       of valid SPXW expiration dates and confirms today is among them.
Rev 6: get_todays_expiration() fixed.  Replaced qualifyContracts() on a
       hardcoded strike-5000 contract with reqContractDetails() on an
       incomplete contract (no strike).  The old approach fired IBKR
       Error 200 whenever strike 5000 had no security definition (i.e.
       always, at current SPX levels).  reqContractDetails with no strike
       returns all listed strikes for the expiry; a non-empty result
       confirms today is a valid SPXW expiration day.
Rev 5: CONV_SPREAD_WIDTH support.
       calc_strikes and calc_chained_strikes use self._cfg.CONV_SPREAD_WIDTH
       for conv_strike (was SPREAD_WIDTH). place_collapse() added: net-debit
       BAG order that buys the inner wing / closes outer wing immediately
       after a WIN fill, reducing the conversion spread to entry width.
Rev 4: IB_HOST and IB_PORT now read from config_ctv2 at module load
       (getattr with fallback to 127.0.0.1:7497). Matches ibkr_stream.py
       Rev 2. Allows gateway config via Config Editor.
Rev 3: get_vix9d() added. Returns current VIX9D price via yfinance
       (symbol ^VIX9D). Free, no API key, no IBKR subscription required.
       ~15-minute delay is acceptable for a 60-second gate poll.
       Replaces self.client.get_quote('VIX9D') Tradier call in runner's
       _start_vix_poll.
Rev 2: precache_contracts(center) added.  Bulk-qualifies all SPXW calls and
       puts within +/-1.5% of center price at SPREAD_WIDTH increments via a
       single batched qualifyContracts() call.  _option() triggers an
       automatic re-cache on any cache miss so entries beyond the initial
       radius always recover.  Re-cache is guarded by _recaching flag to
       prevent concurrent invocations.
Rev 1: Initial implementation.  Replaces tradier_client.py (Rev 13) and
       tradier_orders.py (Rev 11).  Public interface mirrors the two Tradier
       classes exactly so ctv2_runner.py changes are limited to swapping
       imports and collapsing self.client into self.order_manager.
"""

from __future__ import annotations

import asyncio
import logging
import math
import threading
from collections import defaultdict
from datetime import date as _date
from typing import Dict, List, Optional, Tuple

from ib_insync import IB, ComboLeg, Contract, LimitOrder, Option

import config_ctv2 as cfg
from ibkr_scale import build_scaled_config


# ---------------------------------------------------------------------------
# Connection constants  (IB Gateway paper port; live = 7496)
# ---------------------------------------------------------------------------

_HOST       = getattr(cfg, 'IB_HOST', '127.0.0.1')
_PORT       = getattr(cfg, 'IB_PORT', 7497)   # paper=7497  live=7496
_TIMEOUT    = 15        # seconds to wait for gateway handshake
_QUOTE_WAIT = 3.0       # seconds to wait for snapshot market data


# ---------------------------------------------------------------------------
# Tick rounding  (identical to tradier_orders.py)
# ---------------------------------------------------------------------------

def round_to_tick(price: float) -> float:
    """
    Round price DOWN to nearest valid SPX option tick.
        price < $3.00  ->  $0.05 tick
        price >= $3.00 ->  $0.10 tick

    Uses integer cent arithmetic to eliminate float drift.
    Always rounds DOWN (floor) - conservative for both entries and exits.
    """
    cents      = int(round(price * 100, 8))
    tick_cents = 5 if price < 3.00 else 10
    return (cents // tick_cents) * tick_cents / 100.0


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _safe_float(val) -> float:
    """Convert ib_insync tick values (may be NaN or None) to 0.0."""
    if val is None:
        return 0.0
    try:
        f = float(val)
        return 0.0 if math.isnan(f) or math.isinf(f) else f
    except (TypeError, ValueError):
        return 0.0


def _occ_from_contract(contract) -> Optional[str]:
    """
    Build an OCC-format symbol from an ib_insync contract object.

    OCC format (matches runner's _parse_occ regex):
        SPXW{YY}{MM}{DD}{C|P}{8-digit-strike*1000}
    e.g. SPXW260401C06570000

    Returns None if the contract cannot be mapped.
    """
    expiry = (contract.lastTradeDateOrContractMonth or '').replace('-', '')
    if len(expiry) < 8:
        return None
    yy = expiry[2:4]
    mm = expiry[4:6]
    dd = expiry[6:8]
    right = (contract.right or '').upper()[:1]
    if right not in ('C', 'P'):
        return None
    strike_enc = f'{int(round(contract.strike * 1000)):08d}'
    return f'SPXW{yy}{mm}{dd}{right}{strike_enc}'


# ---------------------------------------------------------------------------
# IBKR order status -> Tradier-compatible status string
# ---------------------------------------------------------------------------

_STATUS_MAP: Dict[str, str] = {
    'Filled':        'filled',
    'Cancelled':     'canceled',
    'Canceled':      'canceled',
    'Inactive':      'canceled',
    'Submitted':     'open',
    'PreSubmitted':  'open',
    'ApiPending':    'open',
    'PendingSubmit': 'open',
    'PendingCancel': 'open',
    'Unknown':       'open',
}


# ---------------------------------------------------------------------------
# Main class
# ---------------------------------------------------------------------------

class IBKROrderManager:
    """
    Single replacement for TradierClient + TradierOrderManager.

    Instantiate once in ctv2_runner.__init__() and assign to both
    self.order_manager and self.client so all existing call sites work
    without further runner changes:

        self.order_manager = IBKROrderManager()
        self.client        = self.order_manager

    Threading model
    ---------------
    IBKROrderManager owns a single daemon thread (_loop_thread) that runs
    asyncio.loop.run_forever().  ALL ib_insync API calls are dispatched to
    this thread via _run_on_loop() or _call_on_loop().

    This is required because ib_insync 0.9.86's util.getLoop() returns
    asyncio.get_event_loop_policy().get_event_loop() - the calling thread's
    event loop.  Any ib.* call made from a different thread (e.g. the
    runner's bar-processing thread) uses the wrong loop, causing failures.
    By funneling all calls through a single thread with a stable running
    loop, this problem is eliminated entirely.

    nest_asyncio (a required ib_insync dependency, applied at import) allows
    ib.sleep() to be called from within a coroutine already running on the
    loop, which is needed by the order placement and status poll paths.

    All public methods are safe to call from any thread.
    """

    def __init__(self, client_id: int = 2):
        self._ib              = IB()
        self._cfg             = build_scaled_config()
        self._client_id       = client_id
        self._expiration      = ''   # 'YYYY-MM-DD' set by set_expiration()
        self._expiration_ib   = ''   # 'YYYYMMDD'   IBKR API format
        self._opt_cache: Dict[Tuple[str, float], Option] = {}
        self._recaching: bool = False
        self._account_subscribed: bool = False

        # Reconnect state
        self._connected:    threading.Event = threading.Event()
        self._gateway_down: bool            = False

        # ------------------------------------------------------------------
        # Dedicated event loop thread.
        # Creates a brand-new event loop, starts the daemon thread that owns
        # it, waits for the thread to signal ready, then schedules
        # _connect_forever on that loop.  _connect_forever manages the IB
        # connection for the lifetime of the process, reconnecting silently
        # after any gateway disconnect (daily restart, weekend, holiday,
        # up to 5 days).  __init__ blocks until the first successful
        # connection is established.
        # ------------------------------------------------------------------
        self._loop        = asyncio.new_event_loop()
        self._loop_ready  = threading.Event()
        self._loop_thread = threading.Thread(
            target = self._run_loop,
            daemon = True,
            name   = 'OM-Loop',
        )
        self._loop_thread.start()
        if not self._loop_ready.wait(timeout=10):
            raise RuntimeError('[OM  ] Event loop thread did not start within 10 s')

        # Schedule the persistent connection coroutine and wait for first connect.
        asyncio.run_coroutine_threadsafe(self._connect_forever(), self._loop)
        if not self._connected.wait(timeout=_TIMEOUT + 5):
            raise RuntimeError(
                f'[OM  ] Could not connect to IB Gateway {_HOST}:{_PORT} '
                f'within {_TIMEOUT + 5}s'
            )

    # -----------------------------------------------------------------------
    # Event loop thread
    # -----------------------------------------------------------------------

    def _run_loop(self) -> None:
        """
        Entry point for the dedicated event loop daemon thread.
        Sets the event loop for this thread (so util.getLoop() returns the
        correct loop), applies nest_asyncio to the loop so that blocking
        ib_insync methods (ib.sleep, reqAccountUpdates, etc.) can call
        loop.run_until_complete() from within a coroutine already running
        on this loop, then runs forever until disconnect() calls loop.stop().

        nest_asyncio.apply() called at ib_insync import time patches the
        default event loop only - it must be explicitly applied to any
        new loop created after import.
        """
        import nest_asyncio
        asyncio.set_event_loop(self._loop)
        nest_asyncio.apply(self._loop)
        self._loop.call_soon(self._loop_ready.set)
        self._loop.run_forever()

    async def _connect_forever(self) -> None:
        """
        Persistent connection coroutine running on the OM-Loop thread.
        Manages the IB Gateway connection for the entire process lifetime.

        On first call: connects and sets self._connected so __init__
        can unblock.

        On any subsequent disconnect (IB Gateway daily 11:45 PM restart,
        Sunday weekly restart requiring user validation, manual close,
        or multi-day holiday weekend up to 5 days): logs a single message,
        waits _RECONNECT_DELAY seconds, creates a fresh IB() instance,
        and reconnects.  Retries indefinitely - the only exit is
        disconnect() calling loop.stop().

        A fresh IB() is created on every reconnect so ib_insync internal
        state is fully reset.  All public methods reference self._ib
        which is updated on each reconnect.
        """
        _RECONNECT_DELAY = 30   # seconds between reconnect attempts

        first_connect = True
        while True:
            try:
                self._ib = IB()
                if first_connect:
                    print(f'[OM  ] Connecting to IB Gateway {_HOST}:{_PORT} '
                          f'(clientId={self._client_id})')
                await self._ib.connectAsync(
                    _HOST, _PORT,
                    clientId = self._client_id,
                    timeout  = _TIMEOUT,
                )
                if first_connect:
                    print(f'[OM  ] IBKROrderManager connected '
                          f'clientId={self._client_id}')
                    first_connect = False
                else:
                    print('[OM  ] IBKROrderManager reconnected to IB Gateway')
                    # Re-subscribe account updates after reconnect
                    self._account_subscribed = False

                self._gateway_down = False
                self._connected.set()
                logging.getLogger('ib_insync').setLevel(logging.ERROR)

                # Wait here until the gateway disconnects
                while self._ib.isConnected():
                    await asyncio.sleep(5)

                # Gateway disconnected
                if not self._gateway_down:
                    print('[OM  ] IB Gateway disconnected - waiting for restart')
                    self._gateway_down = True
                    logging.getLogger('ib_insync').setLevel(logging.CRITICAL)
                self._connected.clear()

            except Exception as e:
                if not self._gateway_down:
                    if first_connect:
                        print(f'[OM  ] Connection error: {e}')
                    else:
                        print('[OM  ] IB Gateway disconnected - waiting for restart')
                    self._gateway_down = True
                    logging.getLogger('ib_insync').setLevel(logging.CRITICAL)
                self._connected.clear()

            await asyncio.sleep(_RECONNECT_DELAY)

    def _run_on_loop(self, coro, timeout: float = 30):
        """
        Submit an async coroutine to the IB event loop and block the
        calling thread until it completes.  Safe to call from any thread.
        """
        return asyncio.run_coroutine_threadsafe(coro, self._loop).result(
            timeout=timeout
        )

    def _call_on_loop(self, func, *args, timeout: float = 30):
        """
        Run a synchronous callable on the IB event loop thread and return
        its result.  Wraps the callable as a coroutine body so it executes
        in the correct thread/loop context.

        nest_asyncio (applied by ib_insync at import) allows the callable
        to itself call ib.sleep() or other blocking ib_insync methods that
        internally invoke loop.run_until_complete().
        """
        async def _wrapper():
            return func(*args)
        return self._run_on_loop(_wrapper(), timeout=timeout)

    # -----------------------------------------------------------------------
    # Shutdown
    # -----------------------------------------------------------------------

    def disconnect(self) -> None:
        """
        Cleanly disconnect from IB Gateway and stop the event loop thread.
        Must be called on shutdown to prevent 'clientId already in use'
        errors on restart.
        """
        self._gateway_down = True   # suppress reconnect message on intentional close
        try:
            if self._ib.isConnected():
                self._call_on_loop(self._ib.disconnect, timeout=10)
                print(f'[OM  ] IBKROrderManager disconnected '
                      f'clientId={self._client_id}')
        except Exception as e:
            print(f'[OM  ] disconnect error: {e}')
        finally:
            self._loop.call_soon_threadsafe(self._loop.stop)

    # -----------------------------------------------------------------------
    # Thread-safe contract qualification
    # -----------------------------------------------------------------------

    def _qualify_contracts(self, *contracts):
        """
        Qualify one or more contracts via the IB event loop thread.
        Uses qualifyContractsAsync (native coroutine) dispatched via
        _run_on_loop - no loop attribute access required.
        """
        return self._run_on_loop(
            self._ib.qualifyContractsAsync(*contracts)
        )

    # -----------------------------------------------------------------------
    # Expiration
    # -----------------------------------------------------------------------

    def set_expiration(self, expiration: str) -> None:
        """
        Set today's SPXW expiration date ('YYYY-MM-DD').
        Clears the contract cache (new day, new conIds).
        Must be called before any order or quote method.
        """
        self._expiration    = expiration
        self._expiration_ib = expiration.replace('-', '')
        self._opt_cache.clear()
        print(f'[OM  ] Expiration set: {expiration}')

    def _require_expiration(self) -> None:
        if not self._expiration:
            raise RuntimeError(
                '[OM  ] set_expiration() must be called before placing orders'
            )

    # -----------------------------------------------------------------------
    # Contract cache
    # -----------------------------------------------------------------------

    def _option(self, right: str, strike: float) -> Option:
        """
        Return a qualified SPXW Option contract for the current expiration.
        Results are cached for the session; qualification is called at most
        once per (right, strike) pair per trading day.

        On a cache miss the single contract is lazily qualified immediately
        so the calling trade can proceed.  A full re-cache is then triggered
        centered on the missed strike so subsequent calls in the same area
        will hit the cache.  The _recaching guard prevents a re-cache from
        spawning another re-cache.
        """
        self._require_expiration()
        key = (right.upper(), round(strike, 2))
        if key in self._opt_cache:
            return self._opt_cache[key]

        # Lazy qualify - single contract round trip via loop thread (~100 ms)
        opt = Option('SPX', self._expiration_ib, strike, right.upper(), 'CBOE',
                     tradingClass='SPXW')
        qualified = self._qualify_contracts(opt)
        if not qualified:
            raise RuntimeError(
                f'[OM  ] Could not qualify SPXW {right} {strike:.1f} '
                f'exp={self._expiration} - check IB Gateway market data subscription'
            )
        self._opt_cache[key] = qualified[0]

        # Re-cache around the missed strike unless already doing so
        if not self._recaching:
            print(f'[OM  ] Cache miss {right} {strike:.1f} - '
                  f're-caching around {strike:.1f}')
            self.precache_contracts(strike)

        return self._opt_cache[key]

    def precache_contracts(self, center: float) -> None:
        """
        Bulk-qualify all SPXW calls and puts within +/-1.5% of center price,
        at SPREAD_WIDTH strike increments, and store results in _opt_cache.

        Called at 9:33 ET using the close of the 9:30 bar as center, and
        automatically on any cache miss (_option re-cache path).

        At SPX ~6900: radius = 104 pts -> ~42 strikes x 2 rights = ~84
        contracts.  A single batched qualifyContractsAsync call typically
        completes in 2-4 seconds.  Already-cached contracts are skipped
        so re-cache runs are fast when most strikes are already warm.
        """
        self._require_expiration()
        self._recaching = True
        try:
            inc    = self._cfg.SPREAD_WIDTH
            radius = center * 0.015                          # 1.5%
            lo     = math.floor((center - radius) / inc) * inc
            hi     = math.ceil( (center + radius) / inc) * inc

            to_qualify: List[Option] = []
            s = lo
            while s <= hi + 1e-9:
                sr = round(s, 2)
                for right in ('C', 'P'):
                    if (right, sr) not in self._opt_cache:
                        to_qualify.append(
                            Option('SPX', self._expiration_ib, sr, right, 'CBOE',
                                   tradingClass='SPXW')
                        )
                s = round(s + inc, 2)

            n_total = int(round((hi - lo) / inc + 1)) * 2
            if not to_qualify:
                print(f'[OM  ] Precache: all {n_total} contracts already cached '
                      f'(SPX {center:.1f} +/-1.5% = {lo:.1f}-{hi:.1f})')
                return

            print(f'[OM  ] Precaching {len(to_qualify)} contracts '
                  f'(SPX {center:.1f} +/-1.5% = {lo:.1f}-{hi:.1f} '
                  f'inc={inc})')

            qualified = self._qualify_contracts(*to_qualify)

            count = 0
            for opt in qualified:
                right = opt.right.upper()[:1]
                key   = (right, round(opt.strike, 2))
                self._opt_cache[key] = opt
                count += 1

            print(f'[OM  ] Precache complete: {count}/{len(to_qualify)} qualified '
                  f'({len(self._opt_cache)} total cached)')

        except Exception as e:
            print(f'[OM  ] precache_contracts error: {e}')
        finally:
            self._recaching = False

    def _build_bag(self, legs_spec: List[Tuple[Option, str]]) -> Contract:
        """
        Build a BAG (combo) Contract from a list of (Option, 'BUY'|'SELL') tuples.
        """
        bag = Contract(
            symbol   = 'SPXW',
            secType  = 'BAG',
            currency = 'USD',
            exchange = 'CBOE',
        )
        bag.comboLegs = []
        for opt, action in legs_spec:
            leg          = ComboLeg()
            leg.conId    = opt.conId
            leg.ratio    = 1
            leg.action   = action.upper()
            leg.exchange = 'CBOE'
            bag.comboLegs.append(leg)
        return bag

    # -----------------------------------------------------------------------
    # Snapshot market data
    # -----------------------------------------------------------------------

    async def _snapshot_quotes_async(self, *options: Option) -> Dict[int, object]:
        """
        Async coroutine: request snapshot market data for one or more
        option contracts, wait _QUOTE_WAIT seconds for data to arrive,
        cancel all requests, return {conId: Ticker} dict.

        Uses asyncio.sleep (not ib.sleep) so the loop stays free to
        process incoming tick data during the wait.

        Dispatched via _run_on_loop so it always executes on the
        dedicated IB event loop thread.
        """
        tickers: Dict[int, object] = {}
        for opt in options:
            tickers[opt.conId] = self._ib.reqMktData(opt, '', True, False)
        await asyncio.sleep(_QUOTE_WAIT)
        for opt in options:
            self._ib.cancelMktData(opt)
        return tickers

    def _snapshot_quotes(self, *options: Option) -> Dict[int, object]:
        return self._run_on_loop(
            self._snapshot_quotes_async(*options),
            timeout=_QUOTE_WAIT + 5,
        )

    # -----------------------------------------------------------------------
    # Strike calculators  (identical to TradierOrderManager, scaled)
    # -----------------------------------------------------------------------

    def calc_strikes(self,
                     spx:       float,
                     direction: str) -> Tuple[float, float, float]:
        """
        First-OTM vertical + conversion strikes.
        Strike increment = SPREAD_WIDTH from ScaledConfig (5.0 for SPX,
        0.5 for XSP).  Conversion wing uses CONV_SPREAD_WIDTH.
        Returns (long_strike, short_strike, conv_strike).
        """
        inc      = self._cfg.SPREAD_WIDTH
        conv_inc = self._cfg.CONV_SPREAD_WIDTH
        if direction == 'UP':
            long_s  = math.ceil(spx / inc) * inc
            short_s = long_s  + inc
            conv_s  = short_s + conv_inc
        else:
            long_s  = math.floor(spx / inc) * inc
            short_s = long_s  - inc
            conv_s  = short_s - conv_inc
        return long_s, short_s, conv_s

    def calc_chained_strikes(self,
                              conv_strike: float,
                              direction:   str) -> Tuple[float, float, float]:
        """
        Strikes for a chained re-entry.  conv_strike of the completed
        trade becomes new long_strike.
        Returns (long_strike, short_strike, conv_strike).
        """
        inc      = self._cfg.SPREAD_WIDTH
        conv_inc = self._cfg.CONV_SPREAD_WIDTH
        long_s   = conv_strike
        if direction == 'UP':
            short_s = long_s + inc
            conv_s  = short_s + conv_inc
        else:
            short_s = long_s - inc
            conv_s  = short_s - conv_inc
        return long_s, short_s, conv_s

    # -----------------------------------------------------------------------
    # Spread quote
    # -----------------------------------------------------------------------

    def get_spread_quote(self,
                          direction:    str,
                          long_strike:  float,
                          short_strike: float) -> Tuple[float, float]:
        """
        Snapshot bid/ask for a vertical spread (per-share, not * 100).
        Returns (spread_bid, spread_ask).
        spread_ask = long_ask  - short_bid  (cost to enter)
        spread_bid = long_bid  - short_ask  (credit if sold)
        Returns (0.0, 0.0) on any failure.
        """
        right = 'C' if direction == 'UP' else 'P'
        try:
            long_opt  = self._option(right, long_strike)
            short_opt = self._option(right, short_strike)

            ticks = self._snapshot_quotes(long_opt, short_opt)
            lt    = ticks.get(long_opt.conId)
            st    = ticks.get(short_opt.conId)

            long_bid  = _safe_float(lt.bid  if lt else None)
            long_ask  = _safe_float(lt.ask  if lt else None)
            short_bid = _safe_float(st.bid  if st else None)
            short_ask = _safe_float(st.ask  if st else None)

            spread_bid = long_bid  - short_ask
            spread_ask = long_ask  - short_bid

            print(f'[OM  ] Quote {direction} {int(long_strike)}/{int(short_strike)} '
                  f'bid=${spread_bid:.2f} ask=${spread_ask:.2f}')
            return spread_bid, spread_ask

        except Exception as e:
            print(f'[OM  ] get_spread_quote error: {e}')
            return 0.0, 0.0

    # -----------------------------------------------------------------------
    # Order placement - entry
    # -----------------------------------------------------------------------

    def place_entry(self,
                    direction:    str,
                    long_strike:  float,
                    short_strike: float,
                    ask_price:    float,
                    contracts:    int   = 1) -> Optional[int]:
        """
        Place a vertical spread entry order.

        Entry is a net-debit BAG order:
            Order.action = 'BUY'
            Leg 0: long_strike  -> buy_to_open
            Leg 1: short_strike -> sell_to_open
            lmtPrice = round_to_tick(ask * ENTRY_SLIPPAGE)

        Returns order ID on success, None on failure.
        """
        right = 'C' if direction == 'UP' else 'P'
        limit = round_to_tick(ask_price * cfg.ENTRY_SLIPPAGE)

        print(f'[OM  ] Entry payload: BUY {contracts}x '
              f'{int(long_strike)}/{int(short_strike)} {direction} '
              f'LMT ${limit:.2f} '
              f'(ask=${ask_price:.2f} x {cfg.ENTRY_SLIPPAGE})')

        try:
            long_opt  = self._option(right, long_strike)
            short_opt = self._option(right, short_strike)
            bag       = self._build_bag([(long_opt, 'BUY'), (short_opt, 'SELL')])
            order     = LimitOrder('BUY', contracts, limit)

            def _place():
                trade = self._ib.placeOrder(bag, order)
                self._ib.sleep(0)   # flush event queue so orderId is confirmed
                return trade

            trade = self._call_on_loop(_place)
            oid   = trade.order.orderId
            print(f'[OM  ] Order submitted: id={oid}')
            return int(oid)
        except Exception as e:
            print(f'[OM  ] place_entry error: {e}')
            return None

    # -----------------------------------------------------------------------
    # Order placement - win sell / butterfly conversion
    # -----------------------------------------------------------------------

    def place_win_sell(self,
                        direction:        str,
                        short_strike:     float,
                        conv_strike:      float,
                        bid:              float,
                        min_profit_price: float,
                        contracts:        int   = 1) -> Optional[int]:
        """
        Place a conversion spread (win-exit) order.

        Win-sell is a net-credit BAG order:
            Order.action = 'SELL'
            Leg 0: short_strike -> sell_to_open  (complete -2 butterfly center)
            Leg 1: conv_strike  -> buy_to_open   (buy far wing)
            lmtPrice = max(bid * SELL_SLIPPAGE, min_profit_price / 100),
                       rounded to tick

        Returns order ID on success, None on failure.
        """
        right         = 'C' if direction == 'UP' else 'P'
        min_per_share = min_profit_price / 100.0
        bid_based     = bid * cfg.SELL_SLIPPAGE
        limit         = round_to_tick(max(bid_based, min_per_share))
        used          = 'bid-based' if bid_based >= min_per_share else 'min-profit'

        print(f'[OM  ] Win-sell payload: SELL {contracts}x '
              f'{int(short_strike)}/{int(conv_strike)} {direction} '
              f'LMT ${limit:.2f} '
              f'(bid=${bid:.2f}x{cfg.SELL_SLIPPAGE}=${bid_based:.2f} '
              f'min=${min_per_share:.2f} -> {used})')

        try:
            short_opt = self._option(right, short_strike)
            conv_opt  = self._option(right, conv_strike)
            bag       = self._build_bag([(short_opt, 'SELL'), (conv_opt, 'BUY')])
            order     = LimitOrder('SELL', contracts, limit)

            def _place():
                trade = self._ib.placeOrder(bag, order)
                self._ib.sleep(0)
                return trade

            trade = self._call_on_loop(_place)
            oid   = trade.order.orderId
            print(f'[OM  ] Order submitted: id={oid}')
            return int(oid)
        except Exception as e:
            print(f'[OM  ] place_win_sell error: {e}')
            return None

    # -----------------------------------------------------------------------
    # Order placement - collapse (reduce conversion spread to entry width)
    # -----------------------------------------------------------------------

    def place_collapse(self,
                       direction:   str,
                       near_strike: float,
                       far_strike:  float,
                       ask_price:   float,
                       contracts:   int  = 1) -> Optional[int]:
        """
        Place the collapse order that reduces the CONV_SPREAD_WIDTH
        win-sell spread back to SPREAD_WIDTH, completing the standard butterfly.

        Fired immediately after a WIN fill.  The position after WIN fill is:
            Long  long_strike  (+1)
            Short short_strike (-2)
            Long  conv_strike  (+1, CONV_SPREAD_WIDTH away from short)

        Collapse buys the inner wing and closes the outer wing:
            near_strike = short_strike +/- SPREAD_WIDTH      (new inner long)
            far_strike  = conv_strike  (= short +/- CONV_SPREAD_WIDTH, closed)

        Collapse is a net-debit BAG order:
            Order.action = 'BUY'
            Leg 0: near_strike -> BUY   (open new inner long)
            Leg 1: far_strike  -> SELL  (close existing outer long)
            lmtPrice = round_to_tick(ask * ENTRY_SLIPPAGE)

        Resulting position after collapse:
            Long  long_strike  (+1)
            Short short_strike (-2)
            Long  near_strike  (+1)   <- standard SPREAD_WIDTH butterfly

        Returns order ID on success, None on failure.
        """
        right = 'C' if direction == 'UP' else 'P'
        limit = round_to_tick(ask_price * cfg.ENTRY_SLIPPAGE)

        print(f'[OM  ] Collapse payload: BUY {contracts}x '
              f'{int(near_strike)}/{int(far_strike)} {direction} '
              f'LMT ${limit:.2f} '
              f'(ask=${ask_price:.2f} x {cfg.ENTRY_SLIPPAGE})')

        try:
            near_opt = self._option(right, near_strike)
            far_opt  = self._option(right, far_strike)
            bag      = self._build_bag([(near_opt, 'BUY'), (far_opt, 'SELL')])
            order    = LimitOrder('BUY', contracts, limit)

            def _place():
                trade = self._ib.placeOrder(bag, order)
                self._ib.sleep(0)
                return trade

            trade = self._call_on_loop(_place)
            oid   = trade.order.orderId
            print(f'[OM  ] Order submitted: id={oid}')
            return int(oid)
        except Exception as e:
            print(f'[OM  ] place_collapse error: {e}')
            return None

    # -----------------------------------------------------------------------
    # Cancel
    # -----------------------------------------------------------------------

    def cancel(self, order_id: int) -> bool:
        """
        Cancel an open order by orderId.
        Looks up the Trade object from ib.trades() then calls cancelOrder().
        Returns True if the cancel was dispatched; False if order not found.
        """
        def _cancel():
            # Pump the event queue so trade state is current.
            self._ib.sleep(0)
            trade = next(
                (t for t in self._ib.trades() if t.order.orderId == order_id),
                None,
            )
            if not trade:
                print(f'[OM  ] Cancel: order {order_id} not found in trades()')
                return False
            self._ib.cancelOrder(trade.order)
            self._ib.sleep(0)
            print(f'[OM  ] Cancel order {order_id}: requested')
            return True

        return self._call_on_loop(_cancel)

    # -----------------------------------------------------------------------
    # Order status  (matches TradierClient.get_order() dict shape)
    # -----------------------------------------------------------------------

    def get_order(self, order_id: int) -> Dict:
        """
        Return order status dict matching the Tradier interface:
            { 'status': 'filled'|'canceled'|'open', 'avg_fill_price': float }

        Processes the ib_insync event queue before reading trade state so
        status is current when polled in a 1-second loop.
        """
        def _get():
            self._ib.sleep(0)
            trade = next(
                (t for t in self._ib.trades() if t.order.orderId == order_id),
                None,
            )
            if not trade:
                return {'status': 'open', 'avg_fill_price': 0.0}
            raw_status = trade.orderStatus.status
            status     = _STATUS_MAP.get(raw_status, 'open')
            avg_fill   = _safe_float(trade.orderStatus.avgFillPrice)
            return {'status': status, 'avg_fill_price': avg_fill}

        return self._call_on_loop(_get)

    # -----------------------------------------------------------------------
    # Session setup  (mirrors TradierClient.get_todays_expiration)
    # -----------------------------------------------------------------------

    def get_todays_expiration(self, live_trading: bool = False) -> str:
        """
        Verify today is a valid SPXW expiration day and return 'YYYY-MM-DD'.

        Paper mode : skips IBKR validation entirely and returns today.
                     Validation is advisory-only in paper; no real money at
                     risk and contract queries consistently trigger Error 200.

        Live mode  : calls reqSecDefOptParams on the SPX index to retrieve
                     the full set of valid SPXW expiration dates, then
                     confirms today is among them.  Raises ValueError if
                     today is not a listed expiration (weekend / holiday).
        """
        today    = _date.today().isoformat()
        today_ib = today.replace('-', '')

        if not live_trading:
            print(f'[OM  ] Paper mode - skipping SPXW expiration check, '
                  f'using today: {today}')
            return today

        # Live mode: use reqSecDefOptParams to get valid SPXW expiry dates.
        try:
            from ib_insync import Index as _Index

            # Step 1 - qualify the SPX index contract to obtain its conId.
            spx       = _Index('SPX', 'CBOE')
            qualified = self._qualify_contracts(spx)
            if not qualified:
                raise RuntimeError('Could not qualify SPX index contract')
            con_id = qualified[0].conId

            # Step 2 - fetch option chain parameters on the loop thread.
            # expirations is a set of 'YYYYMMDD' strings.
            def _fetch_chains():
                return self._ib.reqSecDefOptParams(
                    underlyingSymbol  = 'SPX',
                    futFopExchange    = '',
                    underlyingSecType = 'IND',
                    underlyingConId   = con_id,
                )

            chains      = self._call_on_loop(_fetch_chains, timeout=30)
            expirations = set()
            for chain in chains:
                if getattr(chain, 'tradingClass', '') == 'SPXW':
                    expirations.update(chain.expirations)

            if today_ib in expirations:
                print(f"[OM  ] Today's SPXW expiration confirmed: {today}")
                return today

        except Exception as e:
            raise ValueError(
                f'[OM  ] reqSecDefOptParams expiration check failed: {e}'
            ) from e

        raise ValueError(
            f'[OM  ] No SPXW expiration found for today ({today}). '
            f'Check IB Gateway connection and CBOE options data subscription. '
            f'This may be a weekend or market holiday.'
        )

    # -----------------------------------------------------------------------
    # Account  (mirrors TradierClient.get_option_buying_power)
    # -----------------------------------------------------------------------

    def _start_account_subscription(self) -> None:
        """
        Start reqAccountUpdates() on the IB loop thread via a background
        thread so it does not block the runner's initialisation.

        reqAccountUpdates() is blocking - it waits for full account and
        portfolio data before returning.  It must run on the IB loop thread
        (via _call_on_loop) so ib_insync's internal event queue is pumped
        correctly.  A wrapper thread dispatches it and exits when done.
        """
        def _subscribe():
            try:
                self._call_on_loop(self._ib.reqAccountUpdates, timeout=60)
                print('[OM  ] Account update subscription complete')
            except Exception as e:
                # Log type + message - TimeoutError renders as empty string
                # without the type name, making the warning unreadable.
                print(f'[OM  ] reqAccountUpdates warning: '
                      f'{type(e).__name__}: {e or "(no message)"}')
            finally:
                # reqAccountUpdates() sends the subscription request before
                # blocking for the response.  Even on timeout the request
                # was dispatched and data will arrive asynchronously,
                # populating accountValues() within seconds.  Mark subscribed
                # so get_option_buying_power() does not re-subscribe.
                self._account_subscribed = True

        threading.Thread(target=_subscribe, daemon=True,
                         name='acct-subscribe').start()

    def get_option_buying_power(self) -> float:
        """
        Returns option buying power from IBKR account values.
        Reads the OptionBuyingPower tag (USD) from accountValues().

        _start_account_subscription() is called on first use to kick off
        reqAccountUpdates() on the loop thread.  Retries up to 3 times
        with a 1-second pump while waiting for the subscription to deliver
        data.
        """
        import time

        if not self._account_subscribed:
            self._start_account_subscription()

        for attempt in range(3):
            try:
                vals = {
                    v.tag: v.value
                    for v in self._ib.accountValues()
                    if v.currency in ('USD', '')
                }
                bp = float(vals.get('OptionBuyingPower', 0) or 0)
                if bp > 0:
                    return bp
                if attempt < 2:
                    # Pump the event loop on the loop thread to receive data.
                    self._call_on_loop(lambda: self._ib.sleep(1), timeout=5)
            except Exception as e:
                print(f'[OM  ] get_option_buying_power error: {e}')
                if attempt < 2:
                    time.sleep(1)

        print('[OM  ] WARNING: Option buying power $0 - '
              'account may have no options buying power')
        return 0.0

    # -----------------------------------------------------------------------
    # Positions  (mirrors TradierClient.get_positions)
    # -----------------------------------------------------------------------

    def get_positions(self) -> List[Dict]:
        """
        Returns open positions as a list of dicts matching the Tradier shape:
            [{ 'symbol': 'SPXW260401C06570000', 'quantity': 1.0 }, ...]

        Filters to SPXW/SPX option contracts only.  The OCC symbol is
        reconstructed from the IBKR contract fields so the runner's
        existing _parse_occ() helper can parse it without modification.

        Reads from ib_insync's cached positions() state - safe to call
        from any thread (CPython GIL protects the dict read).
        """
        try:
            result = []
            for pos in self._ib.positions():
                c = pos.contract
                if c.secType != 'OPT' or c.symbol not in ('SPXW', 'SPX'):
                    continue
                occ = _occ_from_contract(c)
                if occ is None:
                    print(f'[OM  ] get_positions: could not build OCC for {c}')
                    continue
                result.append({'symbol': occ, 'quantity': pos.position})
            return result
        except Exception as e:
            print(f'[OM  ] get_positions error: {e}')
            return []

    # -----------------------------------------------------------------------
    # VIX9D  (yfinance - free, no IBKR subscription required)
    # -----------------------------------------------------------------------

    def get_vix9d(self) -> float:
        """
        Fetch the current VIX9D (9-day expected volatility) price via
        yfinance.  Yahoo Finance symbol: ^VIX9D.

        Free with no API key.  Data carries ~15-minute delay which is
        acceptable for a 60-second gate poll - VIX9D does not cross the
        entry ceiling (VIX_MAX_ENTRY) and reverse within 15 minutes under
        normal conditions.

        Returns last price as a float, 0.0 on any failure.
        A return of 0.0 is treated by the runner as 'feed absent - no block',
        matching the existing heartbeat behaviour.
        """
        try:
            import yfinance as yf
            info  = yf.Ticker('^VIX9D').fast_info
            price = float(info.last_price or 0.0)
            return price
        except Exception as e:
            print(f'[VIX ] get_vix9d error: {e}')
            return 0.0

    # -----------------------------------------------------------------------
    # EOD report  (mirrors TradierClient.get_eod_report / parse_eod_orders)
    # -----------------------------------------------------------------------

    def get_eod_report(self, today: str) -> Dict:
        """
        Build today's EOD accounting report from IBKR execution fills.

        Groups fills by orderId.  Each combo order generates one fill per
        leg, all sharing the same orderId.  Two-leg orders are classified as
        entry (debit: bought long, sold short) or conversion (credit: sold
        short, bought conv wing).  Entries and conversions are matched by
        (right, short_strike).

        Returns the same dict structure as tradier_client.parse_eod_orders():
            entries, conversions, matched, expired,
            total_cost, total_expired_cost

        today: 'YYYY-MM-DD'

        Reads from ib_insync's cached fills() state - safe to call from
        any thread (CPython GIL protects the dict read).
        """
        today_ib = today.replace('-', '')

        by_order: Dict[int, List] = defaultdict(list)
        for fill in self._ib.fills():
            c  = fill.contract
            ex = fill.execution
            if c.secType != 'OPT' or c.symbol not in ('SPXW', 'SPX'):
                continue
            expiry = (c.lastTradeDateOrContractMonth or '').replace('-', '')
            if expiry != today_ib:
                continue
            by_order[ex.orderId].append(fill)

        entries     = []
        conversions = []

        for order_id, fills in by_order.items():
            if len(fills) != 2:
                continue

            buy_fills  = [f for f in fills if f.execution.side == 'BOT']
            sell_fills = [f for f in fills if f.execution.side == 'SLD']
            if len(buy_fills) != 1 or len(sell_fills) != 1:
                continue

            buy_fill  = buy_fills[0]
            sell_fill = sell_fills[0]

            buy_right  = (buy_fill.contract.right  or '').upper()[:1]
            sell_right = (sell_fill.contract.right or '').upper()[:1]
            if buy_right != sell_right:
                continue
            right = buy_right

            buy_strike  = float(buy_fill.contract.strike)
            sell_strike = float(sell_fill.contract.strike)
            buy_price   = _safe_float(buy_fill.execution.avgPrice)
            sell_price  = _safe_float(sell_fill.execution.avgPrice)
            qty         = int(abs(buy_fill.execution.shares))

            if right == 'C':
                is_entry = buy_strike < sell_strike
            else:
                is_entry = buy_strike > sell_strike

            if is_entry:
                net_cost = (buy_price - sell_price) * qty * 100
                entries.append({
                    'order_id':     order_id,
                    'right':        right,
                    'long_strike':  buy_strike,
                    'short_strike': sell_strike,
                    'net_cost':     net_cost,
                    'contracts':    qty,
                })
            else:
                net_credit = (sell_price - buy_price) * qty * 100
                conversions.append({
                    'order_id':    order_id,
                    'right':       right,
                    'short_strike': sell_strike,
                    'conv_strike':  buy_strike,
                    'net_credit':  net_credit,
                    'contracts':   qty,
                })

        conv_index = {(c['right'], c['short_strike']): c for c in conversions}
        matched    = []
        expired    = []
        for e in entries:
            c = conv_index.get((e['right'], e['short_strike']))
            if c:
                matched.append({'entry': e, 'conversion': c})
            else:
                expired.append(e)

        total_cost         = sum(e['net_cost'] for e in entries)
        total_expired_cost = sum(e['net_cost'] for e in expired)

        return {
            'entries':            entries,
            'conversions':        conversions,
            'matched':            matched,
            'expired':            expired,
            'total_cost':         total_cost,
            'total_expired_cost': total_expired_cost,
        }


# ---------------------------------------------------------------------------
# Quick connectivity test (run directly - requires IB Gateway on port 7497)
# ---------------------------------------------------------------------------

if __name__ == '__main__':
    import sys
    from datetime import date

    print('--- IBKROrderManager connectivity test ---')
    om = IBKROrderManager()

    print('\n[1] Option buying power:')
    bp = om.get_option_buying_power()
    print(f'    OptionBuyingPower = ${bp:,.2f}')

    print('\n[2] Open positions:')
    pos = om.get_positions()
    if pos:
        for p in pos:
            print(f'    {p}')
    else:
        print('    (none)')

    print('\n[3] Todays expiration (paper mode):')
    try:
        exp = om.get_todays_expiration(live_trading=False)
        print(f'    expiration = {exp}')
        om.set_expiration(exp)
    except Exception as ex:
        print(f'    error: {ex}')
        sys.exit(1)

    print('\n[4] Strike calculator:')
    long_s, short_s, conv_s = om.calc_strikes(5847.3, 'UP')
    print(f'    calc_strikes(5847.3, UP)  -> {long_s}/{short_s}/{conv_s}')
    long_s, short_s, conv_s = om.calc_strikes(5847.3, 'DOWN')
    print(f'    calc_strikes(5847.3, DOWN)-> {long_s}/{short_s}/{conv_s}')

    print('\n[5] EOD report (fills so far today):')
    today = date.today().isoformat()
    report = om.get_eod_report(today)
    print(f'    entries={len(report["entries"])}  '
          f'conversions={len(report["conversions"])}')
    print(f'    total_cost=${report["total_cost"]:.2f}  '
          f'expired_cost=${report["total_expired_cost"]:.2f}')

    print('\n--- Test complete ---')
    om.disconnect()
    sys.exit(0)
