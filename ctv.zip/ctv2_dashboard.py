#!/usr/bin/env python3
# Copyright (c) Gregory Howard 2026  All rights reserved
"""
ctv2_dashboard.py - CTV2 Local Web Dashboard

Revision: 1.0

CHANGELOG
---------
Rev 1.0: Initial release. Flask app on localhost:5000.
         Reads the most recent logs/ctv2_*.csv on every request.
         Displays: summary bar (P&L, W/L, VIX last), open positions,
         closed trades (color-coded win/loss), butterflies.
         Auto-refreshes every 10 seconds.

Run from C:\\CTV:
    python ctv2_dashboard.py
Then open http://localhost:5000 in a browser.
"""

import csv
import glob
import os
import sys
from datetime import datetime
from pathlib import Path

try:
    from flask import Flask, render_template_string
except ImportError:
    print("ERROR: Flask not installed. Run: pip install flask")
    sys.exit(1)

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

LOG_DIR  = Path(os.path.dirname(os.path.abspath(__file__))) / 'logs'
HOST     = '127.0.0.1'
PORT     = 5000
REFRESH  = 10   # seconds between auto-refresh

# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def find_latest_csv():
    """Return path to most recently modified ctv2_*.csv in logs/."""
    pattern = str(LOG_DIR / 'ctv2_*.csv')
    files = glob.glob(pattern)
    if not files:
        return None
    return max(files, key=os.path.getmtime)


def load_data(csv_path):
    """
    Parse CSV and return structured data dict.
    Returns dict with keys: entries, exits, butterflies, bfly_expirations,
    cancelled, summary.
    """
    entries    = {}   # trade_id -> row
    exits      = {}   # trade_id -> row
    bflies     = {}   # trade_id -> row
    bfly_exps  = {}   # trade_id -> row
    cancelled  = []

    try:
        with open(csv_path, newline='', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                rt = row.get('record_type', '').strip()
                tid = row.get('trade_id', '').strip()
                if rt == 'ENTRY':
                    entries[tid] = row
                elif rt == 'EXIT':
                    exits[tid] = row
                elif rt == 'BUTTERFLY':
                    bflies[tid] = row
                elif rt == 'BFLY_EXPIRATION':
                    bfly_exps[tid] = row
                elif rt == 'CANCELLED':
                    cancelled.append(row)
    except Exception as e:
        return None, str(e)

    # Open positions: have ENTRY but no EXIT and no BUTTERFLY
    open_positions = {tid: row for tid, row in entries.items()
                      if tid not in exits and tid not in bflies}

    # Closed trades: have EXIT row
    closed_trades = []
    for tid, exit_row in exits.items():
        entry_row = entries.get(tid, {})
        closed_trades.append({'entry': entry_row, 'exit': exit_row})
    # Sort newest first by entry_time
    closed_trades.sort(key=lambda x: x['exit'].get('entry_time', ''), reverse=True)

    # Butterfly positions (converted but not expired)
    bfly_positions = []
    for tid, brow in bflies.items():
        exp_row = bfly_exps.get(tid)
        bfly_positions.append({'butterfly': brow, 'expiration': exp_row})
    bfly_positions.sort(key=lambda x: x['butterfly'].get('entry_time', ''), reverse=True)

    # Summary
    wins   = sum(1 for t in closed_trades if _pnl(t['exit']) >= 0)
    losses = sum(1 for t in closed_trades if _pnl(t['exit']) < 0)
    net    = sum(_pnl(t['exit']) for t in closed_trades)
    bfly_exp_total = sum(_pnl(r) for r in bfly_exps.values())

    summary = {
        'wins':          wins,
        'losses':        losses,
        'net_pnl':       net,
        'open_count':    len(open_positions),
        'bfly_count':    len(bfly_positions),
        'cancelled':     len(cancelled),
        'bfly_exp':      bfly_exp_total,
        'csv_path':      csv_path,
        'as_of':         datetime.now().strftime('%H:%M:%S'),
    }

    return {
        'open_positions': open_positions,
        'closed_trades':  closed_trades,
        'bfly_positions': bfly_positions,
        'cancelled':      cancelled,
        'summary':        summary,
    }, None


def _pnl(row):
    try:
        return float(row.get('net_pnl') or 0)
    except (ValueError, TypeError):
        return 0.0


def _fmt_pnl(val):
    try:
        v = float(val)
        sign = '+' if v >= 0 else ''
        return f"{sign}${v:.0f}"
    except (ValueError, TypeError):
        return '-'


def _fmt_price(val):
    try:
        return f"${float(val):.2f}"
    except (ValueError, TypeError):
        return '-'


def _fmt_time(val):
    """Shorten ISO timestamp to HH:MM."""
    if not val:
        return '-'
    try:
        return val[11:16]
    except Exception:
        return val


# ---------------------------------------------------------------------------
# HTML template
# ---------------------------------------------------------------------------

TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="refresh" content="{{ refresh }}">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CTV2 Dashboard</title>
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: 'Segoe UI', Arial, sans-serif;
    background: #0f1117;
    color: #d0d6e0;
    font-size: 14px;
    padding: 16px;
  }
  h1 {
    font-size: 20px;
    font-weight: 700;
    color: #e8eaf0;
    margin-bottom: 14px;
    letter-spacing: 0.04em;
  }
  h2 {
    font-size: 13px;
    font-weight: 600;
    color: #8892a4;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    margin: 20px 0 8px;
  }

  /* Summary bar */
  .summary {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-bottom: 6px;
  }
  .stat {
    background: #1a1f2e;
    border: 1px solid #2a3045;
    border-radius: 8px;
    padding: 10px 18px;
    min-width: 120px;
  }
  .stat-label {
    font-size: 11px;
    color: #6b7794;
    text-transform: uppercase;
    letter-spacing: 0.07em;
    margin-bottom: 4px;
  }
  .stat-value {
    font-size: 22px;
    font-weight: 700;
    color: #e8eaf0;
  }
  .stat-value.green { color: #4caf7d; }
  .stat-value.red   { color: #e05252; }
  .stat-value.amber { color: #e0a030; }

  /* Tables */
  table {
    width: 100%;
    border-collapse: collapse;
    background: #1a1f2e;
    border-radius: 8px;
    overflow: hidden;
    margin-bottom: 8px;
  }
  th {
    background: #232940;
    color: #8892a4;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.07em;
    padding: 8px 12px;
    text-align: left;
    border-bottom: 1px solid #2a3045;
  }
  td {
    padding: 7px 12px;
    border-bottom: 1px solid #1f2538;
    color: #c8d0e0;
    white-space: nowrap;
  }
  tr:last-child td { border-bottom: none; }
  tr:hover td { background: #1f263a; }

  .tag {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.05em;
  }
  .tag-up     { background: #1a3a2a; color: #4cde8c; }
  .tag-down   { background: #3a1a1a; color: #e06060; }
  .tag-win    { background: #1a3a2a; color: #4cde8c; }
  .tag-loss   { background: #3a1a1a; color: #e06060; }
  .tag-bfly   { background: #1a2a3a; color: #60a0e0; }
  .tag-parked { background: #2a2a1a; color: #e0c040; }
  .tag-active { background: #1a2a1a; color: #80c060; }

  .pnl-pos { color: #4cde8c; font-weight: 600; }
  .pnl-neg { color: #e06060; font-weight: 600; }

  .meta {
    margin-top: 20px;
    font-size: 11px;
    color: #4a5268;
  }
  .empty { color: #4a5268; font-style: italic; padding: 12px; }

  .no-data {
    background: #1a1f2e;
    border: 1px solid #2a3045;
    border-radius: 8px;
    padding: 40px;
    text-align: center;
    color: #6b7794;
    margin-top: 40px;
  }
</style>
</head>
<body>

<h1>CTV2 Dashboard</h1>

{% if error %}
  <div class="no-data">
    <div style="font-size:18px; margin-bottom:8px;">No data</div>
    <div>{{ error }}</div>
    <div style="margin-top:12px; font-size:12px; color:#4a5268;">
      Waiting for a trading session to start and create a CSV log file.
    </div>
  </div>
{% else %}

<!-- Summary bar -->
<div class="summary">
  <div class="stat">
    <div class="stat-label">Net P&amp;L</div>
    <div class="stat-value {{ 'green' if summary.net_pnl >= 0 else 'red' }}">
      {{ fmt_pnl(summary.net_pnl) }}
    </div>
  </div>
  <div class="stat">
    <div class="stat-label">Wins</div>
    <div class="stat-value green">{{ summary.wins }}</div>
  </div>
  <div class="stat">
    <div class="stat-label">Losses</div>
    <div class="stat-value {{ 'red' if summary.losses > 0 else '' }}">{{ summary.losses }}</div>
  </div>
  <div class="stat">
    <div class="stat-label">Open</div>
    <div class="stat-value amber">{{ summary.open_count }}</div>
  </div>
  <div class="stat">
    <div class="stat-label">Butterflies</div>
    <div class="stat-value">{{ summary.bfly_count }}</div>
  </div>
  {% if summary.bfly_exp != 0 %}
  <div class="stat">
    <div class="stat-label">Bfly Expiry Est.</div>
    <div class="stat-value {{ 'green' if summary.bfly_exp >= 0 else 'red' }}">
      {{ fmt_pnl(summary.bfly_exp) }}
    </div>
  </div>
  {% endif %}
  {% if summary.cancelled > 0 %}
  <div class="stat">
    <div class="stat-label">Cancelled</div>
    <div class="stat-value">{{ summary.cancelled }}</div>
  </div>
  {% endif %}
</div>

<!-- Open Positions -->
<h2>Open Positions ({{ summary.open_count }})</h2>
{% if open_positions %}
<table>
  <thead>
    <tr>
      <th>Dir</th><th>Strikes</th><th>Ctrs</th>
      <th>Premium</th><th>Win Target</th><th>VIX</th>
      <th>SPX Fill</th><th>Entry</th><th>State</th>
    </tr>
  </thead>
  <tbody>
    {% for tid, row in open_positions.items() %}
    <tr>
      <td><span class="tag {{ 'tag-up' if row.direction == 'UP' else 'tag-down' }}">
        {{ row.direction }}</span></td>
      <td>{{ row.long_strike }}/{{ row.short_strike }}</td>
      <td>{{ row.contracts }}</td>
      <td>{{ fmt_price(row.premium_paid) }}</td>
      <td>{{ fmt_price(row.win_target) }}</td>
      <td>{{ row.vix_at_entry }}</td>
      <td>{{ fmt_price(row.spx_at_fill) }}</td>
      <td>{{ fmt_time(row.entry_time) }}</td>
      <td><span class="tag tag-active">ACTIVE</span></td>
    </tr>
    {% endfor %}
  </tbody>
</table>
{% else %}
<div class="empty">No open positions.</div>
{% endif %}

<!-- Butterflies -->
{% if bfly_positions %}
<h2>Open Butterflies ({{ summary.bfly_count }})</h2>
<table>
  <thead>
    <tr>
      <th>Dir</th><th>Strikes</th><th>Cost Basis</th>
      <th>VIX</th><th>SPX Fill</th><th>Entry</th>
      <th>Reason</th><th>Expiry Est.</th>
    </tr>
  </thead>
  <tbody>
    {% for item in bfly_positions %}
    {% set b = item.butterfly %}
    {% set e = item.expiration %}
    <tr>
      <td><span class="tag {{ 'tag-up' if b.direction == 'UP' else 'tag-down' }}">
        {{ b.direction }}</span></td>
      <td>{{ b.long_strike }}/{{ b.short_strike }}/{{ b.conv_strike }}</td>
      <td>{{ fmt_price(b.net_cost) }}</td>
      <td>{{ b.vix_at_entry }}</td>
      <td>{{ fmt_price(b.spx_at_fill) }}</td>
      <td>{{ fmt_time(b.entry_time) }}</td>
      <td>{{ b.bfly_reason }}</td>
      <td>{% if e %}<span class="pnl-pos">{{ fmt_pnl(e.net_pnl) }}</span>{% else %}-{% endif %}</td>
    </tr>
    {% endfor %}
  </tbody>
</table>
{% endif %}

<!-- Closed Trades -->
<h2>Closed Trades ({{ closed_trades | length }})</h2>
{% if closed_trades %}
<table>
  <thead>
    <tr>
      <th>Dir</th><th>Strikes</th><th>Ctrs</th>
      <th>Premium</th><th>Exit Credit</th><th>Net P&amp;L</th>
      <th>VIX</th><th>SPX Fill</th><th>Entry</th><th>Outcome</th>
    </tr>
  </thead>
  <tbody>
    {% for item in closed_trades %}
    {% set ex = item.exit %}
    {% set pnl = pnl_val(ex) %}
    <tr>
      <td><span class="tag {{ 'tag-up' if ex.direction == 'UP' else 'tag-down' }}">
        {{ ex.direction }}</span></td>
      <td>{{ ex.long_strike }}/{{ ex.short_strike }}</td>
      <td>{{ ex.contracts }}</td>
      <td>{{ fmt_price(ex.premium_paid) }}</td>
      <td>{{ fmt_price(ex.exit_credit) }}</td>
      <td class="{{ 'pnl-pos' if pnl >= 0 else 'pnl-neg' }}">{{ fmt_pnl(ex.net_pnl) }}</td>
      <td>{{ ex.vix_at_entry }}</td>
      <td>{{ fmt_price(ex.spx_at_fill) }}</td>
      <td>{{ fmt_time(ex.entry_time) }}</td>
      <td>
        {% set oc = ex.outcome %}
        {% if 'WIN' in oc %}
          <span class="tag tag-win">WIN</span>
        {% elif 'STOP' in oc or 'LOSS' in oc or 'ADVERSE' in oc %}
          <span class="tag tag-loss">{{ oc }}</span>
        {% elif 'BUTTERFLY' in oc %}
          <span class="tag tag-bfly">BFLY</span>
        {% else %}
          <span class="tag">{{ oc }}</span>
        {% endif %}
      </td>
    </tr>
    {% endfor %}
  </tbody>
</table>
{% else %}
<div class="empty">No closed trades yet.</div>
{% endif %}

<div class="meta">
  As of {{ summary.as_of }} &nbsp;&bull;&nbsp; Auto-refresh every {{ refresh }}s &nbsp;&bull;&nbsp; {{ summary.csv_path }}
</div>
{% endif %}

</body>
</html>
"""

# ---------------------------------------------------------------------------
# Flask app
# ---------------------------------------------------------------------------

app = Flask(__name__)
app.jinja_env.globals.update(
    fmt_pnl=_fmt_pnl,
    fmt_price=_fmt_price,
    fmt_time=_fmt_time,
    pnl_val=_pnl,
)


@app.route('/')
def index():
    csv_path = find_latest_csv()
    if not csv_path:
        return render_template_string(
            TEMPLATE,
            error=f"No CSV files found in {LOG_DIR}. Start a trading session first.",
            summary={}, open_positions={}, closed_trades=[],
            bfly_positions=[], refresh=REFRESH,
        )

    data, err = load_data(csv_path)
    if err:
        return render_template_string(
            TEMPLATE,
            error=f"Error reading {csv_path}: {err}",
            summary={}, open_positions={}, closed_trades=[],
            bfly_positions=[], refresh=REFRESH,
        )

    return render_template_string(
        TEMPLATE,
        error=None,
        summary=data['summary'],
        open_positions=data['open_positions'],
        closed_trades=data['closed_trades'],
        bfly_positions=data['bfly_positions'],
        refresh=REFRESH,
    )


if __name__ == '__main__':
    print(f"CTV2 Dashboard - http://{HOST}:{PORT}")
    print(f"Reading logs from: {LOG_DIR}")
    print("Press Ctrl+C to stop.\n")
    app.run(host=HOST, port=PORT, debug=False)
