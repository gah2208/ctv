@echo off
REM ============================================================
REM  CONFIG_EDITOR.bat - CTV2 Config Editor Launcher
REM  Revision: 1.0
REM  Calls ctv2_config_editor.py via Python.
REM  This file must exist in C:\CTV for the shortcut to work.
REM ============================================================
powershell.exe -ExecutionPolicy Bypass -NoProfile -File "C:\CTV\CONFIG_EDITOR.ps1"
pause
