# Copyright (c) Gregory Howard 2026  All rights reserved
"""
ibkr_scale.py - Runtime Parameter Scaling for CTV2
====================================================
Applies a scale factor to all index-point and option-dollar denominated
config parameters based on the UNDERLYING setting in config_ctv2.py.

  SPX : full-size S&P 500 index options  (scale = 1.0  - no change)
  XSP : mini S&P 500 index options       (scale = 0.1  - 1/10 of SPX)

Usage (from ctv2_runner.__init__):

    from ibkr_scale import build_scaled_config
    self.cfg = build_scaled_config()

    # Use self.cfg.SPREAD_WIDTH instead of config.SPREAD_WIDTH, etc.

All time-based, count, flag, VIX, slippage, and percentage parameters
are NOT scaled - read them from config_ctv2 directly as before.

Parameters scaled (x SCALE)
----------------------------
  Index-point denominated:
    EMA_DIRECTION_THRESHOLD
    SPREAD_WIDTH
    CONV_SPREAD_WIDTH
    WIN_TARGET_BUFFER
    PARK_CONVERT_EMA_LOW
    PARK_CONVERT_EMA_MID
    PARK_CONVERT_EMA_HIGH
    ACTIVE_ADVERSE_MOVE

  Option-dollar denominated:
    MAX_PREMIUM
    MAX_BID_ASK_WIDTH

Revision history
----------------
Rev 3: GAP_OPEN_THRESHOLD removed from ScaledConfig, raw dict, and
       build_scaled_config() constructor. Gap entry process was removed
       from config and defaults; ScaledConfig no longer carries this field.
       ctv2_runner.py _check_gap_open() now uses module-level GAP_OPEN_THRESHOLD
       constant (getattr fallback 20.0) instead of self.cfg.GAP_OPEN_THRESHOLD.
Rev 2: Added CONV_SPREAD_WIDTH as a scaled index-point parameter.
       Controls win-sell spread width; scaled identically to SPREAD_WIDTH.
Rev 1: Initial implementation.
"""

from __future__ import annotations

from dataclasses import dataclass

import config_ctv2 as cfg


# ---------------------------------------------------------------------------
# Supported underlyings
# ---------------------------------------------------------------------------

_SCALE_MAP: dict[str, float] = {
    'SPX': 1.0,
    'XSP': 0.1,
}


# ---------------------------------------------------------------------------
# Scaled config dataclass
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ScaledConfig:
    """
    Holds every config parameter that requires scaling, at its effective
    runtime value.  Immutable after construction.

    Access via the same name as config_ctv2 so call-sites read naturally:
        self.cfg.SPREAD_WIDTH        (scaled)
        config_ctv2.SPREAD_WIDTH     (raw - do not use for these fields)
    """
    underlying: str
    scale:      float

    # Index-point denominated
    EMA_DIRECTION_THRESHOLD: float
    SPREAD_WIDTH:            float
    CONV_SPREAD_WIDTH:       float
    WIN_TARGET_BUFFER:       float
    PARK_CONVERT_EMA_LOW:    float
    PARK_CONVERT_EMA_MID:    float
    PARK_CONVERT_EMA_HIGH:   float
    ACTIVE_ADVERSE_MOVE:     float

    # Option-dollar denominated
    MAX_PREMIUM:      float
    MAX_BID_ASK_WIDTH: float


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

def build_scaled_config() -> ScaledConfig:
    """
    Read UNDERLYING from config_ctv2, determine the scale factor, apply it
    to every scalable parameter, log the result, and return a ScaledConfig.

    Raises ValueError if UNDERLYING is not recognised.
    """
    underlying = getattr(cfg, 'UNDERLYING', 'SPX').upper().strip()

    if underlying not in _SCALE_MAP:
        raise ValueError(
            f'[CFG] Unknown UNDERLYING={underlying!r}. '
            f'Valid values: {list(_SCALE_MAP)}'
        )

    scale = _SCALE_MAP[underlying]

    # Raw values from config
    raw = {
        'EMA_DIRECTION_THRESHOLD': cfg.EMA_DIRECTION_THRESHOLD,
        'SPREAD_WIDTH':            cfg.SPREAD_WIDTH,
        'CONV_SPREAD_WIDTH':       cfg.CONV_SPREAD_WIDTH,
        'WIN_TARGET_BUFFER':       cfg.WIN_TARGET_BUFFER,
        'PARK_CONVERT_EMA_LOW':    cfg.PARK_CONVERT_EMA_LOW,
        'PARK_CONVERT_EMA_MID':    cfg.PARK_CONVERT_EMA_MID,
        'PARK_CONVERT_EMA_HIGH':   cfg.PARK_CONVERT_EMA_HIGH,
        'ACTIVE_ADVERSE_MOVE':     cfg.ACTIVE_ADVERSE_MOVE,
        'MAX_PREMIUM':             cfg.MAX_PREMIUM,
        'MAX_BID_ASK_WIDTH':       cfg.MAX_BID_ASK_WIDTH,
    }

    # Log startup summary
    print(f'[CFG] UNDERLYING={underlying}  scale={scale}')
    if scale != 1.0:
        for name, val in raw.items():
            print(f'[CFG]   {name}: {val} -> {round(val * scale, 6)}')
    else:
        print('[CFG]   All parameters at SPX full-size values (no scaling)')

    return ScaledConfig(
        underlying              = underlying,
        scale                   = scale,
        EMA_DIRECTION_THRESHOLD = raw['EMA_DIRECTION_THRESHOLD'] * scale,
        SPREAD_WIDTH            = raw['SPREAD_WIDTH']            * scale,
        CONV_SPREAD_WIDTH       = raw['CONV_SPREAD_WIDTH']       * scale,
        WIN_TARGET_BUFFER       = raw['WIN_TARGET_BUFFER']       * scale,
        PARK_CONVERT_EMA_LOW    = raw['PARK_CONVERT_EMA_LOW']    * scale,
        PARK_CONVERT_EMA_MID    = raw['PARK_CONVERT_EMA_MID']    * scale,
        PARK_CONVERT_EMA_HIGH   = raw['PARK_CONVERT_EMA_HIGH']   * scale,
        ACTIVE_ADVERSE_MOVE     = raw['ACTIVE_ADVERSE_MOVE']     * scale,
        MAX_PREMIUM             = raw['MAX_PREMIUM']             * scale,
        MAX_BID_ASK_WIDTH       = raw['MAX_BID_ASK_WIDTH']       * scale,
    )
