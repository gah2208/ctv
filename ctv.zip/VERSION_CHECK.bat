@echo off
:: ============================================================
::  VERSION_CHECK.bat - CTV2 Version Audit and Build Gate
::  Revision: 1.0
::  Run from C:\CTV
::
::  Checks every file's version string against the expected
::  version. If all pass, runs BUILD_ZIP.bat. If any fail,
::  lists the failures and stops.
:: ============================================================

cd /d C:\CTV
powershell.exe -ExecutionPolicy Bypass -NoProfile -File "C:\CTV\version_check.ps1"

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Build aborted - version mismatches found above.
    pause
    exit /b 1
)
