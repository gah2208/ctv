@echo off
:: ============================================================
::  VERSION_CHECK.bat - CTV2 Version Audit and Build Gate
::  Revision: 1.1
::  Run from C:\CTV
::
::  Checks every file's version string against the expected
::  version. If all pass, runs BUILD_CTV_ZIP.bat then
::  BUILD_INSTALLER.bat. If any step fails, lists the
::  failures and stops without proceeding to the next step.
:: ============================================================

cd /d C:\CTV
powershell.exe -ExecutionPolicy Bypass -NoProfile -File "C:\CTV\version_check.ps1"

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Build aborted - version mismatches found above.
    pause
    exit /b 1
)

call BUILD_CTV_ZIP.bat

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Build aborted - ZIP build failed. Installer not built.
    pause
    exit /b 1
)

call BUILD_INSTALLER.bat
