"""
config_ctv2_default.py - CTV2 Factory Default Configuration

This file contains the factory-default values for all CTV2 parameters.
It is included in ctv.zip and used in two ways:

  Fresh install : copied to config_ctv2.py as-is
  Update        : merged with existing config_ctv2.py via merge_config.py
                  (user values are preserved; new fields added at default)

Do NOT store credentials here. Credentials are entered via the Config
Editor (Config Editor -> Tradier tab / Pushover tab) after install.

To restore factory defaults, delete config_ctv2.py and restart the
installer, or use Reset to Defaults in the Config Editor.
"""

VERSION = "CFG-2.0"
from datetime import time

# -- EMA / Direction Signal -------------------------------------
MACD_FAST               = 3
MACD_SLOW               = 15
MACD_SIGNAL             = 9
EMA_DIRECTION_THRESHOLD = 1.5

# -- Entry ------------------------------------------------------
POSITION_SIZE     = 1.0
SPREAD_WIDTH      = 5.0
MAX_PREMIUM       = 350.0
MAX_BID_ASK_WIDTH  = 1.0
MAX_ACTIVE_TRADES = 4
VIX_MAX_ENTRY     = 35.0
ENTRY_TIMEOUT     = 10
GAP_OPEN_THRESHOLD    = 20.0
GAP_TRADE_EXPIRY_TIME = time(9, 45)
GAP_ENTRY_SLIPPAGE    = 1.1

# -- Exit -------------------------------------------------------
WIN_TARGET_BUFFER = 1.0
MIN_CONV_CREDIT_PCT = 1.05
SELL_SLIPPAGE       = 0.95

# -- Park & Risk ------------------------------------------------
PARK_CONVERT_EMA_LOW  = 4.0
PARK_CONVERT_EMA_MID  = 5.0
PARK_CONVERT_EMA_HIGH = 6.0
PARK_VIX_LOW          = 18.0
PARK_VIX_HIGH         = 25.0
ACTIVE_ADVERSE_MOVE   = 10.0

# -- Trading Window ---------------------------------------------
TRADING_START       = time(10, 0)
TRADING_END         = time(16, 0)
LAST_ENTRY_TIME     = time(14, 0)
PM_BOUNDARY         = time(13, 0)
INTRINSIC_EXIT_TIME = time(14, 30)

# -- Order Pricing ----------------------------------------------
ENTRY_SLIPPAGE  = 1.05

# -- Data (backtester only) -------------------------------------
SPX_DATA_DIR = "SPX_3min_bars"

# -- Trading Mode -----------------------------------------------
# LIVE_TRADING=False = paper trading (live data, preview orders - nothing fills)
# LIVE_TRADING=True  = real orders, real money
#
LIVE_TRADING = False

# -- Tradier API Credentials ------------------------------------
# Both fields are required. The runner will not start until
# every field is populated. Open Config Editor -> Tradier Credentials tab.
#
TRADIER_ACCOUNT_ID       = ''
TRADIER_PRODUCTION_TOKEN = ''

# -- Pushover Alerts --------------------------------------------
PUSHOVER_ENABLED           = False
PUSHOVER_USER_KEY          = ''
PUSHOVER_API_TOKEN         = ''
PUSHOVER_CRITICAL_PRIORITY = 1
PUSHOVER_SUMMARY_TIME      = '16:30'

PUSHOVER_NOTIFY_ALL_TRADES      = True
PUSHOVER_NOTIFY_RISK_SUSPEND    = True
PUSHOVER_NOTIFY_LOST_CONNECTION = True
PUSHOVER_NOTIFY_SYSTEM_CRASH    = True
PUSHOVER_EOD_DIGEST             = True
