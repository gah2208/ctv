# Copyright (c) Gregory Howard 2026  All rights reserved
"""
config_ctv2_default.py - CTV2 Factory Default Configuration

Revision: 1.6
Rev 1.6: SIG_CONFIRM_TICKS_SEC = 30 added. Seconds the signal must hold
         before an entry is queued (5-second resolution, so 30s = 6 ticks).
Rev 1.5: MAX_ACTIVE_TRADES removed. Trade slot limits are now hardcoded
         constants in ctv2_runner.py (_MAX_ACTIVE=1, _MAX_PARKED=2).
Rev 1.4: LIVE_TRADING comment updated - paper mode now sends real orders to
         IBKR paper account; preview/synthetic fill path removed from runner.
Rev 1.3: INTRINSIC_EXIT_TIME default changed from 14:30 to 15:30.
Rev 1.2: MIN_CONV_CREDIT_PCT 1.05->1.2, SELL_SLIPPAGE 0.95->0.9,
         ENTRY_SLIPPAGE 1.05->1.1, PM_BOUNDARY removed.
Rev 1.1: GAP_OPEN_THRESHOLD, GAP_TRADE_EXPIRY_TIME, GAP_ENTRY_SLIPPAGE removed.
         MAX_PREMIUM corrected to 200.0. ENTRY_TIMEOUT confirmed 10.
Rev 1.0: Initial revision tracking. CONV_SPREAD_WIDTH and UNDERLYING added.

This file contains the factory-default values for all CTV2 parameters.
It is included in ctv.zip and used in two ways:

  Fresh install : copied to config_ctv2.py as-is
  Update        : merged with existing config_ctv2.py via merge_config.py
                  (user values are preserved; new fields added at default)

Do NOT store credentials here. Pushover credentials are entered via the
Config Editor after install. IB Gateway connection requires no credentials
in this file - configure host/port in IB Gateway itself.

To restore factory defaults, delete config_ctv2.py and restart the
installer, or use Reset to Defaults in the Config Editor.
"""

VERSION = "CFG-2.0"
from datetime import time

# -- Underlying -------------------------------------------------
# SPX = full-size S&P 500 index options (scale 1.0)
# XSP = mini S&P 500 index options     (scale 0.1)
UNDERLYING = 'SPX'

# -- Entry Spread Widths ----------------------------------------
# SPREAD_WIDTH      = entry vertical width (5 pts for SPX)
# CONV_SPREAD_WIDTH = conversion (win-sell) vertical width (10 pts for SPX)
#                     Must be > SPREAD_WIDTH.  Collapse order fires
#                     immediately after WIN fill to reduce the $10
#                     conversion spread back to a $5 butterfly.
CONV_SPREAD_WIDTH = 10.0

# -- EMA / Direction Signal -------------------------------------
MACD_FAST               = 3
MACD_SLOW               = 15
MACD_SIGNAL             = 9
EMA_DIRECTION_THRESHOLD = 1.5

# -- Entry ------------------------------------------------------
POSITION_SIZE     = 1.0
SPREAD_WIDTH      = 5.0
MAX_PREMIUM       = 200.0
MAX_BID_ASK_WIDTH  = 1.0
VIX_MAX_ENTRY     = 35.0
ENTRY_TIMEOUT     = 10
SIG_CONFIRM_TICKS_SEC = 30   # seconds signal must hold before entry queued (5s resolution)

# -- Exit -------------------------------------------------------
WIN_TARGET_BUFFER = 1.0
MIN_CONV_CREDIT_PCT = 1.2
SELL_SLIPPAGE       = 0.9

# -- Park & Risk ------------------------------------------------
PARK_CONVERT_EMA_LOW  = 4.0
PARK_CONVERT_EMA_MID  = 5.0
PARK_CONVERT_EMA_HIGH = 6.0
PARK_VIX_LOW          = 18.0
PARK_VIX_HIGH         = 25.0
ACTIVE_ADVERSE_MOVE   = 10.0

# -- Trading Window ---------------------------------------------
TRADING_START       = time(10, 0)
TRADING_END         = time(16, 0)
LAST_ENTRY_TIME     = time(14, 0)
INTRINSIC_EXIT_TIME = time(15, 30)

# -- Order Pricing ----------------------------------------------
ENTRY_SLIPPAGE  = 1.1

# -- Data (backtester only) -------------------------------------
SPX_DATA_DIR = "SPX_3min_bars"

# -- IB Gateway ------------------------------------------------
# IB Gateway must be running and logged in before starting the runner.
# Paper port: 7497. Live port: 7496.
IB_HOST = '127.0.0.1'
IB_PORT = 7497

# -- Trading Mode -----------------------------------------------
# LIVE_TRADING=False = paper trading (live data, real IBKR paper orders,
#                      IBKR simulates fills - no real money at risk)
# LIVE_TRADING=True  = live trading (real orders, real money)
#
LIVE_TRADING = False

# -- Pushover Alerts --------------------------------------------
PUSHOVER_ENABLED           = False
PUSHOVER_USER_KEY          = ''
PUSHOVER_API_TOKEN         = ''
PUSHOVER_CRITICAL_PRIORITY = 1
PUSHOVER_SUMMARY_TIME      = '16:30'

PUSHOVER_NOTIFY_ALL_TRADES      = True
PUSHOVER_NOTIFY_RISK_SUSPEND    = True
PUSHOVER_NOTIFY_LOST_CONNECTION = True
PUSHOVER_NOTIFY_SYSTEM_CRASH    = True
PUSHOVER_EOD_DIGEST             = True
