# Copyright (c) Gregory Howard 2026  All rights reserved
"""
ibkr_stream.py - IB Gateway Market Data Stream for CTV2
========================================================
Replaces tradier_stream.py.  Manages the connection to IB Gateway and
delivers two data products to ctv2_runner.py - identical interface to
the Tradier stream it replaces.

  1. RAW TICKS  (every SPX last-price update)
       on_spx_tick(price: float, timestamp: str)
       Used by: intrabar win target monitoring (_live_spx)

  2. 3-MIN BARS  (via SpxBarAggregator - built from SPX 5-second ticks)
       spx_aggregator.on_spx_tick() receives every SPX tick.
       SpxBarAggregator constructs 5-second bars, aggregates to 3-minute
       bars, and fires on_bar_close(bar) on each 3-minute completion.
       Used by: EMA36/EMA180 signal generation, entry/butterfly logic

Architecture
------------
  IBKRStream runs in a dedicated daemon thread - same pattern as
  TradierStream.  The thread owns an asyncio event loop and runs
  ib_insync's IB client within it.  The caller (ctv2_runner) stays on
  the main thread and receives callbacks via the two hooks above.
  Callbacks are invoked from the stream thread; ctv2_runner must treat
  them as thread-safe notifications (no blocking work inside callbacks).

  Bar construction is fully delegated to SpxBarAggregator (spx_bars.py).
  This module is responsible only for IB Gateway connection management and
  routing raw SPX tick events to the correct handler.

Connection
----------
  Connects to IB Gateway (not TWS) at 127.0.0.1:7497 (paper) via
  ib_insync.  Paper vs live is entirely determined by which account
  IB Gateway is logged into - no code change required to switch.

  SPX is subscribed via reqMktData as an Index contract on CBOE.
  Requires an active IB market data subscription that includes CBOE
  index data (e.g. "US Securities Snapshot and Futures Value Bundle").

Reconnect policy
----------------
  Initial connection: retries every _RECONNECT_DELAY seconds until
  IB Gateway responds. All attempts log connection errors normally.

  After the first successful connection: if IB Gateway closes for any
  reason (daily 11:45 PM auto-restart, Sunday weekly restart requiring
  user validation, or any other cause) the stream logs a single
  "IB Gateway disconnected" message and waits silently, retrying every
  _RECONNECT_DELAY seconds. A single "Reconnected" message fires when
  the gateway comes back online. No intermediate per-attempt messages
  are logged during the wait. This loop runs forever - the only way to
  stop it is stop().

Revision history
----------------
Rev 5: EMA seed from historical 5-second bars. After connecting and
       qualifying the SPX contract, requests 1800 seconds (30 minutes)
       of 5-second bars via reqHistoricalDataAsync and feeds the closes
       through the same EMA36/EMA180 calculation used by spx_bars.py.
       Calls spx_aggregator.seed_emas() with the result before live
       streaming begins. This ensures both EMAs are correctly seeded on
       every startup and restart regardless of when the system starts or
       how long it was offline. Only runs during RTH (09:30-16:00 ET).
       If the request fails or returns no bars, live streaming proceeds
       with self-warm (graceful degradation).
Rev 4: Gateway reconnect waiting. After the first successful connection,
       any subsequent disconnection logs a single "[STRM] IB Gateway
       disconnected - waiting for restart" message and retries silently
       every _RECONNECT_DELAY (30) seconds. A single "[STRM] Reconnected
       to IB Gateway" message fires on recovery. Handles the daily
       11:45 PM IB Gateway auto-restart and the Sunday weekly restart
       (which requires user validation and may take longer) without any
       special-casing - the stream simply waits however long is needed.
       New instance vars: _ever_connected, _gateway_down.
       _RECONNECT_DELAY changed from 5 to 30 seconds.
Rev 3: client_id constructor param replaces hardcoded _CLIENT_ID constant.
       Allows runner to pass REVISION+1 to avoid clientId collisions with
       IBKROrderManager.
Rev 2: IB_HOST and IB_PORT now read from config_ctv2 at module load
       (getattr with fallback to 127.0.0.1:7497). Allows gateway host
       and port to be changed via Config Editor without editing Python files.
Rev 1: Initial implementation.  Replaces tradier_stream.py (Tradier
       WebSocket + sandbox REST poll) with ib_insync IB Gateway stream.
       Public interface (start/stop/reset_bars/last_spx) and both
       callbacks (on_spx_tick, spx_aggregator.on_spx_tick) are
       identical to TradierStream - ctv2_runner requires no logic changes.
"""

from __future__ import annotations

import asyncio
import logging
import threading

import config_ctv2 as cfg
from datetime import datetime
from typing import Callable, Optional
from zoneinfo import ZoneInfo

from ib_insync import IB, Index

from spx_bars import SpxBarAggregator


# ---------------------------------------------------------------------------
# Connection constants  (paper IB Gateway defaults)
# ---------------------------------------------------------------------------

_HOST            = getattr(cfg, 'IB_HOST', '127.0.0.1')
_PORT            = getattr(cfg, 'IB_PORT', 7497)   # paper=7497  live=7496
_RECONNECT_DELAY = 30            # seconds between reconnect attempts
_CONNECT_TIMEOUT = 15            # seconds to wait for IB Gateway handshake

ET = ZoneInfo('America/New_York')


# ---------------------------------------------------------------------------
# Stream
# ---------------------------------------------------------------------------

class IBKRStream:
    """
    Manages the IB Gateway market data stream for SPX.

    Usage (from ctv2_runner):

        stream = IBKRStream(
            on_spx_tick    = self._on_spx_tick,
            spx_aggregator = self._spx_agg,
        )
        stream.reset_bars()
        stream.start()
        ...
        stream.stop()

    on_spx_tick signature : (price: float, timestamp: str) -> None
    on_bar_close is wired through spx_aggregator - see spx_bars.py.

    The optional client= keyword argument is accepted but ignored.
    It exists solely so the ctv2_runner constructor call can be updated
    to drop client= in Phase 4 without touching anything else.
    """

    def __init__(self,
                 on_spx_tick:    Callable[[float, str], None],
                 spx_aggregator: SpxBarAggregator,
                 symbol:         str  = 'SPX',
                 client_id:      int  = 1,
                 client=None):   # accepted, not used - IB connection is internal
        self._on_spx_tick    = on_spx_tick
        self._spx_aggregator = spx_aggregator
        self._symbol         = symbol.upper().strip()
        self._client_id      = client_id

        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._loop:   Optional[asyncio.AbstractEventLoop] = None
        self._ib:     Optional[IB] = None

        # Reconnect state tracking
        self._ever_connected: bool = False   # True after first successful connect
        self._gateway_down:   bool = False   # True while waiting for gateway restart

        # Last known SPX price (accessible from runner without waiting for tick)
        self.last_spx: float = 0.0

    # -----------------------------------------------------------------------
    # Public interface  (identical to TradierStream)
    # -----------------------------------------------------------------------

    def start(self):
        """
        Start the stream in a background daemon thread.
        Returns immediately; IB Gateway connection is made asynchronously.
        """
        if self._running:
            print('[STRM] Already running')
            return
        self._running = True
        self._thread = threading.Thread(
            target=self._run_loop, daemon=True, name='IBKRStream'
        )
        self._thread.start()
        print('[STRM] Stream thread started')

    def stop(self):
        """Signal the stream to stop and disconnect from IB Gateway."""
        self._running = False
        if self._ib:
            try:
                if self._loop and self._loop.is_running():
                    self._loop.call_soon_threadsafe(self._ib.disconnect)
            except Exception:
                pass
        if self._loop and self._loop.is_running():
            self._loop.call_soon_threadsafe(self._loop.stop)
        print('[STRM] Stream stop requested')

    def reset_bars(self):
        """
        Reset SpxBarAggregator at session open (09:30 ET).
        Call from ctv2_runner when the trading day begins.
        Discards any partial bars; EMA state is preserved.
        """
        self._spx_aggregator.reset()

    # -----------------------------------------------------------------------
    # Thread entry point
    # -----------------------------------------------------------------------

    def _run_loop(self):
        """Owned by the stream thread.  Creates an asyncio loop and runs forever."""
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._stream_forever())
        except Exception as e:
            print(f'[STRM] Loop exited with error: {e}')
        finally:
            # Cancel all pending tasks for a clean shutdown.
            try:
                pending = asyncio.all_tasks(self._loop)
                if pending:
                    for task in pending:
                        task.cancel()
                    self._loop.run_until_complete(
                        asyncio.gather(*pending, return_exceptions=True)
                    )
            except Exception:
                pass
            self._loop.close()
            print('[STRM] Stream loop closed')

    # -----------------------------------------------------------------------
    # Async stream logic
    # -----------------------------------------------------------------------

    async def _stream_forever(self):
        """
        Reconnect loop - runs until stop() is called.

        Before first successful connection: logs all errors normally so
        startup problems are visible.

        After first successful connection: on any disconnection, logs a
        single "IB Gateway disconnected" message, then retries silently
        every _RECONNECT_DELAY seconds until the gateway comes back.
        Logs a single "Reconnected" message on recovery. Handles the
        daily 11:45 PM auto-restart and the Sunday weekly restart
        (requiring user validation) without special-casing.
        """
        while self._running:
            try:
                await self._connect_and_stream()
                if self._running:
                    if self._ever_connected and not self._gateway_down:
                        print('[STRM] IB Gateway disconnected - waiting for restart')
                        self._gateway_down = True
                        logging.getLogger('ib_insync').setLevel(logging.CRITICAL)
                    await asyncio.sleep(_RECONNECT_DELAY)
            except Exception as e:
                if self._running:
                    if self._ever_connected:
                        if not self._gateway_down:
                            print('[STRM] IB Gateway disconnected - waiting for restart')
                            self._gateway_down = True
                            logging.getLogger('ib_insync').setLevel(logging.CRITICAL)
                    else:
                        # Still on initial connect - log errors so startup
                        # problems are visible.
                        print(f'[STRM] Connection error: {e} - retrying in {_RECONNECT_DELAY}s')
                    await asyncio.sleep(_RECONNECT_DELAY)

    async def _connect_and_stream(self):
        """
        Connect to IB Gateway, subscribe to index market data, and process
        tick events until disconnected or stop() is called.
        A fresh IB() instance is created on every connect attempt so
        ib_insync state is fully reset after any disconnection.
        """
        self._ib = IB()

        if not self._ever_connected:
            print(f'[STRM] Connecting to IB Gateway {_HOST}:{_PORT} '
                  f'(clientId={self._client_id})')
        await self._ib.connectAsync(
            _HOST, _PORT, clientId=self._client_id, timeout=_CONNECT_TIMEOUT
        )

        # Log reconnect if returning from a gateway-down state; otherwise
        # log the normal initial connection message.
        if self._gateway_down:
            print('[STRM] Reconnected to IB Gateway')
            self._gateway_down = False
            logging.getLogger('ib_insync').setLevel(logging.ERROR)
        else:
            print('[STRM] Connected to IB Gateway')
        self._ever_connected = True
        self._ib.errorEvent += self._on_ib_error

        # Resolve the index contract (SPX or XSP - both on CBOE)
        contract = Index(self._symbol, 'CBOE')
        await self._ib.qualifyContractsAsync(contract)

        # Seed EMAs from historical 5-second bars before going live.
        await self._seed_emas_from_history(contract)

        # Subscribe to streaming market data.
        # pendingTickersEvent fires whenever any subscribed ticker has
        # new data - delivers last price updates at sub-second resolution
        # during RTH, which is the tick-level feed spx_bars.py requires.
        self._ib.reqMktData(contract, '', False, False)
        self._ib.pendingTickersEvent += self._on_pending_tickers

        print(f'[STRM] Subscribed to {self._symbol} market data - streaming ticks + bars')

        # Hold the connection open until disconnected or stop() is called.
        while self._running and self._ib.isConnected():
            await asyncio.sleep(0.5)

        # Clean shutdown
        self._ib.pendingTickersEvent -= self._on_pending_tickers
        self._ib.cancelMktData(contract)
        if self._ib.isConnected():
            self._ib.disconnect()

    # -----------------------------------------------------------------------
    # EMA historical seed
    # -----------------------------------------------------------------------

    async def _seed_emas_from_history(self, contract) -> None:
        """
        Request 30 minutes (1800 seconds) of 5-second historical bars from
        IB Gateway and use the closes to compute EMA36 and EMA180 using
        the same alpha constants as spx_bars.py.  Calls
        spx_aggregator.seed_emas() with the result so both EMAs are
        correctly initialised before live streaming begins.

        30 minutes = 360 bars, which is 2x the 180 bars needed for EMA180
        to be fully converged.  EMA36 needs only 36 bars (3 minutes).

        Runs on every connect and reconnect regardless of time of day.
        Pre-market and post-market historical bars are available from
        IB Gateway; useRTH=False would include extended hours data but
        useRTH=True (RTH only) is correct since our EMAs track the regular
        session.  If the request fails or returns no usable bars, streaming
        proceeds with self-warm (graceful degradation - no exception raised).

        whatToShow='TRADES' is correct for the SPX cash index.
        """
        print('[STRM] Requesting 30 min of 5s bars to seed EMAs...')
        try:
            bars = await self._ib.reqHistoricalDataAsync(
                contract,
                endDateTime   = '',
                durationStr   = '1800 S',
                barSizeSetting= '5 secs',
                whatToShow    = 'TRADES',
                useRTH        = True,
                formatDate    = 1,
                keepUpToDate  = False,
            )
        except Exception as e:
            print(f'[STRM] Historical data request failed: {e} - proceeding with self-warm')
            return

        if not bars:
            print('[STRM] No historical bars returned - proceeding with self-warm')
            return

        # EMA smoothing factors - must match spx_bars.py exactly
        alpha_36  = 2.0 / (36  + 1)
        alpha_180 = 2.0 / (180 + 1)

        ema36     = None
        ema180    = None
        sep_prev  = 0.0
        sep_curr  = 0.0
        last_close= 0.0

        for bar in bars:
            close = float(bar.close)
            if close <= 0:
                continue
            if ema36 is None:
                ema36  = close
                ema180 = close
            else:
                ema36  = close * alpha_36  + ema36  * (1.0 - alpha_36)
                ema180 = close * alpha_180 + ema180 * (1.0 - alpha_180)
            sep_prev   = sep_curr
            sep_curr   = abs(ema36 - ema180)
            last_close = close

        if ema36 is None:
            print('[STRM] No valid closes in historical bars - proceeding with self-warm')
            return

        self._spx_aggregator.seed_emas(
            ema36      = ema36,
            ema180     = ema180,
            sep_prev   = sep_prev,
            sep_curr   = sep_curr,
            last_close = last_close,
        )
        print(f'[STRM] EMAs seeded from {len(bars)} bars: '
              f'EMA36={ema36:.4f} EMA180={ema180:.4f} sep={sep_curr:.4f}')

    # -----------------------------------------------------------------------
    # Error suppression
    # -----------------------------------------------------------------------

    def _on_ib_error(self, reqId: int, errorCode: int,
                     errorString: str, contract) -> None:
        """Suppress Error 300 (cancelMktData noise). All others pass through."""
        if errorCode == 300:
            return

    # -----------------------------------------------------------------------
    # Tick delivery
    # -----------------------------------------------------------------------

    def _on_pending_tickers(self, tickers):
        """
        Called by ib_insync when any subscribed ticker has pending updates.
        Extracts the SPX last price and dispatches to both callbacks.
        Skips ticks where last price is zero, negative, or NaN (IB
        sends placeholder values before the first real print arrives).
        """
        for ticker in tickers:
            price = ticker.last
            if not price or price <= 0 or price != price:   # 0 / neg / NaN guard
                continue
            ts = (ticker.time.isoformat()
                  if ticker.time else
                  datetime.now(ET).isoformat())
            self._dispatch_spx(price, ts)

    def _dispatch_spx(self, price: float, ts: str):
        """
        Route a confirmed SPX price to:
          1. last_spx (always)
          2. on_spx_tick callback (win target monitoring)
          3. spx_aggregator.on_spx_tick (bar + EMA construction)
        """
        self.last_spx = price

        try:
            self._on_spx_tick(price, ts)
        except Exception as e:
            print(f'[STRM] on_spx_tick callback error: {e}')

        try:
            self._spx_aggregator.on_spx_tick(price)
        except Exception as e:
            print(f'[STRM] spx_aggregator.on_spx_tick error: {e}')


# ---------------------------------------------------------------------------
# Quick test (run directly - requires IB Gateway running on port 7497)
# ---------------------------------------------------------------------------

if __name__ == '__main__':
    import sys
    import time
    from spx_bars import SpxBarAggregator

    try:
        import config_ctv2 as _cfg
        _symbol = getattr(_cfg, 'UNDERLYING', 'SPX').upper()
    except ImportError:
        _symbol = 'SPX'

    ticks_seen = 0
    bars_seen  = 0

    def on_tick(price, ts):
        global ticks_seen
        ticks_seen += 1
        if ticks_seen % 10 == 1:
            print(f'[TEST] {_symbol} tick #{ticks_seen}: {price}  ts={ts}')

    def on_bar(bar):
        global bars_seen
        bars_seen += 1
        print(f'[TEST] 3m BAR  {bar["bar_start_time"].strftime("%H:%M")}  '
              f'O={bar["open"]:.2f} H={bar["high"]:.2f} '
              f'L={bar["low"]:.2f} C={bar["close"]:.2f}')

    spx_agg = SpxBarAggregator(on_bar_close=on_bar)
    stream  = IBKRStream(on_spx_tick=on_tick, spx_aggregator=spx_agg, symbol=_symbol)
    stream.reset_bars()
    stream.start()

    print(f'[TEST] Streaming {_symbol} for 30 seconds - Ctrl+C to stop early')
    try:
        time.sleep(30)
    except KeyboardInterrupt:
        pass
    finally:
        stream.stop()
        print(f'[TEST] Done. Ticks={ticks_seen}  Bars={bars_seen}')
        sys.exit(0)
