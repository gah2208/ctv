"""
tradier_stream.py - Tradier WebSocket Stream for CTV2
======================================================
Manages the WebSocket connection to Tradier's market event stream.
Delivers two data products to ctv2_runner.py:

  1. RAW TICKS  (every SPX trade/quote event)
       on_spx_tick(price: float, timestamp: str)
       Used by: intrabar win target monitoring

  2. 3-MIN BARS  (via SpxBarAggregator - built from SPX 5-second ticks)
       spx_aggregator.on_spx_tick() receives every SPX tick.
       SpxBarAggregator constructs 5-second bars, aggregates to 3-minute
       bars, and fires on_bar_close(bar) on each 3-minute completion.
       Used by: EMA36/EMA180 signal generation, entry/park/butterfly logic

Architecture
------------
  TradierStream runs in a dedicated daemon thread.
  It owns an asyncio event loop internally (WebSocket mode) or uses a plain
  threading loop (sandbox REST poll mode).  The caller (ctv2_runner) stays
  on the main thread and receives callbacks via the two hooks above.
  Callbacks are invoked from the stream thread; ctv2_runner must treat
  them as thread-safe notifications (no blocking work inside callbacks).

  Bar construction is fully delegated to SpxBarAggregator (spx_bars.py).
  This module is responsible only for WebSocket connection management and
  routing raw SPX tick events to the correct handler.

Signal source
-------------
  SPX ticks are used natively for both win target monitoring and bar/EMA
  construction. No proxy instrument (SPY) or ratio conversion is needed.
  Every SPX tick feeds both on_spx_tick (win targets) and
  spx_aggregator.on_spx_tick (bar + EMA construction).

Sandbox vs Live
---------------
  Tradier sandbox does NOT support WebSocket streaming (401).
  In sandbox mode (client.sandbox == True), TradierStream automatically
  uses a REST polling fallback:
    - Polls get_quote('SPX') every _SANDBOX_TICK_INTERVAL seconds
  The interface to ctv2_runner is identical in both modes.

Session management
------------------
  Tradier WebSocket requires a session ID obtained via REST before
  connecting.  Session IDs expire in ~5 minutes.  TradierStream
  refreshes the session ID on every reconnect automatically.

Reconnect policy
----------------
  On any connection drop or error the stream waits _RECONNECT_DELAY
  seconds then re-obtains a session ID and reconnects.  This loop
  runs forever - the only way to stop it is stop().

Revision history
----------------
Rev 10: Removed 'trade' and 'quote' from subscription filter and _handle_message.
        Both message types carried stale on-connect snapshots that poisoned
        pre-market bars with stale OHLC values. 'timesale' is the sole
        authoritative price source during market hours.
Rev 9: Fixed tight reconnect loop caused by Tradier "too many sessions"
       error. Root cause: creating a new session on every reconnect stacks
       up sessions beyond Tradier's per-account limit (1 concurrent).
       Fix: session is now reused across reconnects until TTL expires (270s),
       matching original behaviour. Added delay on clean server-side close
       (previously only exceptions triggered the reconnect delay, so a clean
       close produced an instant tight loop). Added raw message diagnostic
       logging (first 3 msgs per connection) and catch-all for error/unknown
       message types.
Rev 8: Disabled websockets client-side ping (ping_interval=None). Tradier
       does not respond to WebSocket ping frames and sends no close frame,
       causing the websockets library to terminate the connection with a
       1011 keepalive timeout error every ~30 seconds. Session TTL refresh
       at 270s already handles reconnection hygiene.
Rev 7: Fixed timesale handler to use 'last' field (not 'price') and 'date'
       timestamp. Tradier timesale events do not contain a 'price' field -
       every timesale tick was being silently dropped, causing bars to stop
       after market open.
Rev 6: Added 'timesale' to subscription filter and _handle_message routing.
Rev 5: SPX native bars. SPY subscription and SpyBarAggregator removed.
       SpxBarAggregator (spx_bars.py) replaces SpyBarAggregator.
       Every SPX tick now feeds both on_spx_tick (win targets) and
       spx_aggregator.on_spx_tick (bar + EMA construction).
       SPY polling removed from sandbox loop.
       spy_aggregator parameter renamed to spx_aggregator.
Rev 4: SPY bar construction. _BarAccumulator removed. Bar construction
       delegated entirely to SpyBarAggregator (spy_bars.py).
       - __init__ now accepts spy_aggregator: SpyBarAggregator instead
         of on_bar_close callable.
       - WebSocket subscribes to both SPX and SPY.
       - SPY trade events routed to spy_aggregator.on_spy_trade().
       - SPX trade/quote events still routed to on_spx_tick unchanged.
       - reset_bars() now calls spy_aggregator.reset().
       - Sandbox poll loop extended to poll SPY quote for bar feed.
Rev 3: Clean asyncio shutdown in _run_loop(). After the loop stops,
       cancel all pending tasks and allow them to finish before closing
       the loop. Eliminates "Task was destroyed but it is pending" and
       "Event loop is closed" warnings on Ctrl+C / clean shutdown.
Rev 2: Sandbox REST polling fallback. Tradier sandbox does not support
       WebSocket streaming (401) or historical timesales (400). When
       client.sandbox is True, TradierStream polls get_quote('SPX')
       every _SANDBOX_TICK_INTERVAL seconds instead of opening a
       WebSocket. The _BarAccumulator and all callbacks are shared
       between both modes - the interface to ctv2_runner is unchanged.
Rev 1: Initial implementation.
"""

from __future__ import annotations

import asyncio
import json
import threading
import time
from datetime import datetime, timezone
from typing import Callable, Optional
from zoneinfo import ZoneInfo

import websockets

from tradier_client import TradierClient
from spx_bars import SpxBarAggregator


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_WS_URI                = 'wss://ws.tradier.com/v1/markets/events'
_SESSION_TTL           = 270          # refresh session ID every 4.5 min (TTL is ~5 min)
_RECONNECT_DELAY       = 5            # seconds to wait before reconnect attempt
_BAR_MINUTES           = 3            # bar size in minutes
_SESSION_OPEN_H        = 9            # RTH open hour  ET
_SESSION_OPEN_M        = 30           # RTH open minute ET
_SANDBOX_TICK_INTERVAL = 5            # seconds between REST quote polls in sandbox mode
ET                     = ZoneInfo('America/New_York')


# ---------------------------------------------------------------------------
# Internal sentinel - raised by _handle_message on Tradier session-limit error
# ---------------------------------------------------------------------------

class _TooManySessions(Exception):
    """Raised when Tradier reports too many concurrent stream sessions.
    Caught by _stream_forever to trigger a long back-off before retrying."""


# ---------------------------------------------------------------------------
# Bar accumulation is handled by SpxBarAggregator in spx_bars.py.
# TradierStream routes raw SPX tick events to SpxBarAggregator.on_spx_tick().
# SpxBarAggregator constructs 5-second bars, aggregates to 3-minute bars,
# maintains EMA36/EMA180 state, and fires on_bar_close(bar) on completion.
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Stream
# ---------------------------------------------------------------------------

class TradierStream:
    """
    Manages the Tradier market data stream for SPX.

    In live mode: WebSocket stream from wss://ws.tradier.com
    In sandbox mode: REST polling via get_quote() every 5s
      (Tradier sandbox does not support WebSocket streaming.)

    Usage (from ctv2_runner):

        spx_agg = SpxBarAggregator(on_bar_close=self._on_bar_complete)
        stream = TradierStream(
            client          = tradier_client_instance,
            on_spx_tick     = self._on_spx_tick,    # called on every SPX tick
            spx_aggregator  = spx_agg,               # receives SPX ticks for bars
        )
        stream.start()
        ...
        stream.stop()

    on_spx_tick signature : (price: float, timestamp: str) -> None
    on_bar_close is wired through spx_aggregator - see spx_bars.py.
    """

    def __init__(self,
                 client:         TradierClient,
                 on_spx_tick:    Callable[[float, str], None],
                 spx_aggregator: SpxBarAggregator):
        self._client          = client
        self._on_spx_tick     = on_spx_tick
        self._spx_aggregator  = spx_aggregator

        self._running      = False
        self._thread: Optional[threading.Thread] = None
        self._loop:   Optional[asyncio.AbstractEventLoop] = None

        # Session management (WebSocket mode only)
        self._session_id:      Optional[str] = None
        self._session_fetched: float = 0.0   # epoch seconds

        # Diagnostic: log first N raw messages per connection
        self._diag_count: int = 0

        # Last known SPX price (accessible from runner without waiting for tick)
        self.last_spx: float = 0.0

    # -----------------------------------------------------------------------
    # Public interface
    # -----------------------------------------------------------------------

    def start(self):
        """
        Start the stream in a background daemon thread.
        Automatically uses REST polling in sandbox mode.
        Returns immediately; stream connects asynchronously.
        """
        if self._running:
            print('[STRM] Already running')
            return
        self._running = True

        if self._client.sandbox:
            # Sandbox: WebSocket not supported - use REST polling
            print('[STRM] Sandbox mode - using REST poll fallback '
                  f'(every {_SANDBOX_TICK_INTERVAL}s)')
            self._thread = threading.Thread(
                target=self._sandbox_poll_loop, daemon=True, name='TradierStream'
            )
        else:
            # Live: use WebSocket stream
            self._thread = threading.Thread(
                target=self._run_loop, daemon=True, name='TradierStream'
            )

        self._thread.start()
        print('[STRM] Stream thread started')

    def stop(self):
        """Signal the stream to stop. Returns immediately."""
        self._running = False
        if self._loop and self._loop.is_running():
            self._loop.call_soon_threadsafe(self._loop.stop)
        print('[STRM] Stream stop requested')

    def reset_bars(self):
        """
        Reset SpxBarAggregator at session open (09:30 ET).
        Call from ctv2_runner when the trading day begins.
        Discards any partial bars; EMA state is preserved.
        """
        self._spx_aggregator.reset()

    # -----------------------------------------------------------------------
    # Sandbox REST polling (replaces WebSocket in sandbox mode)
    # -----------------------------------------------------------------------

    def _sandbox_poll_loop(self):
        """
        Poll get_quote('SPX') every _SANDBOX_TICK_INTERVAL seconds.
        - SPX price -> on_spx_tick (win target monitoring)
        - SPX price -> spx_aggregator.on_spx_tick (bar + EMA construction)
        """
        print('[STRM] Sandbox poll loop running')
        consecutive_errors = 0
        while self._running:
            try:
                q_spx = self._client.get_quote('SPX')
                spx_price = float(q_spx.get('last') or q_spx.get('close') or 0.0)
                if spx_price > 0:
                    ts = datetime.now(tz=ET).isoformat()
                    self._dispatch_spx(spx_price, ts)
                    consecutive_errors = 0
                else:
                    print('[STRM] Sandbox poll: SPX quote returned no price')

            except Exception as e:
                consecutive_errors += 1
                if consecutive_errors <= 3 or consecutive_errors % 10 == 0:
                    print(f'[STRM] Sandbox poll error ({consecutive_errors}): {e}')
            time.sleep(_SANDBOX_TICK_INTERVAL)
        print('[STRM] Sandbox poll loop stopped')

    # -----------------------------------------------------------------------
    # WebSocket thread entry point (live mode)
    # -----------------------------------------------------------------------

    def _run_loop(self):
        """Owned by the stream thread. Creates an asyncio loop and runs forever."""
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._stream_forever())
        except Exception as e:
            print(f'[STRM] Loop exited with error: {e}')
        finally:
            # Cancel all pending tasks so websockets can shut down cleanly.
            # Without this, websockets' keepalive/recv coroutines print
            # "Task was destroyed" and "Event loop is closed" warnings.
            try:
                pending = asyncio.all_tasks(self._loop)
                if pending:
                    for task in pending:
                        task.cancel()
                    self._loop.run_until_complete(
                        asyncio.gather(*pending, return_exceptions=True)
                    )
            except Exception:
                pass
            self._loop.close()
            print('[STRM] Stream loop closed')

    # -----------------------------------------------------------------------
    # Async stream logic (live mode)
    # -----------------------------------------------------------------------

    _SESSION_LIMIT_BACKOFF = 300  # seconds to wait on "too many sessions" (5 min)

    async def _stream_forever(self):
        """Reconnect loop - runs until stop() is called."""
        while self._running:
            try:
                await self._connect_and_stream()
                # Clean exit (server closed connection without error).
                # Delay before reconnecting to avoid hammering Tradier.
                if self._running:
                    print(f'[STRM] Connection closed cleanly - '
                          f'reconnecting in {_RECONNECT_DELAY}s')
                    await asyncio.sleep(_RECONNECT_DELAY)
            except _TooManySessions:
                if self._running:
                    print(f'[STRM] Too many sessions - backing off '
                          f'{self._SESSION_LIMIT_BACKOFF}s. '
                          f'If this persists >5min, contact Tradier support '
                          f'to clear stuck sessions on your account.')
                    await asyncio.sleep(self._SESSION_LIMIT_BACKOFF)
            except Exception as e:
                if self._running:
                    print(f'[STRM] Stream error: {e}  - reconnecting in '
                          f'{_RECONNECT_DELAY}s')
                    await asyncio.sleep(_RECONNECT_DELAY)

    async def _connect_and_stream(self):
        """
        Obtain a session ID, open the WebSocket, and process messages
        until the connection drops or stop() is called.
        Session is always refreshed at the start of each attempt - Tradier
        invalidates a session when its connection closes, so reusing the
        cached ID causes an immediate clean close on every reconnect.
        """
        self._diag_count = 0   # reset per-connection diagnostic counter
        session_id = await self._get_session_id()

        payload = json.dumps({
            'symbols':   ['SPX'],
            'filter':    ['timesale'],
            'sessionid': session_id,
            'linebreak': True,
            'validOnly': False,
        })

        print(f'[STRM] Connecting to {_WS_URI} (session={session_id[:8]}...)')
        async with websockets.connect(
            _WS_URI,
            ssl=True,
            compression=None,
            ping_interval=None,   # Tradier does not respond to WebSocket pings;
                                   # client-side keepalive causes 1011 errors.
                                   # Session TTL refresh at 270s handles reconnect.
        ) as ws:
            await ws.send(payload)
            print(f'[STRM] Connected - streaming SPX (ticks + bars)')

            async for raw_msg in ws:
                if not self._running:
                    break
                await self._handle_message(raw_msg)

                # Refresh session ID proactively before it expires
                if time.time() - self._session_fetched > _SESSION_TTL:
                    print('[STRM] Session TTL approaching - refreshing')
                    self._session_id      = None
                    self._session_fetched = 0.0
                    break   # reconnect loop will fetch a new session

    async def _get_session_id(self) -> str:
        """
        Returns a valid session ID, fetching a new one if needed.
        Runs the blocking REST call in a thread executor so the
        async loop stays unblocked.
        """
        if self._session_id and \
                (time.time() - self._session_fetched) < _SESSION_TTL:
            return self._session_id

        loop = asyncio.get_event_loop()
        session_id = await loop.run_in_executor(
            None, self._client.create_stream_session
        )
        self._session_id      = session_id
        self._session_fetched = time.time()
        return session_id

    # -----------------------------------------------------------------------
    # Message handling (WebSocket mode)
    # -----------------------------------------------------------------------

    async def _handle_message(self, raw: str):
        """Parse one Tradier stream message and route to the correct handler."""
        # Log first 3 raw messages per connection for diagnostics
        self._diag_count += 1
        if self._diag_count <= 3:
            print(f'[STRM] raw msg #{self._diag_count}: {raw[:300]}')

        try:
            msg = json.loads(raw)
        except json.JSONDecodeError:
            return

        msg_type = msg.get('type')
        symbol   = msg.get('symbol', '')

        # Tradier session limit error - signal caller to back off
        if 'error' in msg:
            err = msg['error']
            print(f'[STRM] Tradier stream error msg: {msg}')
            if 'too many sessions' in str(err).lower():
                raise _TooManySessions(err)
            return

        if symbol == 'SPX':
            if msg_type == 'timesale':
                price = float(msg.get('last', 0) or 0)
                ts    = msg.get('date', '')
                if price > 0:
                    self._dispatch_spx(price, ts)

            elif msg_type not in ('trade', 'quote'):
                print(f'[STRM] Unhandled SPX msg type={msg_type!r}: {msg}')



    def _dispatch_spx(self, price: float, ts: str):
        """
        Route a confirmed SPX price to:
          1. last_spx (always)
          2. on_spx_tick callback (win target monitoring)
          3. spx_aggregator.on_spx_tick (bar + EMA construction)
        """
        self.last_spx = price

        try:
            self._on_spx_tick(price, ts)
        except Exception as e:
            print(f'[STRM] on_spx_tick callback error: {e}')

        try:
            self._spx_aggregator.on_spx_tick(price)
        except Exception as e:
            print(f'[STRM] spx_aggregator.on_spx_tick error: {e}')


# ---------------------------------------------------------------------------
# Quick test (run directly - requires valid config_ctv2.py credentials)
# ---------------------------------------------------------------------------

if __name__ == '__main__':
    import sys
    from tradier_client import TradierClient
    from spx_bars import SpxBarAggregator

    ticks_seen = 0
    bars_seen  = 0

    def on_tick(price, ts):
        global ticks_seen
        ticks_seen += 1
        if ticks_seen % 10 == 1:
            print(f'[TEST] SPX tick #{ticks_seen}: {price}  ts={ts}')

    def on_bar(bar):
        global bars_seen
        bars_seen += 1
        print(f'[TEST] 3m BAR  {bar["bar_start_time"].strftime("%H:%M")}  '
              f'O={bar["open"]:.2f} H={bar["high"]:.2f} '
              f'L={bar["low"]:.2f} C={bar["close"]:.2f}')

    client  = TradierClient()
    spx_agg = SpxBarAggregator(on_bar_close=on_bar)
    stream  = TradierStream(client=client,
                            on_spx_tick=on_tick,
                            spx_aggregator=spx_agg)
    stream.start()

    mode = 'SANDBOX REST poll' if client.sandbox else 'LIVE WebSocket'
    print(f'[TEST] Streaming ({mode}) for 30 seconds - Ctrl+C to stop early')
    try:
        time.sleep(30)
    except KeyboardInterrupt:
        pass
    finally:
        stream.stop()
        print(f'[TEST] Done. Ticks={ticks_seen}  Bars={bars_seen}')
        sys.exit(0)
