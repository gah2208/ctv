# ============================================================
#  Update.ps1 - CTV2 Updater
#  Revision: 2.4
#  Downloads latest ctv.zip from GitHub, extracts to C:\CTV,
#  merges config settings, refreshes install_manifest.json integrity
#  hashes, then recreates desktop shortcuts.
#
#  Place this file in C:\CTV
#  Usage: Double-click / Run with PowerShell
#
#  v2.4 - IB Gateway exe search path corrected to C:\Program Files\ibgateway.
#  v2.3 - User-facing text updated from CTV2 to VTB branding.
#  v2.2 - Version guard: peeks VERSION file inside downloaded zip before
#          extracting. Aborts with clear message if zip version is older
#          than currently installed version (prevents GitHub-not-updated
#          from silently rolling back a manual deployment).
#  v1.1 - Replaced config skip/restore with merge_config.py.
#  v1.2 - Fixed $manifestPath used before defined. Removed em dash.
#  v1.3 - Added non-ASCII scan and fix on extracted files.
#  v1.4 - Fixed Repair-NonAscii to write UTF-8 without BOM.
#  v1.5 - Fixed merge output display.
#  v1.6 - Accept YES or yes at confirmation prompt.
#  v2.0 - Repair-NonAscii: replaced slow byte-pipeline with fast Regex.IsMatch()
#          check. Reduces non-ASCII scan from minutes to seconds.
#  v1.9 - Removed Step 4b file integrity check (hash mismatches due to
#          line ending differences between build and install machines).
#  v1.7 - Added -SkipConfirm and -SkipMerge switches for use by
#          CTV_Install bootstrap (clean install, no prior config).
# ============================================================
param(
    [switch]$SkipConfirm,
    [switch]$SkipMerge
)

Set-Location -Path "C:\CTV"

$CTV_DIR     = "C:\CTV"

function Get-SHA256FileNormalized { param([string]$Path)
    if (-not $Path -or -not (Test-Path $Path)) { return $null }
    $bytes = [System.IO.File]::ReadAllBytes($Path)
    $cr = [char]13
    $lf = [char]10
    $text = [System.Text.Encoding]::UTF8.GetString($bytes)
    $normalized = $text.Replace([string]$cr + [string]$lf, [string]$lf).Replace([string]$cr, [string]$lf)
    $normBytes = [System.Text.Encoding]::UTF8.GetBytes($normalized)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $hashBytes = $sha.ComputeHash($normBytes)
    return ([BitConverter]::ToString($hashBytes) -replace '-','').ToUpper()
}

$ZIP_URL     = "https://github.com/gah2208/ctv/releases/latest/download/ctv.zip"
$ZIP_PATH    = "$CTV_DIR\ctv_update.zip"
$EXTRACT_DIR = "$CTV_DIR\_update_tmp"

Write-Host ""
Write-Host "============================================================"
Write-Host "  VTB UPDATER"
Write-Host "============================================================"
Write-Host ""

# -- Step 1: Confirm ----------------------------------------------------------
Write-Host "  This will download and install the latest VTB release."
Write-Host "  Existing files in C:\CTV will be overwritten."
Write-Host "  Your config_ctv2.py will be preserved."
Write-Host ""
if (-not $SkipConfirm) {
    $confirm = Read-Host "  Type YES to continue"
    if ($confirm -ne "YES" -and $confirm -ne "yes") {
        Write-Host ""
        Write-Host "  Update cancelled."
        Write-Host ""
        Read-Host "Press Enter to exit"
        exit
    }
}

# -- Step 2: Stop any running CTV2 instance -----------------------------------
Write-Host ""
Write-Host "  [1/5] Stopping any running VTB processes..."
Get-Process python -ErrorAction SilentlyContinue |
    Where-Object { $_.MainWindowTitle -like "ctv2*" } |
    Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
Write-Host "        Done."

# -- Step 3: Download ctv.zip -------------------------------------------------
Write-Host ""
Write-Host "  [2/5] Downloading latest release..."
Write-Host "        $ZIP_URL"
try {
    $ProgressPreference = 'SilentlyContinue'
    Invoke-WebRequest -Uri $ZIP_URL -OutFile $ZIP_PATH -UseBasicParsing
    Write-Host "        Download complete."
} catch {
    Write-Host ""
    Write-Host "  ERROR: Download failed."
    Write-Host "  $_"
    Write-Host ""
    Write-Host "  Check your internet connection and try again."
    Read-Host "Press Enter to exit"
    exit 1
}

# -- Version guard: peek VERSION inside zip before extracting ----------------
Write-Host ""
Write-Host "  Verifying zip version..."
$zipVersion       = $null
$installedVersion = $null
try {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zipObj   = [System.IO.Compression.ZipFile]::OpenRead($ZIP_PATH)
    $verEntry = $zipObj.Entries | Where-Object { $_.FullName -eq 'VERSION' } | Select-Object -First 1
    if ($verEntry) {
        $reader     = New-Object System.IO.StreamReader($verEntry.Open())
        $zipVersion = $reader.ReadToEnd().Trim()
        $reader.Close()
    }
    $zipObj.Dispose()
} catch {
    Write-Host "        Warning: could not read VERSION from zip - $_"
}

$versionFile = "$CTV_DIR\VERSION"
if (Test-Path $versionFile) {
    $installedVersion = (Get-Content $versionFile -Raw).Trim()
}

if ($zipVersion)       { Write-Host "        Zip version:       v$zipVersion" }
if ($installedVersion) { Write-Host "        Installed version: v$installedVersion" }

if ($zipVersion -and $installedVersion) {
    try {
        if ([version]$zipVersion -lt [version]$installedVersion) {
            Write-Host ""
            Write-Host "  ERROR: Downloaded zip (v$zipVersion) is OLDER than installed version (v$installedVersion)."
            Write-Host "  Your GitHub release has not been updated with the latest files yet."
            Write-Host "  Push your latest build to GitHub first, then re-run Update.ps1."
            Write-Host ""
            Remove-Item $ZIP_PATH -Force -ErrorAction SilentlyContinue
            Read-Host "Press Enter to exit"
            exit 1
        } elseif ([version]$zipVersion -eq [version]$installedVersion) {
            Write-Host "        Already at v$installedVersion."
            if (-not $SkipConfirm) {
                $proceed = Read-Host "        Reinstall same version? (YES to continue)"
                if ($proceed -ne "YES" -and $proceed -ne "yes") {
                    Write-Host "  Update cancelled."
                    Remove-Item $ZIP_PATH -Force -ErrorAction SilentlyContinue
                    Read-Host "Press Enter to exit"
                    exit 0
                }
            }
        } else {
            Write-Host "        Version check passed - upgrading v$installedVersion -> v$zipVersion"
        }
    } catch {
        Write-Host "        Warning: could not compare versions - $_"
    }
} elseif ($zipVersion) {
    Write-Host "        Zip version v$zipVersion confirmed (no installed version to compare)."
}

# -- Step 4: Backup config, extract, merge config -----------------------------
Write-Host ""
Write-Host "  [3/5] Installing update..."

# Backup existing config - safety net if merge fails
$CONFIG_FILE   = "$CTV_DIR\config_ctv2.py"
$CONFIG_BACKUP = "$CTV_DIR\config_ctv2.py.bak"
if ((-not $SkipMerge) -and (Test-Path $CONFIG_FILE)) {
    Copy-Item $CONFIG_FILE $CONFIG_BACKUP -Force
    Write-Host "        Config backed up to config_ctv2.py.bak"
}

# Clean up any previous temp extract
if (Test-Path $EXTRACT_DIR) {
    Remove-Item $EXTRACT_DIR -Recurse -Force
}

# Extract zip to temp dir - includes new default config_ctv2.py
try {
    Expand-Archive -Path $ZIP_PATH -DestinationPath $EXTRACT_DIR -Force
} catch {
    Write-Host ""
    Write-Host "  ERROR: Failed to extract zip."
    Write-Host "  $_"
    Read-Host "Press Enter to exit"
    exit 1
}

# Scan and fix non-ASCII characters in extracted .ps1 and .py files
Write-Host "        Scanning extracted files for non-ASCII characters..."

function Repair-NonAscii {
    param([string]$Path)
    $content = [System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::UTF8)
    if (-not [System.Text.RegularExpressions.Regex]::IsMatch($content, '[^\x00-\x7F]')) { return $false }
    $fixed = $content
    $fixed = $fixed -replace [char]0x201C, '"'
    $fixed = $fixed -replace [char]0x201D, '"'
    $fixed = $fixed -replace [char]0x2018, "'"
    $fixed = $fixed -replace [char]0x2019, "'"
    $fixed = $fixed -replace [char]0x2014, '-'
    $fixed = $fixed -replace [char]0x2013, '-'
    $fixed = $fixed -replace [char]0x2500, '-'
    $fixed = $fixed -replace [char]0x2502, '|'
    [System.IO.File]::WriteAllText($Path, $fixed, [System.Text.UTF8Encoding]::new($false))
    return $true
}

$extractedScripts = @(
    Get-ChildItem "$EXTRACT_DIR\*.ps1" -ErrorAction SilentlyContinue
    Get-ChildItem "$EXTRACT_DIR\*.py"  -ErrorAction SilentlyContinue
) | Where-Object { $_ -ne $null }

$fixCount = 0
foreach ($file in $extractedScripts) {
    if (Repair-NonAscii -Path $file.FullName) {
        Write-Host "        FIXED: $($file.Name)"
        $fixCount++
    }
}
if ($fixCount -eq 0) {
    Write-Host "        All files clean."
} else {
    Write-Host "        Fixed $fixCount file(s)."
}

# Copy all extracted files to C:\CTV - including new config_ctv2.py as template
$source = Get-ChildItem $EXTRACT_DIR -Recurse -File
foreach ($file in $source) {
    $dest = $file.FullName.Replace($EXTRACT_DIR, $CTV_DIR)
    $destDir = Split-Path $dest
    if (-not (Test-Path $destDir)) {
        New-Item -ItemType Directory -Path $destDir -Force | Out-Null
    }
    Copy-Item $file.FullName $dest -Force
}

Write-Host "        Files installed."

# Merge user config values into new config template
# existing (backup) -> user's values   new (just installed) -> new defaults
# Result: new keys added with defaults, existing keys preserve user values
$NEW_CONFIG_DEFAULT = "$CTV_DIR\config_ctv2.py"

if (-not $SkipMerge) {
    if (Test-Path $CONFIG_BACKUP) {
        Write-Host ""
        Write-Host "        Merging your config settings into new release..."
        try {
            python "$CTV_DIR\merge_config.py" `
                --existing $CONFIG_BACKUP `
                --new      $NEW_CONFIG_DEFAULT `
                --output   $CONFIG_FILE
            if ($LASTEXITCODE -ne 0) { throw "merge_config.py exited with code $LASTEXITCODE" }
            Write-Host "        Config merge complete."
        } catch {
            Write-Host "        WARNING: Config merge failed ($_) - restoring backup."
            Copy-Item $CONFIG_BACKUP $CONFIG_FILE -Force
        }
    } else {
        Write-Host "        No existing config found - using new defaults."
    }
}

# Update manifest: config hash + integrity hashes for all CTV files
$manifestPath = "$CTV_DIR\install_manifest.json"
if (Test-Path $manifestPath) {
    try {
        $mfst = Get-Content $manifestPath | ConvertFrom-Json

        # Config hash
        $configHash = (Get-FileHash -Path $CONFIG_FILE -Algorithm SHA256).Hash
        if (-not $mfst.config) {
            $mfst | Add-Member -NotePropertyName 'config' -NotePropertyValue ([PSCustomObject]@{
                path   = $CONFIG_FILE
                sha256 = $configHash
            }) -Force
        } else {
            $mfst.config.sha256 = $configHash
            $mfst.config.path   = $CONFIG_FILE
        }

        # CTV Python file hashes (line-ending normalized)
        $ctvFileNames = @(
            "ctv2_runner.py", "ctv2_auth.py", "ctv2_config_editor.py",
            "ctv2_dashboard.py", "ibkr_orders.py", "ibkr_scale.py",
            "ibkr_stream.py", "merge_config.py", "preflight_check.py",
            "pushover_alerts.py", "risk_manager.py", "spx_bars.py",
            "config_ctv2_default.py"
        )
        if (-not $mfst.ctv_files) {
            $mfst | Add-Member -NotePropertyName 'ctv_files' -NotePropertyValue ([PSCustomObject]@{}) -Force
        }
        foreach ($f in $ctvFileNames) {
            $h = Get-SHA256FileNormalized "$CTV_DIR\$f"
            if ($h) {
                if ($mfst.ctv_files.PSObject.Properties[$f]) {
                    $mfst.ctv_files.$f = $h
                } else {
                    $mfst.ctv_files | Add-Member -NotePropertyName $f -NotePropertyValue $h -Force
                }
            }
        }

        # IB Gateway hash (raw bytes)
        if ($mfst.ibgateway) {
            $ibgwPath = $mfst.ibgateway.path
            if (-not $ibgwPath -or -not (Test-Path $ibgwPath)) {
                $found = Get-ChildItem "C:\Program Files\ibgateway" -Recurse -Filter "ibgateway.exe" `
                         -ErrorAction SilentlyContinue | Select-Object -First 1
                if ($found) { $ibgwPath = $found.FullName }
            }
            if ($ibgwPath -and (Test-Path $ibgwPath)) {
                $mfst.ibgateway.path   = $ibgwPath
                $mfst.ibgateway.sha256 = (Get-FileHash -Path $ibgwPath -Algorithm SHA256).Hash
            }
        }

        $mfst | ConvertTo-Json -Depth 5 | Set-Content $manifestPath -Encoding UTF8
        Write-Host "        Integrity manifest refreshed."
    } catch {
        Write-Host "        WARNING: Could not update manifest: $_"
    }
}

# Cleanup temp files
Remove-Item $EXTRACT_DIR -Recurse -Force -ErrorAction SilentlyContinue

# Cleanup downloaded zip (kept until after CTV file verify)
Remove-Item $ZIP_PATH -Force -ErrorAction SilentlyContinue

# -- Step 5: Recreate desktop shortcuts ---------------------------------------
Write-Host ""
Write-Host "  [5/5] Updating desktop shortcuts..."
try {
    & "$CTV_DIR\CREATE_SHORTCUTS.ps1"
} catch {
    Write-Host "        Warning: Could not recreate shortcuts. Run CREATE_SHORTCUTS.ps1 manually."
}

# -- Done ---------------------------------------------------------------------
Write-Host ""
Write-Host "  Update complete!"
Write-Host ""
Write-Host "============================================================"
Write-Host "  VTB has been updated to the latest release."
Write-Host "  Your configuration settings have been preserved."
Write-Host "  Any new parameters have been added with default values."
Write-Host "  Review the Pushover and other tabs in Config Editor if needed."
Write-Host "============================================================"
Write-Host ""
Read-Host "Press Enter to exit"
