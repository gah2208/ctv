@echo off
REM ============================================================
REM  UPDATE.bat - CTV2 Update Launcher
REM  Revision: 1.0
REM  Calls Update.ps1 via PowerShell.
REM  This file must exist in C:\CTV for the shortcut to work.
REM ============================================================
powershell.exe -ExecutionPolicy Bypass -NoProfile -File "C:\CTV\Update.ps1"
pause
