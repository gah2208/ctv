# ============================================================
#  CTV2_WATCHDOG.ps1 - CTV2 Process Watchdog
#  Revision: 1.0
#
#  Run by Task Scheduler at 09:05 AM Mon-Fri.
#  Checks whether ctv2_runner.py is alive.
#  Sends a Pushover alert if not.
#
#  Registered automatically by CTV_Install.exe.
#  Do not run manually.
# ============================================================

# Check if runner is alive
$proc = Get-CimInstance Win32_Process |
        Where-Object { $_.CommandLine -like '*ctv2_runner*' } |
        Select-Object -First 1

if ($proc) {
    # Runner is alive - nothing to do
    exit 0
}

# Runner not found - send Pushover alert
try {
    $cfg = Get-Content "C:\CTV\config_ctv2.py" -ErrorAction SilentlyContinue
    if (-not $cfg) { exit 1 }
    if (-not ($cfg | Select-String "PUSHOVER_ENABLED\s*=\s*True")) { exit 0 }

    $userKey  = ($cfg | Select-String "PUSHOVER_USER_KEY\s*=\s*'([^']+)'").Matches.Groups[1].Value
    $apiToken = ($cfg | Select-String "PUSHOVER_API_TOKEN\s*=\s*'([^']+)'").Matches.Groups[1].Value
    if (-not $userKey -or -not $apiToken) { exit 1 }

    $ts = (Get-Date -Format 'HH:mm')
    Invoke-RestMethod -Uri "https://api.pushover.net/1/messages.json" -Method Post -Body @{
        token    = $apiToken
        user     = $userKey
        title    = "CTV2: Runner Not Running"
        message  = "CTV2 runner was not detected at $ts. The system may have crashed overnight. Check before market open."
        priority = 1
        sound    = "siren"
    } | Out-Null
} catch {
    # Swallow - watchdog should never itself crash loudly
}

exit 1
