@echo off
:: Diagnostic - find exactly where Python 3.11.9 lives in registry
:: Output written to C:\CTV\python_registry.txt so it can't flash by

powershell -NoProfile -Command "
@(
  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
  'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
  'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
) | ForEach-Object {
  Get-ItemProperty $_ -ErrorAction SilentlyContinue
} | Where-Object { $_.DisplayName -like '*Python*' -or $_.DisplayName -like '*python*' } |
Select-Object DisplayName, UninstallString, InstallLocation |
Format-List
" > "C:\CTV\python_registry.txt" 2>&1

echo.
echo Results written to C:\CTV\python_registry.txt
echo Opening now...
echo.
notepad "C:\CTV\python_registry.txt"
