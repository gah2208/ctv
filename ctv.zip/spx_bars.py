#!/usr/bin/env python3
"""
spx_bars.py  -  SPX 5-second and 3-minute bar aggregator for CTV2

REVISION: 5
Rev 5: is_accelerating() now requires sep_curr to exceed the highest sep
       recorded at any prior accel=Y reading in the current direction
       (_peak_accel_sep high-water mark). Prevents entry on a 5s momentum
       blip that fails to make new ground versus the trend's prior peak
       separation. Peak resets on EMA direction flip and on seed_emas().
Rev 4: Added optional on_5s_bar_close callback. Fired at the end of every
       real 5-second bar close (after EMAs updated, lock released) so the
       runner can check entry gates at 5-second resolution without waiting
       for the 3-minute bar boundary.
Rev 3: Added seed_emas() method. Called by ctv2_runner._recover_state() on
       mid-day restart to restore EMA36/EMA180/sep/last_close from the saved
       state file. Prevents re-warming from zero after a crash or restart.
Rev 2: Release self._lock before firing on_bar_close callback and reacquire
       after. Previously the lock was held during the callback, blocking all
       incoming ticks while the runner made blocking REST calls (option chain
       fetch etc). This caused the WebSocket ping to time out and disconnect.

Receives raw SPX tick events from TradierStream and:
  - Builds 5-second OHLC bars aligned to local wall-clock ET boundaries
  - Aggregates 5-second bars into 3-minute OHLC bars (wall-clock aligned)
  - Maintains rolling EMA36 and EMA180 on 5-second bar closes
  - Fires on_bar_close(bar) callback on each 3-minute bar completion
  - Exposes is_accelerating(direction) for the chain reentry gate

EMA time equivalence
--------------------
  EMA36  on 5s bars = 36 x 5s = 180s =  3 min  (equivalent to EMA3  on 3-min bars)
  EMA180 on 5s bars = 180 x 5s = 900s = 15 min  (equivalent to EMA15 on 3-min bars)

EMA self-warm policy
--------------------
  No historical seed required. EMA180 accumulates from live SPX ticks from
  09:30. By TRADING_START (10:00), 120 of 180 bars have accumulated which
  is sufficient for reliable signal (prior-day seed influence < 2%).

Bar boundary rules
------------------
  5-second bars : floor(timestamp.second / 5) * 5  -> closes at :00 :05 :10 ... :55
  3-minute bars : floor(timestamp.minute  / 3) * 3  -> closes at :00 :03 :06 ... :57

Flat bar policy
---------------
  If no SPX ticks arrive during a 5-second window, a flat bar is emitted
  (O=H=L=C=prior_close, V=0) to keep the EMA series continuous.
  Flat bars are detected lazily: when the next real tick arrives we emit one
  flat bar per missed 5-second window before processing the new tick.
  This matches ThetaData's own documented behaviour for sparse index feeds.

Thread safety
-------------
  on_spx_tick() may be called from a WebSocket callback thread.
  All mutable state is protected by self._lock (threading.Lock).
"""

from __future__ import annotations

import threading
from datetime import datetime, timedelta
from typing import Callable, Optional
from zoneinfo import ZoneInfo

REVISION = 5

ET = ZoneInfo("America/New_York")

# EMA smoothing factors
_ALPHA_36  = 2.0 / (36  + 1)   # ~0.05405
_ALPHA_180 = 2.0 / (180 + 1)   # ~0.01105

# Bar period constants
_5S_SECONDS = 5
_3M_SECONDS = 180
_5S_PER_3M  = _3M_SECONDS // _5S_SECONDS   # 36


# =============================================================================
# Wall-clock alignment helpers
# =============================================================================

def _floor_5s(dt: datetime) -> datetime:
    """Floor a datetime to the nearest 5-second wall-clock boundary."""
    return dt.replace(second=(dt.second // _5S_SECONDS) * _5S_SECONDS,
                      microsecond=0)


def _floor_3m(dt: datetime) -> datetime:
    """Floor a datetime to the nearest 3-minute wall-clock boundary."""
    return dt.replace(minute=(dt.minute // 3) * 3,
                      second=0, microsecond=0)


# =============================================================================
# Main aggregator
# =============================================================================

class SpxBarAggregator:
    """
    Aggregates SPX index ticks into 5-second and 3-minute OHLC bars.

    Usage
    -----
    1. Instantiate with the on_bar_close callback.
    2. Wire TradierStream to call on_spx_tick() on every SPX tick event.
    3. Call reset() on stream reconnect.
    4. Query is_accelerating(direction) inside _try_chain_entry().
    """

    REVISION = 4

    def __init__(self, on_bar_close: Callable[[dict], None],
                 on_5s_bar_close: Optional[Callable[[], None]] = None):
        """
        Parameters
        ----------
        on_bar_close : callable
            Fired when a 3-minute bar completes.
            Signature: on_bar_close(bar: dict)
            bar keys: open, high, low, close, bar_start_time
        on_5s_bar_close : callable, optional
            Fired after every real 5-second bar close, with lock released.
            Signature: on_5s_bar_close() -> None
            Used by ctv2_runner to check entry gates at 5-second resolution.
        """
        self._on_bar_close    = on_bar_close
        self._on_5s_bar_close = on_5s_bar_close
        self._lock            = threading.Lock()

        # -- EMA state -----------------------------------------------------
        # None until seeded or first bar self-warms.
        self._ema36:  Optional[float] = None
        self._ema180: Optional[float] = None

        # -- Separation tracking for acceleration check --------------------
        # sep_prev: separation at the end of the previous 5s bar
        # sep_curr: separation at the end of the current  5s bar
        # _peak_accel_sep: highest sep recorded at any accel=Y in current direction
        # _accel_dir: EMA direction ('UP'/'DOWN'/'') when peak was last set
        self._sep_prev:       float = 0.0
        self._sep_curr:       float = 0.0
        self._peak_accel_sep: float = 0.0
        self._accel_dir:      str   = ''

        # -- Current 5-second bar accumulator ------------------------------
        self._5s_bar_start: Optional[datetime] = None
        self._5s_open:      Optional[float]    = None
        self._5s_high:      float              = 0.0
        self._5s_low:       float              = float('inf')
        self._5s_close:     Optional[float]    = None
        self._5s_volume:    int                = 0

        # -- Current 3-minute bar accumulator ------------------------------
        self._3m_bar_start: Optional[datetime] = None
        self._3m_open:      Optional[float]    = None
        self._3m_high:      float              = 0.0
        self._3m_low:       float              = float('inf')
        self._3m_close:     Optional[float]    = None
        self._3m_volume:    int                = 0

        # -- Last known close (used for flat bar emission) -----------------
        self._last_close: float = 0.0

    # =========================================================================
    # PUBLIC API
    # =========================================================================

    def on_spx_tick(self, price: float):
        """
        Called by TradierStream on every SPX tick event.
        Uses local wall-clock ET for bar boundary decisions.
        Thread-safe.
        """
        if price <= 0:
            return
        now = datetime.now(ET)
        with self._lock:
            self._process_tick(price, now)

    def is_accelerating(self, direction: str) -> bool:
        """
        Returns True if EMA36/EMA180 separation is currently wider than it
        was at the end of the previous 5-second bar, AND the EMAs are aligned
        with the requested direction.

        direction='UP'  : requires EMA36 > EMA180 and separation increasing
        direction='DOWN': requires EMA36 < EMA180 and separation increasing

        Returns False if EMAs are not yet seeded.
        Thread-safe.
        """
        with self._lock:
            if self._ema36 is None or self._ema180 is None:
                return False
            if direction == 'UP'   and self._ema36 <= self._ema180:
                return False
            if direction == 'DOWN' and self._ema36 >= self._ema180:
                return False
            return (self._sep_curr > self._sep_prev
                    and self._sep_curr > self._peak_accel_sep)

    def get_ema_state(self) -> dict:
        """
        Return current EMA state snapshot for diagnostics / logging.
        Keys: ema36, ema180, sep_curr, sep_prev, accelerating_up, accelerating_dn
        Thread-safe.
        """
        with self._lock:
            e36  = self._ema36  or 0.0
            e180 = self._ema180 or 0.0
            return {
                'ema36':           e36,
                'ema180':          e180,
                'sep_curr':        self._sep_curr,
                'sep_prev':        self._sep_prev,
                'peak_accel_sep':  self._peak_accel_sep,
                'accelerating_up': (e36 > e180 and self._sep_curr > self._sep_prev
                                    and self._sep_curr > self._peak_accel_sep),
                'accelerating_dn': (e36 < e180 and self._sep_curr > self._sep_prev
                                    and self._sep_curr > self._peak_accel_sep),
            }

    def reset(self):
        """
        Called on stream reconnect.
        Discards any partial 5-second and 3-minute bar accumulators.
        EMA state is preserved - it will self-correct as bars arrive.
        After reset the aggregator waits for the next wall-clock boundary
        before starting new bars.
        """
        with self._lock:
            self._5s_bar_start = None
            self._5s_open      = None
            self._5s_close     = None
            self._5s_high      = 0.0
            self._5s_low       = float('inf')
            self._5s_volume    = 0
            self._3m_bar_start = None
            self._3m_open      = None
            self._3m_close     = None
            self._3m_high      = 0.0
            self._3m_low       = float('inf')
            self._3m_volume    = 0
        print("[SPXB ] reset() - partial bars discarded, EMAs preserved")

    def seed_emas(self, ema36: float, ema180: float,
                  sep_prev: float, sep_curr: float,
                  last_close: float):
        """
        Restore EMA state from a previously saved snapshot.
        Called by ctv2_runner._recover_state() on mid-day restart so the
        aggregator resumes from the last known state rather than re-warming
        from zero.

        Parameters match the keys written by _save_state() via get_ema_state():
            ema36, ema180  : EMA values at time of last save
            sep_prev       : separation at the previous 5s bar
            sep_curr       : separation at the last completed 5s bar
            last_close     : last SPX close price (used for flat bar emission)

        Thread-safe.
        """
        with self._lock:
            self._ema36           = ema36
            self._ema180          = ema180
            self._sep_prev        = sep_prev
            self._sep_curr        = sep_curr
            self._last_close      = last_close
            self._peak_accel_sep  = 0.0   # reset on restart; first accel=Y re-establishes it
            self._accel_dir       = ''
        print(f"[SPXB ] EMA state seeded from restart: "
              f"EMA36={ema36:.4f}  EMA180={ema180:.4f}  "
              f"sep={sep_curr:.4f}  last_close={last_close:.2f}")

    # =========================================================================
    # TICK PROCESSING  (all called under self._lock)
    # =========================================================================

    def _update_peak_accel(self):
        """
        Called after sep_prev/sep_curr are updated on every 5s bar close.
        Resets _peak_accel_sep when EMA direction flips, then advances the
        peak if the current bar qualifies as accel=Y under the new rule
        (sep_curr > sep_prev AND sep_curr > current peak).
        Called under self._lock.
        """
        if self._ema36 is None or self._ema180 is None:
            return
        if self._ema36 > self._ema180:
            curr_dir = 'UP'
        elif self._ema36 < self._ema180:
            curr_dir = 'DOWN'
        else:
            curr_dir = ''

        if curr_dir != self._accel_dir:
            self._peak_accel_sep = 0.0
            self._accel_dir      = curr_dir

        if (self._sep_curr > self._sep_prev
                and self._sep_curr > self._peak_accel_sep):
            self._peak_accel_sep = self._sep_curr

    def _process_tick(self, price: float, now: datetime):
        """
        Core tick handler.  Called under self._lock.

        1. Compute the 5-second bucket this tick belongs to.
        2. If it is a new bucket:
              a. Close the previous 5-second bar.
              b. Emit flat bars for any 5-second windows that were skipped.
              c. Open the new 5-second bar.
        3. Update the current 5-second accumulator with this tick.
        """
        bucket = _floor_5s(now)

        # First tick ever - just open the bar and record
        if self._5s_bar_start is None:
            self._open_5s_bar(bucket, price)
            self._update_5s_bar(price)
            return

        # Same 5-second bucket - update in place
        if bucket == self._5s_bar_start:
            self._update_5s_bar(price)
            return

        # New 5-second bucket:
        #   1. Close the bar that just ended
        #   2. Fill any silent windows between old and new bucket
        #   3. Open the new bar
        prev_bucket = self._5s_bar_start
        self._close_5s_bar(prev_bucket)
        self._fill_5s_gaps(prev_bucket, bucket)
        self._open_5s_bar(bucket, price)
        self._update_5s_bar(price)

    def _open_5s_bar(self, bucket: datetime, price: float):
        """Initialise the 5-second bar accumulator at wall-clock bucket."""
        self._5s_bar_start = bucket
        self._5s_open      = price
        self._5s_high      = price
        self._5s_low       = price
        self._5s_close     = price
        self._5s_volume    = 0

    def _update_5s_bar(self, price: float):
        """Incorporate one SPX tick into the current 5-second bar."""
        if price > self._5s_high:
            self._5s_high = price
        if price < self._5s_low:
            self._5s_low = price
        self._5s_close = price

    def _close_5s_bar(self, bucket: datetime):
        """
        Finalise the current 5-second bar:
          - Update EMA36 / EMA180
          - Update sep_prev / sep_curr
          - Feed OHLCV into the 3-minute accumulator
          - Emit the 3-minute bar if a boundary was crossed
        """
        close = self._5s_close if self._5s_close is not None else self._last_close
        if close <= 0:
            return

        open_  = self._5s_open  or close
        high   = self._5s_high  if self._5s_high > 0          else close
        low    = self._5s_low   if self._5s_low  < float('inf') else close
        volume = self._5s_volume

        self._last_close = close

        # -- Update EMAs ---------------------------------------------------
        if self._ema36 is None:
            # Self-warm on first bar if seed_emas was not called
            self._ema36  = close
            self._ema180 = close
        else:
            self._ema36  = close * _ALPHA_36  + self._ema36  * (1.0 - _ALPHA_36)
            self._ema180 = close * _ALPHA_180 + self._ema180 * (1.0 - _ALPHA_180)

        # -- Update separation tracking ------------------------------------
        self._sep_prev = self._sep_curr
        self._sep_curr = abs(self._ema36 - self._ema180)
        self._update_peak_accel()
        self._update_3m_bar(open_, high, low, close, volume, bucket)

        # -- Fire 5-second bar callback (lock released so runner can call
        #    is_accelerating() and _try_enter_pending without deadlock) ----
        if self._on_5s_bar_close is not None:
            self._lock.release()
            try:
                self._on_5s_bar_close()
            except Exception as e:
                print(f"[SPXB ] on_5s_bar_close callback raised: {e}")
            finally:
                self._lock.acquire()

    def _fill_5s_gaps(self, last_bucket: datetime, new_bucket: datetime):
        """
        Emit flat 5-second bars for every window that passed with no trades.
        Each flat bar uses last_close for O/H/L/C and V=0.
        Called after _close_5s_bar so self._last_close is already updated.
        """
        if self._last_close <= 0:
            return
        gap = last_bucket + timedelta(seconds=_5S_SECONDS)
        while gap < new_bucket:
            self._emit_flat_5s_bar(gap)
            gap += timedelta(seconds=_5S_SECONDS)

    def _emit_flat_5s_bar(self, bucket: datetime):
        """
        Process a silent 5-second window directly into the EMA and
        3-minute accumulator without touching the 5s instance accumulators
        (which belong to the real bar in progress).
        """
        close = self._last_close
        if close <= 0:
            return

        # Update EMAs with flat close
        if self._ema36 is None:
            self._ema36  = close
            self._ema180 = close
        else:
            self._ema36  = close * _ALPHA_36  + self._ema36  * (1.0 - _ALPHA_36)
            self._ema180 = close * _ALPHA_180 + self._ema180 * (1.0 - _ALPHA_180)

        self._sep_prev = self._sep_curr
        self._sep_curr = abs(self._ema36 - self._ema180)
        self._update_peak_accel()

        # Feed flat bar into 3-minute accumulator
        self._update_3m_bar(close, close, close, close, 0, bucket)

    # =========================================================================
    # 3-MINUTE BAR CONSTRUCTION  (called under self._lock)
    # =========================================================================

    def _update_3m_bar(self, open_: float, high: float, low: float,
                       close: float, volume: int, bucket: datetime):
        """
        Incorporate a completed 5-second bar into the 3-minute accumulator.
        If this bar belongs to a new 3-minute window, emit the previous window
        first then open a fresh accumulator.
        """
        bar_3m = _floor_3m(bucket)

        # First 5s bar ever
        if self._3m_bar_start is None:
            self._open_3m_bar(bar_3m, open_, high, low, close, volume)
            return

        # Crossing into a new 3-minute window
        if bar_3m != self._3m_bar_start:
            self._emit_3m_bar()
            self._open_3m_bar(bar_3m, open_, high, low, close, volume)
            return

        # Same 3-minute window - accumulate
        if high > self._3m_high:
            self._3m_high = high
        if low < self._3m_low:
            self._3m_low = low
        self._3m_close   = close
        self._3m_volume += volume

    def _open_3m_bar(self, bar_3m: datetime, open_: float, high: float,
                     low: float, close: float, volume: int):
        """Initialise the 3-minute accumulator for a new window."""
        self._3m_bar_start = bar_3m
        self._3m_open      = open_
        self._3m_high      = high
        self._3m_low       = low
        self._3m_close     = close
        self._3m_volume    = volume

    def _emit_3m_bar(self):
        """
        Fire the on_bar_close callback with the completed 3-minute bar dict,
        then reset the 3-minute accumulator.
        The bar dict format matches what _on_bar_complete in the runner expects.
        """
        if self._3m_bar_start is None or self._3m_open is None:
            return

        bar = {
            'open':           self._3m_open,
            'high':           self._3m_high,
            'low':            self._3m_low  if self._3m_low  < float('inf') else self._3m_open,
            'close':          self._3m_close or self._3m_open,
            'volume':         self._3m_volume,
            'bar_start_time': self._3m_bar_start,
        }

        e36  = self._ema36  or 0.0
        e180 = self._ema180 or 0.0
        print(f"[SPXB ] 3m bar  {self._3m_bar_start.strftime('%H:%M')}  "
              f"O={bar['open']:.2f}  H={bar['high']:.2f}  "
              f"L={bar['low']:.2f}  C={bar['close']:.2f}  "
              f"V={bar['volume']}  "
              f"EMA36={e36:.4f}  EMA180={e180:.4f}  "
              f"sep={self._sep_curr:.4f}  "
              f"accel={'Y' if self._sep_curr > self._sep_prev else 'N'}")

        # Reset 3-minute accumulator
        self._3m_bar_start = None
        self._3m_open      = None
        self._3m_high      = 0.0
        self._3m_low       = float('inf')
        self._3m_close     = None
        self._3m_volume    = 0

        # Fire callback with lock released so incoming ticks can be processed
        # while the runner handles the bar (which may make blocking REST calls).
        self._lock.release()
        try:
            self._on_bar_close(bar)
        except Exception as e:
            print(f"[SPXB ] on_bar_close callback raised: {e}")
        finally:
            self._lock.acquire()
