using System;
using System.IO;
using System.Diagnostics;

// ================================================================
// CTV_Install.cs
// Revision: 3.17
// v3.17- Added Include_pip=1 to Python installer args. Added ensurepip
//          bootstrap before pip installs to guarantee pip is present.
// v3.16- Python installer now runs with /repair flag to force full
//          reinstall of all components regardless of existing state.
// v3.15- Step 3: refresh PATH and clear PYTHONHOME/PYTHONPATH before pip;
//          use python -m pip instead of bare pip to guarantee correct
//          Python installation is used.
// v3.14- IB Gateway exe search path corrected from C:\Jts\ibgateway
//          to C:\Program Files\ibgateway.
// v3.13- Python health check before merge: tests import encodings before
//          calling merge_config.py. If Python is damaged, installs default
//          config and saves existing as .bak rather than crashing.
// v3.12- Before config merge: remove stale ._pth and pyvenv.cfg files
//          from C:\CTV (caused No module named encodings crash). Clear
//          PYTHONHOME/PYTHONPATH in process. Merge now uses full Python path.
// Embedded bootstrap installs Python 3.11.9, pip packages,
// IB Gateway (stable standalone), deploys latest CTV release,
// writes install manifest with file integrity hashes,
// and notifies Greg via Pushover.
// Compile with BUILD_INSTALLER.bat (uses built-in .NET csc.exe).
//
// v3.11- Version guard in Step 5: peeks VERSION from downloaded ctv.zip,
//          displays it, and requires YES confirmation before extracting.
//          Prevents accidental install of a stale GitHub release.
// v3.10- Manifest now includes SHA-256 hashes of all CTV Python files
//          (line-ending normalized via Get-SHA256FileNormalized) and the
//          IB Gateway executable (raw bytes). preflight_check.py Rev 11
//          verifies these hashes on every launch.
// v3.9 - Added Step 4: IB Gateway stable standalone download and silent
//          install. Skipped if C:\Jts\ibgateway already exists.
//          Step count increased from 6 to 7. Fixed completion message
//          syntax error (unclosed PowerShell string on IB Gateway line).
// v3.7 - Config merge step after Expand-Archive.
//          Fresh install: copy config_ctv2_default.py -> config_ctv2.py.
//          Update: merge existing config_ctv2.py with config_ctv2_default.py
//          via merge_config.py - user values preserved, new fields added.
// v3.6 - Rename CTV_Install.exe to .bak before Expand-Archive, restore after.
//          Prevents access-denied error when old ctv.zip still contains the exe.
// v3.5 - Set console BackgroundColor=Black ForegroundColor=White at startup.
//          Ensures readable white text regardless of machine terminal defaults.
// v3.4 - Register CTV2 Watchdog task via schtasks in step 4.
//          Watchdog fires at 09:05 AM Mon-Fri, Pushover alerts if runner not alive.
//          Added ABORT_TRADING shortcut via CREATE_SHORTCUTS.ps1 v1.16.
// v3.3 - Changed Python installer from 3.9.11 to 3.11.9.
// v3.2 - Added --disable-pip-version-check to pip install calls. pip version
//          warning on stderr was being caught as a terminating error in step 3.
// v3.1 - Fixed Write-Host "" spacers inside try blocks (produced broken
//          PowerShell: Write-Host " with unclosed string). Use Write-Host
//          (no arg) for blank lines. Moved Get-SHA256File function outside
//          try block to top level.
// v3.0 - All 6 steps wrapped in try/catch for visible error reporting.
// v2.9 - Python progress: replaced -Wait with -PassThru + HasExited
//          polling loop so elapsed time prints while installer runs.
// v2.8 - Call CREATE_SHORTCUTS.ps1 after zip extract to create desktop
//          shortcuts. Fixed stale TWS reference in completion message.
// v2.7 - Admin enforcement: hard stop if not running as Administrator.
//          Python progress: polling loop shows elapsed time.
//          ctv.zip URL changed to GitHub releases/latest/download.
// v2.6 - Step 4 now downloads ctv.zip from GitHub and extracts it
//          directly to C:\\CTV. Removes dependency on Update.ps1 in repo.
// v2.5 - Fixed PATH concatenation (PathSeparator), date formats and
//          Administrator check to use single quotes instead of ""
//          escaped doubles - C# verbatim string was mangling them.
// v2.4 - Replaced Write-Step/Write-Info helper functions with plain
//          Write-Host calls. The C# verbatim string quoting mangled
//          the function definitions when written to disk.
// v2.3 - Fixed step labels [1/8] and [2/8] to [1/6] and [2/6].
// v2.2 - Compiled as /target:exe (console app) not /target:winexe.
//          winexe closes the window on error with no visible output.
// v2.1 - Removed TWS/IBKR install step (CTV now uses Tradier).
//          Removed TWS_API_SETUP.pdf step.
//          Updated pip packages: removed ibapi, pyyaml, pytz, pyinstaller;
//          added requests, websockets. Kept tzdata, pandas-market-calendars, flask.
//          Step count reduced from 8 to 6.
//          Manifest no longer records tws path/hash.
// v2.0 - Full bootstrap replaces CTV_SETUP.ps1. Steps:
//          1. Create C:\CTV
//          2. Install Python 3.11.9
//          3. Install pip packages
//          4. Install TWS (latest from IBKR)
//          5. Deploy CTV via Update.ps1 -SkipConfirm -SkipMerge
//          6. Write install_manifest.json (python + tws + pip)
//          7. Open TWS_API_SETUP.pdf
//          8. Notify Greg via Pushover
// ================================================================

class CTVInstall
{
    // ================================================================
    // *** VERBATIM STRING RULES - READ BEFORE EDITING ANYTHING BELOW ***
    //
    // This script is embedded as a C# verbatim string (@"...").
    // In a verbatim string, "" = one literal " in the .ps1 file on disk.
    // This has caused the installer to crash TWICE. Read all four rules.
    //
    // RULE 1 — BLANK LINES: Never use Write-Host "" for blank lines.
    //   WHY:  Write-Host "" in C# → Write-Host " on disk (unclosed string).
    //         PowerShell consumes the next line as the string value.
    //         Silently wrong at top level. Terminating crash inside try/catch.
    //   BAD:  Write-Host ""          ← produces Write-Host " on disk
    //   GOOD: Write-Host             ← bare Write-Host, no argument, no quotes
    //
    // RULE 2 — FUNCTION DEFINITIONS: Never use "" inside a function body.
    //   WHY:  "" inside a function collapses to " and opens an unclosed string
    //         that swallows the rest of the function definition.
    //   BAD:  function Write-Step { param([string]$msg) Write-Host ""; Write-Host $msg }
    //         → lands as: function Write-Step { param([string]$msg) Write-Host "; ...
    //   GOOD: Use plain Write-Host with no quotes, or restructure to avoid "" entirely.
    //
    // RULE 3 — ROLE CHECKS: Use single quotes for WindowsBuiltInRole, not "".
    //   WHY:  ""Administrator"" → "Administrator" on disk which is correct, BUT
    //         some PS versions parse the role enum differently with double quotes.
    //   BAD:  IsInRole([Security.Principal.WindowsBuiltInRole]""Administrator"")
    //   GOOD: IsInRole([Security.Principal.WindowsBuiltInRole]'Administrator')
    //
    // RULE 4 — FUNCTION SCOPE: Define PS functions at TOP LEVEL, never inside try{}.
    //   WHY:  Functions defined inside a try block with ErrorActionPreference=Stop
    //         can behave unpredictably and may not be visible to later try blocks.
    //   BAD:  try { ... function Get-SHA256File { ... } ... }
    //   GOOD: function Get-SHA256File { ... }   ← before the first try block
    //         try { ... (Get-SHA256File $x) ... }
    // ================================================================
    private static readonly string Script = @"
# =============================================================
# CTV_Bootstrap.ps1 - CTV Initial Install Bootstrap
# Embedded in CTV_Install.exe - do not run directly.
# =============================================================

$ErrorActionPreference = ""Stop""

$Host.UI.RawUI.BackgroundColor = 'Black'
$Host.UI.RawUI.ForegroundColor = 'White'
Clear-Host


Write-Host """"
Write-Host ""============================================================""
Write-Host ""   CTV TRADING PLATFORM - INITIAL INSTALL""
Write-Host ""============================================================""

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]'Administrator')
if (-not $isAdmin) {
    Write-Host
    Write-Host ""ERROR: CTV installer must be run as Administrator.""
    Write-Host ""Please right-click the installer and select Run as administrator.""
    Write-Host
    Read-Host ""Press Enter to exit""
    exit 1
}

$downloadDir = ""$env:TEMP\ctv_install""
New-Item -ItemType Directory -Path $downloadDir -Force | Out-Null


function Get-SHA256File { param([string]$Path)
    if (-not $Path -or -not (Test-Path $Path)) { return $null }
    return (Get-FileHash -Path $Path -Algorithm SHA256).Hash
}

function Get-SHA256FileNormalized { param([string]$Path)
    if (-not $Path -or -not (Test-Path $Path)) { return $null }
    $bytes = [System.IO.File]::ReadAllBytes($Path)
    $cr = [char]13
    $lf = [char]10
    $text = [System.Text.Encoding]::UTF8.GetString($bytes)
    $normalized = $text.Replace([string]$cr + [string]$lf, [string]$lf).Replace([string]$cr, [string]$lf)
    $normBytes = [System.Text.Encoding]::UTF8.GetBytes($normalized)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $hashBytes = $sha.ComputeHash($normBytes)
    return ([BitConverter]::ToString($hashBytes) -replace '-','').ToUpper()
}

try {
    # =============================================================
    # STEP 1: Create C:\CTV
    # =============================================================
    Write-Host
    Write-Host ""[1/7] Creating C:\CTV...""
    if (-not (Test-Path ""C:\CTV"")) {
        New-Item -ItemType Directory -Path ""C:\CTV"" -Force | Out-Null
    }
    Write-Host ""  Done.""
} catch {
    Write-Host ""ERROR in step 1/7: $_""
    Read-Host ""Press Enter to exit""
    exit 1
}


try {
    # =============================================================
    # STEP 2: Python 3.11.9
    # =============================================================
    Write-Host
    Write-Host ""[2/7] Installing Python 3.11.9...""

    $pyUrl       = ""https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe""
    $pyInstaller = ""$downloadDir\python-3.11.9-amd64.exe""

    Write-Host ""  Downloading Python 3.11.9 (be patient - this may take a while)...""
    $ProgressPreference = 'SilentlyContinue'
    Invoke-WebRequest -Uri $pyUrl -OutFile $pyInstaller -UseBasicParsing

    if (-not (Test-Path $pyInstaller)) {
        Write-Host ""ERROR: Failed to download Python. Check your internet connection.""
        Read-Host ""Press Enter to exit""
        exit 1
    }

    Write-Host ""  Installing Python 3.11.9 (be patient - this may take a while)...""
    $pyProc = Start-Process -FilePath $pyInstaller `
        -ArgumentList ""/quiet InstallAllUsers=1 PrependPath=1 Include_test=0 Include_pip=1 /repair"" `
        -PassThru
    $elapsed = 0
    while (-not $pyProc.HasExited) {
        Start-Sleep -Seconds 5
        $elapsed += 5
        Write-Host ""  ... $($elapsed)s""
        if ($elapsed -gt 300) {
            Write-Host ""ERROR: Python installation timed out after 5 minutes.""
            Read-Host ""Press Enter to exit""
            exit 1
        }
    }
    Write-Host ""  Python installed ($($elapsed)s).""
    $env:PATH = [System.Environment]::GetEnvironmentVariable(""PATH"",""Machine"") + [System.IO.Path]::PathSeparator +
                [System.Environment]::GetEnvironmentVariable(""PATH"",""User"")
} catch {
    Write-Host ""ERROR in step 2/7: $_""
    Read-Host ""Press Enter to exit""
    exit 1
}


try {
    # =============================================================
    # STEP 3: Python libraries
    # =============================================================
    Write-Host
    Write-Host ""[3/7] Installing Python libraries...""

    # Refresh PATH from machine + user environment so the newly installed
    # Python is found, then clear any stale PYTHONHOME/PYTHONPATH that
    # could corrupt the Python path before we call pip.
    $env:PATH = [System.Environment]::GetEnvironmentVariable(""PATH"",""Machine"") + [System.IO.Path]::PathSeparator +
                [System.Environment]::GetEnvironmentVariable(""PATH"",""User"")
    $env:PYTHONHOME = $null
    $env:PYTHONPATH = $null

    # Resolve python.exe explicitly and use 'python -m pip' to guarantee
    # we're using the pip that belongs to this Python installation.
    $pyExe = (Get-Command python -ErrorAction SilentlyContinue).Source
    if (-not $pyExe) {
        throw ""Python executable not found on PATH after installation.""
    }
    Write-Host ""  Using Python: $pyExe""

    # Bootstrap pip in case it was not included in the install
    Write-Host ""  Ensuring pip is available...""
    & $pyExe -m ensurepip --upgrade 2>$null | Out-Null
    & $pyExe -m pip install --upgrade pip --quiet --disable-pip-version-check 2>$null | Out-Null

    foreach ($pkg in @(""ib_insync"",""yfinance"",""tzdata"",""pandas-market-calendars"",""flask"")) {
        Write-Host ""  Installing $pkg...""
        & $pyExe -m pip install $pkg --quiet --disable-pip-version-check 2>$null | Out-Null
    }
    Write-Host ""  Libraries installed.""
} catch {
    Write-Host ""ERROR in step 3/7: $_""
    Read-Host ""Press Enter to exit""
    exit 1
}


try {
    # =============================================================
    # STEP 4: IB Gateway (stable standalone)
    # =============================================================
    Write-Host
    Write-Host ""[4/7] Installing IB Gateway...""

    $ibgwDir = ""C:\Jts\ibgateway""
    if (Test-Path $ibgwDir) {
        Write-Host ""  IB Gateway already installed - skipping.""
    } else {
        $ibgwUrl  = ""https://download2.interactivebrokers.com/installers/ibgateway/stable-standalone/ibgateway-stable-standalone-windows-x64.exe""
        $ibgwExe  = ""$downloadDir\ibgateway-stable-standalone-windows-x64.exe""

        Write-Host ""  Downloading IB Gateway stable standalone (be patient - ~200 MB)...""
        $ProgressPreference = 'SilentlyContinue'
        Invoke-WebRequest -Uri $ibgwUrl -OutFile $ibgwExe -UseBasicParsing

        if (-not (Test-Path $ibgwExe)) {
            Write-Host ""  ERROR: Failed to download IB Gateway. Check your internet connection.""
            Read-Host ""Press Enter to exit""
            exit 1
        }

        Write-Host ""  Installing IB Gateway (be patient - this may take a while)...""
        $ibgwProc = Start-Process -FilePath $ibgwExe -ArgumentList ""-q"" -PassThru
        $elapsed = 0
        while (-not $ibgwProc.HasExited) {
            Start-Sleep -Seconds 5
            $elapsed += 5
            Write-Host ""  ... $($elapsed)s""
            if ($elapsed -gt 600) {
                Write-Host ""  ERROR: IB Gateway installation timed out after 10 minutes.""
                Read-Host ""Press Enter to exit""
                exit 1
            }
        }
        Write-Host ""  IB Gateway installed ($($elapsed)s).""
    }
} catch {
    Write-Host ""ERROR in step 4/7: $_""
    Read-Host ""Press Enter to exit""
    exit 1
}


try {
    # =============================================================
    # STEP 5: Deploy CTV release from ctv.zip
    # =============================================================
    Write-Host
    Write-Host ""[5/7] Deploying CTV release...""

    $zipUrl  = ""https://github.com/gah2208/ctv/releases/latest/download/ctv.zip""
    $zipPath = ""$downloadDir\ctv.zip""

    Write-Host ""  Downloading ctv.zip...""
    $ProgressPreference = 'SilentlyContinue'
    Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing

    if (-not (Test-Path $zipPath)) {
        Write-Host ""ERROR: Failed to download ctv.zip. Check your internet connection.""
        Read-Host ""Press Enter to exit""
        exit 1
    }

    # Peek VERSION inside zip before extracting
    $zipVersion = $null
    try {
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $zipObj   = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
        $verEntry = $zipObj.Entries | Where-Object { $_.FullName -eq 'VERSION' } | Select-Object -First 1
        if ($verEntry) {
            $reader     = New-Object System.IO.StreamReader($verEntry.Open())
            $zipVersion = $reader.ReadToEnd().Trim()
            $reader.Close()
        }
        $zipObj.Dispose()
    } catch {}

    if ($zipVersion) {
        Write-Host ""  CTV release version: v$zipVersion""
    } else {
        Write-Host ""  Warning: could not read VERSION from zip.""
    }
    $confirm = Read-Host ""  Type YES to install, or press Enter to abort""
    if ($confirm -ne 'YES' -and $confirm -ne 'yes') {
        Write-Host ""  Install aborted.""
        Read-Host ""Press Enter to exit""
        exit 0
    }

    Write-Host ""  Extracting to C:\CTV...""
    # Temporarily rename this running exe so Expand-Archive can overwrite it
    # if an older ctv.zip still contains CTV_Install.exe.
    $selfExe = ""C:\CTV\CTV_Install.exe""
    $selfBak = ""C:\CTV\CTV_Install.exe.bak""
    if (Test-Path $selfExe) {
        Rename-Item -Path $selfExe -NewName $selfBak -Force -ErrorAction SilentlyContinue
    }
    Expand-Archive -Path $zipPath -DestinationPath ""C:\CTV"" -Force
    # Restore our own exe (zip may or may not have contained one)
    if (Test-Path $selfBak) {
        if (Test-Path $selfExe) { Remove-Item $selfExe -Force -ErrorAction SilentlyContinue }
        Rename-Item -Path $selfBak -NewName $selfExe -Force -ErrorAction SilentlyContinue
    }

    Write-Host ""  CTV deployed.""

    Write-Host ""  Cleaning up stale Python path artifacts...""
    # Remove any ._pth or pyvenv.cfg files that Python may have left in C:\CTV
    # during a previous install. These hijack sys.prefix away from the real
    # Python installation and cause 'No module named encodings' on next launch.
    Remove-Item ""C:\CTV\python311._pth"" -Force -ErrorAction SilentlyContinue
    Remove-Item ""C:\CTV\python3._pth""   -Force -ErrorAction SilentlyContinue
    Remove-Item ""C:\CTV\pyvenv.cfg""     -Force -ErrorAction SilentlyContinue
    [System.Environment]::SetEnvironmentVariable(""PYTHONHOME"", $null, ""Process"")
    [System.Environment]::SetEnvironmentVariable(""PYTHONPATH"", $null, ""Process"")
    Write-Host ""  Done.""

    Write-Host ""  Merging configuration...""
    $defaultCfg = ""C:\CTV\config_ctv2_default.py""
    $userCfg    = ""C:\CTV\config_ctv2.py""
    $mergePy    = ""C:\CTV\merge_config.py""
    if (-not (Test-Path $userCfg)) {
        Copy-Item $defaultCfg $userCfg -Force
        Write-Host ""  Fresh install - default config installed.""
    } elseif (Test-Path $mergePy) {
        $pyExe = (Get-Command python -ErrorAction SilentlyContinue).Source
        if (-not $pyExe) { $pyExe = ""python"" }

        # Verify Python is functional before attempting merge
        $pyTest = & $pyExe -c ""import encodings; print('ok')"" 2>&1
        if ($pyTest -notmatch 'ok') {
            Write-Host ""  WARNING: Python installation appears damaged ($pyTest)""
            Write-Host ""  Skipping merge - backing up existing config and installing defaults.""
            Copy-Item $userCfg ""$userCfg.bak"" -Force -ErrorAction SilentlyContinue
            Copy-Item $defaultCfg $userCfg -Force
            Write-Host ""  Default config installed. Your previous config saved as config_ctv2.py.bak""
            Write-Host ""  Re-enter your settings in Config Editor after install completes.""
            Write-Host ""  To fix Python: uninstall via Add/Remove Programs and re-run this installer.""
        } else {
            $env:PYTHONHOME = Split-Path $pyExe
            & $pyExe -u $mergePy --existing $userCfg --new $defaultCfg --output $userCfg
        if ($LASTEXITCODE -eq 0) {
                Write-Host ""  Config merged - your settings preserved.""
            } else {
                Write-Host ""  WARNING: Config merge failed - existing config unchanged.""
            }
        }
    } else {
        Write-Host ""  WARNING: merge_config.py not found - config not updated.""
    }

    Write-Host ""  Creating desktop shortcuts...""
    $shortcutScript = ""C:\CTV\CREATE_SHORTCUTS.ps1""
    if (Test-Path $shortcutScript) {
        & powershell.exe -ExecutionPolicy Bypass -File $shortcutScript
    } else {
        Write-Host ""  WARNING: CREATE_SHORTCUTS.ps1 not found - shortcuts not created.""
    }

    Write-Host ""  Registering CTV2 watchdog task...""
    $watchdogAction = ""powershell.exe -NoProfile -ExecutionPolicy Bypass -File C:\CTV\CTV2_WATCHDOG.ps1""
    & schtasks /create /tn ""CTV2 Watchdog"" /tr $watchdogAction /sc weekly /d MON,TUE,WED,THU,FRI /st 09:05 /f /ru SYSTEM 2>$null | Out-Null
    if ($LASTEXITCODE -eq 0) {
        Write-Host ""  Watchdog task registered (09:05 AM Mon-Fri).""
    } else {
        Write-Host ""  WARNING: Watchdog task registration failed - register manually if needed.""
    }
} catch {
    Write-Host ""ERROR in step 5/7: $_""
    Read-Host ""Press Enter to exit""
    exit 1
}


try {
    # =============================================================
    # STEP 6: Write install manifest
    # =============================================================
    Write-Host
    Write-Host ""[6/7] Writing install manifest...""

    $env:PATH = [System.Environment]::GetEnvironmentVariable(""PATH"",""Machine"") + [System.IO.Path]::PathSeparator +
                [System.Environment]::GetEnvironmentVariable(""PATH"",""User"")

    $pyExe  = (Get-Command python -ErrorAction SilentlyContinue).Source

    $pipFreeze = & pip freeze 2>$null | Out-String

    Write-Host ""  Hashing CTV Python files...""
    $ctvFiles = @(
        ""ctv2_runner.py"", ""ctv2_auth.py"", ""ctv2_config_editor.py"",
        ""ctv2_dashboard.py"", ""ibkr_orders.py"", ""ibkr_scale.py"",
        ""ibkr_stream.py"", ""merge_config.py"", ""preflight_check.py"",
        ""pushover_alerts.py"", ""risk_manager.py"", ""spx_bars.py"",
        ""config_ctv2_default.py""
    )
    $fileHashes = [ordered]@{}
    foreach ($f in $ctvFiles) {
        $p = ""C:\CTV\$f""
        $h = Get-SHA256FileNormalized $p
        $fileHashes[$f] = $h
        Write-Host ""    $f : $($h.Substring(0,16))...""
    }

    Write-Host ""  Hashing IB Gateway executable...""
    $ibgwExeItem = Get-ChildItem ""C:\Program Files\ibgateway"" -Recurse -Filter ""ibgateway.exe"" -ErrorAction SilentlyContinue | Select-Object -First 1
    $ibgwPath = $null
    $ibgwHash = $null
    if ($ibgwExeItem) {
        $ibgwPath = $ibgwExeItem.FullName
        $ibgwHash = Get-SHA256File $ibgwPath
        Write-Host ""    $ibgwPath : $($ibgwHash.Substring(0,16))...""
    } else {
        Write-Host ""    IB Gateway exe not found - skipping.""
    }

    $manifest = [ordered]@{
        generated = (Get-Date -Format 'yyyy-MM-ddTHH:mm:ss')
        python    = [ordered]@{ path = $pyExe;  sha256 = (Get-SHA256File $pyExe)  }
        pip       = [ordered]@{ packages = $pipFreeze.Trim() }
        ctv_files = $fileHashes
        ibgateway = [ordered]@{ path = $ibgwPath; sha256 = $ibgwHash }
    }

    $manifestPath = ""C:\CTV\install_manifest.json""
    $manifest | ConvertTo-Json -Depth 5 | Set-Content $manifestPath -Encoding UTF8
    Write-Host ""  Manifest written: $manifestPath""
} catch {
    Write-Host ""ERROR in step 6/7: $_""
    Read-Host ""Press Enter to exit""
    exit 1
}


# =============================================================
# STEP 7: Notify Greg via Pushover
# =============================================================
Write-Host
Write-Host ""[7/7] Sending install notification...""

try {
    # Derive machine ID: SHA-256 of Windows MachineGuid, first 8 hex chars
    $guid    = (Get-ItemProperty ""HKLM:\SOFTWARE\Microsoft\Cryptography"").MachineGuid
    $sha256  = [System.Security.Cryptography.SHA256]::Create()
    $bytes   = [System.Text.Encoding]::UTF8.GetBytes($guid)
    $hash    = $sha256.ComputeHash($bytes)
    $machineId = ([BitConverter]::ToString($hash) -replace '-','').ToLower().Substring(0, 8)

    $ts      = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
    $body    = ""token=a5pugjws46zsvfz16i7ookntxkoneb"" +
               ""&user=uck9cc5jyue5oir91izu2ordr6s4uc"" +
               ""&title=CTV2%3A+New+Install"" +
               ""&message=New+CTV2+install%0A%0AID%3A+$machineId%0ATime%3A+$ts"" +
               ""&priority=1""
    $bodyBytes = [System.Text.Encoding]::UTF8.GetBytes($body)

    $req                = [System.Net.HttpWebRequest]::Create(""https://api.pushover.net/1/messages.json"")
    $req.Method         = ""POST""
    $req.ContentType    = ""application/x-www-form-urlencoded""
    $req.ContentLength  = $bodyBytes.Length
    $stream             = $req.GetRequestStream()
    $stream.Write($bodyBytes, 0, $bodyBytes.Length)
    $stream.Close()
    $resp = $req.GetResponse()
    $resp.Close()
    Write-Host ""  Notification sent.""
} catch {
    Write-Host ""  Notification skipped ($_).""
}

# Cleanup
Remove-Item $downloadDir -Recurse -Force -ErrorAction SilentlyContinue

# =============================================================
# DONE
# =============================================================
Write-Host """"
Write-Host ""============================================================""
Write-Host ""   CTV INSTALL COMPLETE""
Write-Host ""============================================================""
Write-Host """"
Write-Host ""Trading shortcuts have been placed on your desktop.""
Write-Host
Write-Host ""IMPORTANT: Start IB Gateway and log in before trading (paper port 7497, live port 7496). Then open Config Editor to enter your Pushover credentials.""
Write-Host
Read-Host ""Press Enter to exit""
";
    static int Main()
    {
        string tmpFile = Path.Combine(
            Path.GetTempPath(),
            "ctv_bootstrap_" + Guid.NewGuid().ToString("N") + ".ps1");

        File.WriteAllText(tmpFile, Script, System.Text.Encoding.UTF8);

        try
        {
            var psi = new ProcessStartInfo
            {
                FileName        = "powershell.exe",
                Arguments       = "-NoProfile -ExecutionPolicy Bypass -File \"" + tmpFile + "\"",
                UseShellExecute = false,
                CreateNoWindow  = false,
            };

            using (var proc = Process.Start(psi))
            {
                proc.WaitForExit();
                return proc.ExitCode;
            }
        }
        finally
        {
            try { File.Delete(tmpFile); } catch { }
        }
    }
}
