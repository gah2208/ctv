# ============================================================
#  version_check.ps1 - CTV2 Version Audit and Build Gate
#  Revision: 8.24
#  v8.24- VERSION bumped to 97.2 (retroactive decimal bumps for stream Rev 10
#          and spx_bars Rev 5 - both ship in ctv.zip)
#  v8.23- Updated spx_bars.py to Revision: 5 (peak_accel_sep high-water mark gate;
#          is_accelerating() now requires sep_curr > peak sep at last accel=Y)
#          No VERSION bump - runner unchanged
#  v8.22- Updated tradier_stream.py to Rev 10 (removed 'trade' and 'quote' from
#          subscription filter and _handle_message; timesale is sole price source)
#          No VERSION bump - runner unchanged
#  v8.21- Updated ctv2_runner.py to Rev 97 (chain entry pending_entries direction guard)
#          Updated ctv2_config_editor.py to Revision: 3.8 (MAX_PREMIUM default 350->200)
#          VERSION bumped to 97
#  v8.20- Added config_ctv2_default.py (factory defaults - ships in zip)
#          Updated build_zip.ps1 to Revision: 2.4 (exclude config_ctv2.py,
#          include config_ctv2_default.py, remove credential strip/restore)
#          Updated CTV_Install.cs to Revision: 3.7 (config merge on install)
#          VERSION bumped to 96.2
#  v8.19- Updated tradier_stream.py to Rev 9 (fixed tight reconnect loop;
#          "too many sessions" back-off 300s; session ID logged on connect;
#          clean-exit reconnect delay added)
#          VERSION bumped to 96.1
#  v8.18- Updated ctv2_runner.py to REVISION = 96 (5-second entry gate,
#          acceleration required, time-based expiry, WIN_TARGET_BUFFER)
#          Updated spx_bars.py to Revision: 4 (on_5s_bar_close callback)
#          Updated ctv2_config_editor.py to Revision: 3.7 (WIN_TARGET_BUFFER,
#          ENTRY_TIMEOUT added; WIN_MOVE, MAX_ENTRY_RETRIES removed)
#          VERSION bumped to 96
#  v8.17- Updated ctv2_runner.py to REVISION = 95 (EMA state saved/restored
#          across restarts via state JSON ema key + seed_emas())
#          Updated spx_bars.py to Revision: 3 (seed_emas() method added)
#          VERSION bumped to 95
#  v8.16- Updated tradier_client.py to Rev 13 (get_todays_expiration catches
#          401/exceptions from get_option_expirations; paper mode falls back
#          to today's date instead of crashing)
#          VERSION bumped to 94.3
#  v8.15- Updated tradier_stream.py to Rev 8 (disabled websockets ping_interval;
#          Tradier does not respond to pings, causing 1011 keepalive errors)
#          VERSION bumped to 94.2
#  v8.14- Updated tradier_orders.py to Rev 11 (fixed _win_sell_payload missing
#          second leg - conv_sym/side[1]/quantity[0] all absent, caused every
#          win-sell order to be rejected by Tradier with 400)
#          VERSION bumped to 94.1
#  v8.13- Updated ctv2_runner.py to REVISION = 94 (stale IBKR stop-order
#          comment removed from _park_trade)
#          Updated ctv2_config_editor.py to Revision: 3.6 (PM_BOUNDARY
#          tooltip corrected - describes butterfly conversion, not stop order)
#          VERSION bumped to 94
#  v8.12- Updated ctv2_runner.py to REVISION = 93 (live EOD Tradier order report;
#          premature _print_eod_summary removed from _check_late_day_exits)
#          Updated tradier_client.py to Rev 12 (get_today_orders, get_eod_report,
#          _parse_occ_symbol, parse_eod_orders)
#          VERSION bumped to 93
#  v8.11- Updated ctv2_runner.py to REVISION = 92 (BFLY_CONV uses place_win_sell,
#          late-stage strike conflict re-check in _entry_quote_thread)
#          Updated tradier_orders.py to Rev 10 (removed place_close/_close_payload,
#          fixed win-sell leg side sell_to_close -> sell_to_open)
#          VERSION bumped to 92
#  v8.10- Updated ctv2_runner.py to REVISION = 90 (expired vertical accounting fix -
#          trades open at 16:00 logged as EXPIRED with exit_credit=0.0)
#          VERSION bumped to 90
#  v8.9 - Updated ctv2_runner.py to REVISION = 89 (schedule messages clarified;
#          EOD trade summary CSV - logs/summaryYYYYMMDD.csv written at session end)
#          VERSION bumped to 89
#  v8.8 - Updated ctv2_runner.py to REVISION = 88 (strike conflict check
#          differentiates by option right C/P - eliminates false-positive skips)
#          VERSION bumped to 88
#  v8.7 - Updated spx_bars.py to Revision: 2 (release lock before on_bar_close callback)
#          Removed debug print from tradier_stream.py Rev 7.
#  v8.6 - Updated tradier_stream.py to Rev 7 (timesale uses 'last' not 'price')
#  v8.5 - Updated tradier_stream.py to Rev 6 (timesale filter - bars silent after 9:30 fix)
#  v8.4 - Updated build_zip.ps1 to Revision: 2.3 (abort if config missing)
#  v8.3 - Updated CTV_Install.cs to Revision: 3.6 (self-rename before extraction)
#  v8.2 - Updated CTV_Install.cs to Revision: 3.5 (white text on black console)
#  v8.1 - Removed BUILD_INSTALLER.bat call from build pipeline. CTV_Install.exe
#          is locked while the installer is running, causing compile to fail.
#          Run BUILD_INSTALLER.bat manually after version check completes.
#  v8.0 - Updated build_zip.ps1 to Revision: 2.2 (exclude CTV_Install.exe from ctv.zip)
#  v7.9 - Added BUILD_INSTALLER.bat call after BUILD_CTV_ZIP.bat.
#          Full build now produces both ctv.zip and CTV_Install.exe in one run.
#  v7.8 - Updated preflight_check.py to Rev 8 (live_confirmed.flag support)
#          Updated START_TRADING.ps1 to Revision: 1.9 (clear flag on exit)
#          Updated RESTART.ps1 to Revision: 2.1 (clear flag before preflight)
#          Updated CREATE_SHORTCUTS.ps1 to v1.16 (Abort Trading shortcut)
#          Updated CTV_Install.cs to Revision: 3.4 (watchdog task registration)
#          Added ABORT_TRADING.ps1 Rev 1.0, CTV2_WATCHDOG.ps1 Rev 1.0
#          VERSION bumped to 87
#  v7.7 - Updated ctv2_runner.py to REVISION = 87 (perpetual loop, clean EOD exit)
#          VERSION bumped to 87
#  v7.6 - Updated ctv2_config_editor.py to Revision: 3.5 (ASCII arrow fix)
#          VERSION bumped to 86.7
#  v7.5 - Renamed spy_bars.py -> spx_bars.py (REVISION: 1)
#          Updated tradier_stream.py to Rev 5 (SPX native bars, SPY removed)
#          Updated ctv2_runner.py to REVISION = 86 (quality_filter.is_viable replaced)
#          VERSION bumped to 86.7
#  v7.4 - Updated ctv2_runner.py to REVISION = 85 (gate pre-market bars before 09:30)
#          VERSION bumped to 86.6
#  v7.3 - Updated build_zip.ps1 to Revision: 2.1 (fast non-ASCII scan)
#          Updated Update.ps1 to Revision: 2.0 (fast non-ASCII scan)
#          VERSION bumped to 86.5
#  v7.2 - Updated build_zip.ps1 to Revision: 2.0 (exclude version_check.ps1
#          from non-ASCII scan). VERSION bumped to 86.4
#  v7.1 - Reverted build_zip.ps1 to 1.9, preflight_check.py to Rev 7,
#          Update.ps1 to 1.9 (removed file hash checking - line ending issues)
#          VERSION bumped to 86.3
#  v7.0 - Updated build_zip.ps1 to Revision: 1.8 (ctv_hashes.json generation)
#          Updated preflight_check.py to Rev 6 (file integrity check)
#          Updated Update.ps1 to Revision: 1.8 (use ctv_hashes.json)
#          VERSION bumped to 86.2
#  v6.9 - Added merge_config.py to FILES table (Revision: 1.1)
#  v6.8 - Added spy_bars.py to FILES table (Revision: 1)
#  v6.7 - Updated ctv2_config_editor.py to Revision: 3.4 (API Token label rename)
#          Updated preflight_check.py to Rev 5 (API Token label rename)
#          VERSION bumped to 86.1
#  v6.6 - Corrected FILES table: ctv2_runner.py -> REVISION = 84, VERSION -> 86,
#          ctv2_config_editor.py -> 3.3, START_TRADING.ps1 -> 1.8,
#          BUILD_ZIP.bat renamed to BUILD_CTV_ZIP.bat. Fixed missing # on line 72.
#  v6.5 - VERSION bumped to 86
#  v6.4 - Updated CTV_Install.cs to Revision: 3.3 (Python 3.9.11 -> 3.11.9)
#          VERSION bumped to 85
#  v6.3 - Updated CTV_Install.cs to Revision: 3.2 (disable-pip-version-check)
#          Updated build_zip.ps1 to Revision: 1.7 (Tradier credential strip/restore)
#          VERSION bumped to 84.4
#  v6.2 - Updated tradier_orders.py to Rev 8 (bypass closing position error
#          in paper mode - fixes win-sell runaway loop)
#          VERSION bumped to 84.3
#  v6.1 - Updated tradier_orders.py to Rev 7
#          VERSION bumped to 84.2
#  v6.0 - Updated tradier_client.py to Rev 11
#          VERSION bumped to 84.1
#  v5.9 - Updated ctv2_runner.py to REVISION = 82
#          VERSION bumped to 84
#  v5.8 - Updated CTV_Install.cs to Revision: 3.0
#          in try/catch for visible error reporting)
#  v5.7 - Updated START_TRADING.ps1 to Revision: 1.9
#          reference in manifest-not-found error message)
#  v5.6 - Added BUILD_INSTALLER.bat to FILES table
#          Bumped VERSION to 83.5.
#  v5.5 - Updated CTV_Install.cs to Revision: 2.9
#          fixed TWS completion message)
#  v5.3 - Updated CTV_Install.cs to Revision: 2.7
#          Python progress, ctv.zip release URL fix)
#  v5.2 - Added CTV_Install.cs to FILES table
#  v5.1 - Updated ctv2_runner.py to REVISION = 81 (stop stream at market close)
#          VERSION bumped to 83
#  v5.0 - Updated ctv2_config_editor.py to Revision: 3.4 (removed PREFETCH_RADIUS)
#  v4.9 - VERSION file introduced. Package version moved out of config_ctv2.py
#          to break circular dependency. build_zip.ps1 Rev 1.6 reads it.
#          version_check.ps1 checks it. ctv2_auth.py reads it directly.
#  v4.8 - Updated ctv2_runner.py to REVISION = 80 (PACKAGE_VERSION auth gating)
#          Updated ctv2_auth.py to Revision: 1.3 (PACKAGE_VERSION auth gating)
#          config_ctv2.py PACKAGE_VERSION bumped to 82
#  v4.7 - Updated RESTART.ps1 to Revision: 2.0 (inline terminal, no new window)
#  v4.6 - Updated ctv2_runner.py to REVISION = 79 (non-ASCII print fix)
#          Updated tradier_orders.py to Rev 6 (non-ASCII win-sell print fix)
#  v4.5 - Decoupled PACKAGE_VERSION from runner REVISION.
#          PACKAGE_VERSION added to config_ctv2.py (starts at 79).
#          version_check.ps1 now reads and displays it.
#          build_zip.ps1 Rev 1.5 reads and stamps it.
#  v4.4 - Updated pushover_alerts.py to Revision: 1.4 (UP/DOWN → CALL/PUT labels)
#  v4.3 - Updated tradier_orders.py to Rev 5 (bypass buying power on preview)
#  v4.2 - Updated tradier_orders.py to Rev 4 (accept result=true on preview)
#  v4.1 - Updated tradier_orders.py to Rev 3 (multileg type=limit → debit/credit)
#  v4.0 - Updated RESTART.ps1 to Revision: 1.9 (added -u flag to python call)
#  v3.9 - Updated RESTART.ps1 to Revision: 1.8 (fix blank window on launch)
#  v3.8 - Updated tradier_stream.py to Rev 3 (clean asyncio shutdown on Ctrl+C)
#  v3.7 - Updated RESTART.ps1 to Revision: 1.7 (removed TWS integrity check)
#  v3.6 - Updated tradier_client.py to Rev 10 (spread quote *100 bug fix)
#          Updated tradier_orders.py to Rev 2 (docstring update)
#  v3.5 - Updated ctv2_runner.py to REVISION = 78 (prev_day_bars AttributeError fix)
#  v3.4 - Updated ctv2_config_editor.py to Revision: 3.3 (live trading confirmation)
#          Updated preflight_check.py to Rev 4 (live trading confirmation dialog)
#  v3.3 - Updated ctv2_runner.py to REVISION = 77 (removed per-bar auth poll)
#          Updated ctv2_auth.py to Revision: 1.2 (removed no-cache headers)
#  v3.2 - Updated tradier_client.py to Rev 9 (SPXW expirations query fix)
#  v3.1 - Updated tradier_client.py to Rev 8 (margin account buying power fix)
#  v3.0 - Updated ctv2_runner.py to REVISION = 76 (pre-market warmup message fix)
#  v2.9 - Updated tradier_client.py to Rev 7 (sandbox attribute crash fix)
#  v2.8 - Updated ctv2_runner.py to REVISION = 75
#          Removed ctv2_order_manager.py (superseded by tradier_orders.py)
#  v4.9 - Updated ctv2_runner.py to REVISION = 71; removed polygon_stream.py
#          Updated ctv2_config_editor.py to Revision: 3.1
#          Added LIVE_TRADING flag; removed STREAM_SOURCE/POLYGON_API_KEY
#  v4.7 - Updated ctv2_runner.py to REVISION = 69
#  v4.6 - Updated ctv2_runner.py to REVISION = 68; tradier_stream.py to Rev 2
#  v4.5 - Updated ctv2_runner.py expected version to REVISION = 67
#  v4.4 - Updated tradier_client.py expected version to Rev 4
#  v4.3 - Updated tradier_client.py expected version to Rev 3
#  v4.2 - Updated ctv2_config_editor.py expected version to Revision: 2.9
#  v4.1 - Updated tradier_client.py expected version to Rev 2
#  v4.0 - Updated ctv2_config_editor.py expected version to Revision: 2.8
#  v3.9 - Updated RESTART.ps1 expected version to Revision: 1.5
#          Updated Update.ps1 expected version to Revision: 1.7
#          Updated START_TRADING.ps1 expected version to Revision: 1.7
#          Removed CTV_SETUP.ps1 (not distributed in ctv.zip)
#          Added tradier_orders.py, tradier_client.py, tradier_stream.py
#  v3.8 - runner -> REVISION = 66 (cancelOrder stale arg crash fix)
#  v3.7 - config_editor -> 2.7 (PREFETCH_RADIUS default 200 -> 300)
#  v3.6 - config_editor -> 2.6 (PREFETCH_RADIUS default 75 -> 200)
#  v3.5 - runner -> REVISION = 65 (fix contract cache misses on entry)
#  v3.4 - runner -> REVISION = 64 (all config time gates use wall-clock)
#  v3.3 - runner -> REVISION = 63 (LAST_ENTRY_TIME uses wall-clock time)
#  v3.2 - runner -> REVISION = 62 (gap expiry uses wall-clock time)
#  v3.1 - runner -> REVISION = 61 (gap-open entry fires on 9:30 bar)
#  v3.0 - runner -> REVISION = 60, pushover -> 1.3, config_editor -> 2.5
#          Added ctv2_dashboard.py at Revision: 1.0
#  v2.9 - Updated ctv2_runner.py to REVISION = 59
#  v2.8 - Updated ctv2_runner.py to REVISION = 58, ctv2_config_editor.py to Revision: 2.4
#  v2.7 - Updated ctv2_runner.py expected version to REVISION = 57
#  v2.6 - Updated ctv2_config_editor.py expected version to Revision: 2.3
#  v2.5 - Updated ctv2_config_editor.py expected version to Revision: 2.2
#  v2.4 - Updated ctv2_runner.py expected version to REVISION = 56
#  v2.3 - Updated ctv2_runner.py expected version to REVISION = 55
#  v1.1 - Updated START_TRADING.ps1 expected version to Revision: 1.6
#
#  Called by VERSION_CHECK.bat. Do not run directly.
#
#  For each file, searches for the expected version string.
#  If ALL pass  -> runs BUILD_ZIP.bat
#  If ANY fail  -> lists failures and exits with code 1
#
#  To update expected versions after a code change, edit the
#  $FILES table below.
# ============================================================

Set-Location -Path "C:\CTV"

# -- Read package version from VERSION file ------------------------------------
$pkgVer = 'unknown'
$versionFile = "C:\CTV\VERSION"
if (Test-Path $versionFile) {
    $pkgVer = (Get-Content $versionFile -Raw).Trim()
}

Write-Host ""
Write-Host "============================================================"
Write-Host "  CTV2 VERSION AUDIT  |  Package v$pkgVer"
Write-Host "============================================================"
Write-Host ""

# -- Version table ------------------------------------------------------------
# Each entry: filename, string that must appear somewhere in that file
$FILES = @(
    @{ File = "ctv2_runner.py";        Expect = "Rev 97: _try_chain_entry now checks self.pending_entries" },
    @{ File = "VERSION";               Expect = "97.2" },
    @{ File = "ctv2_config_editor.py"; Expect = "Revision: 3.8" },
    @{ File = "preflight_check.py";    Expect = "Rev 8: live_confirmed.flag" },
    @{ File = "tradier_orders.py";     Expect = "Rev 11: Fixed _win_sell_payload" },
    @{ File = "tradier_client.py";     Expect = "Rev 13: get_todays_expiration" },
    @{ File = "tradier_stream.py";     Expect = "Rev 10: Removed 'trade' and 'quote' from subscription filter" },
    @{ File = "pushover_alerts.py";    Expect = "Revision: 1.4" },
    @{ File = "ctv2_dashboard.py";     Expect = "Revision: 1.0" },
    @{ File = "risk_manager.py";       Expect = "Revision: 1.0" },
    @{ File = "spx_bars.py";           Expect = "Revision: 5" },
    @{ File = "merge_config.py";       Expect = "Revision: 1.1" },
    @{ File = "config_ctv2_default.py"; Expect = "WIN_TARGET_BUFFER = 1.0" },
    @{ File = "ctv2_auth.py";          Expect = "Revision: 1.3" },
    @{ File = "CREATE_SHORTCUTS.ps1";  Expect = "v1.16" },
    @{ File = "START_TRADING.ps1";     Expect = "Revision: 1.9" },
    @{ File = "RESTART.ps1";           Expect = "Revision: 2.1" },
    @{ File = "Update.ps1";            Expect = "Revision: 2.0" },
    @{ File = "BUILD_CTV_ZIP.bat";         Expect = "Revision: 1.3" },
    @{ File = "BUILD_INSTALLER.bat";   Expect = "v1.3" },
    @{ File = "build_zip.ps1";         Expect = "Revision: 2.4" },
    @{ File = "CTV_Install.cs";        Expect = "Revision: 3.7" },
    @{ File = "ABORT_TRADING.ps1";     Expect = "Revision: 1.0" },
    @{ File = "CTV2_WATCHDOG.ps1";     Expect = "Revision: 1.0" }
)

# -- Check each file ----------------------------------------------------------
$failures = @()

foreach ($entry in $FILES) {
    $path = "C:\CTV\$($entry.File)"

    if (-not (Test-Path $path)) {
        Write-Host "  MISSING  $($entry.File)"
        $failures += "$($entry.File) - FILE NOT FOUND (expected: $($entry.Expect))"
        continue
    }

    $content = Get-Content $path -Raw -ErrorAction SilentlyContinue
    if ($content -like "*$($entry.Expect)*") {
        Write-Host "  OK       $($entry.File)  [$($entry.Expect)]"
    } else {
        Write-Host "  FAIL     $($entry.File)  [expected: $($entry.Expect)]"
        $failures += "$($entry.File) - expected '$($entry.Expect)'"
    }
}

Write-Host ""

# -- Result -------------------------------------------------------------------
if ($failures.Count -gt 0) {
    Write-Host "============================================================"
    Write-Host "  VERSION MISMATCH - Build blocked"
    Write-Host "============================================================"
    Write-Host ""
    Write-Host "  The following files are not at the expected version:"
    Write-Host ""
    foreach ($f in $failures) {
        Write-Host "    - $f"
    }
    Write-Host ""
    Write-Host "  Provide this list to Claude to get the correct files,"
    Write-Host "  then rerun VERSION_CHECK.bat."
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "============================================================"
Write-Host "  All files at correct version - running build..."
Write-Host "============================================================"
Write-Host ""

# -- Build --------------------------------------------------------------------
& "C:\CTV\BUILD_CTV_ZIP.bat"
