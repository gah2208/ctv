# ============================================================
#  version_check.ps1 - CTV2 Version Audit and Build Gate
#  Revision: 8.78
#  v8.74- Stepped entry auction. ctv2_runner.py REVISION 122->123:
#          _check_entry_auctions() + _remove_pending_trade() added;
#          _on_entry_quote starts auction at midpoint instead of
#          rejecting. config_ctv2_default.py Rev 1.7: BID_STEP_INTERVAL
#          + ENTRY_OTM_ABANDON added. ctv2_config_editor.py Rev 5.3:
#          both fields added to Entry tab. VERSION 118.0
#  v8.78- ctv2_config_editor.py Rev 5.5: withdraw/deiconify added to
#          eliminate window flash on startup. VERSION bumped to 118.4
#  v8.77- ctv2_config_editor.py Rev 5.4: SIG_CONFIRM_TICKS_SEC display
#          label changed to SIG_CONFIRM_SEC. VERSION bumped to 118.3
#  v8.76- ibkr_orders.py + ibkr_stream.py: _on_ib_error handler added.
#          Error 300 (cancelMktData noise) suppressed in both modules.
#          VERSION bumped to 118.2
#  v8.75- ibkr_orders.py Rev 18: openClose=1 added to all ComboLeg
#          instances in _build_bag(). Fixes Error 201 Riskless
#          combination orders on every win-sell and butterfly
#          conversion order. VERSION bumped to 118.1
#  v8.74- ctv2_runner.py Rev 124: auction immediate step to MAX_PREMIUM
#          when midpoint rises above current bid. Completes auction
#          logic from Rev 123. VERSION bumped to 118.0
#  v8.73- ibkr_orders.py Rev 17: BAG contract symbol corrected from
#          SPXW to SPX with tradingClass=SPXW in _build_bag().
#          Fixes Error 200 on every order placement. VERSION 117.1
#  v8.72- SIG_CONFIRM_TICKS_SEC added. _on_5s_bar simplified: sep_ema
#          removed (redundant); uses sep_curr > sep_prev directly.
#          ctv2_runner.py REVISION 121->122. config_ctv2_default.py
#          Rev 1.6: SIG_CONFIRM_TICKS_SEC=30. ctv2_config_editor.py
#          Rev 5.2: dropdown added to Entry tab. VERSION 117.0
#  v8.71- EMA3/EMA15 terminology corrected to EMA36/EMA180 in comments.
#          ctv2_runner.py REVISION 120->121: architecture header,
#          QualityFilter docstring (marked dead code), _post_warmup doc.
#          ctv2_config_editor.py Rev 5.1: SECTIONS descriptions updated.
#          No logic change. VERSION bumped to 116.0
#  v8.70- ibkr_stream.py Rev 5: RTH guard removed from
#          _seed_emas_from_history. EMA seed now runs on every
#          connect including pre-market and post-market. Ensures
#          EMAs are seeded before 09:30 open. VERSION 115.10
#  v8.69- build_zip.ps1 Rev 2.6: success Read-Host removed; catch
#          block exits 1 on ZIP failure. BUILD_CTV_ZIP.bat Rev 1.4:
#          pause changed to exit /b 1. VERSION_CHECK.bat Rev 1.1:
#          full build chain wired - version check -> zip -> installer.
#          VERSION bumped to 115.9
#  v8.68- ibkr_orders.py + ibkr_stream.py: ib_insync logger silenced
#          during gateway reconnect wait. "API connection failed" and
#          "Make sure API port" messages suppressed between disconnect
#          and reconnect. Logger restored to ERROR on reconnect.
#          VERSION bumped to 115.8
#  v8.67- ibkr_orders.py Rev 16: Gateway reconnect handling added.
#          _connect_forever coroutine replaces one-shot connectAsync.
#          Handles up to 5 days of gateway downtime without killing
#          the process. Fixes overnight/weekend gateway close crashing
#          CTV2 while sleeping for next trading day. VERSION 115.7
#  v8.66- ibkr_stream.py Rev 5: EMA seed from historical 5s bars.
#          On connect, requests 1800S of 5-second TRADES bars from IB
#          Gateway and seeds EMA36/EMA180 before live streaming begins.
#          Eliminates cold-start EMA divergence on mid-day restarts.
#          Only runs during RTH; graceful degradation if request fails.
#          VERSION bumped to 115.6
#  v8.65- ibkr_orders.py: Option constructor corrected in _option() and
#          precache_contracts(). symbol changed from SPXW to SPX with
#          tradingClass=SPXW. IBKR requires symbol=SPX for all SPX/SPXW
#          options; tradingClass distinguishes weeklies. Fixes Error 200
#          on every contract qualification attempt. VERSION bumped to 115.5
#  v8.64- ibkr_orders.py: nest_asyncio.apply(self._loop) added to
#          _run_loop() so blocking ib_insync calls work inside coroutines.
#          _start_account_subscription: exception type now logged;
#          _account_subscribed=True moved to finally block so re-subscribe
#          is prevented even when reqAccountUpdates times out.
#          VERSION bumped to 115.4
#  v8.63- ibkr_orders.py Rev 14: dedicated event loop thread. IBKROrderManager
#          now owns a daemon thread (OM-Loop) running loop.run_forever().
#          All ib_insync API calls dispatched via _run_on_loop/_call_on_loop.
#          Eliminates client.loop/IB.loop attribute errors permanently.
#          VERSION bumped to 115.3
#  v8.62- ibkr_orders.py Rev 13: _qualify_contracts() loop access fixed.
#          self._ib.loop replaced with self._ib.client.loop - IB.loop
#          property removed in newer ib_insync versions; caused 'IB object
#          has no attribute loop' on every get_spread_quote call, blocking
#          all entries. VERSION bumped to 115.2
#  v8.61- ibkr_stream.py Rev 4: gateway reconnect waiting.
#          After first successful connection, any disconnection
#          (daily 11:45 PM auto-restart, Sunday weekly restart)
#          logs a single "IB Gateway disconnected" message and
#          waits silently, retrying every 30s. Single "Reconnected"
#          message fires on recovery. _RECONNECT_DELAY 5->30s.
#          VERSION bumped to 115.1
#  v8.60- MAX_ACTIVE_TRADES config parameter removed. Trade slot limits
#          hardcoded in ctv2_runner.py: _MAX_ACTIVE=1, _MAX_PARKED=2.
#          ctv2_runner.py Rev 113 / REVISION=113. VERSION bumped to 115.0
#          config_ctv2_default.py Rev 1.5 (MAX_ACTIVE_TRADES removed).
#          ctv2_config_editor.py Rev 5.0 (MAX_ACTIVE_TRADES row and
#          write_config() line removed).
#  v8.59- ctv2_runner.py Rev 112: _collapse_thread fill detection corrected.
#          status == 'Filled' -> 'filled' (matches get_order() _STATUS_MAP output).
#          'avg_fill' key -> 'avg_fill_price' (matches get_order() dict shape).
#          Previously collapse fills were never detected; every attempt
#          timed out and reported "not filled after 2 min" even on clean fills.
#          REVISION bumped to 112. VERSION bumped to 114.0
#  v8.58- ctv2_runner.py Rev 109: gap-open logic fully removed,
#          disconnect() wired into shutdown paths, REVISION-based
#          clientId passed to OrderManager and Stream.
#          ibkr_orders.py Rev 9: reqAccountUpdates() subscription,
#          disconnect() method, preview params removed, client_id param.
#          ibkr_stream.py Rev 3: client_id constructor param.
#          spx_bars.py Rev 6: is_accelerating simplified, peak accel removed.
#          ibkr_orders.py Rev 10: reqAccountUpdates() fire-and-forget -
#          removed time.sleep(2) that caused startup lockup. VERSION 113.1
#          ctv2_runner.py Rev 111: clientId reverted to stable hardcoded
#          values (2 for orders, 1 for stream). REVISION-based clientIds
#          introduced in Rev 109 change on every release - reverted.
#          VERSION bumped to 113.0
#          ctv2_runner.py Rev 110: entry expiry moved to step 3a in
#          _on_bar_complete - stale entries cleared before new entry check.
#          VERSION bumped to 112.0
#          REVISION bumped to 111. VERSION bumped to 111.0
#  v8.57- VTB branding applied to all user-facing mode displays.
#          Updated START_TRADING.ps1 to Revision: 2.1
#          Updated RESTART.ps1 to Revision: 2.3
#          Updated ABORT_TRADING.ps1 to Revision: 1.2
#          Updated config_editor.ps1 to v1.3
#          Updated ctv2_config_editor.py to Revision: 4.9
#          Updated preflight_check.py to Rev 14
#          VERSION bumped to 110.0
#          ctv2_runner.py Rev 108: sticky direction in _on_bar_complete -
#          sub-threshold crossovers no longer flip current_dir.
#          VERSION bumped to 109.0
#          ctv2_runner.py Rev 107: _recover_state() stale 'Tradier positions'
#          log messages replaced with 'IBKR positions'.
#          VERSION bumped to 108.0
#          ctv2_runner.py Rev 106: synthetic fill path removed - paper mode
#          now sends real orders to IBKR paper account and polls for fills.
#          config_ctv2_default.py Rev 1.4: LIVE_TRADING comment updated.
#          VERSION bumped to 107.2
#          ibkr_orders.py Rev 8: _qualify_contracts() helper added - fixes
#          'event loop already running' error in precache_contracts, _option,
#          and get_todays_expiration by using run_coroutine_threadsafe.
#          VERSION bumped to 107.1
#          ibkr_orders.py Rev 7: get_todays_expiration() rewritten - paper
#          mode short-circuits (no IBKR call); live mode uses
#          reqSecDefOptParams on SPX conId to confirm valid SPXW expiry.
#          VERSION bumped to 107.0
#          ibkr_orders.py Rev 6: get_todays_expiration() fixed - replaced
#          qualifyContracts on hardcoded strike 5000 with reqContractDetails
#          on incomplete contract (no strike). Eliminates Error 200 at startup.
#          VERSION bumped to 106.0
#  v8.56- IB Gateway shortcut removed from CREATE_SHORTCUTS.ps1.
#          IBKR installer places its own shortcut on the desktop.
#          CREATE_SHORTCUTS.ps1 v1.20. VERSION bumped to 105.8
#  v8.55- Include_pip=1 added; ensurepip bootstrap before package installs.
#          CTV_Install.cs Rev 3.17. VERSION bumped to 105.7
#  v8.54- Python installer uses /repair flag (forces full reinstall).
#          CTV_Install.cs Rev 3.16. VERSION bumped to 105.6
#  v8.53- IB Gateway shortcut path fixed to C:\Program Files\ibgateway.
#          CREATE_SHORTCUTS.ps1 v1.19. VERSION bumped to 105.5
#  v8.52- Step 3 pip fix: PATH refresh, clear PYTHONHOME, use python -m pip.
#          CTV_Install.cs Rev 3.15. VERSION bumped to 105.4
#  v8.51- IB Gateway exe path fixed in installer, updater, and preflight.
#          CTV_Install.cs Rev 3.14, Update.ps1 Rev 2.4,
#          preflight_check.py Rev 12. VERSION bumped to 105.3
#  v8.50- Python health check before merge in CTV_Install.cs Rev 3.13.
#          VERSION bumped to 105.2
#  v8.49- Fixed Python path corruption during install (encodings crash).
#          Updated CTV_Install.cs to Revision: 3.12 (removes stale ._pth
#          and pyvenv.cfg from C:\CTV before merge; clears PYTHONHOME/
#          PYTHONPATH; merge uses resolved Python exe path)
#          VERSION bumped to 105.1
#  v8.48- GAP_OPEN_THRESHOLD removed from ibkr_scale.py (crash fix).
#          Updated ibkr_scale.py to Rev 3 (GAP_OPEN_THRESHOLD removed from
#          ScaledConfig dataclass, raw dict, and constructor; gap entry
#          was already removed from config/defaults)
#          Updated ctv2_runner.py (self.cfg.GAP_OPEN_THRESHOLD replaced
#          with module-level constant; gap banner lines removed)
#          REVISION bumped to 105. VERSION bumped to 105.0
#  v8.47- Version check added as Step 1 of build_zip.ps1.
#          Updated build_zip.ps1 to Revision: 2.5 (runs version_check.ps1
#          -BuildGate before zip; aborts if any file fails; steps 2/3 3/3)
#          Updated version_check.ps1 (param -BuildGate added; exits 0 on
#          pass without re-launching BUILD_CTV_ZIP.bat; prevents recursion)
#          VERSION bumped to 104.1
#  v8.46- VTB branding on user-facing update text.
#          Updated Update.ps1 to Revision: 2.3 (all user-visible strings
#          changed from CTV2 to VTB)
#          Updated UPDATE.bat to Revision: 1.1 (comment only)
#          Updated CREATE_SHORTCUTS.ps1 to v1.18 (Update shortcut label
#          changed from "Update CTV2" to "Update VTB")
#          VERSION bumped to 104.0
#  v8.45- _collapse_thread hardened for IBKR rejection edge cases.
#          Updated ctv2_runner.py to Rev 105 / REVISION=104:
#          bid/ask width check before placing collapse; retry on rejection
#          or poll timeout; cancel stale order before retry; max 3 attempts
#          VERSION bumped to 103.9
#  v8.44- Version guard added to Update.ps1 and CTV_Install.cs.
#          Updated Update.ps1 to Revision: 2.2 (peeks VERSION from zip
#          after download; aborts if zip older than installed; warns and
#          confirms if same version)
#          Updated CTV_Install.cs to Revision: 3.11 (peeks VERSION from
#          zip, displays it, requires YES confirmation before extracting)
#          VERSION bumped to 103.8
#  v8.43- IB Gateway desktop shortcut added to CREATE_SHORTCUTS.ps1.
#          Updated CREATE_SHORTCUTS.ps1 to v1.17 (searches for
#          ibgateway.exe under C:\Jts\ibgateway, creates IB Gateway.lnk
#          pointing directly to exe with embedded icon; skipped if not found)
#          VERSION bumped to 103.7
#  v8.42- Update.ps1 silently refreshes integrity manifest after deploy.
#          Updated Update.ps1 to Revision: 2.1 (Get-SHA256FileNormalized
#          added; manifest refresh re-hashes all 13 CTV .py files and
#          IB Gateway exe after every update - eliminates Trust & Update
#          Manifest dialog in preflight after legitimate update)
#          VERSION bumped to 103.6
#  v8.41- File integrity checking added.
#          Updated CTV_Install.cs to Revision: 3.10 (manifest now stores
#          SHA-256 of all 13 CTV .py files via Get-SHA256FileNormalized
#          and IB Gateway exe; hashes persist in install_manifest.json)
#          Updated preflight_check.py to Rev 11 (check_file_integrity()
#          re-hashes files at launch, blocking dialog on mismatch with
#          Abort / Trust & Update Manifest options; Rev 7 CRLF bug fixed)
#          VERSION bumped to 103.5
#  v8.40- CTV_Install.cs updated to Revision 3.9 (IB Gateway step added;
#          completion message syntax bug fixed).
#          Updated CTV_Install.cs to Revision: 3.9 (7 steps: added step 4
#          IB Gateway stable standalone download+silent install, skips if
#          already present; fixed unclosed PS string in completion message)
#          VERSION bumped to 103.4
#  v8.39- Intrinsic exit pacing corrected; duplicate fill fix.
#          Updated ctv2_runner.py Rev 104 (no REVISION bump):
#          _check_late_day_exits retry interval 60s->5min; 6-attempt cap
#          added (4 pos x 2 OER actions x 6 = 48, under 50:1 limit);
#          _on_order_not_filled cancels live IBKR order before revert.
#          VERSION bumped to 103.3
#  v8.38- Collapse-after-WIN added.
#          Updated ctv2_runner.py to Rev 102 / REVISION=102:
#          _collapse_thread added; fires after every WIN fill.
#          VERSION bumped to 103.2
#  v8.37- VIX9D switched from Tradier to yfinance.
#          Updated ctv2_runner.py to Rev 101 / REVISION=101:
#          _start_vix_poll uses ibkr_orders.get_vix9d() (yfinance ^VIX9D).
#          VERSION bumped to 103.1 (minor; no runner REVISION bump)
#  v8.36- SPXW contract pre-cache on 9:30 bar close.
#          Updated ctv2_runner.py to Rev 100 / REVISION=100:
#          precache_contracts() on 9:30 bar; lazy re-cache on miss.
#          VERSION bumped to 103.0
#  v8.35- Phase 3 IBKR migration complete.
#          tradier_client.py + tradier_orders.py replaced by ibkr_orders.py.
#          ctv2_runner.py Rev 99: order layer swap + Phase 4 cleanup.
#          VERSION bumped to 102.0
#  v8.34- Phase 2 IBKR migration.
#          ibkr_stream.py Rev 1 wired in. TradierStream replaced.
#          ctv2_runner.py Rev 98. VERSION bumped to 101.0
#  v8.33- ibkr_scale.py Rev 2 (IB_HOST/IB_PORT config reads).
#          ibkr_stream.py Rev 2 (IB_HOST/IB_PORT config reads).
#          VERSION bumped to 100.2
#  v8.32- ibkr_scale.py Rev 1 added (standalone scaling module).
#          VERSION bumped to 100.1
#  v8.31- Phase 1 IBKR migration complete.
#          config_ctv2.py UNDERLYING added. VERSION bumped to 100.0
#  v8.30- Risk manager added. risk_manager.py Revision: 1.1.
#          VERSION bumped to 99.1
#  v8.29- ctv2_auth.py Revision: 1.3 (machine_id from MAC).
#          VERSION bumped to 99.0
#  v8.28- ctv2_auth.py Revision: 1.2. VERSION bumped to 98.2
#  v8.27- merge_config.py Revision: 1.1. VERSION bumped to 98.1
#  v8.26- ctv2_auth.py Revision: 1.1 added. VERSION bumped to 98.0
#  v8.25- pushover_alerts.py Revision: 1.4. VERSION bumped to 97.3
#  v8.24- ctv2_runner.py Rev 97. VERSION bumped to 97.2
#  v8.23- ctv2_runner.py Rev 96. VERSION bumped to 97.1
#  v8.22- spx_bars.py Revision: 6. VERSION bumped to 97.0
#  v8.21- ctv2_runner.py Rev 95. VERSION bumped to 96.1
#  v8.20- spx_bars.py Revision: 5. VERSION bumped to 96.0
#  v8.19- ctv2_runner.py Rev 94. VERSION bumped to 95.1
#  v8.18- ctv2_runner.py Rev 93. VERSION bumped to 95.0
#  v8.17- pushover_alerts.py Revision: 1.3. VERSION bumped to 94.2
#  v8.16- ctv2_runner.py Rev 92. VERSION bumped to 94.1
#  v8.15- ctv2_runner.py Rev 91. VERSION bumped to 94.0
#  v8.14- ctv2_runner.py Rev 90. VERSION bumped to 93.1
#  v8.13- ctv2_runner.py Rev 89. VERSION bumped to 93.0
#  v8.12- ctv2_runner.py Rev 88. VERSION bumped to 92.1
#  v8.11- ctv2_runner.py Rev 87. VERSION bumped to 92.0
#  v8.10- ctv2_runner.py Rev 86 + spx_bars.py Rev 4. VERSION bumped to 91.0
#  v8.9 - ctv2_runner.py Rev 85. VERSION bumped to 90.1
#  v8.8 - ctv2_runner.py Rev 84. VERSION bumped to 90.0
#  v8.7 - ctv2_runner.py Rev 84.1 + spx_bars.py Rev 3. VERSION bumped to 89.1
#  v8.6 - ctv2_runner.py Rev 83 + spy_bars.py Rev 2. VERSION bumped to 89.0
#  v8.5 - pushover_alerts.py Revision: 1.2 added. VERSION bumped to 88.1
#  v8.4 - ctv2_runner.py Rev 82. VERSION bumped to 88.0
#  v8.3 - ctv2_runner.py Rev 81. VERSION bumped to 87.1
#  v8.2 - ctv2_runner.py Rev 80. VERSION bumped to 87.0
#  v8.1 - ctv2_dashboard.py Revision: 1.0 added. VERSION bumped to 86.1
#  v8.0 - ctv2_runner.py Rev 79. VERSION bumped to 86.0
#  v7.9 - ctv2_runner.py Rev 78. VERSION bumped to 85.1
#  v7.8 - ctv2_runner.py Rev 77. VERSION bumped to 85.0
#  v7.7 - ctv2_runner.py Rev 76. VERSION bumped to 84.1
#  v7.6 - ctv2_runner.py Rev 75. VERSION bumped to 84.0
#  v7.5 - ctv2_runner.py Rev 74. VERSION bumped to 83.1
#  v7.4 - ctv2_runner.py Rev 73. VERSION bumped to 83.0
#  v7.3 - ctv2_runner.py Rev 72. VERSION bumped to 82.1
#  v7.2 - ctv2_runner.py Rev 71. VERSION bumped to 82.0
#  v7.1 - ctv2_runner.py Rev 70. VERSION bumped to 81.1
#  v7.0 - ctv2_runner.py Rev 69 + pushover_alerts.py Rev 1.1. VERSION 81.0
#  v6.9 - ctv2_runner.py Rev 68. VERSION bumped to 80.1
#  v6.8 - risk_manager.py Revision: 1.0 added. VERSION bumped to 80.0
#  v6.7 - ctv2_runner.py Rev 67. VERSION bumped to 79.1
#  v6.6 - ctv2_config_editor.py Revision: 4.8. VERSION bumped to 79.0
#  v6.5 - ctv2_runner.py Rev 66. VERSION bumped to 78.1
#  v6.4 - ctv2_runner.py Rev 65. VERSION bumped to 78.0
#  v6.3 - ctv2_runner.py Rev 64. VERSION bumped to 77.1
#  v6.2 - ctv2_runner.py Rev 63. VERSION bumped to 77.0
#  v6.1 - ctv2_runner.py Rev 62. VERSION bumped to 76.1
#  v6.0 - ctv2_runner.py Rev 61. VERSION bumped to 76.0
#  v5.9 - ctv2_runner.py Rev 60 + pushover_alerts.py + config_editor 2.5.
#          Added ctv2_dashboard.py at Revision: 1.0. VERSION bumped to 75.0
#  v5.8 - ctv2_runner.py Rev 59. VERSION bumped to 74.1
#  v5.7 - ctv2_runner.py Rev 58 + ctv2_config_editor.py Rev 2.4. VERSION 74.0
#  v5.6 - ctv2_runner.py Rev 57. VERSION bumped to 73.1
#  v5.5 - ctv2_config_editor.py Rev 2.3. VERSION bumped to 73.0
#  v5.4 - ctv2_config_editor.py Rev 2.2. VERSION bumped to 72.1
#  v5.3 - ctv2_runner.py Rev 56. VERSION bumped to 72.0
#  v5.2 - ctv2_runner.py Rev 55. VERSION bumped to 71.1
#  v5.1 - START_TRADING.ps1 Revision: 1.6. VERSION bumped to 71.0
#  v5.0 - ctv2_runner.py Rev 54 + LIVE_TRADING flag added.
#          Removed STREAM_SOURCE/POLYGON_API_KEY. VERSION bumped to 70.0
#  v4.7 - Updated ctv2_runner.py to REVISION = 69
#  v4.6 - Updated ctv2_runner.py to REVISION = 68; tradier_stream.py to Rev 2
#  v4.5 - Updated ctv2_runner.py expected version to REVISION = 67
#  v4.4 - Updated tradier_client.py expected version to Rev 4
#  v4.3 - Updated tradier_client.py expected version to Rev 3
#  v4.2 - Updated ctv2_config_editor.py expected version to Revision: 2.9
#  v4.1 - Updated tradier_client.py expected version to Rev 2
#  v4.0 - Updated ctv2_config_editor.py expected version to Revision: 2.8
#  v3.9 - Updated RESTART.ps1 expected version to Revision: 1.5
#          Updated Update.ps1 expected version to Revision: 1.7
#          Updated START_TRADING.ps1 expected version to Revision: 1.7
#          Removed CTV_SETUP.ps1 (not distributed in ctv.zip)
#          Added tradier_orders.py, tradier_client.py, tradier_stream.py
#  v3.8 - runner -> REVISION = 66 (cancelOrder stale arg crash fix)
#  v3.7 - config_editor -> 2.7 (PREFETCH_RADIUS default 200 -> 300)
#  v3.6 - config_editor -> 2.6 (PREFETCH_RADIUS default 75 -> 200)
#  v3.5 - runner -> REVISION = 65 (fix contract cache misses on entry)
#  v3.4 - runner -> REVISION = 64 (all config time gates use wall-clock)
#  v3.3 - runner -> REVISION = 63 (LAST_ENTRY_TIME uses wall-clock time)
#  v3.2 - runner -> REVISION = 62 (gap expiry uses wall-clock time)
#  v3.1 - runner -> REVISION = 61 (gap-open entry fires on 9:30 bar)
#  v3.0 - runner -> REVISION = 60, pushover -> 1.3, config_editor -> 2.5
#          Added ctv2_dashboard.py at Revision: 1.0
#  v2.9 - Updated ctv2_runner.py to REVISION = 59
#  v2.8 - Updated ctv2_runner.py to REVISION = 58, ctv2_config_editor.py to Revision: 2.4
#  v2.7 - Updated ctv2_runner.py expected version to REVISION = 57
#  v2.6 - Updated ctv2_config_editor.py expected version to Revision: 2.3
#  v2.5 - Updated ctv2_config_editor.py expected version to Revision: 2.2
#  v2.4 - Updated ctv2_runner.py expected version to REVISION = 56
#  v2.3 - Updated ctv2_runner.py expected version to REVISION = 55
#  v1.1 - Updated START_TRADING.ps1 expected version to Revision: 1.6
#
#  Called by VERSION_CHECK.bat. Do not run directly.
#
#  For each file, searches for the expected version string.
#  If ALL pass  -> runs BUILD_ZIP.bat
#  If ANY fail  -> lists failures and exits with code 1
#
#  To update expected versions after a code change, edit the
#  $FILES table below.
# ============================================================
param(
    [switch]$BuildGate   # When set: skip launching BUILD_CTV_ZIP.bat on success.
                         # Used by build_zip.ps1 to gate the build without recursion.
)

Set-Location -Path "C:\CTV"

# -- Read package version from VERSION file ------------------------------------
$pkgVer = 'unknown'
$versionFile = "C:\CTV\VERSION"
if (Test-Path $versionFile) {
    $pkgVer = (Get-Content $versionFile -Raw).Trim()
}

Write-Host ""
Write-Host "============================================================"
Write-Host "  VTB VERSION AUDIT  |  Package v$pkgVer"
Write-Host "============================================================"
Write-Host ""

# -- Version table ------------------------------------------------------------
# Each entry: filename, string that must appear somewhere in that file
$FILES = @(
    @{ File = "ctv2_runner.py";        Expect = "Rev 124: _check_entry_auctions" },
    @{ File = "VERSION";               Expect = "118.4" },
    @{ File = "ibkr_stream.py";        Expect = "Rev 5: EMA seed from historical 5-second bars" },
    @{ File = "ibkr_scale.py";         Expect = "Rev 3: GAP_OPEN_THRESHOLD removed" },
    @{ File = "ibkr_orders.py";        Expect = "Rev 18: openClose=1 (Open) added to all ComboLeg instances in _build_bag." },
    @{ File = "ctv2_config_editor.py"; Expect = "Revision: 5.5" },
    @{ File = "preflight_check.py";    Expect = "Rev 14: VTB branding applied" },
    @{ File = "pushover_alerts.py";    Expect = "Revision: 1.4" },
    @{ File = "ctv2_dashboard.py";     Expect = "Revision: 1.0" },
    @{ File = "risk_manager.py";       Expect = "Revision: 1.1" },
    @{ File = "spx_bars.py";           Expect = "Revision: 6" },
    @{ File = "merge_config.py";       Expect = "Revision: 1.1" },
    @{ File = "config_ctv2_default.py"; Expect = "Revision: 1.7" },
    @{ File = "ctv2_auth.py";          Expect = "Revision: 1.3" },
    @{ File = "CREATE_SHORTCUTS.ps1";  Expect = "v1.20" },
    @{ File = "START_TRADING.ps1";     Expect = "Revision: 2.1" },
    @{ File = "RESTART.ps1";           Expect = "Revision: 2.3" },
    @{ File = "Update.ps1";            Expect = "Revision: 2.4" },
    @{ File = "BUILD_CTV_ZIP.bat";         Expect = "Revision: 1.4" },
    @{ File = "BUILD_INSTALLER.bat";   Expect = "v1.3" },
    @{ File = "build_zip.ps1";         Expect = "Revision: 2.6" },
    @{ File = "CTV_Install.cs";        Expect = "Revision: 3.17" },
    @{ File = "ABORT_TRADING.ps1";     Expect = "Revision: 1.2" },
    @{ File = "CTV2_WATCHDOG.ps1";     Expect = "Revision: 1.0" }
)

# -- Check each file ----------------------------------------------------------
$failures = @()

foreach ($entry in $FILES) {
    $path = "C:\CTV\$($entry.File)"

    if (-not (Test-Path $path)) {
        Write-Host "  MISSING  $($entry.File)"
        $failures += "$($entry.File) - FILE NOT FOUND (expected: $($entry.Expect))"
        continue
    }

    $content = Get-Content $path -Raw -ErrorAction SilentlyContinue
    if ($content -like "*$($entry.Expect)*") {
        Write-Host "  OK       $($entry.File)  [$($entry.Expect)]"
    } else {
        Write-Host "  FAIL     $($entry.File)  [expected: $($entry.Expect)]"
        $failures += "$($entry.File) - expected '$($entry.Expect)'"
    }
}

Write-Host ""

# -- Result -------------------------------------------------------------------
if ($failures.Count -gt 0) {
    Write-Host "============================================================"
    Write-Host "  VERSION MISMATCH - Build blocked"
    Write-Host "============================================================"
    Write-Host ""
    Write-Host "  The following files are not at the expected version:"
    Write-Host ""
    foreach ($f in $failures) {
        Write-Host "    - $f"
    }
    Write-Host ""
    Write-Host "  Provide this list to Claude to get the correct files,"
    Write-Host "  then rerun VERSION_CHECK.bat."
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "============================================================"
Write-Host "  All files at correct version - running build..."
Write-Host "============================================================"
Write-Host ""

# -- Build --------------------------------------------------------------------
if ($BuildGate) {
    # Called from build_zip.ps1 - just exit 0 so the caller proceeds.
    exit 0
}
& "C:\CTV\BUILD_CTV_ZIP.bat"
