@echo off
REM ============================================================
REM BUILD_INSTALLER.bat - Build CTV_Install.exe and zip it
REM Run from C:\CTV
REM
REM v1.3 - Increased ping delay from 3 to 6 pings to reliably release file lock.
REM v1.2 - Changed /target:winexe to /target:exe so the console stays open.
REM v1.1 - Added ping delay after compile to release file lock before zipping.
REM v1.0 - Initial implementation.
REM
REM Output: C:\CTV\CTV_Install.zip (send this to new users)
REM ============================================================

cd /d C:\CTV

echo.
echo ============================================================
echo   CTV INSTALLER BUILD
echo ============================================================
echo.

REM -- Locate csc.exe ---------------------------------------------------
set CSC=
for /f "delims=" %%i in ('where csc.exe 2^>nul') do (
    if not defined CSC set CSC=%%i
)

if not defined CSC (
    REM Try common .NET Framework paths
    for %%v in (4.0.30319) do (
        if exist "%WINDIR%\Microsoft.NET\Framework64\v%%v\csc.exe" (
            set CSC=%WINDIR%\Microsoft.NET\Framework64\v%%v\csc.exe
        )
    )
)

if not defined CSC (
    echo ERROR: csc.exe not found. Install .NET Framework SDK or use Visual Studio Developer Command Prompt.
    pause
    exit /b 1
)

echo   Compiler : %CSC%
echo.

REM -- Compile ----------------------------------------------------------
echo   [1/3] Compiling CTV_Install.cs...
"%CSC%" /out:CTV_Install.exe /target:exe CTV_Install.cs 2>&1
if errorlevel 1 (
    echo.
    echo ERROR: Compilation failed. See errors above.
    pause
    exit /b 1
)
echo         CTV_Install.exe built.

REM -- Wait for file lock to release ------------------------------------
ping -n 6 127.0.0.1 > nul

REM -- Verify exe exists ------------------------------------------------
if not exist CTV_Install.exe (
    echo ERROR: CTV_Install.exe not found after compile.
    pause
    exit /b 1
)

REM -- Zip --------------------------------------------------------------
echo.
echo   [2/3] Creating CTV_Install.zip...
if exist CTV_Install.zip del /f CTV_Install.zip

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "Compress-Archive -Path 'C:\CTV\CTV_Install.exe' -DestinationPath 'C:\CTV\CTV_Install.zip' -Force"

if not exist CTV_Install.zip (
    echo ERROR: Failed to create CTV_Install.zip.
    pause
    exit /b 1
)
echo         CTV_Install.zip created.

REM -- Done -------------------------------------------------------------
echo.
echo   [3/3] Verifying output...
for %%f in (CTV_Install.exe CTV_Install.zip) do (
    echo         %%f
)

echo.
echo ============================================================
echo   BUILD COMPLETE
echo   Send CTV_Install.zip to new users.
echo   They extract and double-click CTV_Install.exe.
echo ============================================================
echo.
pause
