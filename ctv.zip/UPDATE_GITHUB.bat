@echo off
:: ============================================================
::  UPDATE_GITHUB.bat - Push auth.json and ctv.zip to GitHub
::  Revision: 1.0
::  Run from C:\CTV
::
::  v1.0 - Initial implementation.
::         1. Reads current version from C:\CTV\VERSION
::         2. Updates min_version in C:\CTC\Source Files\auth.json
::         3. Pushes auth.json to gah2208/ctv main branch via REST API
::         4. Pushes ctv.zip to gah2208/ctv main branch via REST API
::
::  Requires: PowerShell 5+
::  Token scope: public_repo
:: ============================================================

cd /d C:\CTV

echo.
echo ============================================================
echo   UPDATE GITHUB  -  auth.json + ctv.zip
echo ============================================================
echo.

powershell.exe -ExecutionPolicy Bypass -NoProfile -File "C:\CTV\update_github.ps1"

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo ERROR: GitHub update failed. See messages above.
    pause
    exit /b 1
)
