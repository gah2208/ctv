# CTV2 Changelog

All notable changes to CTV2 are documented here.
Format: `## [vNN] — YYYY-MM-DD` followed by a summary of changes.

---

## [v38.1] — 2026-04-17

### Changed
- `update_github.ps1` — Rev 1.1
  - GitHub Personal Access Token removed from the script body. Token
    is now loaded at startup from `C:\CTV\Source Files\github_token.txt`
    (single line, token only, no quotes or prefix).
  - Missing file, empty file, or a token not starting with `ghp_` each
    produce a clear error message with remediation guidance and exit 1.
  - Rationale: the hardcoded token was being bundled into `ctv.zip` by
    `build_zip.ps1`, which in turn was pushed to GitHub by this same
    script. GitHub's secret scanner would see the token in the archive
    contents on arrival and auto-revoke it on the spot — which is why
    every token appeared to "work once and then die."

- `build_zip.ps1` — Rev 2.7
  - Developer-side scripts excluded from `ctv.zip`:
    `update_github.ps1`, `UPDATE_GITHUB.bat`, `UPLOAD_CONFIG.bat`,
    `UPLOAD_CORE.bat`, `UPLOAD_SCRIPTS.bat`. All five run only on the
    developer machine and must never ship to end users.
  - Structural fix for the token-revocation issue: even if a developer
    script ever contained a credential again in the future, the
    exclusion keeps it out of the distributed zip regardless.

### Security
- Any previously-committed PAT must be revoked manually at
  GitHub → Settings → Developer settings → Personal access tokens.
  Generate a new token, paste into `C:\CTV\Source Files\github_token.txt`,
  and the rotation is complete. The token file must not be committed
  to git (it lives in `Source Files\`, which sits outside the
  `C:\CTV\*.ps1` / `*.bat` / `*.py` wildcards used by `build_zip.ps1`).

---

## [v38.0] — 2026-04-17

### Added
- `structure_resolver.py` (new module) — Rev 1
  - `resolve_structure(order_mgr, body, direction)` returns a dict with
    the $5-wide symmetric butterfly leg strikes (long, short, far) or
    `None` if either required strike (B ± 5 or B ± 10) is missing from
    the contract cache. On `None`, the calling path is expected to
    abandon the entry and log the skip reason.
  - `PAPER_LEG_WIDTH = 5.0` module constant. Resolver is specific to
    the $5 grid; no $10 fallback by design.
  - Phase 1 delivery: module is present and importable but not yet
    called by the runner. Wiring happens in Phase 3 alongside paper-
    legged execution.

### Changed
- `ibkr_orders.py` — Rev 19
  - `has_strike(right, strike) -> bool` public method added. Pure
    `_opt_cache` lookup; never triggers qualification, no side effects.
    Safe to call synchronously from entry-decision paths.
  - `precache_contracts()` radius widened from `± 1.5%` of center to
    `± 1.5% + 25pt` buffer on each side. Guarantees the outer wing
    (B ± 10) of a paper-legged butterfly is cached for any body B
    within the normal trading band, so resolver lookups cannot return
    false-negatives at range edges. Precache rises from ~89 to ~108
    contracts at SPX ~7100 — still a single batched
    `qualifyContractsAsync` call.

---

## [v37.0] — 2026-04-15

### Changed
- `spx_bars.py` — Revision 7
  - `_sep_ema` added: 6-bar EMA of raw separation (α=2/7, ~30-second smoothing).
    Updated on every 5-second bar close alongside `sep_curr`/`sep_prev`.
  - `_sep_ema_prev` tracks the previous tick's `sep_ema` for slope evaluation.
  - `get_ema_state()` now exposes `sep_ema` and `sep_ema_prev`.
  - `reset()` clears `_sep_ema` and `_sep_ema_prev`.
  - `_emit_3m_bar()` log line includes `sep_ema` value.

- `ctv2_runner.py` — Rev 120
  - Rolling signal confirmation replaces fixed 3-minute bar entry trigger.
  - `_on_5s_bar` rewritten: evaluates EMA separation and `sep_ema` slope on
    every 5-second tick. When `_SIG_CONFIRM_TICKS` (6) consecutive ticks
    satisfy sep > threshold AND sep_ema slope positive AND direction consistent,
    signal is confirmed and entry queued immediately.
  - Entry queuing removed from `_on_bar_complete` (now handled exclusively
    by `_on_5s_bar`). `_on_bar_complete` retains logging, trade processing,
    stale order checks, and pending entry expiry.
  - `_sig_confirm_dir`, `_sig_confirm_count`, `_sig_active_dir` state
    variables added to `__init__`.
  - `_SIG_CONFIRM_TICKS = 6` module constant added.
  - Requires `spx_bars.py` Rev 7 for `sep_ema`/`sep_ema_prev` in `get_ema_state()`.

---

## [v36.12] — 2026-04-15

### Fixed
- `ibkr_orders.py` — Rev 18.3
  - `cancelMktData` loop removed from `_snapshot_quotes_async`.
    `reqMktData` with `snapshot=True` causes IB Gateway to
    auto-cancel the subscription after delivering data. Calling
    `cancelMktData` afterwards referenced a tickerId already cleaned
    up server-side, producing `Error 300` on every quote request.

---

## [v36.11] — 2026-04-15

### Fixed
- `ibkr_orders.py` — Rev 18.2
  - `get_vix9d()` reverted from `history()` back to `fast_info`.
    `history()` cannot retrieve data for `^VIX9D` (yfinance reports
    it as possibly delisted). `fast_info.last_price` restored with a
    `previous_close` fallback via `getattr()` — avoids the internal
    dict subscript that raised `TypeError` when the underlying data
    dict was `None`.

---

## [v36.10] — 2026-04-15

### Fixed
- `ctv2_runner.py` — Rev 119
  - `_StdoutTracker` class added. Wraps `sys.stdout` in `run_live()`
    to track the content of the last complete line written by any
    thread. Pre-market countdown checks `'T-minus' in tracker.last`
    before deciding to ANSI-overwrite or plain-print, so lines from
    other threads (VIX poll errors, STRM messages) are never erased.
    `sys.stdout` restored to original in `finally` block.
    `_hb_printed` flag removed.

---

## [v36.9] — 2026-04-15

### Fixed
- `ibkr_orders.py` — Rev 18.1
  - `get_vix9d()` switched from `fast_info.last_price` to
    `ticker.history(period='1d', interval='1m')`. `fast_info`
    internally subscripts a dict that can be `None` pre-market or on
    transient network failures, producing
    `'NoneType' object is not subscriptable`. `history()` always
    returns a DataFrame — empty on failure, never `None`.

---

## [v36.8] — 2026-04-15

### Changed
- `ctv2_runner.py` — Rev 118
  - Buying power fetch moved from `run_live()` to `_calc_contracts()`.
    Lazy evaluation on first fractional entry (~10:00 ET): by that time
    account data has been populated for nearly 30 minutes and the fetch
    always succeeds on the first read. Result cached in
    `_available_funds` for the remainder of the session. Startup buying
    power block in `run_live()` removed entirely.
- `ibkr_orders.py` — Rev 18
  - `get_option_buying_power()` docstring updated to reflect lazy-call
    context. 30-second retry loop retained as a safety net.

---

## [v36.7] — 2026-04-15

### Fixed
- `ctv2_runner.py` — Rev 117
  - `get_option_buying_power()` call moved to after the mode banner,
    after VIX poll and STRM threads are already started. Blocks up to
    30 seconds while `accountValues()` populates, ensuring all startup
    noise (STRM seed, VIX tick, BP result) lands before the pre-market
    countdown begins.
- `ibkr_orders.py` — Rev 17
  - `get_option_buying_power()` retry loop restored with a 30-second
    ceiling. `accountValues()` may be empty immediately after connect
    while IB Gateway is still delivering account data; the loop retries
    every second until `OptionBuyingPower > 0` or 30s elapses. The OM
    event loop runs in its own thread and processes IB messages
    throughout — no explicit pumping required. `import time` added at
    module level.

---

## [v36.6] — 2026-04-15

### Fixed
- `ibkr_orders.py` — Rev 16
  - `_start_account_subscription()` and `_account_subscribed` flag
    removed entirely. `connectAsync()` already calls
    `reqAccountUpdatesAsync()` during the connection handshake for
    single-account connections; calling `reqAccountUpdates()` a second
    time was the source of the 60-second `TimeoutError` warning at
    every startup.
  - `get_option_buying_power()` rewritten as a direct single read of
    `accountValues()`. No retry loop, no background thread, no event
    loop pumping — data is fully populated by the time `connectAsync()`
    returns.
- `ctv2_runner.py` — Rev 116
  - `_account_subscribed` gate removed from pre-market countdown in
    main loop. Flag no longer exists in `ibkr_orders.py`; countdown
    now relies on the natural 30-second interval to clear STRM/VIX
    startup noise.

---

## [v36.5] — 2026-04-15

### Changed
- `ctv2_runner.py` — Rev 115
  - `_run_warmup()` removed entirely (method body, section header, and
    call site). Dead code since the IBKR stream now seeds EMAs from
    historical bars; the self-warm messages were both misleading and
    incorrect.
  - Pre-market countdown added to main loop. Gated on
    `order_manager._account_subscribed` so startup noise (VIX tick,
    `reqAccountUpdates` warning) lands on screen before the countdown
    begins. First update is a plain `print()`; subsequent updates use
    ANSI escape (`\x1b[1A\x1b[2K`) to erase and rewrite the previous
    line every 30 seconds, so exactly one countdown line persists:
    `[SCHED] Waiting for market open - T-minus Xm XXs`

---

## [v36.4] — 2026-04-15

### Fixed
- `ibkr_stream.py` — Rev 6
  - RTH time-of-day guard removed from `_seed_emas_from_history()`.
    Previously skipped EMA seeding before 09:30 and after 16:00 ET.
    `useRTH=True` on `reqHistoricalDataAsync` ensures IB always returns
    bars from the most recent RTH session regardless of when the request
    is made, so a pre-market startup seeds from prior session closing
    data instead of starting cold.
- `ctv2_runner.py` — Rev 114
  - Pre-market "waiting" message added to `_check_market_schedule()`.
    On a valid trading day started before 09:30, now prints
    `[SCHED] Pre-market start - market opens at HH:MM ET (T-minus Xm)`
    so the system is visibly alive after startup rather than silent.

---

## [v36.3] — 2026-04-14

### Fixed
- `ibkr_orders.py` — Rev 12
  - `reqAccountUpdates()` moved to a daemon thread via new
    `_start_account_subscription()` helper. `ib_insync` documents
    `reqAccountUpdates()` as blocking — it calls `_run()` and waits for
    full account and portfolio data before returning. Running it on the
    main thread froze startup at `[TDCL] Option buying power`. The
    background thread completes asynchronously while the runner continues;
    `accountValues()` is populated by the time the retry loop reads it.

---

## [v36.2] — 2026-04-14

### Fixed
- `ibkr_orders.py` — Rev 11
  - `reqAccountUpdates()` moved out of `__init__` entirely. Now called
    lazily on first `get_option_buying_power()` invocation, by which time
    the event loop is fully running. Even without `time.sleep()`, calling
    it in `__init__` blocked startup because the event loop is not yet
    stable immediately after `connect()`.

---

## [v36.1] — 2026-04-13

### Fixed
- `ibkr_orders.py` — Rev 10
  - `reqAccountUpdates()` made fire-and-forget. Removed `time.sleep(2)`
    that blocked the main thread after connection — caused consistent
    startup lockup at `[OM  ] IBKROrderManager connected`. Account data
    arrives asynchronously; `get_option_buying_power()` already pumps
    the event loop when values are needed.

---

## [v36] — 2026-04-13

### Fixed
- `ctv2_runner.py` — Rev 111
  - clientId reverted to stable hardcoded values: 2 for IBKROrderManager,
    1 for IBKRStream. Rev 109 introduced REVISION-based clientIds to prevent
    stale slot collisions, but this causes the clientId to change with every
    release (e.g. clientId=111 at Rev 111). The correct fix is `disconnect()`
    in all shutdown paths (also Rev 109), which releases the slot cleanly.

---

## [v35] — 2026-04-13

### Fixed
- `ctv2_runner.py` — Rev 110
  - Entry expiry moved to step 3a in `_on_bar_complete`, before the new
    entry check (step 4). Previously expiry ran inside `_try_enter_pending`
    (step 5) — too late. A pending entry timing out on a viable bar would
    block step 4 from re-queuing, leaving `Pending=0` with no fresh entry
    despite a valid signal. With expiry in step 3a, the stale entry is
    cleared before step 4 runs, allowing immediate re-queue on the same bar.

---

## [v34] — 2026-04-13

### Changed
- `ctv2_runner.py` — Rev 109
  - Gap-open logic fully removed (~15 touch points).
  - `disconnect()` wired into all shutdown paths (finally, SIGINT, market-close).
  - REVISION-based clientId passed to IBKROrderManager and IBKRStream
    (REVISION for orders, REVISION+1 for stream) — eliminates stale
    clientId collisions on restart.

---

## [v33] — 2026-04-13

### Changed
- `spx_bars.py` — Rev 6
  - `is_accelerating()` simplified to `sep_curr > sep_prev`. Peak accel
    high-water mark (`_peak_accel_sep`) and `_update_peak_accel()` removed.
    Matches specification: acceleration = current separation exceeds previous
    separation, nothing more.

---

## [v32] — 2026-04-13

### Changed
- `ibkr_stream.py` — Rev 3
  - `client_id` constructor param replaces hardcoded `_CLIENT_ID` constant.
    Allows runner to pass REVISION+1 to avoid clientId collisions with
    IBKROrderManager.

---

## [v31] — 2026-04-13

### Fixed
- `ibkr_orders.py` — Rev 9
  - `reqAccountUpdates()` subscription added in `__init__` (fixes $0 buying
    power at startup).
  - `disconnect()` method added for clean shutdown.
  - Preview/synthetic mode parameters removed from `place_entry`,
    `place_win_sell`, `place_collapse`.
  - Constructor accepts `client_id` param (passed from runner).

---

## [v30] — 2026-04-13

### Fixed
- `ctv2_runner.py` — Rev 108
  - `_on_bar_complete()`: sticky direction applied. `current_dir` now holds
    the last confirmed direction when `sep < EMA_DIRECTION_THRESHOLD` instead
    of flipping on any micro-crossover. `EMA_DIRECTION_THRESHOLD` now
    correctly gates both entry viability and direction changes. Previously a
    0.15pt crossover would flip direction to DOWN, cancel pending UP entries,
    and require a full direction-change event to re-enter UP — even though
    DOWN was never viable.

---

## [v29] — 2026-04-13

### Fixed
- `ctv2_runner.py` — Rev 107
  - `_recover_state()`: three stale log messages referencing "Tradier
    positions" updated to "IBKR positions". Recovery logic was already
    querying IBKR correctly via `get_positions()`; only the messages
    were left behind from the migration.

---

## [v28] — 2026-04-13

### Changed
- `ctv2_runner.py` — Rev 106
  - Synthetic fill path completely removed. Paper mode now sends real orders
    to the IBKR paper account and polls for genuine IBKR-simulated fills,
    identical to live mode. Removed: `_poll_order_fill` synthetic fill block,
    all `preview=not LIVE_TRADING` kwargs at every call site, collapse
    thread early-return guard. Mode banner updated to reflect real paper
    orders. `LIVE_TRADING` now controls account selection only, not whether
    orders are placed.
- `config_ctv2_default.py` — Rev 1.4
  - `LIVE_TRADING` comment updated to reflect new paper mode behaviour.

---

## [v27.2] — 2026-04-13

### Fixed
- `ibkr_orders.py` — Rev 8
  - Added `_qualify_contracts()` thread-safe helper. All direct calls to
    `self._ib.qualifyContracts()` replaced with this helper. The raw call
    raised "This event loop is already running" when invoked from the
    runner's bar-processing thread. The helper uses
    `asyncio.run_coroutine_threadsafe` to submit `qualifyContractsAsync`
    to the already-running `ib_insync` loop and blocks for the result —
    safe to call from any thread. Fixes `precache_contracts`, `_option`,
    and `get_todays_expiration` (live mode).

---

## [v27.1] — 2026-04-13

### Fixed
- `ibkr_orders.py` — Rev 7
  - `get_todays_expiration()` rewritten again. Paper mode now short-circuits
    immediately with no IBKR call — validation is advisory-only in paper and
    both `qualifyContracts` and `reqContractDetails` approaches triggered
    Error 200. Live mode uses `reqSecDefOptParams` on the SPX index `conId`
    to retrieve the complete set of valid SPXW expiration dates and confirms
    today is among them before allowing trading to proceed.

---

## [v27] — 2026-04-13

### Fixed
- `ibkr_orders.py` — Rev 6
  - `get_todays_expiration()`: replaced `qualifyContracts()` on a
    hardcoded strike-5000 SPXW contract with `reqContractDetails()` on
    an incomplete contract (no strike field).  The old approach always
    fired IBKR Error 200 because strike 5000 has no security definition
    at current SPX price levels.  The new approach uses IBKR's wildcard
    matching — a non-empty result confirms today is a valid SPXW
    expiration day without depending on any specific strike price.

---

## [v26] — 2026-03-15

### Added
- `ctv2_auth.py` — startup authorization and in-session polling
  - Machine ID computed from hashed Windows GUID (8-char hex)
  - Remote auth via `auth.json` hosted on GitHub
  - Unknown machine ID sends Pushover to Greg + registration message to user
  - In-session poll every bar; confirmed disable honored at 16:00 ET
  - At 16:00: writes local `AUTH_DISABLED.flag` + sends Pushover to user
  - Local flag persists until GitHub confirms re-enabled
  - Fetch failure policy: `allow` (GitHub outage never blocks trading)
- `auth.json` — hosted in GitHub repo root; controls who can run CTV2
- `TEST_AUTH.bat` / `test_auth.py` — standalone auth verification tool
  - Prints machine ID, GitHub status, version check, auth result
  - Safe to share with new users for onboarding
- `TEST_PUSHOVER.bat` / `test_pushover.py` — standalone Pushover verification tool
- `START_TRADING.bat`, `RESTART.bat`, `UPDATE.bat` — `.bat` wrappers for
  PowerShell scripts; fixes terminal window closing immediately on errors

### Changed
- `ctv2_runner.py` — Rev 26
  - `run_startup_checks()` called at top of `run_live()` before TWS connects
  - `_check_auth_poll()` called every bar for in-session monitoring
  - `_check_market_close()` writes disable flag and notifies user at 16:00
- `ctv2_order_manager.py` — Rev 1
  - Removed `create_stop_order()` — stop orders are never placed
- `pushover_alerts.py` — Rev 1.1
  - All alert titles updated from `R10:` to `CTV2:`
  - `send_trade_exit_alert()` now uses full dollar amounts ($150 not $1.50)
  - `send_test_notification()` updated from R9e to CTV2
- `CREATE_SHORTCUTS.ps1` — v1.13
  - Shortcuts now target `.bat` wrappers instead of `.ps1` files directly

### Fixed
- `ctv2_runner.py` — Removed dead `stop_order_id` field from `LiveTrade`
  and all associated `cancelOrder` guards (field was never set to non-zero)
- `ctv2_runner.py` — `send_trade_exit_alert()` call sites corrected to pass
  full dollar amounts consistent with `send_trade_entry_alert()`

### Revision tracking added to
- `config_ctv2.py` — Rev 1.0
- `ctv2_config_editor.py` — Rev 1.0
- `risk_manager.py` — Rev 1.0
- `pushover_alerts.py` — Rev 1.0
- `RESTART.ps1` — Rev 1.0
- `START_TRADING.ps1` — Rev 1.0
- `Update.ps1` — Rev 1.0
- `BUILD_ZIP.bat` — Rev 1.0
- `CTV_Install.cs` — Rev 1.0

---

## [v25] — 2026-03-15

### Changed
- `ctv2_runner.py` — Rev 25
  - Removed `stop_order_id` field from `LiveTrade` dataclass
  - Removed 4 dead `cancelOrder(stop_order_id)` guard blocks
  - Fixed `send_trade_exit_alert()` call sites to pass full dollar amounts
- `ctv2_order_manager.py` — Rev 1
  - Removed `create_stop_order()` method
  - Updated module docstring

---

## [v24] — prior to 2026-03-15

Initial distributed release. Baseline for revision control.
