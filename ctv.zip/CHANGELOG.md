# CTV2 Changelog

All notable changes to CTV2 are documented here.
Format: `## [vNN] — YYYY-MM-DD` followed by a summary of changes.

---

## [v26] — 2026-03-15

### Added
- `ctv2_auth.py` — startup authorization and in-session polling
  - Machine ID computed from hashed Windows GUID (8-char hex)
  - Remote auth via `auth.json` hosted on GitHub
  - Unknown machine ID sends Pushover to Greg + registration message to user
  - In-session poll every bar; confirmed disable honored at 16:00 ET
  - At 16:00: writes local `AUTH_DISABLED.flag` + sends Pushover to user
  - Local flag persists until GitHub confirms re-enabled
  - Fetch failure policy: `allow` (GitHub outage never blocks trading)
- `auth.json` — hosted in GitHub repo root; controls who can run CTV2
- `TEST_AUTH.bat` / `test_auth.py` — standalone auth verification tool
  - Prints machine ID, GitHub status, version check, auth result
  - Safe to share with new users for onboarding
- `TEST_PUSHOVER.bat` / `test_pushover.py` — standalone Pushover verification tool
- `START_TRADING.bat`, `RESTART.bat`, `UPDATE.bat` — `.bat` wrappers for
  PowerShell scripts; fixes terminal window closing immediately on errors

### Changed
- `ctv2_runner.py` — Rev 26
  - `run_startup_checks()` called at top of `run_live()` before TWS connects
  - `_check_auth_poll()` called every bar for in-session monitoring
  - `_check_market_close()` writes disable flag and notifies user at 16:00
- `ctv2_order_manager.py` — Rev 1
  - Removed `create_stop_order()` — stop orders are never placed
- `pushover_alerts.py` — Rev 1.1
  - All alert titles updated from `R10:` to `CTV2:`
  - `send_trade_exit_alert()` now uses full dollar amounts ($150 not $1.50)
  - `send_test_notification()` updated from R9e to CTV2
- `CREATE_SHORTCUTS.ps1` — v1.13
  - Shortcuts now target `.bat` wrappers instead of `.ps1` files directly

### Fixed
- `ctv2_runner.py` — Removed dead `stop_order_id` field from `LiveTrade`
  and all associated `cancelOrder` guards (field was never set to non-zero)
- `ctv2_runner.py` — `send_trade_exit_alert()` call sites corrected to pass
  full dollar amounts consistent with `send_trade_entry_alert()`

### Revision tracking added to
- `config_ctv2.py` — Rev 1.0
- `ctv2_config_editor.py` — Rev 1.0
- `risk_manager.py` — Rev 1.0
- `pushover_alerts.py` — Rev 1.0
- `RESTART.ps1` — Rev 1.0
- `START_TRADING.ps1` — Rev 1.0
- `Update.ps1` — Rev 1.0
- `BUILD_ZIP.bat` — Rev 1.0
- `CTV_Install.cs` — Rev 1.0

---

## [v25] — 2026-03-15

### Changed
- `ctv2_runner.py` — Rev 25
  - Removed `stop_order_id` field from `LiveTrade` dataclass
  - Removed 4 dead `cancelOrder(stop_order_id)` guard blocks
  - Fixed `send_trade_exit_alert()` call sites to pass full dollar amounts
- `ctv2_order_manager.py` — Rev 1
  - Removed `create_stop_order()` method
  - Updated module docstring

---

## [v24] — prior to 2026-03-15

Initial distributed release. Baseline for revision control.
