# ============================================================
#  build_zip.ps1 -- CTV2 ZIP Build Logic
#  Revision: 2.6
#
#  Called by BUILD_ZIP.bat. Do not run directly.
#
#  v2.6 - Success path Read-Host removed so control returns to caller
#          (VERSION_CHECK.bat) for chained BUILD_INSTALLER.bat run.
#          ZIP build catch block now exits 1 on failure so caller
#          can detect and stop the chain.
#  v2.5 - Step 1: Run version_check.ps1 before building. Aborts if any
#          file is missing or at the wrong version. Zip is only built when
#          all files pass. Steps renumbered 2/3 and 3/3.
#          excluded from zip; config_ctv2_default.py ships instead).
#          Excluded config_ctv2.py from zip file list.
#          Simplified build: non-ASCII scan -> zip -> done.
#  v2.3 - Hard abort before step 1 if config_ctv2.py is missing.
#          Prevents partial credential-blank with no restore on failed builds.
#  v2.2 - Excluded CTV_Install.exe from ctv.zip. Including it caused an
#          access-denied error when Expand-Archive tried to overwrite the
#          running executable during install.
#  v2.1 - Repair-NonAscii: replaced slow byte-pipeline with fast Regex.IsMatch()
#          check. Reduces non-ASCII scan from minutes to seconds.
#  v2.0 - Excluded version_check.ps1 from non-ASCII scan (not distributed
#          in ctv.zip; was being modified every build unnecessarily).
#  v1.9 - Removed file hashing step (hash mismatches due to line ending
#          differences between build and install machines).
#  v1.7 - Added TRADIER_ACCOUNT_ID and TRADIER_PRODUCTION_TOKEN to
#          credential strip/restore cycle (steps 1, 2, 4).
#  v1.6 - Reads package version from VERSION file (not config_ctv2.py).
#          Adds VERSION file to zip contents.
#  v1.5 - Reads PACKAGE_VERSION from config_ctv2.py and displays it.
#  v1.4 - Excluded ctv2_param_tester.py from zip.
#  v1.3 - Fixed Repair-NonAscii to write UTF-8 without BOM.
#  v1.2 - Added Step 0: scan and fix non-ASCII characters.
#  v1.1 - Removed failed -replace syntax attempt in step 2.
#  v1.0 - Initial implementation.
# ============================================================

Set-Location -Path "C:\CTV"

$ZIP    = "C:\CTV\ctv.zip"
$CONFIG = "C:\CTV\config_ctv2.py"

# -- Read package version -------------------------------------------------------
$pkgVer = 'unknown'
$versionFile = "C:\CTV\VERSION"
if (Test-Path $versionFile) {
    $pkgVer = (Get-Content $versionFile -Raw).Trim()
}

Write-Host ""
Write-Host "============================================================"
Write-Host "  CTV2 Build ZIP  |  Package v$pkgVer"
Write-Host "============================================================"
Write-Host ""

# -- Step 1: Version check - abort if any file is wrong version ---------------
Write-Host "  [1/3] Running version check..."
Write-Host ""
$vcResult = & powershell.exe -NoProfile -ExecutionPolicy Bypass `
    -File "C:\CTV\version_check.ps1" -BuildGate
if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "============================================================"
    Write-Host "  BUILD ABORTED - version check failed."
    Write-Host "  Fix the files listed above, then re-run BUILD_CTV_ZIP.bat."
    Write-Host "============================================================"
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}
Write-Host ""
Write-Host "  Version check passed - proceeding with build."
Write-Host ""

# -- Step 2: Scan and fix non-ASCII characters ---------------------------------
Write-Host "  [2/3] Scanning for non-ASCII characters in .ps1 and .py files..."

function Repair-NonAscii {
    param([string]$Path)
    $content = [System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::UTF8)
    if (-not [System.Text.RegularExpressions.Regex]::IsMatch($content, '[^\x00-\x7F]')) { return $false }
    $fixed = $content
    $fixed = $fixed -replace [char]0x201C, '"'   # left double quote
    $fixed = $fixed -replace [char]0x201D, '"'   # right double quote
    $fixed = $fixed -replace [char]0x2018, "'"   # left single quote
    $fixed = $fixed -replace [char]0x2019, "'"   # right single quote
    $fixed = $fixed -replace [char]0x2014, '-'   # em dash
    $fixed = $fixed -replace [char]0x2013, '-'   # en dash
    $fixed = $fixed -replace [char]0x2500, '-'   # box drawing horizontal
    $fixed = $fixed -replace [char]0x2502, '|'   # box drawing vertical
    [System.IO.File]::WriteAllText($Path, $fixed, [System.Text.UTF8Encoding]::new($false))
    return $true
}

$scriptFiles = @(
    Get-ChildItem "C:\CTV\*.ps1" | Where-Object { $_.Name -ne "version_check.ps1" }
    Get-ChildItem "C:\CTV\*.py"
) | Where-Object { $_ -ne $null }

$fixCount = 0
foreach ($file in $scriptFiles) {
    if (Repair-NonAscii -Path $file.FullName) {
        Write-Host "  FIXED: $($file.Name)"
        $fixCount++
    }
}

if ($fixCount -eq 0) {
    Write-Host "  All files clean - no non-ASCII characters found."
} else {
    Write-Host "  Fixed $fixCount file(s)."
}
Write-Host ""

# -- Pre-flight: abort if default config missing -------------------------------
$DEFAULT_CONFIG = "C:\CTV\config_ctv2_default.py"
if (-not (Test-Path $DEFAULT_CONFIG)) {
    Write-Host "============================================================"
    Write-Host "  ERROR: config_ctv2_default.py not found at $DEFAULT_CONFIG"
    Write-Host "  Build aborted. No files were modified."
    Write-Host "  Ensure config_ctv2_default.py exists before building."
    Write-Host "============================================================"
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}

# -- Step 2: Build zip ---------------------------------------------------------
Write-Host "  [3/3] Building ctv.zip..."

if (Test-Path $ZIP) { Remove-Item $ZIP -Force }

$files = @(
    Get-ChildItem "C:\CTV\*.py"   | Where-Object {
        $_.Name -ne "ctv2_param_tester.py" -and $_.Name -ne "config_ctv2.py"
    }
    Get-ChildItem "C:\CTV\*.ico"
    Get-ChildItem "C:\CTV\*.pdf"
    Get-ChildItem "C:\CTV\*.cs"
    Get-ChildItem "C:\CTV\*.exe" | Where-Object { $_.Name -ne "CTV_Install.exe" }
    Get-ChildItem "C:\CTV\*.ps1"
    Get-ChildItem "C:\CTV\*.bat"
    Get-ChildItem "C:\CTV\*.md"
    Get-Item      "C:\CTV\VERSION" -ErrorAction SilentlyContinue
) | Where-Object { $_ -ne $null }

try {
    Compress-Archive -Path $files.FullName -DestinationPath $ZIP
    Write-Host "  Zipped $($files.Count) files."
} catch {
    Write-Host ""
    Write-Host "  ERROR: ZIP build failed: $_"
    Read-Host "Press Enter to exit"
    exit 1
}

# -- Done ----------------------------------------------------------------------
Write-Host ""
Write-Host "============================================================"
Write-Host "  ZIP saved to: $ZIP"
Write-Host "  config_ctv2.py excluded - config_ctv2_default.py ships instead."
Write-Host "============================================================"
Write-Host ""
