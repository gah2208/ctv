#!/usr/bin/env python3
# Copyright (c) Gregory Howard 2026  All rights reserved
"""
ctv2_config_editor.py - CTV2 Configuration Editor

Revision: 5.1
Rev 5.1: EMA3/EMA15 labels updated to EMA36/EMA180 throughout
         SECTIONS descriptions. No logic change - documentation only.
Rev 5.0: MAX_ACTIVE_TRADES removed from Entry tab and write_config().
         Trade slot limits are now hardcoded in ctv2_runner.py.
Rev 4.8: Copyright (c) Gregory Howard 2026 All rights reserved added to file
         header, title bar, and bottom button bar footer label.
Rev 4.7: INTRINSIC_EXIT_TIME default changed from 14:30 to 15:30.
Rev 4.6: EXIT - MIN_CONV_CREDIT_PCT default 1.05->1.2, description updated.
         EXIT - SELL_SLIPPAGE default 0.95->0.9, description updated.
         PRICING - ENTRY_SLIPPAGE default 1.05->1.1, description updated.
         PM_BOUNDARY removed from Timing section and write_config().
Rev 4.5: Fixed Save Failed KeyError on LIVE_TRADING. write_config() was still
         deriving IB_PORT from values["LIVE_TRADING"] which is no longer a UI
         field (removed in Rev 4.3). IB_PORT now written as fixed 7497;
         preflight_check.py overwrites it with the correct detected port.
Rev 4.4: Aligned description top with value top across all tabs (sticky=nw).
         Added vertical scrollbar to all tab sections (display-scale fix).
         POSITION_SIZE description updated to match spec.
         MAX_PREMIUM description fixed (formula with slippage).
         ENTRY_TIMEOUT default corrected to 10 minutes.
         Gap entry process removed: GAP_OPEN_THRESHOLD, GAP_TRADE_EXPIRY_TIME,
         GAP_ENTRY_SLIPPAGE deleted from SECTIONS, write_config(), and defaults.
         LAST_ENTRY_TIME description updated to "No new long positions...".
         ENTRY_SLIPPAGE description fixed (? -> *).
         PUSHOVER_NOTIFY_SYSTEM_CRASH description: "runner" -> "system".
Rev 4.3: LIVE_TRADING removed from IB Gateway tab and write_config().
         Paper/live mode is now auto-detected by preflight_check.py Rev 10
         from IB Gateway account type (DU prefix = paper, U = live).
         _update_port_label and port info label removed (no checkbox to drive them).
         Test Connection now tries port 7497 then 7496 and reports which answered.
         write_config() writes LIVE_TRADING=False as safe placeholder;
         preflight overwrites it with the detected value at launch time.
Rev 4.2: Added CONV_SPREAD_WIDTH to Entry tab and write_config().
         Separate from SPREAD_WIDTH; controls win-sell spread width
         to bypass IBKR zero-risk filter. Default 10.0 pts (SPX).
Rev 4.1: Removed IB_PORT from SECTIONS and UI. Port is now derived automatically:
         paper (LIVE_TRADING=False) -> 7497, live (LIVE_TRADING=True) -> 7496.
         Port info label added to IB Gateway tab showing current effective port.
         _update_port_label() called on every LIVE_TRADING toggle.
         _on_test_ib_connection derives port from LIVE_TRADING var (not IB_PORT).
         write_config() derives IB_PORT from LIVE_TRADING value at save time.
Rev 4.0: Added UNDERLYING field to Entry tab (SPX/XSP dropdown via OptionMenu).
         Added "choice" ptype with OptionMenu widget in _build_section.
         Added "choice" branch in _collect (uppercases value).
         Added UNDERLYING to write_config() block (written as string literal).
         Added UNDERLYING = 'SPX' to config_ctv2_default.py with scale comment.
Rev 3.9: Tradier tab replaced by IB Gateway tab. LIVE_TRADING moved to
         IB Gateway tab alongside IB_HOST and IB_PORT. Test Connection
         button added to IB Gateway tab (clientId=99, timeout=5s).
         write_config() updated: Tradier credential lines removed, IB
         Gateway block added. LIVE_TRADING confirmation dialog updated
         to reference IBKR account instead of Tradier account.
Rev 3.8: MAX_PREMIUM default changed from 350.0 to 200.0.
Rev 3.5: Replaced Unicode arrow U+2192 with ASCII '->' in write_config() comment.
         Arrow caused exponential file bloat (~2x per build) via cp1252/UTF-8
         re-encoding in build_zip.ps1. config_ctv2.py now contains only ASCII.
Rev 3.4: Renamed "Live Bearer Token" label to "API Token" in Tradier tab.

CHANGELOG
---------
Rev 3.4: Removed PREFETCH_RADIUS from Pricing tab and write_config().
         Contract IDs are not needed with Tradier - OCC symbols are built
         deterministically. PREFETCH_RADIUS had no effect.
Rev 3.3: LIVE_TRADING checkbox shows a confirmation dialog when toggled on.
         If the user declines, the checkbox is reverted to False.
Rev 3.2: Sandbox mode removed from Tradier tab.
         Removed TRADIER_SANDBOX, TRADIER_SANDBOX_ACCOUNT, TRADIER_SANDBOX_TOKEN
         fields from the tab definition and write_config(). Paper trading is now
         triggered by LIVE_TRADING=False alone. write_config() comments updated.
Rev 3.1: Replaced Polygon tab with LIVE_TRADING field on Tradier tab.
         LIVE_TRADING=False: preview orders (paper). True: real orders.
         Removed STREAM_SOURCE and POLYGON_API_KEY.
Rev 2.9: Added Tradier fields to write_config() - credentials were silently
         dropped on Save because write_config is hardcoded. Tab was present
         (Rev 2.8) but values never written to disk.
Rev 2.8: Added Tradier credentials tab (TRADIER_SANDBOX, TRADIER_ACCOUNT_ID,
         TRADIER_SANDBOX_ACCOUNT, TRADIER_SANDBOX_TOKEN, TRADIER_PRODUCTION_TOKEN).
Rev 2.7: PREFETCH_RADIUS default changed from 200 to 300.
Rev 2.6: PREFETCH_RADIUS default changed from 75 to 200.
Rev 2.5: Added PUSHOVER_EOD_DIGEST checkbox to Pushover tab.
         Added corresponding write_config() line.
Rev 2.4: Added VIX_MAX_ENTRY to Entry tab.
Rev 2.3: Removed note box from Park & Risk tab (moved to user guide).
Rev 2.2: Renamed "Direction Threshold" label to "EMA Direction Threshold".
         Park & Risk tab: added yellow explanatory note box above ACTIVE_ADVERSE_MOVE.
         _build_section now handles "note" pseudo-type (spanning label, not a var).
Rev 2.1: Renamed MAX_SPREAD_WIDTH to MAX_BID_ASK_WIDTH everywhere.
Rev 2.0: Added GAP_ENTRY_SLIPPAGE to Entry tab and write_config().
Rev 1.9: Added POSITION_SIZE to Entry tab. Floor-on-save: int values >= 1
         silently floored to nearest integer. write_config() updated.
Rev 1.8: Fixed write_config() time formatting - leading zeros in hour values
         (e.g. 09:45 -> time(09, 45)) caused SyntaxError in generated config.
         Now strips leading zeros: time(9, 45).
Rev 1.7: Park & Risk tab: replaced PARK_MAX_MOVE with 6 new params
         (PARK_CONVERT_EMA_LOW/MID/HIGH, PARK_VIX_LOW/HIGH, ACTIVE_ADVERSE_MOVE).
         Exit tab: removed REVERSAL_CLOSE_MIN_MOVE row.
         write_config() updated to match.
Rev 1.4: Removed stray "ET" unit label from PUSHOVER_SUMMARY_TIME row.
Rev 1.3: Replaced ttk.Checkbutton with tk.Checkbutton - ttk indicator
         disappears at larger font sizes on Windows. tk.Checkbutton
         renders reliably at any font size.
Rev 1.2: Opens maximized (zoomed) on Windows. Increased all font sizes
         to 14pt (body) and 13pt (secondary labels).
Rev 1.1: Added 4 missing Pushover notification toggles to Pushover tab:
         PUSHOVER_NOTIFY_ALL_TRADES, PUSHOVER_NOTIFY_RISK_SUSPEND,
         PUSHOVER_NOTIFY_LOST_CONNECTION, PUSHOVER_NOTIFY_SYSTEM_CRASH.
         Also added corresponding lines to write_config().
Rev 1.0: Initial revision tracking.

GUI for editing CTV2 trading parameters.
Always operates on C:\\CTV\\config_ctv2.py.

To create EXE:
    pip install pyinstaller
    pyinstaller --onefile --windowed ctv2_config_editor.py
"""

import os
import sys
import re
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import time

# -- Lock to CTV directory ---------------------------------------------------
CTV_DIR    = r"C:\CTV"
CONFIG_FILE = os.path.join(CTV_DIR, "config_ctv2.py")

os.chdir(CTV_DIR)

# -- Parameter definitions ---------------------------------------------------
# (section_label, accent_hex, [ (key, label, type, default, unit, description) ])

SECTIONS = [
    ("Signal", "#B8860B", [
        ("MACD_FAST",               "EMA Fast",            "int",   3,      "bars", "Fast EMA period (EMA36 on 5s bars). Controls entry sensitivity."),
        ("MACD_SLOW",               "EMA Slow",            "int",   15,     "bars", "Slow EMA period (EMA180 on 5s bars). Sets the trend baseline."),
        ("MACD_SIGNAL",             "MACD Signal",         "int",   9,      "bars", "Signal line period. Informational - not used for entry gating."),
        ("EMA_DIRECTION_THRESHOLD", "EMA Direction Threshold", "float", 1.5,    "pts",  "Minimum |EMA36-EMA180| separation to confirm a viable direction. Below this = noise, no entry."),
    ]),
    ("Entry", "#1874CD", [
        ("UNDERLYING",            "Underlying",        "choice", "SPX", "",     "Index to trade. SPX = full-size S&P 500 options (1x scale). XSP = mini S&P 500 options (0.1x scale). All index-point and dollar parameters are entered at SPX scale; ibkr_scale.py applies the 0.1x factor automatically when XSP is selected."),
        ("POSITION_SIZE",         "Position Size",     "float", 1.0,   "",     "Position Size >= 1 = # of contracts/trade. Position Size < 1 = % of available cash used to determine # of contracts/trade. i.e. .05=5% of available cash"),
        ("SPREAD_WIDTH",          "Spread Width",      "float", 5.0,   "pts",  "Width of the debit vertical spread in strike points."),
        ("CONV_SPREAD_WIDTH",      "Conv Spread Width", "float", 10.0,  "pts",  "Width of the win-sell (conversion) vertical spread. Must be > Spread Width. The runner sells a CONV_SPREAD_WIDTH spread at the short strike on a WIN, then immediately places a collapse order to reduce it back to SPREAD_WIDTH, bypassing the IBKR zero-risk filter while netting a standard butterfly."),
        ("MAX_PREMIUM",           "Max Premium",       "float", 200.0, "$",    "Skip entry if (spread ask * (1+slippage) * 100) exceeds this dollar amount"),
        ("MAX_BID_ASK_WIDTH",     "Max Bid/Ask Width", "float", 1.0,   "$/sh", "Skip entry if bid/ask spread on the quote is wider than this per share."),
        ("VIX_MAX_ENTRY",         "VIX Max Entry",     "float", 35.0,  "",     "Block new entries when VIX9D exceeds this level. Butterfly conversion is unaffected. Set to 0 to disable."),
        ("ENTRY_TIMEOUT",         "Entry Timeout",     "int",   10,    "min",  "Drop a pending entry if it has not filled within this many minutes of the signal. Prevents stale entries from firing long after conditions changed."),
    ]),
    ("Exit", "#228B22", [
        ("WIN_TARGET_BUFFER",   "Win Target Buffer","float", 1.0,  "pts", "SPX must reach short_strike +/- this many points to trigger the conversion sell. Keeps the conversion spread just outside the money for maximum time value."),
        ("MIN_CONV_CREDIT_PCT", "Min Conv Credit", "float", 1.2,  "x",   "Win sell floor = premium_paid x this. 1.2 = must net at least 20% profit."),
        ("SELL_SLIPPAGE",       "Sell Slippage",   "float", 0.9,  "x",   "All sell spread limit = bid x this. 0.9 accepts up to 10% below current bid."),
    ]),
    ("Park & Risk", "#CD4F00", [
        ("PARK_CONVERT_EMA_LOW",  "Park EMA (Low VIX)",  "float", 4.0,  "pts", "EMA36/EMA180 separation needed to butterfly-convert a PARKED trade when VIX < PARK_VIX_LOW."),
        ("PARK_CONVERT_EMA_MID",  "Park EMA (Mid VIX)",  "float", 5.0,  "pts", "EMA36/EMA180 separation needed to butterfly-convert a PARKED trade when VIX is between low and high."),
        ("PARK_CONVERT_EMA_HIGH", "Park EMA (High VIX)", "float", 6.0,  "pts", "EMA36/EMA180 separation needed to butterfly-convert a PARKED trade when VIX > PARK_VIX_HIGH."),
        ("PARK_VIX_LOW",          "VIX Low Breakpoint",  "float", 18.0, "",    "VIX level below which the low EMA threshold applies."),
        ("PARK_VIX_HIGH",         "VIX High Breakpoint", "float", 25.0, "",    "VIX level above which the high EMA threshold applies."),
        ("ACTIVE_ADVERSE_MOVE",   "Noise Adverse Move",  "float", 10.0, "pts", "While inside the noise band, butterfly-convert an ACTIVE trade if SPX moves this many pts adverse from the noise band entry price."),
    ]),
    ("Timing", "#7B2FBE", [
        ("TRADING_START",       "Trading Start",  "time", "10:00", "ET", "No entries before this time."),
        ("LAST_ENTRY_TIME",     "Last Entry",     "time", "14:00", "ET", "No new long positions after this time."),
        ("INTRINSIC_EXIT_TIME", "Intrinsic Exit", "time", "15:30", "ET", "All open LiveTrades are converted to butterflies at this time."),
    ]),
    ("Pricing", "#C2185B", [
        ("ENTRY_SLIPPAGE",  "Entry Slippage",  "float", 1.1, "x",   "Entry limit = ask * this. 1.1 guarantees fill at a cost of 10% above ask."),
    ]),
    ("IB Gateway", "#00695C", [
        ("IB_HOST",      "Gateway Host",   "str",  "127.0.0.1",   "", "IB Gateway hostname or IP. Default: 127.0.0.1 (local machine)."),
    ]),
    ("Pushover", "#1565C0", [
        ("PUSHOVER_ENABLED",                "Enabled",             "bool",  False,   "",   "Enable Pushover push notifications. Requires a valid user key and API token from pushover.net."),
        ("PUSHOVER_USER_KEY",               "User Key",            "str",   "",      "",   "Your Pushover user key (found on the main page at pushover.net after login)."),
        ("PUSHOVER_API_TOKEN",              "API Token",           "str",   "",      "",   "Your Pushover application API token (create an application at pushover.net to obtain one)."),
        ("PUSHOVER_CRITICAL_PRIORITY",      "Critical Priority",   "int",   1,       "",   "Priority for watchdog critical alerts. 1 = high priority (bypasses quiet hours). 2 = emergency (requires acknowledgment)."),
        ("PUSHOVER_SUMMARY_TIME",           "Summary Time",        "time",  "16:30", "",   "Time to send the daily error summary notification."),
        ("PUSHOVER_NOTIFY_ALL_TRADES",      "Notify: All Trades",  "bool",  True,    "",   "Send a notification on every trade entry, WIN, butterfly conversion, and park event."),
        ("PUSHOVER_NOTIFY_RISK_SUSPEND",    "Notify: Risk Suspend","bool",  True,    "",   "Send a notification when trading is suspended by the risk manager (consecutive or daily loss limit)."),
        ("PUSHOVER_NOTIFY_LOST_CONNECTION", "Notify: Lost Feed",   "bool",  True,    "",   "Send a notification when the live bar watchdog detects a stale feed and attempts resubscription."),
        ("PUSHOVER_NOTIFY_SYSTEM_CRASH",    "Notify: System Crash","bool",  True,    "",   "Send a notification if an unhandled exception crashes the system."),
        ("PUSHOVER_EOD_DIGEST",              "EOD Digest",          "bool",  True,    "",   "Send an end-of-day summary to your phone: total trades, wins, losses, net P&L, and VIX9D range."),
    ]),
]

# -- Config file I/O ---------------------------------------------------------

def read_config():
    """Parse config_ctv2.py and return dict of {KEY: value_string}."""
    values = {}
    if not os.path.exists(CONFIG_FILE):
        return values
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        text = f.read()

    # Match:  KEY = <value>   (ignoring comments and blank lines)
    pattern = re.compile(r"^([A-Z_]+)\s*=\s*(.+)$", re.MULTILINE)
    for match in pattern.finditer(text):
        key = match.group(1)
        raw = match.group(2).strip()
        # Strip inline comments
        raw = re.sub(r"\s*#.*$", "", raw).strip()
        values[key] = raw
    return values


def parse_time_value(raw):
    """Convert time(H, M) or 'HH:MM' to HH:MM string."""
    m = re.match(r"time\((\d+),\s*(\d+)\)", raw)
    if m:
        return f"{int(m.group(1)):02d}:{int(m.group(2)):02d}"
    # Already a plain string like "09:45"
    raw = raw.strip("'\"")
    if re.match(r"\d{1,2}:\d{2}", raw):
        h, mi = raw.split(":")
        return f"{int(h):02d}:{int(mi):02d}"
    return raw


def write_config(values):
    """Write values dict back to config_ctv2.py."""
    from datetime import date
    today = date.today().isoformat()

    lines = [
        '"""',
        f'config_ctv2.py - CTV2 Live Runner Configuration',
        f'Generated {today} by CTV2 Config Editor',
        '"""',
        '',
        'VERSION = "CFG-2.0"',
        'from datetime import time',
        '',
        '# -- Underlying ------------------------------------------------',
        f'UNDERLYING = \'{values["UNDERLYING"]}\'',
        '',
        '# -- EMA / Direction Signal -------------------------------------',
        f'MACD_FAST               = {values["MACD_FAST"]}',
        f'MACD_SLOW               = {values["MACD_SLOW"]}',
        f'MACD_SIGNAL             = {values["MACD_SIGNAL"]}',
        f'EMA_DIRECTION_THRESHOLD = {values["EMA_DIRECTION_THRESHOLD"]}',
        '',
        '# -- Entry ------------------------------------------------------',
        f'POSITION_SIZE     = {values["POSITION_SIZE"]}',
        f'SPREAD_WIDTH      = {values["SPREAD_WIDTH"]}',
        f'CONV_SPREAD_WIDTH = {values["CONV_SPREAD_WIDTH"]}',
        f'MAX_PREMIUM       = {values["MAX_PREMIUM"]}',
        f'MAX_BID_ASK_WIDTH  = {values["MAX_BID_ASK_WIDTH"]}',
        f'VIX_MAX_ENTRY     = {values["VIX_MAX_ENTRY"]}',
        f'ENTRY_TIMEOUT     = {values["ENTRY_TIMEOUT"]}',
        '',
        '# -- Exit -------------------------------------------------------',
        f'WIN_TARGET_BUFFER   = {values["WIN_TARGET_BUFFER"]}',
        f'MIN_CONV_CREDIT_PCT = {values["MIN_CONV_CREDIT_PCT"]}',
        f'SELL_SLIPPAGE       = {values["SELL_SLIPPAGE"]}',
        '',
        '# -- Park & Risk ------------------------------------------------',
        f'PARK_CONVERT_EMA_LOW  = {values["PARK_CONVERT_EMA_LOW"]}',
        f'PARK_CONVERT_EMA_MID  = {values["PARK_CONVERT_EMA_MID"]}',
        f'PARK_CONVERT_EMA_HIGH = {values["PARK_CONVERT_EMA_HIGH"]}',
        f'PARK_VIX_LOW          = {values["PARK_VIX_LOW"]}',
        f'PARK_VIX_HIGH         = {values["PARK_VIX_HIGH"]}',
        f'ACTIVE_ADVERSE_MOVE   = {values["ACTIVE_ADVERSE_MOVE"]}',
        '',
        '# -- Trading Window ---------------------------------------------',
        f'TRADING_START       = time({", ".join(str(int(x)) for x in values["TRADING_START"].split(":"))})',
        f'TRADING_END         = time(16, 0)',
        f'LAST_ENTRY_TIME     = time({", ".join(str(int(x)) for x in values["LAST_ENTRY_TIME"].split(":"))})',
        f'INTRINSIC_EXIT_TIME = time({", ".join(str(int(x)) for x in values["INTRINSIC_EXIT_TIME"].split(":"))})',
        '',
        '# -- Order Pricing ----------------------------------------------',
        f'ENTRY_SLIPPAGE  = {values["ENTRY_SLIPPAGE"]}',
        '',
        '# -- Data (backtester only) -------------------------------------',
        'SPX_DATA_DIR = "SPX_3min_bars"',
        '',
        '# -- IB Gateway ------------------------------------------------',
        '# IB Gateway must be running and logged in before starting the runner.',
        '# LIVE_TRADING and IB_PORT are auto-detected by preflight_check.py',
        '# based on whether IB Gateway is in paper or live mode. Do not edit.',
        '#',
        f'LIVE_TRADING = False',
        f'IB_HOST = \'{values["IB_HOST"]}\'',
        'IB_PORT = 7497',
        '',
        '# -- Pushover Alerts --------------------------------------------',
        f'PUSHOVER_ENABLED           = {values["PUSHOVER_ENABLED"]}',
        f'PUSHOVER_USER_KEY          = \'{values["PUSHOVER_USER_KEY"]}\'',
        f'PUSHOVER_API_TOKEN         = \'{values["PUSHOVER_API_TOKEN"]}\'',
        f'PUSHOVER_CRITICAL_PRIORITY = {values["PUSHOVER_CRITICAL_PRIORITY"]}',
        f'PUSHOVER_SUMMARY_TIME      = \'{values["PUSHOVER_SUMMARY_TIME"]}\'',
        '',
        f'PUSHOVER_NOTIFY_ALL_TRADES      = {values["PUSHOVER_NOTIFY_ALL_TRADES"]}',
        f'PUSHOVER_NOTIFY_RISK_SUSPEND    = {values["PUSHOVER_NOTIFY_RISK_SUSPEND"]}',
        f'PUSHOVER_NOTIFY_LOST_CONNECTION = {values["PUSHOVER_NOTIFY_LOST_CONNECTION"]}',
        f'PUSHOVER_NOTIFY_SYSTEM_CRASH    = {values["PUSHOVER_NOTIFY_SYSTEM_CRASH"]}',
        f'PUSHOVER_EOD_DIGEST             = {values["PUSHOVER_EOD_DIGEST"]}',
    ]
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def _update_config_hash():
    """Recompute SHA-256 of config_ctv2.py and write it into install_manifest.json."""
    import hashlib, json
    manifest_path = os.path.join(CTV_DIR, "install_manifest.json")
    if not os.path.exists(manifest_path):
        return
    try:
        h = hashlib.sha256()
        with open(CONFIG_FILE, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        new_hash = h.hexdigest().upper()

        with open(manifest_path, "r", encoding="utf-8") as f:
            manifest = json.load(f)

        if "config" not in manifest:
            manifest["config"] = {}
        manifest["config"]["path"]   = CONFIG_FILE
        manifest["config"]["sha256"] = new_hash

        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=4)
    except Exception:
        pass   # silent - hash update is best-effort, never blocks a save


# -- Main application --------------------------------------------------------

class CTV2ConfigEditor:

    def __init__(self, root):
        self.root = root
        self.root.title("VTB Config Editor  \u2014  Copyright (c) Gregory Howard 2026  All rights reserved")
        self.root.resizable(True, True)
        self.root.state('zoomed')   # open maximized on Windows

        # Load current values from file (fall back to defaults)
        self.file_values = read_config()
        self.vars = {}        # key -> tk variable
        self.defaults = {}    # key -> default value

        self._build_ui()
        self._center()

    # -- UI construction -----------------------------------------------------

    def _build_ui(self):
        root = self.root

        # -- Top warning bar ----------------------------------------------
        warn = tk.Frame(root, bg="#FFF3CD", pady=4)
        warn.pack(fill="x")
        tk.Label(warn, text='Double click on "Start Trading" or "Restart Trading" after saving changes.',
                 bg="#FFF3CD", fg="#856404",
                 font=("Segoe UI", 14, "bold")).pack()

        # -- Notebook (tabs per section) ----------------------------------
        nb = ttk.Notebook(root)
        nb.pack(fill="both", expand=True, padx=10, pady=(8, 4))

        style = ttk.Style()
        style.configure("TNotebook.Tab", font=("Segoe UI", 14, "bold"), padding=[10, 4])

        for section_label, accent, params in SECTIONS:
            frame = ttk.Frame(nb, padding=12)
            nb.add(frame, text=section_label)
            inner = self._build_section(frame, accent, params)
            if section_label == "IB Gateway":
                self._build_ib_test_button(inner, len(params))

        # -- Bottom button bar --------------------------------------------
        btn_frame = tk.Frame(root, pady=8)
        btn_frame.pack(fill="x")

        tk.Button(btn_frame, text="Save",
                  bg="#4CAF50", fg="white",
                  font=("Segoe UI", 14, "bold"),
                  width=14, command=self._on_save).pack(side="left", padx=(20, 6))

        tk.Button(btn_frame, text="Reset to Defaults",
                  bg="#FF9800", fg="white",
                  font=("Segoe UI", 14, "bold"),
                  width=16, command=self._on_reset).pack(side="left", padx=6)

        tk.Button(btn_frame, text="Cancel",
                  bg="#9E9E9E", fg="white",
                  font=("Segoe UI", 14, "bold"),
                  width=10, command=root.destroy).pack(side="left", padx=6)

        tk.Label(btn_frame,
                 text=f"Config: {CONFIG_FILE}",
                 fg="#888", font=("Segoe UI", 13)).pack(side="right", padx=16)

        tk.Label(btn_frame,
                 text="Copyright (c) Gregory Howard 2026  All rights reserved",
                 fg="#888", font=("Segoe UI", 11, "italic")).pack(side="right", padx=(0, 8))

    def _build_section(self, frame, accent, params):
        """Build a scrollable grid of parameter rows inside a tab frame."""

        # -- Scrollable canvas wrapper -------------------------------------
        canvas = tk.Canvas(frame, highlightthickness=0)
        scrollbar = ttk.Scrollbar(frame, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas, padding=4)

        inner.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas_window = canvas.create_window((0, 0), window=inner, anchor="nw")

        # Make inner frame fill canvas width on resize
        def _on_canvas_resize(event):
            canvas.itemconfig(canvas_window, width=event.width)
        canvas.bind("<Configure>", _on_canvas_resize)

        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Mouse-wheel scrolling (Windows)
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>", _on_mousewheel))
        canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))

        # -- Column headers ------------------------------------------------
        tk.Label(inner, text="Parameter",   font=("Segoe UI", 13, "bold"), fg="#555").grid(
            row=0, column=0, sticky="w", padx=(0, 12), pady=(0, 6))
        tk.Label(inner, text="Value",       font=("Segoe UI", 13, "bold"), fg="#555").grid(
            row=0, column=1, sticky="w", pady=(0, 6))
        tk.Label(inner, text="Unit",        font=("Segoe UI", 13, "bold"), fg="#555").grid(
            row=0, column=2, sticky="w", padx=(6, 16), pady=(0, 6))
        tk.Label(inner, text="Description", font=("Segoe UI", 13, "bold"), fg="#555").grid(
            row=0, column=3, sticky="w", pady=(0, 6))

        ttk.Separator(inner, orient="horizontal").grid(
            row=1, column=0, columnspan=4, sticky="ew", pady=(0, 6))

        for i, (key, label, ptype, default, unit, desc) in enumerate(params):
            row = i + 2

            self.defaults[key] = default

            # Resolve current value
            raw = self.file_values.get(key)
            if ptype == "time":
                cur = parse_time_value(raw) if raw else (
                    default if isinstance(default, str) else
                    f"{default.hour:02d}:{default.minute:02d}")
            elif ptype == "int":
                try:
                    cur = int(raw) if raw else default
                except Exception:
                    cur = default
            elif ptype == "bool":
                if raw is not None:
                    cur = raw.strip().lower() == "true"
                else:
                    cur = bool(default)
            elif ptype == "choice":
                if raw is not None:
                    cur = raw.strip().strip("'\"").upper()
                else:
                    cur = str(default).upper()
            elif ptype == "str":
                if raw is not None:
                    cur = raw.strip().strip("'\"")
                else:
                    cur = str(default)
            else:  # float
                try:
                    cur = float(raw) if raw else default
                except Exception:
                    cur = default

            # Label
            tk.Label(inner, text=label,
                     font=("Segoe UI", 14), anchor="e", width=22).grid(
                row=row, column=0, sticky="ne", padx=(0, 10), pady=2)

            # Input widget
            if ptype == "time":
                var = tk.StringVar(value=str(cur))
                widget = ttk.Entry(inner, textvariable=var, width=8,
                                   font=("Segoe UI", 14))
            elif ptype == "int":
                var = tk.IntVar(value=int(cur))
                widget = ttk.Spinbox(inner, from_=0, to=9999,
                                     textvariable=var, width=8,
                                     font=("Segoe UI", 14))
            elif ptype == "bool":
                var = tk.BooleanVar(value=bool(cur))
                widget = tk.Checkbutton(inner, variable=var,
                                        font=("Segoe UI", 14))
            elif ptype == "choice":
                choices = {"UNDERLYING": ["SPX", "XSP"]}.get(key, ["SPX"])
                var = tk.StringVar(value=str(cur).upper())
                widget = tk.OptionMenu(inner, var, *choices)
                widget.config(font=("Segoe UI", 14), width=8)
            elif ptype == "str":
                var = tk.StringVar(value=str(cur))
                widget = ttk.Entry(inner, textvariable=var, width=36,
                                   font=("Segoe UI", 14))
            else:
                var = tk.DoubleVar(value=float(cur))
                widget = ttk.Entry(inner, textvariable=var, width=8,
                                   font=("Segoe UI", 14))

            widget.grid(row=row, column=1, sticky="nw", pady=2)
            self.vars[key] = (var, ptype)

            # Unit
            tk.Label(inner, text=unit,
                     font=("Segoe UI", 13), fg="#777", width=5, anchor="w").grid(
                row=row, column=2, sticky="nw", padx=(4, 12), pady=2)

            # Description - top-aligned with value widget
            tk.Label(inner, text=desc,
                     font=("Segoe UI", 13), fg="#555", anchor="nw",
                     wraplength=600, justify="left").grid(
                row=row, column=3, sticky="nw", pady=2)

        inner.columnconfigure(3, weight=1)
        return inner

    def _build_ib_test_button(self, frame, num_params):
        """Add Test Connection button + result label to the IB Gateway tab."""
        # Row layout: header=0, separator=1, params=2..num_params+1, spacer, result, button
        spacer_row = num_params + 2
        result_row = spacer_row + 1
        btn_row    = result_row + 1

        tk.Label(frame, text='').grid(row=spacer_row, column=0)  # spacing

        self._ib_test_result = tk.StringVar(value='')
        self._ib_test_lbl = tk.Label(frame, textvariable=self._ib_test_result,
                                      font=('Segoe UI', 13), anchor='w')
        self._ib_test_lbl.grid(row=result_row, column=1, columnspan=3,
                                sticky='w', pady=2)

        tk.Button(frame, text='Test Connection',
                  bg='#00695C', fg='white',
                  font=('Segoe UI', 13, 'bold'),
                  command=self._on_test_ib_connection,
                  padx=12, pady=4).grid(row=btn_row, column=1,
                                        sticky='w', pady=4)

    def _on_test_ib_connection(self):
        """Try port 7497 (paper) then 7496 (live). Report which one answered."""
        host_var, _ = self.vars.get('IB_HOST', (tk.StringVar(value='127.0.0.1'), 'str'))
        host = host_var.get().strip() or '127.0.0.1'

        self._ib_test_result.set('Testing...')
        self._ib_test_lbl.config(fg='#555555')
        self.root.update()

        try:
            from ib_insync import IB
        except ImportError:
            self._ib_test_result.set('ib_insync not installed')
            self._ib_test_lbl.config(fg='#C62828')
            return

        for port, label in ((7497, 'paper'), (7496, 'live')):
            try:
                ib = IB()
                ib.connect(host, port, clientId=99, timeout=5)
                accounts = ib.managedAccounts()
                ib.disconnect()
                acct = ', '.join(accounts) if accounts else ''
                self._ib_test_result.set(
                    f'Connected: {host}:{port} ({label})'
                    + (f'  account: {acct}' if acct else '')
                )
                self._ib_test_lbl.config(fg='#2E7D32')
                return
            except Exception:
                pass

        self._ib_test_result.set(f'No response on {host} ports 7497 or 7496')
        self._ib_test_lbl.config(fg='#C62828')

    def _center(self):
        self.root.update_idletasks()
        w = self.root.winfo_width()
        h = self.root.winfo_height()
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        self.root.geometry(f"+{(sw - w) // 2}+{(sh - h) // 2}")

    # -- Actions --------------------------------------------------------------

    def _collect(self):
        """Read all widget values; return (values_dict, errors_list)."""
        values = {}
        errors = []
        for key, (var, ptype) in self.vars.items():
            try:
                if ptype == "int":
                    values[key] = str(int(var.get()))
                elif ptype == "float":
                    v = float(var.get())
                    # POSITION_SIZE: floor to int if >= 1
                    if key == "POSITION_SIZE" and v >= 1.0:
                        import math
                        v = float(int(math.floor(v)))
                    values[key] = str(v)
                elif ptype == "bool":
                    values[key] = "True" if var.get() else "False"
                elif ptype == "choice":
                    values[key] = var.get().strip().upper()
                elif ptype == "str":
                    values[key] = var.get().strip()
                elif ptype == "time":
                    val = var.get().strip()
                    if not re.match(r"^\d{1,2}:\d{2}$", val):
                        errors.append(f"{key}: invalid time '{val}' - use HH:MM")
                    else:
                        h, m = val.split(":")
                        values[key] = f"{int(h):02d}:{int(m):02d}"
            except Exception:
                errors.append(f"{key}: invalid value")
        return values, errors

    def _on_save(self):
        values, errors = self._collect()
        if errors:
            messagebox.showerror("Validation Error", "\n".join(errors), parent=self.root)
            return
        try:
            write_config(values)
            _update_config_hash()
            messagebox.showinfo("Saved",
                f"Configuration saved to:\n{CONFIG_FILE}\n\nDouble-click Start Trading or Restart Trading to apply changes.",
                parent=self.root)
        except Exception as e:
            messagebox.showerror("Save Failed", str(e), parent=self.root)

    def _on_reset(self):
        if not messagebox.askyesno("Reset to Defaults",
                "Reset all parameters to their default values?", parent=self.root):
            return
        for key, (var, ptype) in self.vars.items():
            d = self.defaults[key]
            if ptype == "time":
                if isinstance(d, str):
                    var.set(d)
                else:
                    var.set(f"{d.hour:02d}:{d.minute:02d}")
            elif ptype == "int":
                var.set(int(d))
            elif ptype == "bool":
                var.set(bool(d))
            elif ptype == "str":
                var.set(str(d))
            else:
                var.set(float(d))


# -- Entry point -------------------------------------------------------------

def main():
    # Verify CTV directory exists
    if not os.path.isdir(CTV_DIR):
        import tkinter as tk2
        r = tk2.Tk(); r.withdraw()
        messagebox.showerror("Directory Not Found",
            f"CTV directory not found:\n{CTV_DIR}\n\nPlease ensure VTB is installed correctly.")
        sys.exit(1)

    root = tk.Tk()
    CTV2ConfigEditor(root)
    root.mainloop()


if __name__ == "__main__":
    main()
