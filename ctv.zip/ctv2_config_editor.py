#!/usr/bin/env python3
"""
ctv2_config_editor.py - CTV2 Configuration Editor

Revision: 3.8
Rev 3.8: MAX_PREMIUM default changed from 350.0 to 200.0.
Rev 3.5: Replaced Unicode arrow U+2192 with ASCII '->' in write_config() comment.
         Arrow caused exponential file bloat (~2x per build) via cp1252/UTF-8
         re-encoding in build_zip.ps1. config_ctv2.py now contains only ASCII.
Rev 3.4: Renamed "Live Bearer Token" label to "API Token" in Tradier tab.

CHANGELOG
---------
Rev 3.4: Removed PREFETCH_RADIUS from Pricing tab and write_config().
         Contract IDs are not needed with Tradier - OCC symbols are built
         deterministically. PREFETCH_RADIUS had no effect.
Rev 3.3: LIVE_TRADING checkbox shows a confirmation dialog when toggled on.
         If the user declines, the checkbox is reverted to False.
Rev 3.2: Sandbox mode removed from Tradier tab.
         Removed TRADIER_SANDBOX, TRADIER_SANDBOX_ACCOUNT, TRADIER_SANDBOX_TOKEN
         fields from the tab definition and write_config(). Paper trading is now
         triggered by LIVE_TRADING=False alone. write_config() comments updated.
Rev 3.1: Replaced Polygon tab with LIVE_TRADING field on Tradier tab.
         LIVE_TRADING=False: preview orders (paper). True: real orders.
         Removed STREAM_SOURCE and POLYGON_API_KEY.
Rev 2.9: Added Tradier fields to write_config() - credentials were silently
         dropped on Save because write_config is hardcoded. Tab was present
         (Rev 2.8) but values never written to disk.
Rev 2.8: Added Tradier credentials tab (TRADIER_SANDBOX, TRADIER_ACCOUNT_ID,
         TRADIER_SANDBOX_ACCOUNT, TRADIER_SANDBOX_TOKEN, TRADIER_PRODUCTION_TOKEN).
Rev 2.7: PREFETCH_RADIUS default changed from 200 to 300.
Rev 2.6: PREFETCH_RADIUS default changed from 75 to 200.
Rev 2.5: Added PUSHOVER_EOD_DIGEST checkbox to Pushover tab.
         Added corresponding write_config() line.
Rev 2.4: Added VIX_MAX_ENTRY to Entry tab.
Rev 2.3: Removed note box from Park & Risk tab (moved to user guide).
Rev 2.2: Renamed "Direction Threshold" label to "EMA Direction Threshold".
         Park & Risk tab: added yellow explanatory note box above ACTIVE_ADVERSE_MOVE.
         _build_section now handles "note" pseudo-type (spanning label, not a var).
Rev 2.1: Renamed MAX_SPREAD_WIDTH to MAX_BID_ASK_WIDTH everywhere.
Rev 2.0: Added GAP_ENTRY_SLIPPAGE to Entry tab and write_config().
Rev 1.9: Added POSITION_SIZE to Entry tab. Floor-on-save: int values >= 1
         silently floored to nearest integer. write_config() updated.
Rev 1.8: Fixed write_config() time formatting - leading zeros in hour values
         (e.g. 09:45 -> time(09, 45)) caused SyntaxError in generated config.
         Now strips leading zeros: time(9, 45).
Rev 1.7: Park & Risk tab: replaced PARK_MAX_MOVE with 6 new params
         (PARK_CONVERT_EMA_LOW/MID/HIGH, PARK_VIX_LOW/HIGH, ACTIVE_ADVERSE_MOVE).
         Exit tab: removed REVERSAL_CLOSE_MIN_MOVE row.
         write_config() updated to match.
Rev 1.4: Removed stray "ET" unit label from PUSHOVER_SUMMARY_TIME row.
Rev 1.3: Replaced ttk.Checkbutton with tk.Checkbutton - ttk indicator
         disappears at larger font sizes on Windows. tk.Checkbutton
         renders reliably at any font size.
Rev 1.2: Opens maximized (zoomed) on Windows. Increased all font sizes
         to 14pt (body) and 13pt (secondary labels).
Rev 1.1: Added 4 missing Pushover notification toggles to Pushover tab:
         PUSHOVER_NOTIFY_ALL_TRADES, PUSHOVER_NOTIFY_RISK_SUSPEND,
         PUSHOVER_NOTIFY_LOST_CONNECTION, PUSHOVER_NOTIFY_SYSTEM_CRASH.
         Also added corresponding lines to write_config().
Rev 1.0: Initial revision tracking.

GUI for editing CTV2 trading parameters.
Always operates on C:\\CTV\\config_ctv2.py.

To create EXE:
    pip install pyinstaller
    pyinstaller --onefile --windowed ctv2_config_editor.py
"""

import os
import sys
import re
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import time

# -- Lock to CTV directory ---------------------------------------------------
CTV_DIR    = r"C:\CTV"
CONFIG_FILE = os.path.join(CTV_DIR, "config_ctv2.py")

os.chdir(CTV_DIR)

# -- Parameter definitions ---------------------------------------------------
# (section_label, accent_hex, [ (key, label, type, default, unit, description) ])

SECTIONS = [
    ("Signal", "#B8860B", [
        ("MACD_FAST",               "EMA Fast",            "int",   3,      "bars", "Fast EMA period (EMA3). Controls entry sensitivity."),
        ("MACD_SLOW",               "EMA Slow",            "int",   15,     "bars", "Slow EMA period (EMA15). Sets the trend baseline."),
        ("MACD_SIGNAL",             "MACD Signal",         "int",   9,      "bars", "Signal line period. Informational - not used for entry gating."),
        ("EMA_DIRECTION_THRESHOLD", "EMA Direction Threshold", "float", 1.5,    "pts",  "Minimum |EMA3?EMA15| separation to confirm a viable direction. Below this = noise, no entry."),
    ]),
    ("Entry", "#1874CD", [
        ("POSITION_SIZE",         "Position Size",     "float", 1.0,   "",     "Contract count per trade. >= 1: floored to int (e.g. 2.5 -> 2). < 1: fraction of available funds (e.g. 0.10 = 10% of account)."),
        ("SPREAD_WIDTH",          "Spread Width",      "float", 5.0,   "pts",  "Width of the debit vertical spread in strike points."),
        ("MAX_PREMIUM",           "Max Premium",       "float", 200.0, "$",    "Skip entry if spread ask?1.05?100 exceeds this dollar amount."),
        ("MAX_BID_ASK_WIDTH",     "Max Bid/Ask Width", "float", 1.0,   "$/sh", "Skip entry if bid/ask spread on the quote is wider than this per share."),
        ("MAX_ACTIVE_TRADES",     "Max Active Trades", "int",   4,     "",     "Maximum simultaneous LiveTrade positions (active + parked). Butterflies excluded."),
        ("VIX_MAX_ENTRY",         "VIX Max Entry",     "float", 35.0,  "",     "Block new entries when VIX9D exceeds this level. Butterfly conversion is unaffected. Set to 0 to disable."),
        ("ENTRY_TIMEOUT",         "Entry Timeout",     "int",   15,    "min",  "Drop a pending entry if it has not filled within this many minutes of the signal. Prevents stale entries from firing long after conditions changed."),
        ("GAP_OPEN_THRESHOLD",    "Gap Threshold",     "float", 20.0,  "pts",  "If SPX opens more than this many points from prior close, enter immediately in the gap direction."),
        ("GAP_TRADE_EXPIRY_TIME", "Gap Trade Expiry",  "time",  "09:45","",    "Cancel any unfilled gap-open entry attempt at this time."),
        ("GAP_ENTRY_SLIPPAGE",    "Gap Entry Slippage","float", 1.10,  "x",    "Limit price multiplier for gap-open entries. 1.10 = up to 10% above ask to ensure fill at 9:30."),
    ]),
    ("Exit", "#228B22", [
        ("WIN_TARGET_BUFFER",   "Win Target Buffer","float", 1.0,  "pts", "SPX must reach short_strike +/- this many points to trigger the conversion sell. Keeps the conversion spread just outside the money for maximum time value."),
        ("MIN_CONV_CREDIT_PCT", "Min Conv Credit", "float", 1.05, "x",   "Win sell floor = premium_paid x this. 1.05 = must net at least 5% profit."),
        ("SELL_SLIPPAGE",       "Sell Slippage",   "float", 0.95, "x",   "All exit limits = bid x this. 0.95 accepts up to 5% below current bid."),
    ]),
    ("Park & Risk", "#CD4F00", [
        ("PARK_CONVERT_EMA_LOW",  "Park EMA (Low VIX)",  "float", 4.0,  "pts", "EMA3/EMA15 separation needed to butterfly-convert a PARKED trade when VIX < PARK_VIX_LOW."),
        ("PARK_CONVERT_EMA_MID",  "Park EMA (Mid VIX)",  "float", 5.0,  "pts", "EMA3/EMA15 separation needed to butterfly-convert a PARKED trade when VIX is between low and high."),
        ("PARK_CONVERT_EMA_HIGH", "Park EMA (High VIX)", "float", 6.0,  "pts", "EMA3/EMA15 separation needed to butterfly-convert a PARKED trade when VIX > PARK_VIX_HIGH."),
        ("PARK_VIX_LOW",          "VIX Low Breakpoint",  "float", 18.0, "",    "VIX level below which the low EMA threshold applies."),
        ("PARK_VIX_HIGH",         "VIX High Breakpoint", "float", 25.0, "",    "VIX level above which the high EMA threshold applies."),
        ("ACTIVE_ADVERSE_MOVE",   "Noise Adverse Move",  "float", 10.0, "pts", "While inside the noise band, butterfly-convert an ACTIVE trade if SPX moves this many pts adverse from the noise band entry price."),
    ]),
    ("Timing", "#7B2FBE", [
        ("TRADING_START",       "Trading Start",  "time", "10:00", "ET", "No entries before this time."),
        ("LAST_ENTRY_TIME",     "Last Entry",     "time", "14:00", "ET", "No new entries (including chain entries) after this time."),
        ("PM_BOUNDARY",         "PM Boundary",    "time", "13:00", "ET", "After this time, newly PARKED trades receive a stop order at 50% of premium paid."),
        ("INTRINSIC_EXIT_TIME", "Intrinsic Exit", "time", "14:30", "ET", "All open LiveTrades are converted to butterflies at this time."),
    ]),
    ("Pricing", "#C2185B", [
        ("ENTRY_SLIPPAGE",  "Entry Slippage",  "float", 1.05, "?",   "Entry limit = ask ? this. 1.05 guarantees fill at cost of 5% above ask."),
    ]),
    ("Tradier", "#00695C", [
        ("LIVE_TRADING",      "Live Trading",   "bool", False, "", "False = paper trading (live data, preview orders - nothing fills). True = real orders, real money."),
        ("TRADIER_ACCOUNT_ID",       "Account ID",        "str",  "",   "",  "Your Tradier account ID / username. Found in the Tradier dashboard under your profile."),
        ("TRADIER_PRODUCTION_TOKEN", "API Token", "str",  "",   "",  "Live account API bearer token. Found at dash.tradier.com under API Access."),
    ]),
    ("Pushover", "#1565C0", [
        ("PUSHOVER_ENABLED",                "Enabled",             "bool",  False,   "",   "Enable Pushover push notifications. Requires a valid user key and API token from pushover.net."),
        ("PUSHOVER_USER_KEY",               "User Key",            "str",   "",      "",   "Your Pushover user key (found on the main page at pushover.net after login)."),
        ("PUSHOVER_API_TOKEN",              "API Token",           "str",   "",      "",   "Your Pushover application API token (create an application at pushover.net to obtain one)."),
        ("PUSHOVER_CRITICAL_PRIORITY",      "Critical Priority",   "int",   1,       "",   "Priority for watchdog critical alerts. 1 = high priority (bypasses quiet hours). 2 = emergency (requires acknowledgment)."),
        ("PUSHOVER_SUMMARY_TIME",           "Summary Time",        "time",  "16:30", "",   "Time to send the daily error summary notification."),
        ("PUSHOVER_NOTIFY_ALL_TRADES",      "Notify: All Trades",  "bool",  True,    "",   "Send a notification on every trade entry, WIN, butterfly conversion, and park event."),
        ("PUSHOVER_NOTIFY_RISK_SUSPEND",    "Notify: Risk Suspend","bool",  True,    "",   "Send a notification when trading is suspended by the risk manager (consecutive or daily loss limit)."),
        ("PUSHOVER_NOTIFY_LOST_CONNECTION", "Notify: Lost Feed",   "bool",  True,    "",   "Send a notification when the live bar watchdog detects a stale feed and attempts resubscription."),
        ("PUSHOVER_NOTIFY_SYSTEM_CRASH",    "Notify: System Crash","bool",  True,    "",   "Send a notification if an unhandled exception crashes the runner."),
        ("PUSHOVER_EOD_DIGEST",              "EOD Digest",          "bool",  True,    "",   "Send an end-of-day summary to your phone: total trades, wins, losses, net P&L, and VIX9D range."),
    ]),
]

# -- Config file I/O ---------------------------------------------------------

def read_config():
    """Parse config_ctv2.py and return dict of {KEY: value_string}."""
    values = {}
    if not os.path.exists(CONFIG_FILE):
        return values
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        text = f.read()

    # Match:  KEY = <value>   (ignoring comments and blank lines)
    pattern = re.compile(r"^([A-Z_]+)\s*=\s*(.+)$", re.MULTILINE)
    for match in pattern.finditer(text):
        key = match.group(1)
        raw = match.group(2).strip()
        # Strip inline comments
        raw = re.sub(r"\s*#.*$", "", raw).strip()
        values[key] = raw
    return values


def parse_time_value(raw):
    """Convert time(H, M) or 'HH:MM' to HH:MM string."""
    m = re.match(r"time\((\d+),\s*(\d+)\)", raw)
    if m:
        return f"{int(m.group(1)):02d}:{int(m.group(2)):02d}"
    # Already a plain string like "09:45"
    raw = raw.strip("'\"")
    if re.match(r"\d{1,2}:\d{2}", raw):
        h, mi = raw.split(":")
        return f"{int(h):02d}:{int(mi):02d}"
    return raw


def write_config(values):
    """Write values dict back to config_ctv2.py."""
    from datetime import date
    today = date.today().isoformat()

    lines = [
        '"""',
        f'config_ctv2.py - CTV2 Live Runner Configuration',
        f'Generated {today} by CTV2 Config Editor',
        '"""',
        '',
        'VERSION = "CFG-2.0"',
        'from datetime import time',
        '',
        '# -- EMA / Direction Signal -------------------------------------',
        f'MACD_FAST               = {values["MACD_FAST"]}',
        f'MACD_SLOW               = {values["MACD_SLOW"]}',
        f'MACD_SIGNAL             = {values["MACD_SIGNAL"]}',
        f'EMA_DIRECTION_THRESHOLD = {values["EMA_DIRECTION_THRESHOLD"]}',
        '',
        '# -- Entry ------------------------------------------------------',
        f'POSITION_SIZE     = {values["POSITION_SIZE"]}',
        f'SPREAD_WIDTH      = {values["SPREAD_WIDTH"]}',
        f'MAX_PREMIUM       = {values["MAX_PREMIUM"]}',
        f'MAX_BID_ASK_WIDTH  = {values["MAX_BID_ASK_WIDTH"]}',
        f'MAX_ACTIVE_TRADES = {values["MAX_ACTIVE_TRADES"]}',
        f'VIX_MAX_ENTRY     = {values["VIX_MAX_ENTRY"]}',
        f'ENTRY_TIMEOUT     = {values["ENTRY_TIMEOUT"]}',
        f'GAP_OPEN_THRESHOLD    = {values["GAP_OPEN_THRESHOLD"]}',
        f'GAP_TRADE_EXPIRY_TIME = time({", ".join(str(int(x)) for x in values["GAP_TRADE_EXPIRY_TIME"].split(":"))})',
        f'GAP_ENTRY_SLIPPAGE    = {values["GAP_ENTRY_SLIPPAGE"]}',
        '',
        '# -- Exit -------------------------------------------------------',
        f'WIN_TARGET_BUFFER   = {values["WIN_TARGET_BUFFER"]}',
        f'MIN_CONV_CREDIT_PCT = {values["MIN_CONV_CREDIT_PCT"]}',
        f'SELL_SLIPPAGE       = {values["SELL_SLIPPAGE"]}',
        '',
        '# -- Park & Risk ------------------------------------------------',
        f'PARK_CONVERT_EMA_LOW  = {values["PARK_CONVERT_EMA_LOW"]}',
        f'PARK_CONVERT_EMA_MID  = {values["PARK_CONVERT_EMA_MID"]}',
        f'PARK_CONVERT_EMA_HIGH = {values["PARK_CONVERT_EMA_HIGH"]}',
        f'PARK_VIX_LOW          = {values["PARK_VIX_LOW"]}',
        f'PARK_VIX_HIGH         = {values["PARK_VIX_HIGH"]}',
        f'ACTIVE_ADVERSE_MOVE   = {values["ACTIVE_ADVERSE_MOVE"]}',
        '',
        '# -- Trading Window ---------------------------------------------',
        f'TRADING_START       = time({", ".join(str(int(x)) for x in values["TRADING_START"].split(":"))})',
        f'TRADING_END         = time(16, 0)',
        f'LAST_ENTRY_TIME     = time({", ".join(str(int(x)) for x in values["LAST_ENTRY_TIME"].split(":"))})',
        f'PM_BOUNDARY         = time({", ".join(str(int(x)) for x in values["PM_BOUNDARY"].split(":"))})',
        f'INTRINSIC_EXIT_TIME = time({", ".join(str(int(x)) for x in values["INTRINSIC_EXIT_TIME"].split(":"))})',
        '',
        '# -- Order Pricing ----------------------------------------------',
        f'ENTRY_SLIPPAGE  = {values["ENTRY_SLIPPAGE"]}',
        '',
        '# -- Data (backtester only) -------------------------------------',
        'SPX_DATA_DIR = "SPX_3min_bars"',
        '',
        '# -- Trading Mode -----------------------------------------------',
        '# LIVE_TRADING=False = paper trading (live data, preview orders - nothing fills)',
        '# LIVE_TRADING=True  = real orders, real money',
        '#',
        f'LIVE_TRADING = {values["LIVE_TRADING"]}',
        '',
        '# -- Tradier API Credentials ------------------------------------',
        '# Both fields are required. The runner will not start until',
        '# every field is populated. Open Config Editor -> Tradier Credentials tab.',
        '#',
        f'TRADIER_ACCOUNT_ID       = \'{values["TRADIER_ACCOUNT_ID"]}\'',
        f'TRADIER_PRODUCTION_TOKEN = \'{values["TRADIER_PRODUCTION_TOKEN"]}\'',
        '',
        '# -- Pushover Alerts --------------------------------------------',
        f'PUSHOVER_ENABLED           = {values["PUSHOVER_ENABLED"]}',
        f'PUSHOVER_USER_KEY          = \'{values["PUSHOVER_USER_KEY"]}\'',
        f'PUSHOVER_API_TOKEN         = \'{values["PUSHOVER_API_TOKEN"]}\'',
        f'PUSHOVER_CRITICAL_PRIORITY = {values["PUSHOVER_CRITICAL_PRIORITY"]}',
        f'PUSHOVER_SUMMARY_TIME      = \'{values["PUSHOVER_SUMMARY_TIME"]}\'',
        '',
        f'PUSHOVER_NOTIFY_ALL_TRADES      = {values["PUSHOVER_NOTIFY_ALL_TRADES"]}',
        f'PUSHOVER_NOTIFY_RISK_SUSPEND    = {values["PUSHOVER_NOTIFY_RISK_SUSPEND"]}',
        f'PUSHOVER_NOTIFY_LOST_CONNECTION = {values["PUSHOVER_NOTIFY_LOST_CONNECTION"]}',
        f'PUSHOVER_NOTIFY_SYSTEM_CRASH    = {values["PUSHOVER_NOTIFY_SYSTEM_CRASH"]}',
        f'PUSHOVER_EOD_DIGEST             = {values["PUSHOVER_EOD_DIGEST"]}',
    ]
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def _update_config_hash():
    """Recompute SHA-256 of config_ctv2.py and write it into install_manifest.json."""
    import hashlib, json
    manifest_path = os.path.join(CTV_DIR, "install_manifest.json")
    if not os.path.exists(manifest_path):
        return
    try:
        h = hashlib.sha256()
        with open(CONFIG_FILE, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        new_hash = h.hexdigest().upper()

        with open(manifest_path, "r", encoding="utf-8") as f:
            manifest = json.load(f)

        if "config" not in manifest:
            manifest["config"] = {}
        manifest["config"]["path"]   = CONFIG_FILE
        manifest["config"]["sha256"] = new_hash

        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=4)
    except Exception:
        pass   # silent - hash update is best-effort, never blocks a save


# -- Main application --------------------------------------------------------

class CTV2ConfigEditor:

    def __init__(self, root):
        self.root = root
        self.root.title("CTV2 Config Editor")
        self.root.resizable(True, True)
        self.root.state('zoomed')   # open maximized on Windows

        # Load current values from file (fall back to defaults)
        self.file_values = read_config()
        self.vars = {}        # key -> tk variable
        self.defaults = {}    # key -> default value

        self._build_ui()
        self._center()

    # -- UI construction -----------------------------------------------------

    def _build_ui(self):
        root = self.root

        # -- Top warning bar ----------------------------------------------
        warn = tk.Frame(root, bg="#FFF3CD", pady=4)
        warn.pack(fill="x")
        tk.Label(warn, text='Double click on "Start Trading" or "Restart Trading" after saving changes.',
                 bg="#FFF3CD", fg="#856404",
                 font=("Segoe UI", 14, "bold")).pack()

        # -- Notebook (tabs per section) ----------------------------------
        nb = ttk.Notebook(root)
        nb.pack(fill="both", expand=True, padx=10, pady=(8, 4))

        style = ttk.Style()
        style.configure("TNotebook.Tab", font=("Segoe UI", 14, "bold"), padding=[10, 4])

        for section_label, accent, params in SECTIONS:
            frame = ttk.Frame(nb, padding=12)
            nb.add(frame, text=section_label)
            self._build_section(frame, accent, params)

        # -- Bottom button bar --------------------------------------------
        btn_frame = tk.Frame(root, pady=8)
        btn_frame.pack(fill="x")

        tk.Button(btn_frame, text="Save",
                  bg="#4CAF50", fg="white",
                  font=("Segoe UI", 14, "bold"),
                  width=14, command=self._on_save).pack(side="left", padx=(20, 6))

        tk.Button(btn_frame, text="Reset to Defaults",
                  bg="#FF9800", fg="white",
                  font=("Segoe UI", 14, "bold"),
                  width=16, command=self._on_reset).pack(side="left", padx=6)

        tk.Button(btn_frame, text="Cancel",
                  bg="#9E9E9E", fg="white",
                  font=("Segoe UI", 14, "bold"),
                  width=10, command=root.destroy).pack(side="left", padx=6)

        tk.Label(btn_frame,
                 text=f"Config: {CONFIG_FILE}",
                 fg="#888", font=("Segoe UI", 13)).pack(side="right", padx=16)

    def _build_section(self, frame, accent, params):
        """Build a grid of parameter rows inside a tab frame."""

        # Column headers
        tk.Label(frame, text="Parameter",   font=("Segoe UI", 13, "bold"), fg="#555").grid(
            row=0, column=0, sticky="w", padx=(0, 12), pady=(0, 6))
        tk.Label(frame, text="Value",       font=("Segoe UI", 13, "bold"), fg="#555").grid(
            row=0, column=1, sticky="w", pady=(0, 6))
        tk.Label(frame, text="Unit",        font=("Segoe UI", 13, "bold"), fg="#555").grid(
            row=0, column=2, sticky="w", padx=(6, 16), pady=(0, 6))
        tk.Label(frame, text="Description", font=("Segoe UI", 13, "bold"), fg="#555").grid(
            row=0, column=3, sticky="w", pady=(0, 6))

        ttk.Separator(frame, orient="horizontal").grid(
            row=1, column=0, columnspan=4, sticky="ew", pady=(0, 6))

        for i, (key, label, ptype, default, unit, desc) in enumerate(params):
            row = i + 2

            self.defaults[key] = default

            # Resolve current value
            raw = self.file_values.get(key)
            if ptype == "time":
                cur = parse_time_value(raw) if raw else (
                    default if isinstance(default, str) else
                    f"{default.hour:02d}:{default.minute:02d}")
            elif ptype == "int":
                try:
                    cur = int(raw) if raw else default
                except Exception:
                    cur = default
            elif ptype == "bool":
                if raw is not None:
                    cur = raw.strip().lower() == "true"
                else:
                    cur = bool(default)
            elif ptype == "str":
                if raw is not None:
                    cur = raw.strip().strip("'\"")
                else:
                    cur = str(default)
            else:  # float
                try:
                    cur = float(raw) if raw else default
                except Exception:
                    cur = default

            # Label
            tk.Label(frame, text=label,
                     font=("Segoe UI", 14), anchor="e", width=22).grid(
                row=row, column=0, sticky="e", padx=(0, 10), pady=2)

            # Input widget
            if ptype == "time":
                var = tk.StringVar(value=str(cur))
                widget = ttk.Entry(frame, textvariable=var, width=8,
                                   font=("Segoe UI", 14))
            elif ptype == "int":
                var = tk.IntVar(value=int(cur))
                widget = ttk.Spinbox(frame, from_=0, to=9999,
                                     textvariable=var, width=8,
                                     font=("Segoe UI", 14))
            elif ptype == "bool":
                var = tk.BooleanVar(value=bool(cur))
                if key == "LIVE_TRADING":
                    def _make_live_trading_command(v=var):
                        def _on_toggle():
                            if not v.get():
                                return   # unchecking - no confirmation needed
                            confirmed = messagebox.askyesno(
                                "Enable Live Trading?",
                                "LIVE_TRADING = True will submit real orders to your "
                                "Tradier account.\n\nReal money is at risk.\n\n"
                                "Are you sure you want to enable live trading?",
                                icon="warning",
                                parent=self.root,
                            )
                            if not confirmed:
                                v.set(False)   # revert checkbox
                        return _on_toggle
                    widget = tk.Checkbutton(frame, variable=var,
                                            command=_make_live_trading_command(),
                                            font=("Segoe UI", 14))
                else:
                    widget = tk.Checkbutton(frame, variable=var,
                                            font=("Segoe UI", 14))
            elif ptype == "str":
                var = tk.StringVar(value=str(cur))
                widget = ttk.Entry(frame, textvariable=var, width=36,
                                   font=("Segoe UI", 14))
            else:
                var = tk.DoubleVar(value=float(cur))
                widget = ttk.Entry(frame, textvariable=var, width=8,
                                   font=("Segoe UI", 14))

            widget.grid(row=row, column=1, sticky="w", pady=2)
            self.vars[key] = (var, ptype)

            # Unit
            tk.Label(frame, text=unit,
                     font=("Segoe UI", 13), fg="#777", width=5, anchor="w").grid(
                row=row, column=2, sticky="w", padx=(4, 12))

            # Description
            tk.Label(frame, text=desc,
                     font=("Segoe UI", 13), fg="#555", anchor="w",
                     wraplength=480, justify="left").grid(
                row=row, column=3, sticky="w")

        frame.columnconfigure(3, weight=1)

    def _center(self):
        self.root.update_idletasks()
        w = self.root.winfo_width()
        h = self.root.winfo_height()
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        self.root.geometry(f"+{(sw - w) // 2}+{(sh - h) // 2}")

    # -- Actions --------------------------------------------------------------

    def _collect(self):
        """Read all widget values; return (values_dict, errors_list)."""
        values = {}
        errors = []
        for key, (var, ptype) in self.vars.items():
            try:
                if ptype == "int":
                    values[key] = str(int(var.get()))
                elif ptype == "float":
                    v = float(var.get())
                    # POSITION_SIZE: floor to int if >= 1
                    if key == "POSITION_SIZE" and v >= 1.0:
                        import math
                        v = float(int(math.floor(v)))
                    values[key] = str(v)
                elif ptype == "bool":
                    values[key] = "True" if var.get() else "False"
                elif ptype == "str":
                    values[key] = var.get().strip()
                elif ptype == "time":
                    val = var.get().strip()
                    if not re.match(r"^\d{1,2}:\d{2}$", val):
                        errors.append(f"{key}: invalid time '{val}' - use HH:MM")
                    else:
                        h, m = val.split(":")
                        values[key] = f"{int(h):02d}:{int(m):02d}"
            except Exception:
                errors.append(f"{key}: invalid value")
        return values, errors

    def _on_save(self):
        values, errors = self._collect()
        if errors:
            messagebox.showerror("Validation Error", "\n".join(errors), parent=self.root)
            return
        try:
            write_config(values)
            _update_config_hash()
            messagebox.showinfo("Saved",
                f"Configuration saved to:\n{CONFIG_FILE}\n\nDouble-click Start Trading or Restart Trading to apply changes.",
                parent=self.root)
        except Exception as e:
            messagebox.showerror("Save Failed", str(e), parent=self.root)

    def _on_reset(self):
        if not messagebox.askyesno("Reset to Defaults",
                "Reset all parameters to their default values?", parent=self.root):
            return
        for key, (var, ptype) in self.vars.items():
            d = self.defaults[key]
            if ptype == "time":
                if isinstance(d, str):
                    var.set(d)
                else:
                    var.set(f"{d.hour:02d}:{d.minute:02d}")
            elif ptype == "int":
                var.set(int(d))
            elif ptype == "bool":
                var.set(bool(d))
            elif ptype == "str":
                var.set(str(d))
            else:
                var.set(float(d))


# -- Entry point -------------------------------------------------------------

def main():
    # Verify CTV directory exists
    if not os.path.isdir(CTV_DIR):
        import tkinter as tk2
        r = tk2.Tk(); r.withdraw()
        messagebox.showerror("Directory Not Found",
            f"CTV directory not found:\n{CTV_DIR}\n\nPlease ensure CTV2 is installed correctly.")
        sys.exit(1)

    root = tk.Tk()
    CTV2ConfigEditor(root)
    root.mainloop()


if __name__ == "__main__":
    main()
