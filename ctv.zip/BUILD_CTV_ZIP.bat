@echo off
:: ============================================================
::  BUILD_ZIP.bat -- Package CTV build files into ctv.zip
::  Revision: 1.3
::  Run from C:\CTV
::
::  v1.1 - Added credential strip/restore around zip build.
::  v1.2 - Removed *.json from zip file list.
::  v1.3 - Moved all logic to build_zip.ps1. Inline PowerShell
::          via -Command fails with ^ line continuations.
:: ============================================================

cd /d C:\CTV
powershell.exe -ExecutionPolicy Bypass -NoProfile -File "C:\CTV\build_zip.ps1"

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo ERROR: build_zip.ps1 exited with code %ERRORLEVEL%
    echo Check the messages above.
    pause
)
