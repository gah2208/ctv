@echo off
:: ============================================================
::  BUILD_ZIP.bat -- Package CTV build files into ctv.zip
::  Revision: 1.4
::  Run from C:\CTV
::
::  v1.4 - Changed pause to exit /b 1 on error so VERSION_CHECK.bat
::          can detect failure and stop the build chain.
::  v1.3 - Moved all logic to build_zip.ps1. Inline PowerShell
::          via -Command fails with ^ line continuations.
::  v1.2 - Removed *.json from zip file list.
::  v1.1 - Added credential strip/restore around zip build.
:: ============================================================

cd /d C:\CTV
powershell.exe -ExecutionPolicy Bypass -NoProfile -File "C:\CTV\build_zip.ps1"

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo ERROR: build_zip.ps1 exited with code %ERRORLEVEL%
    echo Check the messages above.
    exit /b 1
)
