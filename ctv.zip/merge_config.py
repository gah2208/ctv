"""
merge_config.py - CTV2 Configuration Merge Utility

Revision: 1.1

CHANGELOG
---------
Rev 1.1: Replaced Unicode em dash in summary print with plain ASCII dash.
Rev 1.0: Initial implementation.
         Merges user's existing config_ctv2.py with the newly installed
         default config. User values are preserved for existing keys.
         New keys are added with their default values from the new config.
         Keys removed from the new config are dropped cleanly.
         Called by Update.ps1 after extracting the new release.

USAGE
-----
    python merge_config.py --existing <path> --new <path> --output <path>

    --existing : path to user's current config (backed up before update)
    --new      : path to newly extracted default config from zip
    --output   : path to write merged result (normally C:\\CTV\\config_ctv2.py)

EXIT CODES
----------
    0 : success
    1 : error (message printed to stderr)
"""

from __future__ import annotations

import argparse
import os
import re
import sys
from datetime import date
from typing import Dict


def parse_config(path: str) -> Dict[str, str]:
    """
    Parse a config_ctv2.py file and return {KEY: raw_value_string}.
    Strips inline comments. Ignores blank lines, docstrings, imports.
    Raw value is the string as it appears after the = sign, stripped.
    """
    values = {}
    pattern = re.compile(r'^([A-Z][A-Z0-9_]*)\s*=\s*(.+)$', re.MULTILINE)
    try:
        with open(path, 'r', encoding='utf-8') as f:
            text = f.read()
    except Exception as e:
        print(f'[MERGE] ERROR reading {path}: {e}', file=sys.stderr)
        sys.exit(1)

    for match in pattern.finditer(text):
        key = match.group(1)
        raw = match.group(2).strip()
        # Strip inline comments
        raw = re.sub(r'\s*#.*$', '', raw).strip()
        values[key] = raw
    return values


def merge(existing_path: str, new_path: str, output_path: str):
    """
    Merge existing user config into new default config template.
    - For every key in new config: use user's value if present, else new default
    - Keys in user config but not in new config are dropped (with log)
    - Keys in new config but not in user config are added (with log)
    - The new config's file structure, comments, and layout are preserved
    """
    print(f'[MERGE] Existing : {existing_path}')
    print(f'[MERGE] New      : {new_path}')
    print(f'[MERGE] Output   : {output_path}')
    print()

    existing = parse_config(existing_path)
    new      = parse_config(new_path)

    kept    = []
    added   = []
    dropped = []

    # Build substitution map: key -> value to use in output
    substitutions = {}
    for key, new_val in new.items():
        if key in existing:
            substitutions[key] = existing[key]
            kept.append((key, existing[key]))
        else:
            substitutions[key] = new_val
            added.append((key, new_val))

    for key in existing:
        if key not in new:
            dropped.append((key, existing[key]))

    # Log results
    print(f'[MERGE] Keys kept    ({len(kept)}):')
    for k, v in kept:
        print(f'         KEPT    {k} = {v}')

    if added:
        print(f'[MERGE] Keys added   ({len(added)}):')
        for k, v in added:
            print(f'         ADDED   {k} = {v}')

    if dropped:
        print(f'[MERGE] Keys dropped ({len(dropped)}):')
        for k, v in dropped:
            print(f'         DROPPED {k} = {v}')

    print()

    # Read new config as template, substitute values line by line
    with open(new_path, 'r', encoding='utf-8') as f:
        template_lines = f.readlines()

    output_lines = []
    assign_pattern = re.compile(r'^([A-Z][A-Z0-9_]*)\s*=\s*')

    for line in template_lines:
        m = assign_pattern.match(line)
        if m:
            key = m.group(1)
            if key in substitutions:
                # Preserve indentation and key, substitute value
                indent  = len(line) - len(line.lstrip())
                spaces  = line[:indent]
                # Rebuild aligned assignment matching original spacing
                eq_match = re.match(r'^([A-Z][A-Z0-9_\s]*=\s*)', line)
                if eq_match:
                    prefix = eq_match.group(1)
                    output_lines.append(f'{spaces}{prefix}{substitutions[key]}\n')
                else:
                    output_lines.append(line)
            else:
                output_lines.append(line)
        else:
            output_lines.append(line)

    # Update the Generated date in the header
    today = date.today().isoformat()
    output_text = ''.join(output_lines)
    output_text = re.sub(
        r'Generated \d{4}-\d{2}-\d{2} by CTV2 Config Editor',
        f'Generated {today} by CTV2 Update (merged)',
        output_text
    )

    # Write output
    try:
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(output_text)
    except Exception as e:
        print(f'[MERGE] ERROR writing {output_path}: {e}', file=sys.stderr)
        sys.exit(1)

    print(f'[MERGE] Done - {len(kept)} kept, {len(added)} added, {len(dropped)} dropped.')
    print(f'[MERGE] Merged config written to {output_path}')


def main():
    parser = argparse.ArgumentParser(description='CTV2 config merge utility')
    parser.add_argument('--existing', required=True,
                        help='Path to user existing config (backup)')
    parser.add_argument('--new',      required=True,
                        help='Path to newly extracted default config')
    parser.add_argument('--output',   required=True,
                        help='Path to write merged config')
    args = parser.parse_args()

    for path in [args.existing, args.new]:
        if not os.path.exists(path):
            print(f'[MERGE] ERROR: File not found: {path}', file=sys.stderr)
            sys.exit(1)

    merge(args.existing, args.new, args.output)


if __name__ == '__main__':
    main()
