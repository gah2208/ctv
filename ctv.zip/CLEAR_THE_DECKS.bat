@echo off
:: ============================================================
::  CLEAR_THE_DECKS.bat - Remove IB Gateway
::  Revision: 1.6
::
::  v1.6 - Simplified to IB Gateway removal only.
::  Must be run as Administrator.
::  Does NOT remove C:\CTV or any CTV files.
:: ============================================================

:: -- Admin check -----------------------------------------------------
net session >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo  ERROR: This script must be run as Administrator.
    echo  Right-click CLEAR_THE_DECKS.bat and select "Run as administrator".
    echo.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo   CLEAR THE DECKS  -  Uninstall IB Gateway
echo ============================================================
echo.
echo   This will uninstall IB Gateway and remove C:\Jts.
echo   C:\CTV and all CTV files will NOT be touched.
echo.
echo   Type YES to continue, or press Enter to cancel.
echo.
set /p CONFIRM=  Your choice: 
if /i "%CONFIRM%" NEQ "YES" (
    echo.
    echo   Cancelled - nothing was changed.
    echo.
    pause
    exit /b 0
)

echo.
echo ============================================================
echo.

if not exist "C:\Jts" (
    echo   C:\Jts not found - IB Gateway already removed.
    goto done
)

echo   Searching C:\Jts\ibgateway for uninstall.exe...

set IBGW_EXE=
for /f "usebackq delims=" %%F in (`powershell -NoProfile -Command "Get-ChildItem 'C:\Jts\ibgateway' -Recurse -Filter 'uninstall.exe' -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName"`) do set IBGW_EXE=%%F

if not defined IBGW_EXE (
    for /f "usebackq delims=" %%F in (`powershell -NoProfile -Command "Get-ChildItem 'C:\Jts' -Recurse -Filter 'uninstall.exe' -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName"`) do set IBGW_EXE=%%F
)

if defined IBGW_EXE (
    echo   Found: %IBGW_EXE%
    echo   The IB Gateway uninstaller will now open.
    echo   Please click through it to complete removal.
    echo   This window will wait until the uninstaller finishes.
    echo.
    start /wait "" "%IBGW_EXE%"
    echo   Uninstaller finished. Removing C:\Jts...
    rd /s /q "C:\Jts" 2>nul
    echo   Done.
) else (
    echo   IB Gateway uninstaller not found under C:\Jts.
    echo   It may already be removed, or remove manually via Add/Remove Programs.
)

echo.
:done
echo ============================================================
echo   Run CTV_Install.exe when ready to reinstall.
echo ============================================================
echo.
pause
