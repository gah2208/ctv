"""
diag_contract.py - Contract and price diagnostic for CTV2
==========================================================
Connects to IB Gateway, qualifies the SPX index contract, prints
the full contract details, then streams raw ticks for 60 seconds
printing every field on every ticker update so we can see exactly
what price fields IB Gateway is returning.

Run from C:\CTV:
    python diag_contract.py

IB Gateway must be running on port 7497.
"""

import asyncio
import time
from ib_insync import IB, Index

HOST = '127.0.0.1'
PORT = 7497
CLIENT_ID = 99   # unique ID - won't clash with running CTV2


async def main():
    ib = IB()
    print(f'Connecting to IB Gateway {HOST}:{PORT} clientId={CLIENT_ID}')
    await ib.connectAsync(HOST, PORT, clientId=CLIENT_ID, timeout=15)
    print('Connected\n')

    # Qualify the contract and print everything IB Gateway returns
    contract = Index('SPX', 'CBOE')
    qualified = await ib.qualifyContractsAsync(contract)

    if not qualified:
        print('ERROR: qualifyContractsAsync returned nothing - contract not found')
        ib.disconnect()
        return

    c = qualified[0]
    print('=== Qualified contract ===')
    print(f'  symbol         : {c.symbol}')
    print(f'  secType        : {c.secType}')
    print(f'  exchange       : {c.exchange}')
    print(f'  primaryExch    : {c.primaryExchange}')
    print(f'  currency       : {c.currency}')
    print(f'  localSymbol    : {c.localSymbol}')
    print(f'  tradingClass   : {c.tradingClass}')
    print(f'  conId          : {c.conId}')
    print()

    # Subscribe and print every tick field for 60 seconds
    print('=== Streaming ticks for 60 seconds - every field printed ===')
    ticker = ib.reqMktData(c, '', False, False)

    start = time.time()
    last_print = 0.0

    def on_pending(tickers):
        nonlocal last_print
        now = time.time()
        # Print at most once per second to avoid flooding
        if now - last_print < 1.0:
            return
        last_print = now
        for t in tickers:
            print(f'  bid={t.bid}  ask={t.ask}  last={t.last}  '
                  f'close={t.close}  open={t.open}  '
                  f'high={t.high}  low={t.low}  '
                  f'halted={t.halted}  time={t.time}')

    ib.pendingTickersEvent += on_pending

    while time.time() - start < 60:
        await asyncio.sleep(0.5)

    ib.pendingTickersEvent -= on_pending
    ib.cancelMktData(c)
    ib.disconnect()
    print('\nDone.')


if __name__ == '__main__':
    asyncio.run(main())
