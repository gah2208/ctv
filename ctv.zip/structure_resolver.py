# Copyright (c) Gregory Howard 2026  All rights reserved
"""
structure_resolver.py - CTV2 Entry Structure Resolver
=====================================================
Given a candidate body strike and trade direction, determines whether
the $5-wide symmetric butterfly structure can be built at that body
based on strike availability in the contract cache.

The paper-legged trade model (PAPER mode, Error 201 workaround) uses a
symmetric butterfly built from two $5-wide verticals:

    UP:     long vertical  = BUY  B   / SELL B+5   (debit)
            short vertical = SELL B+5 / BUY  B+10  (credit)
            combined       = long B / short (B+5)x2 / long B+10

    DOWN:   long vertical  = BUY  B   / SELL B-5   (debit)
            short vertical = SELL B-5 / BUY  B-10  (credit)
            combined       = long B / short (B-5)x2 / long B-10

Both legs of both verticals must exist at $5 increments for the structure
to be viable.  Since B is selected on the $5 grid at signal time, B is
assumed present.  The resolver confirms the availability of B +/- 5 and
B +/- 10 in the order manager's contract cache.

Behavior:
    - B +/- 5 and B +/- 10 both present  -> return structure dict
    - either strike missing               -> return None (skip entry)

No $10 fallback.  If the $5 grid is not viable at this body, the signal
is skipped entirely.

Usage
-----
    from structure_resolver import resolve_structure

    spec = resolve_structure(order_mgr, body=7135.0, direction='UP')
    if spec is None:
        # log and abandon entry
        return
    # spec = {
    #     'width'     : 5.0,
    #     'right'     : 'C',
    #     'body'      : 7135.0,
    #     'long'      : 7135.0,   # long leg of long vertical
    #     'short'     : 7140.0,   # short leg of long vertical (= body + 5 UP)
    #     'far'       : 7145.0,   # outer wing (= body + 10 UP)
    # }

Revision history
----------------
Rev 1: Initial implementation.  Phase 1 delivery - module present and
       importable but not yet called by the runner.  Wiring happens in
       Phase 3 alongside paper-legged execution.  Uses order manager's
       has_strike() method (added in ibkr_orders.py Rev 19).
"""

from __future__ import annotations

from typing import Optional, Dict, Any

# Width constant for the paper-legged symmetric butterfly.
# Kept as a module-level value (not cfg.SPREAD_WIDTH) because the paper
# legged path is a fixed $5-grid design - if SPREAD_WIDTH ever moves off
# 5.0, the resolver logic does not automatically generalize and the row
# table would need to be re-derived.  Explicit constant prevents silent
# drift.
PAPER_LEG_WIDTH: float = 5.0


def resolve_structure(order_mgr,
                       body:      float,
                       direction: str
                       ) -> Optional[Dict[str, Any]]:
    """
    Resolve the paper-legged butterfly structure for the given body.

    Parameters
    ----------
    order_mgr : IBKROrderManager
        Must expose has_strike(right, strike) -> bool (pure cache lookup,
        no side effects, no qualification round-trip).
    body : float
        Candidate body strike (the long leg of the long vertical).
        Expected to be on the $5 grid.
    direction : str
        'UP' for calls, 'DOWN' for puts.

    Returns
    -------
    dict | None
        Dict with keys {width, right, body, long, short, far} on success,
        or None if either required strike (B +/- 5, B +/- 10) is missing
        from the cache.  On None, the caller should abandon the entry.

    Notes
    -----
    A missing strike in the cache is interpreted as "does not exist at
    IBKR for this expiration".  This is correct as long as the precache
    covers the full range of bodies that can be signaled plus +/- 10pt
    of closure strikes - guaranteed by the ibkr_orders.py precache
    widening to +/- 1.5% + 25pt buffer (Rev 19).
    """
    direction = direction.upper()
    if direction not in ('UP', 'DOWN'):
        print(f'[RESOLVE] invalid direction {direction!r} - skip')
        return None

    right  = 'C' if direction == 'UP' else 'P'
    sign   = 1.0 if direction == 'UP' else -1.0
    width  = PAPER_LEG_WIDTH

    short_strike = round(body + sign * width,       2)   # B +/- 5
    far_strike   = round(body + sign * 2.0 * width, 2)   # B +/- 10

    have_short = order_mgr.has_strike(right, short_strike)
    have_far   = order_mgr.has_strike(right, far_strike)

    if have_short and have_far:
        return {
            'width' : width,
            'right' : right,
            'body'  : body,
            'long'  : body,
            'short' : short_strike,
            'far'   : far_strike,
        }

    # Log which strike(s) failed the lookup so the skip reason is
    # observable in the daily log.
    missing = []
    if not have_short:
        missing.append(f'{right} {short_strike:.1f}')
    if not have_far:
        missing.append(f'{right} {far_strike:.1f}')
    print(f'[RESOLVE] body={body:.1f} {direction} - '
          f'skip (missing: {", ".join(missing)})')
    return None
