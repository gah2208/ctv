@echo off
:: UPLOAD_SCRIPTS.bat
:: Revision: 1.0
:: Packages the launcher/shell scripts into upload_scripts.zip.
:: Use this for sessions involving the PS1 scripts (branding, banners,
:: launch flow, watchdog, shortcuts).
::
:: Files included:
::   START_TRADING.ps1        - Main launcher
::   RESTART.ps1              - Restart launcher
::   ABORT_TRADING.ps1        - Abort script
::   CTV2_WATCHDOG.ps1        - Watchdog
::   CREATE_SHORTCUTS.ps1     - Shortcut creator
::   version_check.ps1        - Version manifest  (always needed)
::   VERSION                  - Version number     (always needed)
::   CHANGELOG.md             - Change log        (always needed)

cd /d C:\CTV

echo Building upload_scripts.zip...
powershell -NoProfile -Command ^
    "Compress-Archive -Force -Path @('START_TRADING.ps1','RESTART.ps1','ABORT_TRADING.ps1','CTV2_WATCHDOG.ps1','CREATE_SHORTCUTS.ps1','version_check.ps1','VERSION','CHANGELOG.md') -DestinationPath 'upload_scripts.zip'"

if %errorlevel%==0 (
    echo Done. Opening folder...
    explorer /select,"C:\CTV\upload_scripts.zip"
) else (
    echo ERROR: zip failed.
    pause
)
