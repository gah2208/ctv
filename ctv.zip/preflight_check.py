#!/usr/bin/env python3
"""
preflight_check.py - CTV2 Pre-flight Credential Check
======================================================
Called by START_TRADING.ps1 and RESTART.ps1 before launching ctv2_runner.py.

Checks that all required credentials are present in config_ctv2.py:
  - TRADIER_ACCOUNT_ID
  - TRADIER_PRODUCTION_TOKEN
  - PUSHOVER_USER_KEY
  - PUSHOVER_API_TOKEN  (only if PUSHOVER_ENABLED = True)

If any required field is missing or blank a tkinter dialog prompts the user
to fill in the missing values.  On OK the values are written back to
config_ctv2.py and this script exits 0 (proceed).  On Cancel it exits 1
(abort launch).

Exit codes
----------
0  All required credentials present (or user supplied them).
1  User cancelled, or a fatal error prevented config write.

Revision history
----------------
Rev 2: Pure white bold text; popup scaled 20% larger (fonts, padding, entry widths).
Rev 8: live_confirmed.flag support. If LIVE_TRADING=True and flag exists,
       confirm_live_trading() skips the dialog entirely and proceeds silently.
       Flag is written when user clicks "Trade Real Money". Cleared by
       START_TRADING.ps1 on exit, RESTART.ps1 before preflight, and
       ABORT_TRADING.ps1 on emergency stop.
Rev 7: Removed file integrity hash check (line ending differences between
       build and install machines caused false hash mismatches).
Rev 5: Renamed "Tradier Live Bearer Token" label to "Tradier API Token".
Rev 4: Live trading confirmation dialog. If LIVE_TRADING=True in config,
       a modal is shown at startup offering "Trade Real Money" or
       "Switch to Paper". Choosing paper writes LIVE_TRADING=False back
       to config_ctv2.py and proceeds normally.
Rev 3: Set all remaining gray text (FG_DIM) to pure white.
Rev 2: Pure white bold text; popup scaled 20% larger (fonts, padding, entry widths).
Rev 1: Initial implementation.
"""

import os
import re
import sys
import tkinter as tk
from tkinter import font as tkfont

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
SCRIPT_DIR  = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(SCRIPT_DIR, 'config_ctv2.py')
FLAG_FILE   = os.path.join(SCRIPT_DIR, 'live_confirmed.flag')

# ---------------------------------------------------------------------------
# Fields to check
# Each entry: (config_key, display_label, is_secret, always_required)
# is_secret=True masks input with '*'.
# always_required=False means only required when PUSHOVER_ENABLED=True.
# ---------------------------------------------------------------------------
FIELDS = [
    ('TRADIER_ACCOUNT_ID',       'Tradier Account ID',       False, True),
    ('TRADIER_PRODUCTION_TOKEN', 'Tradier API Token', True,  True),
    ('PUSHOVER_USER_KEY',        'Pushover User Key',         True,  False),
    ('PUSHOVER_API_TOKEN',       'Pushover API Token',        True,  False),
]

# ---------------------------------------------------------------------------
# Config read / write helpers
# ---------------------------------------------------------------------------

def _read_config_raw():
    """Return the raw text of config_ctv2.py, or '' if not found."""
    if not os.path.exists(CONFIG_FILE):
        return ''
    with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
        return f.read()


def _parse_values(text):
    """Return dict of {KEY: value_string} parsed from config text."""
    values = {}
    pattern = re.compile(r"^([A-Z_]+)\s*=\s*(.+)$", re.MULTILINE)
    for m in pattern.finditer(text):
        key = m.group(1)
        raw = m.group(2).strip()
        raw = re.sub(r'\s*#.*$', '', raw).strip()   # strip inline comment
        raw = raw.strip("'\"")                       # strip quotes
        values[key] = raw
    return values


def _write_value(text, key, value):
    """
    Replace the first occurrence of   KEY = '...'   or   KEY = "..."
    in text with   KEY = '<value>'.
    If the key is not found, append it at the end.
    """
    # Match   KEY   =   '...'  or  KEY = "..."  (with or without surrounding spaces)
    pattern = re.compile(
        r"^(" + re.escape(key) + r"\s*=\s*)['\"].*?['\"]",
        re.MULTILINE
    )
    replacement = r"\g<1>'" + value.replace("'", "\\'") + "'"
    new_text, count = pattern.subn(replacement, text)
    if count == 0:
        # Key not present at all - append
        new_text = text.rstrip('\n') + f"\n{key} = '{value}'\n"
    return new_text


def _save_config(text):
    with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
        f.write(text)

# ---------------------------------------------------------------------------
# Main check logic
# ---------------------------------------------------------------------------

def find_missing(text, values):
    """
    Return list of (key, label, is_secret) for fields that are empty/missing.
    Pushover fields only checked when PUSHOVER_ENABLED=True.
    """
    pushover_enabled = values.get('PUSHOVER_ENABLED', 'False').strip() == 'True'
    missing = []
    for key, label, is_secret, always_required in FIELDS:
        if not always_required and not pushover_enabled:
            continue
        val = values.get(key, '').strip()
        if not val:
            missing.append((key, label, is_secret))
    return missing


def confirm_live_trading():
    """
    If LIVE_TRADING=True in config, show a modal confirmation dialog.

    Offers two choices:
      - "Trade Real Money"  : user confirms intent, returns immediately.
      - "Switch to Paper"   : writes LIVE_TRADING=False back to config and
                              returns (runner will start in paper mode).

    If the config cannot be read or LIVE_TRADING is not True, returns silently.
    """
    text   = _read_config_raw()
    values = _parse_values(text)
    if values.get('LIVE_TRADING', 'False').strip() != 'True':
        return   # paper mode - no confirmation needed

    # If the user already confirmed live trading this session, proceed silently.
    if os.path.exists(FLAG_FILE):
        print('[PREFLIGHT] Live trading pre-authorized (live_confirmed.flag present).')
        return

    # -----------------------------------------------------------------------
    # Build confirmation dialog
    # -----------------------------------------------------------------------
    root = tk.Tk()
    root.title('CTV2 - Live Trading Confirmation')
    root.resizable(False, False)

    BG        = '#1E1E2E'
    WARN_BG   = '#7B1C1C'
    FG        = '#FFFFFF'
    FG_DIM    = '#FFFFFF'
    BTN_LIVE  = '#C62828'
    BTN_HOVER = '#EF5350'
    BTN_PAPER = '#00695C'
    BTN_PAPER_HOVER = '#00897B'

    root.configure(bg=BG)

    try:
        heading_font = tkfont.Font(family='Segoe UI', size=13, weight='bold')
        body_font    = tkfont.Font(family='Segoe UI', size=11, weight='bold')
        btn_font     = tkfont.Font(family='Segoe UI', size=12, weight='bold')
        note_font    = tkfont.Font(family='Segoe UI', size=10, weight='bold', slant='italic')
    except Exception:
        heading_font = body_font = btn_font = note_font = None

    # Warning header
    hdr_frame = tk.Frame(root, bg=WARN_BG, pady=14)
    hdr_frame.pack(fill='x')
    tk.Label(hdr_frame, text='⚠  LIVE TRADING IS ENABLED',
             bg=WARN_BG, fg='white', font=heading_font,
             padx=24).pack(side='left')

    # Body
    body_frame = tk.Frame(root, bg=BG, pady=16, padx=28)
    body_frame.pack(fill='x')
    tk.Label(body_frame,
             text='LIVE_TRADING = True is set in config_ctv2.py.\n\n'
                  'Real orders will be submitted to your Tradier account.\n'
                  'Real money is at risk.',
             bg=BG, fg=FG, font=body_font,
             justify='left').pack(anchor='w')

    # Note
    note_frame = tk.Frame(root, bg=BG, padx=28)
    note_frame.pack(fill='x')
    tk.Label(note_frame,
             text='To run without real trades, click "Switch to Paper" below. '
                  'LIVE_TRADING will be set to False in your config.',
             bg=BG, fg=FG_DIM, font=note_font,
             justify='left', wraplength=480).pack(anchor='w')

    # Buttons
    btn_frame = tk.Frame(root, bg=BG, pady=22, padx=28)
    btn_frame.pack(fill='x')

    choice = ['paper']   # default safe: if window is closed, treat as paper

    def _go_live():
        choice[0] = 'live'
        try:
            with open(FLAG_FILE, 'w', encoding='ascii') as f:
                f.write('live_confirmed\n')
        except Exception as exc:
            print(f'[PREFLIGHT] Could not write live_confirmed.flag: {exc}')
        root.destroy()

    def _go_paper():
        choice[0] = 'paper'
        root.destroy()

    paper_btn = tk.Button(btn_frame, text='Switch to Paper', command=_go_paper,
                          bg=BTN_PAPER, fg='white', relief='flat', font=btn_font,
                          padx=20, pady=8, cursor='hand2',
                          activebackground=BTN_PAPER_HOVER, activeforeground='white')
    paper_btn.pack(side='left')
    paper_btn.bind('<Enter>', lambda e: paper_btn.config(bg=BTN_PAPER_HOVER))
    paper_btn.bind('<Leave>', lambda e: paper_btn.config(bg=BTN_PAPER))

    live_btn = tk.Button(btn_frame, text='Trade Real Money', command=_go_live,
                         bg=BTN_LIVE, fg='white', relief='flat', font=btn_font,
                         padx=20, pady=8, cursor='hand2',
                         activebackground=BTN_HOVER, activeforeground='white')
    live_btn.pack(side='right')
    live_btn.bind('<Enter>', lambda e: live_btn.config(bg=BTN_HOVER))
    live_btn.bind('<Leave>', lambda e: live_btn.config(bg=BTN_LIVE))

    root.bind('<Escape>', lambda e: _go_paper())

    # Centre on screen
    root.update_idletasks()
    w  = root.winfo_reqwidth()
    h  = root.winfo_reqheight()
    sw = root.winfo_screenwidth()
    sh = root.winfo_screenheight()
    root.geometry(f'{w}x{h}+{(sw - w) // 2}+{(sh - h) // 2}')

    root.mainloop()

    if choice[0] == 'paper':
        # Write LIVE_TRADING=False back to config
        current_text = _read_config_raw()
        current_text = _write_value(current_text, 'LIVE_TRADING', 'False')
        try:
            _save_config(current_text)
            print('[PREFLIGHT] Switched to paper trading (LIVE_TRADING set to False).')
        except Exception as exc:
            print(f'[PREFLIGHT] Could not update config: {exc}')


def run_preflight():
    confirm_live_trading()   # show live-trading confirmation if LIVE_TRADING=True
    text   = _read_config_raw()
    values = _parse_values(text)
    missing = find_missing(text, values)

    if not missing:
        # All good - silent exit
        sys.exit(0)

    # -----------------------------------------------------------------------
    # Build dialog
    # -----------------------------------------------------------------------
    root = tk.Tk()
    root.title('CTV2 - Required Credentials Missing')
    root.resizable(False, False)

    # -- Colour palette (matches config editor theme) -----------------------
    BG        = '#1E1E2E'
    CARD_BG   = '#2A2A3E'
    ACCENT    = '#00695C'
    FG        = '#FFFFFF'
    FG_DIM    = '#FFFFFF'
    ENTRY_BG  = '#12121E'
    ERR_FG    = '#EF5350'
    BTN_OK    = '#00897B'
    BTN_HOVER = '#00BFA5'
    BTN_CANCEL= '#424242'

    root.configure(bg=BG)

    # -- Fonts --------------------------------------------------------------
    try:
        heading_font = tkfont.Font(family='Segoe UI', size=13, weight='bold')
        label_font   = tkfont.Font(family='Segoe UI', size=11, weight='bold')
        entry_font   = tkfont.Font(family='Consolas',  size=12)
        btn_font     = tkfont.Font(family='Segoe UI', size=12, weight='bold')
        note_font    = tkfont.Font(family='Segoe UI', size=10, weight='bold', slant='italic')
    except Exception:
        heading_font = label_font = entry_font = btn_font = note_font = None

    # -- Header -------------------------------------------------------------
    hdr_frame = tk.Frame(root, bg=ACCENT, pady=14)
    hdr_frame.pack(fill='x')
    tk.Label(hdr_frame, text='Required Credentials Missing',
             bg=ACCENT, fg='white', font=heading_font,
             padx=24).pack(side='left')

    # -- Instruction --------------------------------------------------------
    instr_frame = tk.Frame(root, bg=BG, pady=10, padx=24)
    instr_frame.pack(fill='x')
    tk.Label(instr_frame,
             text='The following fields must be filled in before trading can start.\n'
                  'Enter the missing values below, then click Save & Continue.',
             bg=BG, fg=FG_DIM, font=label_font, justify='left').pack(anchor='w')

    # -- Fields -------------------------------------------------------------
    card = tk.Frame(root, bg=CARD_BG, padx=24, pady=19)
    card.pack(fill='x', padx=24, pady=(0, 10))

    entry_vars = {}   # key -> StringVar

    for i, (key, label, is_secret) in enumerate(missing):
        row = tk.Frame(card, bg=CARD_BG)
        row.pack(fill='x', pady=7)

        tk.Label(row, text=label, bg=CARD_BG, fg=FG, font=label_font,
                 width=34, anchor='w').pack(side='left')

        var = tk.StringVar()
        entry_vars[key] = var
        show = '*' if is_secret else ''
        ent = tk.Entry(row, textvariable=var, show=show,
                       bg=ENTRY_BG, fg=FG, insertbackground=FG,
                       relief='flat', font=entry_font,
                       width=50, highlightthickness=1,
                       highlightbackground='#444', highlightcolor=ACCENT)
        ent.pack(side='left', ipady=5)

        # Show/hide toggle for secret fields
        if is_secret:
            visible = [False]
            def _toggle(e=ent, v=visible):
                v[0] = not v[0]
                e.config(show=('' if v[0] else '*'))
            tk.Button(row, text='👁', bg=CARD_BG, fg=FG_DIM, relief='flat',
                      activebackground=CARD_BG, cursor='hand2',
                      command=_toggle, font=label_font).pack(side='left', padx=(4, 0))

    # -- Error label (hidden until needed) ----------------------------------
    err_var = tk.StringVar()
    err_lbl = tk.Label(root, textvariable=err_var, bg=BG, fg=ERR_FG,
                       font=label_font)
    err_lbl.pack(padx=24, anchor='w')

    # -- Note ---------------------------------------------------------------
    note_frame = tk.Frame(root, bg=BG, padx=24)
    note_frame.pack(fill='x')
    tk.Label(note_frame,
             text='Values are saved to config_ctv2.py.  '
                  'You can also set them in the Config Editor → Tradier / Pushover tabs.',
             bg=BG, fg=FG_DIM, font=note_font, justify='left').pack(anchor='w')

    # -- Buttons ------------------------------------------------------------
    btn_frame = tk.Frame(root, bg=BG, pady=19, padx=24)
    btn_frame.pack(fill='x')

    result = [False]   # mutable flag

    def _on_save():
        # Validate - no blanks
        for key, label, is_secret in missing:
            if not entry_vars[key].get().strip():
                err_var.set(f'  ✖  {label} cannot be blank.')
                return
        err_var.set('')

        # Write each value back into config text
        current_text = _read_config_raw()
        for key, _, _ in missing:
            current_text = _write_value(current_text, key, entry_vars[key].get().strip())
        try:
            _save_config(current_text)
        except Exception as exc:
            err_var.set(f'  ✖  Could not write config: {exc}')
            return

        result[0] = True
        root.destroy()

    def _on_cancel():
        root.destroy()

    def _btn_enter(btn, color):
        btn.config(bg=color)

    def _btn_leave(btn, color):
        btn.config(bg=color)

    cancel_btn = tk.Button(btn_frame, text='Cancel', command=_on_cancel,
                           bg=BTN_CANCEL, fg=FG, relief='flat', font=btn_font,
                           padx=20, pady=6, cursor='hand2',
                           activebackground='#616161', activeforeground=FG)
    cancel_btn.pack(side='right', padx=(8, 0))
    cancel_btn.bind('<Enter>', lambda e: cancel_btn.config(bg='#616161'))
    cancel_btn.bind('<Leave>', lambda e: cancel_btn.config(bg=BTN_CANCEL))

    save_btn = tk.Button(btn_frame, text='Save & Continue', command=_on_save,
                         bg=BTN_OK, fg='white', relief='flat', font=btn_font,
                         padx=20, pady=6, cursor='hand2',
                         activebackground=BTN_HOVER, activeforeground='white')
    save_btn.pack(side='right')
    save_btn.bind('<Enter>', lambda e: save_btn.config(bg=BTN_HOVER))
    save_btn.bind('<Leave>', lambda e: save_btn.config(bg=BTN_OK))

    # -- Bind Enter key to save ---------------------------------------------
    root.bind('<Return>', lambda e: _on_save())
    root.bind('<Escape>', lambda e: _on_cancel())

    # -- Centre on screen ---------------------------------------------------
    root.update_idletasks()
    w = root.winfo_width()
    h = root.winfo_height()
    sw = root.winfo_screenwidth()
    sh = root.winfo_screenheight()
    root.geometry(f'+{(sw - w) // 2}+{(sh - h) // 2}')

    root.mainloop()

    sys.exit(0 if result[0] else 1)


if __name__ == '__main__':
    run_preflight()
