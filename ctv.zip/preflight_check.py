#!/usr/bin/env python3
# Copyright (c) Gregory Howard 2026  All rights reserved
"""
preflight_check.py - CTV2 Pre-flight Credential Check
======================================================
Called by START_TRADING.ps1 and RESTART.ps1 before launching ctv2_runner.py.

Checks that all required credentials are present in config_ctv2.py:
  - TRADIER_ACCOUNT_ID
  - TRADIER_PRODUCTION_TOKEN
  - PUSHOVER_USER_KEY
  - PUSHOVER_API_TOKEN  (only if PUSHOVER_ENABLED = True)

If any required field is missing or blank a tkinter dialog prompts the user
to fill in the missing values.  On OK the values are written back to
config_ctv2.py and this script exits 0 (proceed).  On Cancel it exits 1
(abort launch).

Exit codes
----------
0  All required credentials present (or user supplied them).
1  User cancelled, or a fatal error prevented config write.

Revision history
----------------
Rev 2: Pure white bold text; popup scaled 20% larger (fonts, padding, entry widths).
Rev 14: VTB branding applied to all dialog titles and labels.
Rev 13: Legal disclosure dialog added (show_disclosure()).
        Fires as the very first step of run_preflight() before any IB Gateway
        or integrity checks. User must type 'yes' (case-insensitive) to proceed.
        Abort or window-close exits with code 1.
        Each acceptance is timestamped and appended to disclosure_log.json with
        invoked_by field ('Start Trading' or 'Restart Trading').
        --mode {start|restart} argument added; passed from START_TRADING.ps1
        and RESTART.ps1 respectively.
        Copyright (c) Gregory Howard 2026 All rights reserved added to all
        .py file headers and displayed in all four program startup interfaces.
        DISCLOSURE_LOG, COPYRIGHT, DISCLOSURE_TEXT constants added.
        _append_disclosure_log() helper added.
        datetime import added.
Rev 12: IB Gateway exe search path corrected to C:\\Program Files\\ibgateway.
Rev 11: File integrity check restored and fixed.
        check_file_integrity() added: loads install_manifest.json, re-hashes
        all registered CTV .py files (line-ending normalized, matching the
        installer) and the IB Gateway exe (raw bytes). On mismatch shows a
        blocking dialog listing changed files with Abort / Trust & Update
        Manifest options. Silently passes if manifest has no hash sections
        (older installs). Fixes Rev 7 false-mismatch bug by normalizing
        CRLF->LF before hashing .py files. hashlib, json, glob imports added.
        MANIFEST_FILE path constant added.
Rev 10: LIVE_TRADING and IB_PORT now auto-detected from IB Gateway.
        check_ib_gateway() tries port 7497 then 7496; calls
        ib.managedAccounts() to detect paper (DU prefix) vs live (U prefix).
        Writes LIVE_TRADING and IB_PORT to config automatically.
        Live confirmation dialog shown only when live account detected.
        confirm_live_trading() removed - merged into check_ib_gateway().
        _write_bool() and _write_int() helpers added for unquoted values.
Rev 9: Tradier credential check replaced by IB Gateway connectivity test.
       TRADIER_ACCOUNT_ID and TRADIER_PRODUCTION_TOKEN removed from FIELDS.
       check_ib_gateway() added: attempts IB().connect(host, port,
       clientId=98, timeout=5) using IB_HOST/IB_PORT from config. On
       failure shows a warning dialog with Proceed Anyway / Abort options.
       Live-trading confirmation text updated: Tradier -> IBKR account.
       Note text updated: Tradier/Pushover tabs -> Pushover tab.
Rev 8: live_confirmed.flag support. If LIVE_TRADING=True and flag exists,
       confirm_live_trading() skips the dialog entirely and proceeds silently.
       Flag is written when user clicks "Trade Real Money". Cleared by
       START_TRADING.ps1 on exit, RESTART.ps1 before preflight, and
       ABORT_TRADING.ps1 on emergency stop.
Rev 7: Removed file integrity hash check (line ending differences between
       build and install machines caused false hash mismatches).
Rev 5: Renamed "Tradier Live Bearer Token" label to "Tradier API Token".
Rev 4: Live trading confirmation dialog. If LIVE_TRADING=True in config,
       a modal is shown at startup offering "Trade Real Money" or
       "Switch to Paper". Choosing paper writes LIVE_TRADING=False back
       to config_ctv2.py and proceeds normally.
Rev 3: Set all remaining gray text (FG_DIM) to pure white.
Rev 2: Pure white bold text; popup scaled 20% larger (fonts, padding, entry widths).
Rev 1: Initial implementation.
"""

import os
import re
import sys
import json
import glob
import hashlib
import tkinter as tk
from tkinter import font as tkfont
from datetime import datetime

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
SCRIPT_DIR    = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE   = os.path.join(SCRIPT_DIR, 'config_ctv2.py')
FLAG_FILE     = os.path.join(SCRIPT_DIR, 'live_confirmed.flag')
MANIFEST_FILE = os.path.join(SCRIPT_DIR, 'install_manifest.json')
DISCLOSURE_LOG = os.path.join(SCRIPT_DIR, 'disclosure_log.json')

# ---------------------------------------------------------------------------
# Copyright / Disclosure
# ---------------------------------------------------------------------------
COPYRIGHT = 'Copyright (c) Gregory Howard 2026  All rights reserved'

DISCLOSURE_TEXT = (
    "DISCLOSURE: The VTB program provides educational materials for general "
    "informational purposes only. The content on this program is not intended "
    "as investment, tax, accounting, or legal advice, nor as an offer, "
    "endorsement, or recommendation of any security, fund, investment product "
    "or opportunity. None of the information herein should be relied upon for "
    "financial, legal, or business decisions, including the buying, selling, or "
    "transacting of currencies, commodities, securities, or other investments. "
    "Past results are not indicative of future success, and individual outcomes "
    "may vary significantly based on factors such as market conditions, personal "
    "effort, and circumstances. The developers do not guarantee financial results, "
    "and users assume all risks associated with applying the information in this "
    "program and in all materials. Neither VTB program nor its owners, officers, "
    "employees, or affiliates are financial or investment advisors. Nothing "
    "contained constitutes tailored advice for any individual or entity. Users "
    "are encouraged to consult with legal, tax, or financial professionals before "
    "acting on any information provided. Content is provided \"as is,\" without "
    "warranties of any kind, including implied warranties of merchantability, "
    "fitness for a particular purpose, or non-infringement. The developers, "
    "employees or affiliates expressly disclaim all liability for errors, "
    "omissions, or any direct, indirect, or consequential damages, including "
    "financial losses, arising from reliance on this information. By using this "
    "program, you acknowledge that evaluating the accuracy and applicability of "
    "the content is your responsibility alone."
)

# ---------------------------------------------------------------------------
# Fields to check
# Each entry: (config_key, display_label, is_secret, always_required)
# is_secret=True masks input with '*'.
# always_required=False means only required when PUSHOVER_ENABLED=True.
# ---------------------------------------------------------------------------
FIELDS = [
    ('PUSHOVER_USER_KEY',        'Pushover User Key',         True,  False),
    ('PUSHOVER_API_TOKEN',       'Pushover API Token',        True,  False),
]

# ---------------------------------------------------------------------------
# Config read / write helpers
# ---------------------------------------------------------------------------

def _read_config_raw():
    """Return the raw text of config_ctv2.py, or '' if not found."""
    if not os.path.exists(CONFIG_FILE):
        return ''
    with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
        return f.read()


def _parse_values(text):
    """Return dict of {KEY: value_string} parsed from config text."""
    values = {}
    pattern = re.compile(r"^([A-Z_]+)\s*=\s*(.+)$", re.MULTILINE)
    for m in pattern.finditer(text):
        key = m.group(1)
        raw = m.group(2).strip()
        raw = re.sub(r'\s*#.*$', '', raw).strip()   # strip inline comment
        raw = raw.strip("'\"")                       # strip quotes
        values[key] = raw
    return values


def _write_value(text, key, value):
    """
    Replace the first occurrence of   KEY = '...'   or   KEY = "..."
    in text with   KEY = '<value>'.
    If the key is not found, append it at the end.
    """
    # Match   KEY   =   '...'  or  KEY = "..."  (with or without surrounding spaces)
    pattern = re.compile(
        r"^(" + re.escape(key) + r"\s*=\s*)['\"].*?['\"]",
        re.MULTILINE
    )
    replacement = r"\g<1>'" + value.replace("'", "\\'") + "'"
    new_text, count = pattern.subn(replacement, text)
    if count == 0:
        # Key not present at all - append
        new_text = text.rstrip('\n') + f"\n{key} = '{value}'\n"
    return new_text


def _write_bool(text, key, bool_val):
    """
    Replace KEY = True/False (unquoted boolean) with the new value.
    Falls back to appending if the key is not found.
    """
    new_val = 'True' if bool_val else 'False'
    pattern = re.compile(
        r'^(' + re.escape(key) + r'\s*=\s*)(True|False)',
        re.MULTILINE
    )
    new_text, count = pattern.subn(r'\g<1>' + new_val, text)
    if count == 0:
        new_text = text.rstrip('\n') + f'\n{key} = {new_val}\n'
    return new_text


def _write_int(text, key, int_val):
    """
    Replace KEY = <integer> (unquoted) with the new value.
    Falls back to appending if the key is not found.
    """
    pattern = re.compile(
        r'^(' + re.escape(key) + r'\s*=\s*)\d+',
        re.MULTILINE
    )
    new_text, count = pattern.subn(r'\g<1>' + str(int_val), text)
    if count == 0:
        new_text = text.rstrip('\n') + f'\n{key} = {int_val}\n'
    return new_text


def _save_config(text):
    with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
        f.write(text)

# ---------------------------------------------------------------------------
# IB Gateway connectivity check
# ---------------------------------------------------------------------------

def check_ib_gateway():
    """
    Auto-detect whether IB Gateway is running in paper or live mode, then
    write LIVE_TRADING and IB_PORT into config_ctv2.py.

    Detection logic:
      1. Try connecting on port 7497 (paper default).
      2. If that fails, try port 7496 (live default).
      3. If both fail, show a "not reachable" warning dialog.
      4. On success, call ib.managedAccounts():
           Account starts with "DU" -> paper trading
           Account starts with "U"  -> live trading
      5. Write LIVE_TRADING (bool) and IB_PORT (int) to config_ctv2.py.
      6. If live detected, show the live-trading confirmation dialog.
         - "Trade Real Money" : proceed.
         - "Abort"            : exit(1) so user can restart Gateway in paper mode.

    Uses clientId=98 - never conflicts with runner (1) or orders (2).
    """
    text   = _read_config_raw()
    values = _parse_values(text)
    host   = values.get('IB_HOST', '127.0.0.1').strip().strip("'\"") or '127.0.0.1'

    # -- Try paper port then live port ------------------------------------
    try:
        from ib_insync import IB
    except ImportError as e:
        print(f'[PREFLIGHT] ib_insync not installed: {e}')
        return

    connected_port = None
    accounts       = []
    ib             = IB()

    for port in (7497, 7496):
        try:
            ib.connect(host, port, clientId=98, timeout=5)
            connected_port = port
            try:
                accounts = ib.managedAccounts()
            except Exception:
                accounts = []
            ib.disconnect()
            break
        except Exception:
            pass

    if connected_port is None:
        print(f'[PREFLIGHT] IB Gateway not reachable on {host} ports 7497 or 7496')
        _show_not_reachable_dialog(host)
        return

    # -- Detect paper vs live from account prefix -------------------------
    # Paper accounts: DUxxxxxxx   Live accounts: Uxxxxxxx
    is_live = any(
        a.strip() and not a.strip().startswith('DU')
        for a in accounts
    )
    mode_label = 'LIVE' if is_live else 'PAPER'
    acct_display = ', '.join(accounts) if accounts else '(unknown)'
    print(f'[PREFLIGHT] IB Gateway connected: {host}:{connected_port} '
          f'mode={mode_label} accounts={acct_display}')

    # -- Write detected values to config ----------------------------------
    text = _read_config_raw()
    text = _write_bool(text, 'LIVE_TRADING', is_live)
    text = _write_int(text,  'IB_PORT',      connected_port)
    try:
        _save_config(text)
        print(f'[PREFLIGHT] Config updated: LIVE_TRADING={is_live} IB_PORT={connected_port}')
    except Exception as exc:
        print(f'[PREFLIGHT] Could not update config: {exc}')

    # -- Live confirmation dialog -----------------------------------------
    if not is_live:
        return   # paper mode - proceed silently

    # Check flag: already confirmed this session
    if os.path.exists(FLAG_FILE):
        print('[PREFLIGHT] Live trading pre-authorized (live_confirmed.flag present).')
        return

    _show_live_confirmation_dialog(acct_display)


def _show_not_reachable_dialog(host):
    """Warning dialog when IB Gateway is not reachable on either port."""
    root = tk.Tk()
    root.title('VTB - IB Gateway Not Reachable')
    root.resizable(False, False)

    BG      = '#1E1E2E'
    WARN_BG = '#7B1C1C'
    FG      = '#FFFFFF'
    BTN_PROCEED = '#00695C'
    BTN_ABORT   = '#424242'
    root.configure(bg=BG)

    try:
        heading_font = tkfont.Font(family='Segoe UI', size=13, weight='bold')
        body_font    = tkfont.Font(family='Segoe UI', size=11, weight='bold')
        btn_font     = tkfont.Font(family='Segoe UI', size=12, weight='bold')
    except Exception:
        heading_font = body_font = btn_font = None

    tk.Frame(root, bg=WARN_BG, pady=14).pack(fill='x')
    tk.Label(root.winfo_children()[-1],
             text='IB Gateway Not Reachable',
             bg=WARN_BG, fg='white', font=heading_font, padx=24).pack(side='left')

    body_frame = tk.Frame(root, bg=BG, pady=16, padx=28)
    body_frame.pack(fill='x')
    tk.Label(body_frame,
             text=f'Could not connect to IB Gateway at {host}\n'
                  f'on port 7497 (paper) or 7496 (live).\n\n'
                  'Make sure IB Gateway is running and logged in\n'
                  'before starting the runner.\n\n'
                  'You can proceed anyway, but the runner will fail\n'
                  'to start market data and order placement.',
             bg=BG, fg=FG, font=body_font, justify='left').pack(anchor='w')

    btn_frame = tk.Frame(root, bg=BG, pady=22, padx=28)
    btn_frame.pack(fill='x')
    choice = ['abort']

    def _proceed(): choice[0] = 'proceed'; root.destroy()
    def _abort():   root.destroy()

    tk.Button(btn_frame, text='Abort', command=_abort,
              bg=BTN_ABORT, fg=FG, relief='flat', font=btn_font,
              padx=20, pady=8, cursor='hand2').pack(side='right', padx=(8, 0))
    tk.Button(btn_frame, text='Proceed Anyway', command=_proceed,
              bg=BTN_PROCEED, fg='white', relief='flat', font=btn_font,
              padx=20, pady=8, cursor='hand2').pack(side='right')

    root.bind('<Escape>', lambda e: _abort())
    root.update_idletasks()
    w, h = root.winfo_reqwidth(), root.winfo_reqheight()
    sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
    root.geometry(f'{w}x{h}+{(sw-w)//2}+{(sh-h)//2}')
    root.mainloop()

    if choice[0] == 'abort':
        sys.exit(1)


def _show_live_confirmation_dialog(acct_display):
    """
    Confirmation dialog shown when IB Gateway is detected in live mode.
    Options: Trade Real Money (proceed) or Abort (exit so user can
    restart Gateway in paper mode).
    """
    root = tk.Tk()
    root.title('VTB - Live Trading Confirmation')
    root.resizable(False, False)

    BG        = '#1E1E2E'
    WARN_BG   = '#7B1C1C'
    FG        = '#FFFFFF'
    BTN_LIVE  = '#C62828'
    BTN_HOVER = '#EF5350'
    BTN_ABORT = '#424242'
    root.configure(bg=BG)

    try:
        heading_font = tkfont.Font(family='Segoe UI', size=13, weight='bold')
        body_font    = tkfont.Font(family='Segoe UI', size=11, weight='bold')
        btn_font     = tkfont.Font(family='Segoe UI', size=12, weight='bold')
        note_font    = tkfont.Font(family='Segoe UI', size=10,
                                   weight='bold', slant='italic')
    except Exception:
        heading_font = body_font = btn_font = note_font = None

    hdr = tk.Frame(root, bg=WARN_BG, pady=14)
    hdr.pack(fill='x')
    tk.Label(hdr, text='\u26a0  LIVE TRADING DETECTED',
             bg=WARN_BG, fg='white', font=heading_font, padx=24).pack(side='left')

    body_frame = tk.Frame(root, bg=BG, pady=16, padx=28)
    body_frame.pack(fill='x')
    tk.Label(body_frame,
             text=f'IB Gateway is connected in LIVE mode.\n'
                  f'Account: {acct_display}\n\n'
                  'Real orders will be submitted to your IBKR account.\n'
                  'Real money is at risk.',
             bg=BG, fg=FG, font=body_font, justify='left').pack(anchor='w')

    note_frame = tk.Frame(root, bg=BG, padx=28)
    note_frame.pack(fill='x')
    tk.Label(note_frame,
             text='To run in paper mode, click Abort, restart IB Gateway '
                  'in Paper Trading mode, then relaunch VTB.',
             bg=BG, fg=FG, font=note_font,
             justify='left', wraplength=480).pack(anchor='w')

    btn_frame = tk.Frame(root, bg=BG, pady=22, padx=28)
    btn_frame.pack(fill='x')
    choice = ['abort']

    def _go_live():
        choice[0] = 'live'
        try:
            with open(FLAG_FILE, 'w', encoding='ascii') as f:
                f.write('live_confirmed\n')
        except Exception as exc:
            print(f'[PREFLIGHT] Could not write live_confirmed.flag: {exc}')
        root.destroy()

    def _abort():
        root.destroy()

    tk.Button(btn_frame, text='Abort', command=_abort,
              bg=BTN_ABORT, fg=FG, relief='flat', font=btn_font,
              padx=20, pady=8, cursor='hand2').pack(side='right', padx=(8, 0))
    tk.Button(btn_frame, text='Trade Real Money', command=_go_live,
              bg=BTN_LIVE, fg='white', relief='flat', font=btn_font,
              padx=20, pady=8, cursor='hand2').pack(side='right')

    root.bind('<Escape>', lambda e: _abort())
    root.update_idletasks()
    w, h = root.winfo_reqwidth(), root.winfo_reqheight()
    sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
    root.geometry(f'{w}x{h}+{(sw-w)//2}+{(sh-h)//2}')
    root.mainloop()

    if choice[0] == 'abort':
        sys.exit(1)

# ---------------------------------------------------------------------------
# Main check logic
# ---------------------------------------------------------------------------

def find_missing(text, values):
    """
    Return list of (key, label, is_secret) for fields that are empty/missing.
    Pushover fields only checked when PUSHOVER_ENABLED=True.
    """
    pushover_enabled = values.get('PUSHOVER_ENABLED', 'False').strip() == 'True'
    missing = []
    for key, label, is_secret, always_required in FIELDS:
        if not always_required and not pushover_enabled:
            continue
        val = values.get(key, '').strip()
        if not val:
            missing.append((key, label, is_secret))
    return missing




# ---------------------------------------------------------------------------
# File integrity checking
# ---------------------------------------------------------------------------

def _hash_py_file(path):
    """
    SHA-256 of a .py file with line endings normalized to LF before hashing.
    Matches the normalization applied by Get-SHA256FileNormalized in the
    installer, so hashes agree regardless of CRLF vs LF on disk.
    Returns uppercase hex string, or None if file not found.
    """
    try:
        with open(path, 'rb') as f:
            raw = f.read()
        text = raw.decode('utf-8', errors='replace')
        normalized = text.replace('\r\n', '\n').replace('\r', '\n')
        return hashlib.sha256(normalized.encode('utf-8')).hexdigest().upper()
    except Exception:
        return None


def _hash_binary_file(path):
    """SHA-256 of a binary file (raw bytes, no normalization). Returns uppercase hex."""
    try:
        with open(path, 'rb') as f:
            return hashlib.sha256(f.read()).hexdigest().upper()
    except Exception:
        return None


def check_file_integrity():
    """
    Load install_manifest.json and verify SHA-256 hashes of all registered
    CTV Python files and the IB Gateway executable.

    On mismatch: show a blocking dialog listing changed files.
      - Abort  : exit(1) - safe default
      - Trust & Update Manifest : re-hash and save, then continue

    Silently passes if manifest is missing or has no hash sections
    (e.g. installed with an older installer).
    """
    if not os.path.exists(MANIFEST_FILE):
        return  # older install without integrity data - skip silently

    try:
        with open(MANIFEST_FILE, 'r', encoding='utf-8') as f:
            manifest = json.load(f)
    except Exception:
        return  # unreadable manifest - skip silently

    failures = []   # list of (filename, expected, actual)

    # -- CTV Python files --------------------------------------------------
    ctv_hashes = manifest.get('ctv_files', {})
    for filename, expected_hash in ctv_hashes.items():
        if not expected_hash:
            continue
        path = os.path.join(SCRIPT_DIR, filename)
        actual = _hash_py_file(path)
        if actual is None:
            failures.append((filename, expected_hash, '<missing>'))
        elif actual.upper() != expected_hash.upper():
            failures.append((filename, expected_hash, actual))

    # -- IB Gateway executable ---------------------------------------------
    ibgw_info = manifest.get('ibgateway', {})
    ibgw_path = ibgw_info.get('path')
    ibgw_expected = ibgw_info.get('sha256')
    if ibgw_path and ibgw_expected:
        if not os.path.exists(ibgw_path):
            # Path may have changed after a Gateway update - search for it
            found = glob.glob(
                r'C:\Program Files\ibgateway\**\ibgateway.exe', recursive=True)
            ibgw_path = found[0] if found else ibgw_path
        actual = _hash_binary_file(ibgw_path)
        label = 'ibgateway.exe (' + os.path.basename(
            os.path.dirname(ibgw_path)) + ')'
        if actual is None:
            failures.append((label, ibgw_expected, '<missing>'))
        elif actual.upper() != ibgw_expected.upper():
            failures.append((label, ibgw_expected, actual))

    if not failures:
        return  # all good

    # -- Show blocking dialog ----------------------------------------------
    choice = [None]

    root = tk.Tk()
    root.title('VTB - File Integrity Check Failed')
    root.resizable(False, False)
    root.configure(bg='#1a1a1a')
    root.attributes('-topmost', True)

    BG      = '#1a1a1a'
    FG      = '#FFFFFF'
    FG_WARN = '#FF9800'
    FG_ERR  = '#FF4444'
    BTN_ABORT  = '#C62828'
    BTN_TRUST  = '#E65100'
    FONT_H  = ('Segoe UI', 13, 'bold')
    FONT_B  = ('Segoe UI', 12)
    FONT_S  = ('Segoe UI', 11)
    FONT_M  = ('Courier New', 10)

    pad = dict(padx=20, pady=6)

    tk.Label(root, text='FILE INTEGRITY CHECK FAILED',
             bg=BG, fg=FG_ERR, font=FONT_H).pack(**pad)

    tk.Label(root,
             text='The following files do not match their install-time signatures.',
             bg=BG, fg=FG, font=FONT_B).pack(padx=20, pady=(0, 2))
    tk.Label(root,
             text='This is normal after running Update.ps1.  If you did NOT just\n'
                  'run an update, do NOT proceed - your installation may be compromised.',
             bg=BG, fg=FG_WARN, font=FONT_S,
             justify='left').pack(padx=20, pady=(0, 8))

    # File list
    list_frame = tk.Frame(root, bg='#111111', relief='sunken', bd=1)
    list_frame.pack(padx=20, pady=(0, 10), fill='x')
    tk.Label(list_frame, text='  Changed file',
             bg='#111111', fg='#AAAAAA', font=FONT_S,
             anchor='w').pack(fill='x', padx=4, pady=(4, 0))
    for (fname, _exp, actual) in failures:
        color = '#FF4444' if actual == '<missing>' else '#FF9800'
        suffix = '  [MISSING]' if actual == '<missing>' else '  [MODIFIED]'
        tk.Label(list_frame, text='  \u2022 ' + fname + suffix,
                 bg='#111111', fg=color, font=FONT_M,
                 anchor='w').pack(fill='x', padx=4)
    tk.Label(list_frame, text='', bg='#111111').pack()

    # Buttons
    btn_frame = tk.Frame(root, bg=BG)
    btn_frame.pack(pady=(4, 16))

    def _abort():
        choice[0] = 'abort'
        root.destroy()

    def _trust():
        choice[0] = 'trust'
        root.destroy()

    tk.Button(btn_frame, text='Abort',
              bg=BTN_ABORT, fg='white', font=FONT_B,
              width=14, command=_abort).pack(side='left', padx=8)
    tk.Button(btn_frame, text='Trust \u0026 Update Manifest',
              bg=BTN_TRUST, fg='white', font=FONT_B,
              width=22, command=_trust).pack(side='left', padx=8)

    root.protocol('WM_DELETE_WINDOW', _abort)
    root.update_idletasks()
    w = root.winfo_reqwidth()
    h = root.winfo_reqheight()
    sw = root.winfo_screenwidth()
    sh = root.winfo_screenheight()
    root.geometry(f'+{(sw-w)//2}+{(sh-h)//2}')
    root.mainloop()

    if choice[0] != 'trust':
        sys.exit(1)

    # -- Re-hash and save updated manifest ---------------------------------
    try:
        for filename in list(ctv_hashes.keys()):
            path = os.path.join(SCRIPT_DIR, filename)
            new_hash = _hash_py_file(path)
            if new_hash:
                manifest['ctv_files'][filename] = new_hash

        if ibgw_path and os.path.exists(ibgw_path):
            new_ibgw_hash = _hash_binary_file(ibgw_path)
            if new_ibgw_hash:
                manifest['ibgateway']['path']   = ibgw_path
                manifest['ibgateway']['sha256'] = new_ibgw_hash

        with open(MANIFEST_FILE, 'w', encoding='utf-8') as f:
            json.dump(manifest, f, indent=4)
        print('[INTEGRITY] Manifest updated with new file hashes.')
    except Exception as e:
        print(f'[INTEGRITY] Warning: could not update manifest: {e}')


# ---------------------------------------------------------------------------
# Disclosure log
# ---------------------------------------------------------------------------

def _append_disclosure_log(mode: str) -> None:
    """
    Append a timestamped record to disclosure_log.json each time the user
    agrees to the disclosure.  Creates the file if it does not exist.

    Record format:
        {"timestamp": "2026-04-12T09:15:23", "invoked_by": "Start Trading", "agreed": true}
    """
    label_map = {
        'start':   'Start Trading',
        'restart': 'Restart Trading',
    }
    record = {
        'timestamp':  datetime.now().strftime('%Y-%m-%dT%H:%M:%S'),
        'invoked_by': label_map.get(mode, mode),
        'agreed':     True,
    }
    try:
        if os.path.exists(DISCLOSURE_LOG):
            with open(DISCLOSURE_LOG, 'r', encoding='utf-8') as f:
                log = json.load(f)
            if not isinstance(log, list):
                log = []
        else:
            log = []
        log.append(record)
        with open(DISCLOSURE_LOG, 'w', encoding='utf-8') as f:
            json.dump(log, f, indent=4)
        print(f'[PREFLIGHT] Disclosure accepted by user - logged to disclosure_log.json')
    except Exception as exc:
        print(f'[PREFLIGHT] Warning: could not write disclosure log: {exc}')


# ---------------------------------------------------------------------------
# Disclosure dialog
# ---------------------------------------------------------------------------

def show_disclosure(mode: str = 'start') -> None:
    """
    Display the legal disclosure dialog.  The user must type 'yes'
    (case-insensitive) and click Continue to proceed.  Any other action
    (Abort, window close, or wrong text) exits with code 1.

    Called as the very first step of run_preflight() so no trading
    infrastructure is launched before the user agrees.

    Args:
        mode: 'start' (Start Trading) or 'restart' (Restart Trading).
              Used to label the disclosure_log.json record.
    """
    label_map = {
        'start':   'Start Trading',
        'restart': 'Restart Trading',
    }
    mode_label = label_map.get(mode, 'VTB')

    root = tk.Tk()
    root.title(f'VTB - {mode_label}  |  {COPYRIGHT}')
    root.resizable(False, False)

    BG          = '#1E1E2E'
    HDR_BG      = '#00695C'
    FG          = '#FFFFFF'
    FG_DIM      = '#B0B0C0'
    ENTRY_BG    = '#12121E'
    BTN_OK      = '#00897B'
    BTN_OK_HOV  = '#00BFA5'
    BTN_ABORT   = '#424242'
    BTN_ABT_HOV = '#616161'
    TEXT_BG     = '#12121E'
    DISABLED_BG = '#2A2A3E'

    root.configure(bg=BG)

    try:
        hdr_font    = tkfont.Font(family='Segoe UI', size=11, weight='bold')
        copy_font   = tkfont.Font(family='Segoe UI', size=9,  slant='italic')
        disc_font   = tkfont.Font(family='Segoe UI', size=10)
        label_font  = tkfont.Font(family='Segoe UI', size=10, weight='bold')
        entry_font  = tkfont.Font(family='Consolas',  size=11)
        btn_font    = tkfont.Font(family='Segoe UI', size=11, weight='bold')
    except Exception:
        hdr_font = copy_font = disc_font = label_font = entry_font = btn_font = None

    # -- Header --------------------------------------------------------------
    hdr_frame = tk.Frame(root, bg=HDR_BG, pady=12)
    hdr_frame.pack(fill='x')
    tk.Label(hdr_frame, text=f'VTB - {mode_label}',
             bg=HDR_BG, fg='white', font=hdr_font, padx=24).pack(side='left')

    # Copyright line beneath header
    copy_frame = tk.Frame(root, bg=BG, pady=4)
    copy_frame.pack(fill='x')
    tk.Label(copy_frame, text=COPYRIGHT,
             bg=BG, fg=FG_DIM, font=copy_font, padx=24).pack(side='left')

    # -- Disclosure text (scrollable) -------------------------------------
    txt_frame = tk.Frame(root, bg=BG, padx=20, pady=6)
    txt_frame.pack(fill='both')

    scrollbar = tk.Scrollbar(txt_frame)
    scrollbar.pack(side='right', fill='y')

    txt = tk.Text(
        txt_frame,
        width=80, height=16,
        bg=TEXT_BG, fg=FG,
        font=disc_font,
        wrap='word',
        relief='flat',
        padx=12, pady=10,
        yscrollcommand=scrollbar.set,
        state='normal',
    )
    txt.insert('1.0', DISCLOSURE_TEXT)
    txt.config(state='disabled')
    txt.pack(side='left', fill='both')
    scrollbar.config(command=txt.yview)

    # -- Confirmation entry -----------------------------------------------
    confirm_frame = tk.Frame(root, bg=BG, padx=24, pady=10)
    confirm_frame.pack(fill='x')

    tk.Label(
        confirm_frame,
        text='Enter yes to confirm that you agree to hold harmless the\n'
             'developers, employees and/or affiliates:',
        bg=BG, fg=FG, font=label_font, justify='left',
    ).pack(anchor='w')

    yes_var = tk.StringVar()
    yes_entry = tk.Entry(
        confirm_frame,
        textvariable=yes_var,
        bg=ENTRY_BG, fg=FG,
        insertbackground=FG,
        relief='flat', font=entry_font,
        width=20,
        highlightthickness=1,
        highlightbackground='#444',
        highlightcolor=HDR_BG,
    )
    yes_entry.pack(anchor='w', ipady=5, pady=(6, 0))

    # -- Buttons ----------------------------------------------------------
    btn_frame = tk.Frame(root, bg=BG, pady=14, padx=24)
    btn_frame.pack(fill='x')

    choice = ['abort']

    def _update_continue(*_):
        """Enable Continue only when entry is 'yes' (case-insensitive)."""
        if yes_var.get().strip().lower() == 'yes':
            continue_btn.config(state='normal', bg=BTN_OK, cursor='hand2')
        else:
            continue_btn.config(state='disabled', bg=DISABLED_BG, cursor='')

    def _on_continue():
        if yes_var.get().strip().lower() != 'yes':
            return
        choice[0] = 'continue'
        root.destroy()

    def _on_abort():
        root.destroy()

    abort_btn = tk.Button(
        btn_frame, text='Abort', command=_on_abort,
        bg=BTN_ABORT, fg=FG, relief='flat', font=btn_font,
        padx=20, pady=8, cursor='hand2',
        activebackground=BTN_ABT_HOV, activeforeground=FG,
    )
    abort_btn.pack(side='right', padx=(8, 0))
    abort_btn.bind('<Enter>', lambda e: abort_btn.config(bg=BTN_ABT_HOV))
    abort_btn.bind('<Leave>', lambda e: abort_btn.config(bg=BTN_ABORT))

    continue_btn = tk.Button(
        btn_frame, text='Continue', command=_on_continue,
        bg=DISABLED_BG, fg=FG_DIM, relief='flat', font=btn_font,
        padx=20, pady=8, state='disabled',
        activebackground=BTN_OK_HOV, activeforeground='white',
    )
    continue_btn.pack(side='right')
    continue_btn.bind('<Enter>', lambda e: (
        continue_btn.config(bg=BTN_OK_HOV) if continue_btn['state'] == 'normal' else None
    ))
    continue_btn.bind('<Leave>', lambda e: (
        continue_btn.config(bg=BTN_OK) if continue_btn['state'] == 'normal' else None
    ))

    yes_var.trace_add('write', _update_continue)
    root.bind('<Escape>', lambda e: _on_abort())
    root.protocol('WM_DELETE_WINDOW', _on_abort)

    # Centre on screen
    root.update_idletasks()
    w = root.winfo_reqwidth()
    h = root.winfo_reqheight()
    sw = root.winfo_screenwidth()
    sh = root.winfo_screenheight()
    root.geometry(f'{w}x{h}+{(sw - w) // 2}+{(sh - h) // 2}')

    yes_entry.focus_set()
    root.mainloop()

    if choice[0] != 'continue':
        sys.exit(1)

    # Log acceptance to disclosure_log.json
    _append_disclosure_log(mode)


def run_preflight(mode: str = 'start'):
    show_disclosure(mode)    # disclosure agreement - must precede everything else
    check_file_integrity()   # verify CTV files and IB Gateway against manifest
    check_ib_gateway()       # detect paper/live, write config, confirm if live
    text   = _read_config_raw()
    values = _parse_values(text)
    missing = find_missing(text, values)

    if not missing:
        # All good - silent exit
        sys.exit(0)

    # -----------------------------------------------------------------------
    # Build dialog
    # -----------------------------------------------------------------------
    root = tk.Tk()
    root.title('VTB - Required Credentials Missing')
    root.resizable(False, False)

    # -- Colour palette (matches config editor theme) -----------------------
    BG        = '#1E1E2E'
    CARD_BG   = '#2A2A3E'
    ACCENT    = '#00695C'
    FG        = '#FFFFFF'
    FG_DIM    = '#FFFFFF'
    ENTRY_BG  = '#12121E'
    ERR_FG    = '#EF5350'
    BTN_OK    = '#00897B'
    BTN_HOVER = '#00BFA5'
    BTN_CANCEL= '#424242'

    root.configure(bg=BG)

    # -- Fonts --------------------------------------------------------------
    try:
        heading_font = tkfont.Font(family='Segoe UI', size=13, weight='bold')
        label_font   = tkfont.Font(family='Segoe UI', size=11, weight='bold')
        entry_font   = tkfont.Font(family='Consolas',  size=12)
        btn_font     = tkfont.Font(family='Segoe UI', size=12, weight='bold')
        note_font    = tkfont.Font(family='Segoe UI', size=10, weight='bold', slant='italic')
    except Exception:
        heading_font = label_font = entry_font = btn_font = note_font = None

    # -- Header -------------------------------------------------------------
    hdr_frame = tk.Frame(root, bg=ACCENT, pady=14)
    hdr_frame.pack(fill='x')
    tk.Label(hdr_frame, text='Required Credentials Missing',
             bg=ACCENT, fg='white', font=heading_font,
             padx=24).pack(side='left')

    # -- Instruction --------------------------------------------------------
    instr_frame = tk.Frame(root, bg=BG, pady=10, padx=24)
    instr_frame.pack(fill='x')
    tk.Label(instr_frame,
             text='The following fields must be filled in before trading can start.\n'
                  'Enter the missing values below, then click Save & Continue.',
             bg=BG, fg=FG_DIM, font=label_font, justify='left').pack(anchor='w')

    # -- Fields -------------------------------------------------------------
    card = tk.Frame(root, bg=CARD_BG, padx=24, pady=19)
    card.pack(fill='x', padx=24, pady=(0, 10))

    entry_vars = {}   # key -> StringVar

    for i, (key, label, is_secret) in enumerate(missing):
        row = tk.Frame(card, bg=CARD_BG)
        row.pack(fill='x', pady=7)

        tk.Label(row, text=label, bg=CARD_BG, fg=FG, font=label_font,
                 width=34, anchor='w').pack(side='left')

        var = tk.StringVar()
        entry_vars[key] = var
        show = '*' if is_secret else ''
        ent = tk.Entry(row, textvariable=var, show=show,
                       bg=ENTRY_BG, fg=FG, insertbackground=FG,
                       relief='flat', font=entry_font,
                       width=50, highlightthickness=1,
                       highlightbackground='#444', highlightcolor=ACCENT)
        ent.pack(side='left', ipady=5)

        # Show/hide toggle for secret fields
        if is_secret:
            visible = [False]
            def _toggle(e=ent, v=visible):
                v[0] = not v[0]
                e.config(show=('' if v[0] else '*'))
            tk.Button(row, text='👁', bg=CARD_BG, fg=FG_DIM, relief='flat',
                      activebackground=CARD_BG, cursor='hand2',
                      command=_toggle, font=label_font).pack(side='left', padx=(4, 0))

    # -- Error label (hidden until needed) ----------------------------------
    err_var = tk.StringVar()
    err_lbl = tk.Label(root, textvariable=err_var, bg=BG, fg=ERR_FG,
                       font=label_font)
    err_lbl.pack(padx=24, anchor='w')

    # -- Note ---------------------------------------------------------------
    note_frame = tk.Frame(root, bg=BG, padx=24)
    note_frame.pack(fill='x')
    tk.Label(note_frame,
             text='Values are saved to config_ctv2.py.  '
                  'You can also set them in the Config Editor -> Pushover tab.',
             bg=BG, fg=FG_DIM, font=note_font, justify='left').pack(anchor='w')

    # -- Buttons ------------------------------------------------------------
    btn_frame = tk.Frame(root, bg=BG, pady=19, padx=24)
    btn_frame.pack(fill='x')

    result = [False]   # mutable flag

    def _on_save():
        # Validate - no blanks
        for key, label, is_secret in missing:
            if not entry_vars[key].get().strip():
                err_var.set(f'  ✖  {label} cannot be blank.')
                return
        err_var.set('')

        # Write each value back into config text
        current_text = _read_config_raw()
        for key, _, _ in missing:
            current_text = _write_value(current_text, key, entry_vars[key].get().strip())
        try:
            _save_config(current_text)
        except Exception as exc:
            err_var.set(f'  ✖  Could not write config: {exc}')
            return

        result[0] = True
        root.destroy()

    def _on_cancel():
        root.destroy()

    def _btn_enter(btn, color):
        btn.config(bg=color)

    def _btn_leave(btn, color):
        btn.config(bg=color)

    cancel_btn = tk.Button(btn_frame, text='Cancel', command=_on_cancel,
                           bg=BTN_CANCEL, fg=FG, relief='flat', font=btn_font,
                           padx=20, pady=6, cursor='hand2',
                           activebackground='#616161', activeforeground=FG)
    cancel_btn.pack(side='right', padx=(8, 0))
    cancel_btn.bind('<Enter>', lambda e: cancel_btn.config(bg='#616161'))
    cancel_btn.bind('<Leave>', lambda e: cancel_btn.config(bg=BTN_CANCEL))

    save_btn = tk.Button(btn_frame, text='Save & Continue', command=_on_save,
                         bg=BTN_OK, fg='white', relief='flat', font=btn_font,
                         padx=20, pady=6, cursor='hand2',
                         activebackground=BTN_HOVER, activeforeground='white')
    save_btn.pack(side='right')
    save_btn.bind('<Enter>', lambda e: save_btn.config(bg=BTN_HOVER))
    save_btn.bind('<Leave>', lambda e: save_btn.config(bg=BTN_OK))

    # -- Bind Enter key to save ---------------------------------------------
    root.bind('<Return>', lambda e: _on_save())
    root.bind('<Escape>', lambda e: _on_cancel())

    # -- Centre on screen ---------------------------------------------------
    root.update_idletasks()
    w = root.winfo_width()
    h = root.winfo_height()
    sw = root.winfo_screenwidth()
    sh = root.winfo_screenheight()
    root.geometry(f'+{(sw - w) // 2}+{(sh - h) // 2}')

    root.mainloop()

    sys.exit(0 if result[0] else 1)


if __name__ == '__main__':
    import argparse
    _parser = argparse.ArgumentParser(add_help=False)
    _parser.add_argument('--mode', default='start', choices=['start', 'restart'])
    _args, _ = _parser.parse_known_args()
    run_preflight(mode=_args.mode)
