@echo off
REM ============================================================
REM  ABORT_TRADING.bat - CTV2 Emergency Stop Launcher
REM  Revision: 1.0
REM  Calls ABORT_TRADING.ps1 via PowerShell.
REM ============================================================
powershell.exe -ExecutionPolicy Bypass -NoProfile -File "C:\CTV\ABORT_TRADING.ps1"
pause
