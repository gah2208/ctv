"""
pushover_alerts.py - Pushover Notification System for CTV2

Revision: 1.4

CHANGELOG
---------
Rev 1.4: Direction labels changed from UP/DOWN to CALL/PUT in all alert
         messages and titles. UP → CALL, DOWN → PUT.
Rev 1.3: Added send_daily_digest() - EOD Pushover summary with wins,
         losses, net P&L, VIX range, and butterfly count.
Rev 1.2: send_position_parked_alert: removed stale stop_price param and Stop
         line. CTV2 no longer uses stops; parked positions convert to
         butterflies on adverse move. Message now reflects actual behavior.
Rev 1.1: Updated send_test_notification() message text from R9e to CTV2.
Rev 1.0: Updated send_trade_exit_alert to display full dollar amounts
         (entry_price, exit_price, pnl passed as dollars - e.g. $150, not $1.50)
         consistent with send_trade_entry_alert convention.
         Renamed module title from R9e to CTV2.

Sends critical alerts via Pushover when trading stops.
Aggregates non-critical errors and sends daily summary.

CRITICAL ALERTS (immediate):
1. Connection timeout (TWS not running)
2. Account verification failure
3. Manual shutdown (Ctrl+C)
4. Uncaught exceptions (system crash)
5. Risk manager suspension (2 consecutive losses / 3 daily losses)

NON-CRITICAL ALERTS (daily summary):
- Market data errors (2103, 2110, 354, 10167, 10168, 10197)
- Contract not found (200)
- Order rejected (201)
- Historical data timeouts
- Previous day close fetch failures

Configuration:
    Add to config_ctv2.py:
    
    pushover:
      enabled: true
      user_key: "YOUR_USER_KEY"
      api_token: "YOUR_API_TOKEN"
      critical_priority: 1      # 1 = high priority sound, 2 = emergency (requires ack)
      daily_summary_time: "16:30"  # Time to send daily error summary (HH:MM)
"""

from __future__ import annotations

import http.client
import urllib.parse
from datetime import datetime, time
from pathlib import Path
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from enum import Enum


class AlertPriority(Enum):
    """Pushover alert priority levels"""
    SILENT = -2      # No notification
    QUIET = -1       # No sound/vibration
    NORMAL = 0       # Normal priority
    HIGH = 1         # High priority, bypass quiet hours
    EMERGENCY = 2    # Requires acknowledgment


class AlertCategory(Enum):
    """Categories of alerts"""
    CRITICAL = "CRITICAL"       # Trading stopped
    NON_CRITICAL = "NON_CRITICAL"  # Errors but trading continues


@dataclass
class ErrorRecord:
    """Record of a single error event"""
    timestamp: datetime
    error_code: int
    error_message: str
    category: str  # "connection", "market_data", "contract", "order", "historical"
    
    def __str__(self) -> str:
        return f"[{self.timestamp.strftime('%H:%M:%S')}] {self.error_code}: {self.error_message}"


class PushoverAlerter:
    """
    Sends critical alerts via Pushover immediately.
    Aggregates non-critical errors for daily summary.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize Pushover alerter.
        
        Args:
            config: Configuration dict with pushover section
        """
        pushover_config = config.get('pushover', {})
        
        self.enabled = pushover_config.get('enabled', False)
        self.user_key = pushover_config.get('user_key', '')
        self.api_token = pushover_config.get('api_token', '')
        self.critical_priority = pushover_config.get('critical_priority', 1)  # High priority
        
        # Daily summary settings
        self.daily_summary_time_str = pushover_config.get('daily_summary_time', '16:30')
        self.daily_summary_time = self._parse_time(self.daily_summary_time_str)
        self.last_summary_date: Optional[datetime] = None
        
        # Error tracking
        self.error_log_file = Path('daily_errors.txt')
        self.daily_errors: List[ErrorRecord] = []
        
        # Validation
        if self.enabled and (not self.user_key or not self.api_token):
            print("[PUSHOVER] WARNING: Pushover enabled but missing user_key or api_token")
            self.enabled = False
        
        if self.enabled:
            print(f"[PUSHOVER] Alerts enabled")
            print(f"[PUSHOVER] Daily summary at: {self.daily_summary_time_str}")
            print(f"[PUSHOVER] Error log: {self.error_log_file}")
            self._load_todays_errors()
        else:
            print(f"[PUSHOVER] Alerts disabled")
    
    def _parse_time(self, time_str: str) -> time:
        """Parse HH:MM time string"""
        try:
            hour, minute = map(int, time_str.split(':'))
            return time(hour=hour, minute=minute)
        except:
            print(f"[PUSHOVER] Invalid time format '{time_str}', using default 16:30")
            return time(hour=16, minute=30)
    
    def _load_todays_errors(self):
        """Load errors from today's log file"""
        if not self.error_log_file.exists():
            return
        
        today = datetime.now().date()
        try:
            with open(self.error_log_file, 'r') as f:
                for line in f:
                    if line.strip():
                        # Simple parse: [HH:MM:SS] code: message
                        parts = line.strip().split('] ', 1)
                        if len(parts) == 2:
                            timestamp_str = parts[0].replace('[', '')
                            try:
                                # Add today's date to time
                                timestamp = datetime.strptime(
                                    f"{today} {timestamp_str}", 
                                    "%Y-%m-%d %H:%M:%S"
                                )
                                # Only load if from today
                                if timestamp.date() == today:
                                    self.daily_errors.append(parts[1])  # Store raw text
                            except:
                                pass
        except Exception as e:
            print(f"[PUSHOVER] Error loading daily errors: {e}")
    
    def _send_pushover(self, message: str, title: str, priority: int = 0, 
                      sound: str = "pushover") -> bool:
        """
        Send notification via Pushover API.
        
        Args:
            message: Notification message
            title: Notification title
            priority: -2 to 2 (see AlertPriority)
            sound: Notification sound name
            
        Returns:
            True if sent successfully
        """
        if not self.enabled:
            return False
        
        try:
            conn = http.client.HTTPSConnection("api.pushover.net:443")
            conn.request("POST", "/1/messages.json",
                urllib.parse.urlencode({
                    "token": self.api_token,
                    "user": self.user_key,
                    "message": message,
                    "title": title,
                    "priority": priority,
                    "sound": sound,
                    "timestamp": int(datetime.now().timestamp())
                }), { "Content-type": "application/x-www-form-urlencoded" })
            
            response = conn.getresponse()
            success = response.status == 200
            
            if success:
                print(f"[PUSHOVER] Sent: {title}")
            else:
                print(f"[PUSHOVER] Failed ({response.status}): {response.reason}")
            
            conn.close()
            return success
            
        except Exception as e:
            print(f"[PUSHOVER] Error sending notification: {e}")
            return False
    
    # =========================================================================
    # CRITICAL ALERTS - Immediate notification when trading stops
    # =========================================================================
    
    def send_connection_timeout_alert(self):
        """Alert: TWS connection timeout at startup"""
        message = (
            "? TRADING STOPPED - Connection Timeout\n\n"
            "System could not connect to TWS within 30 seconds.\n\n"
            "Check:\n"
            "* TWS is running\n"
            "* Correct port (7497 paper / 7496 live)\n"
            "* Firewall settings"
        )
        self._send_pushover(
            message=message,
            title="CTV2: Connection Timeout",
            priority=self.critical_priority,
            sound="siren"
        )
    
    def send_account_verification_failure_alert(self, account_type: str):
        """Alert: User failed to confirm account type"""
        message = (
            f"? TRADING STOPPED - Account Verification Failed\n\n"
            f"Detected account type: {account_type}\n\n"
            f"User did not confirm live trading intent.\n"
            f"System has shut down."
        )
        self._send_pushover(
            message=message,
            title="CTV2: Account Verification Failed",
            priority=self.critical_priority,
            sound="siren"
        )
    
    def send_manual_shutdown_alert(self, position_open: bool = False):
        """Alert: User pressed Ctrl+C"""
        message = (
            "?? TRADING STOPPED - Manual Shutdown\n\n"
            "User pressed Ctrl+C.\n"
        )
        if position_open:
            message += "\nNote: Position was open at shutdown."
        
        self._send_pushover(
            message=message,
            title="CTV2: Manual Shutdown",
            priority=self.critical_priority,
            sound="pushover"
        )
    
    def send_exception_crash_alert(self, exception_type: str, exception_msg: str, 
                                   traceback_summary: str):
        """Alert: Unhandled exception crashed the system"""
        message = (
            f"? TRADING STOPPED - System Crash\n\n"
            f"Exception: {exception_type}\n"
            f"{exception_msg}\n\n"
            f"Last operations:\n{traceback_summary[:200]}"
        )
        self._send_pushover(
            message=message,
            title="CTV2: SYSTEM CRASH",
            priority=2,  # Emergency - requires acknowledgment
            sound="siren"
        )
    
    def send_risk_suspension_alert(self, reason: str, consecutive_losses: int = 0, 
                                   daily_losses: int = 0):
        """Alert: Risk manager suspended trading"""
        message = (
            f"? TRADING STOPPED - Risk Limit Hit\n\n"
            f"Reason: {reason}\n"
            f"Consecutive losses: {consecutive_losses}\n"
            f"Daily losses: {daily_losses}\n\n"
            f"Run RESTART script to resume trading."
        )
        self._send_pushover(
            message=message,
            title="CTV2: Risk Suspension",
            priority=self.critical_priority,
            sound="siren"
        )
    
    # =========================================================================
    # TRADE EVENTS - Entry, exit, parking notifications
    # =========================================================================

    def send_trade_entry_alert(self, direction: str, long_strike: float,
                               short_strike: float, entry_price: float,
                               spx_price: float, profit_target: float):
        """Alert: Trade entry filled."""
        label = "CALL" if direction == "UP" else "PUT"
        arrow = "↑" if direction == "UP" else "↓"
        spread_str = f"{int(long_strike)}/{int(short_strike)}"
        message = (
            f"{arrow} {label} spread entered\n\n"
            f"Spread:  {spread_str}\n"
            f"Premium: ${entry_price:.2f}\n"
            f"Target:  +${profit_target:.2f} → exit @ ${entry_price + profit_target:.2f}\n"
            f"SPX:     ${spx_price:.2f}"
        )
        self._send_pushover(
            message=message,
            title=f"CTV2: {label} Entry",
            priority=self.critical_priority,
            sound="cashregister"
        )

    def send_trade_exit_alert(self, direction: str, long_strike: float,
                              short_strike: float, entry_price: float,
                              exit_price: float, pnl: float, outcome: str):
        """Alert: Trade exit filled (profit target or stop).
        All prices in dollars (e.g. entry_price=150, exit_price=180, pnl=30).
        """
        if pnl > 0:
            icon = "?"
            sound = "magic"
        else:
            icon = "?"
            sound = "falling"
        label = "CALL" if direction == "UP" else "PUT"
        spread_str = f"{int(long_strike)}/{int(short_strike)}"
        message = (
            f"{icon} {label} {outcome}\n\n"
            f"Spread:  {spread_str}\n"
            f"Entry:   ${entry_price:.0f}  →  Exit: ${exit_price:.0f}\n"
            f"P&L:     ${pnl:+.0f}"
        )
        self._send_pushover(
            message=message,
            title=f"CTV2: {outcome}  ${pnl:+.0f}",
            priority=self.critical_priority,
            sound=sound
        )

    def send_position_parked_alert(self, direction: str, spx_price: float):
        """Alert: Position parked on trend reversal.
        Parked positions are held and converted to butterflies on adverse move.
        """
        label = "CALL" if direction == "UP" else "PUT"
        message = (
            f"⏸ {label} position PARKED\n\n"
            f"Trend reversed - position held.\n"
            f"Will convert to butterfly on adverse move.\n"
            f"SPX:  ${spx_price:.2f}"
        )
        self._send_pushover(
            message=message,
            title="CTV2: Position Parked",
            priority=0,
            sound="pushover"
        )

    # =========================================================================
    # NON-CRITICAL ERRORS - Log for daily summary
    # =========================================================================
    
    def log_non_critical_error(self, error_code: int, error_message: str, 
                               category: str = "general"):
        """
        Log a non-critical error for daily summary.
        Does NOT send immediate notification.
        
        Args:
            error_code: IB error code
            error_message: Error message text
            category: Error category (connection, market_data, contract, order, historical)
        """
        timestamp = datetime.now()
        error_text = f"[{timestamp.strftime('%H:%M:%S')}] {error_code}: {error_message}"
        
        # Add to memory
        self.daily_errors.append(error_text)
        
        # Append to file
        try:
            with open(self.error_log_file, 'a') as f:
                f.write(error_text + '\n')
        except Exception as e:
            print(f"[PUSHOVER] Error writing to log: {e}")
    
    def check_and_send_daily_summary(self):
        """
        Check if it's time to send daily error summary.
        Call this periodically (e.g., every minute in main loop).
        """
        if not self.enabled:
            return
        
        now = datetime.now()
        today = now.date()
        
        # Check if we've already sent summary today
        if self.last_summary_date == today:
            return
        
        # Check if it's time to send (within 1 minute window)
        current_time = now.time()
        summary_time = self.daily_summary_time
        
        # Create 1-minute window around target time
        if (summary_time.hour == current_time.hour and 
            abs(summary_time.minute - current_time.minute) <= 1):
            
            self._send_daily_summary()
            self.last_summary_date = today
    
    def _send_daily_summary(self):
        """Send daily error summary notification"""
        if not self.daily_errors:
            # No errors today - send "all clear" message
            message = "? No errors today. System ran cleanly!"
            self._send_pushover(
                message=message,
                title="CTV2: Daily Summary (All Clear)",
                priority=0,
                sound="none"
            )
        else:
            # Group errors by type
            error_counts = {}
            for error in self.daily_errors:
                # Extract error code
                try:
                    code = error.split(']')[1].split(':')[0].strip()
                    error_counts[code] = error_counts.get(code, 0) + 1
                except:
                    pass
            
            # Build summary message
            total = len(self.daily_errors)
            summary_lines = [f"Total: {total} errors"]
            for code, count in sorted(error_counts.items(), key=lambda x: -x[1]):
                summary_lines.append(f"* {code}: {count}x")
            
            message = (
                f"?? Daily Error Summary\n\n" +
                '\n'.join(summary_lines) +
                f"\n\nCheck daily_errors.txt for details."
            )
            
            self._send_pushover(
                message=message,
                title=f"CTV2: {total} Errors Today",
                priority=0,
                sound="pushover"
            )
        
        # Archive/clear the log for next day
        self._archive_daily_errors()
    
    def _archive_daily_errors(self):
        """Archive today's errors and start fresh"""
        if not self.error_log_file.exists():
            return
        
        try:
            # Rename to dated archive
            archive_name = f"daily_errors_{datetime.now().strftime('%Y%m%d')}.txt"
            archive_path = self.error_log_file.parent / archive_name
            self.error_log_file.rename(archive_path)
            
            # Clear memory
            self.daily_errors = []
            
            print(f"[PUSHOVER] Archived errors to {archive_name}")
        except Exception as e:
            print(f"[PUSHOVER] Error archiving log: {e}")
    
    def send_test_notification(self):
        """Send a test notification to verify Pushover is working"""
        message = (
            "This is a test notification from CTV2.\n\n"
            "If you receive this, Pushover alerts are configured correctly!"
        )
        return self._send_pushover(
            message=message,
            title="CTV2: Test Alert",
            priority=0,
            sound="pushover"
        )


    def send_daily_digest(self, wins: int, losses: int, net_pnl: float,
                          bfly_count: int, bfly_expiration: float,
                          vix_min: float, vix_max: float):
        """EOD summary alert - total trades, P&L, VIX range, open butterflies."""
        if not self.enabled:
            return
        total = wins + losses
        pnl_sign = '+' if net_pnl >= 0 else ''
        win_pct = f"{100 * wins // total}%" if total > 0 else "N/A"

        lines = [
            f"SESSION SUMMARY",
            f"",
            f"Trades : {total}  ({wins}W / {losses}L)  {win_pct}",
            f"Net P&L: {pnl_sign}${net_pnl:.0f}",
        ]
        if bfly_count > 0:
            lines.append(f"Bfly   : {bfly_count} open  +${bfly_expiration:.0f} expiry est.")
        vix_line = ""
        if vix_min > 0 and vix_max > 0:
            vix_line = f"VIX9D  : {vix_min:.1f} - {vix_max:.1f}"
            lines.append(vix_line)

        message = "\n".join(lines)
        self._send_pushover(
            message=message,
            title="CTV2: EOD Summary",
            priority=0,
            sound="none"
        )

    def send_critical(self, message: str):
        """Immediate high-priority alert - used by watchdog for feed failures."""
        self._send_pushover(
            message=message,
            title='CTV2: Critical Alert',
            priority=self.critical_priority,
            sound='siren'
        )

    def send_alert(self, message: str):
        """Standard-priority alert - used by watchdog for resubscription warnings."""
        self._send_pushover(
            message=message,
            title='CTV2: Alert',
            priority=1,
            sound='pushover'
        )


# Backwards compatibility wrapper
class SMSAlerter:
    """Wrapper to maintain compatibility with existing code"""
    def __init__(self, config: Dict[str, Any]):
        self.pushover = PushoverAlerter(config)
    
    def send_suspension_alert(self, reason: str, restart_path: str = "") -> bool:
        """Send risk suspension alert"""
        # Parse reason to extract loss counts
        if "consecutive" in reason.lower():
            losses = int(reason.split()[0])
            self.pushover.send_risk_suspension_alert(
                reason=reason,
                consecutive_losses=losses,
                daily_losses=0
            )
        elif "losses today" in reason.lower():
            losses = int(reason.split()[0])
            self.pushover.send_risk_suspension_alert(
                reason=reason,
                consecutive_losses=0,
                daily_losses=losses
            )
        else:
            self.pushover.send_risk_suspension_alert(reason=reason)
        return True
    
    def send_restart_alert(self) -> bool:
        """Send trading resumed notification"""
        message = "? Trading has RESUMED\n\nAll loss counters reset to 0."
        return self.pushover._send_pushover(
            message=message,
            title="CTV2: Trading Resumed",
            priority=1,
            sound="magic"
        )


def test_pushover():
    """Test Pushover notifications"""
    config = {
        'pushover': {
            'enabled': True,
            'user_key': 'YOUR_USER_KEY',  # Replace with your user key
            'api_token': 'YOUR_API_TOKEN',  # Replace with your API token
            'critical_priority': 1,
            'daily_summary_time': '16:30'
        }
    }
    
    alerter = PushoverAlerter(config)
    
    print("Testing Pushover notifications...")
    alerter.send_test_notification()
    print("Check your phone/device for the test notification!")


if __name__ == '__main__':
    test_pushover()
