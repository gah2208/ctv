#!/usr/bin/env python3
# Copyright (c) Gregory Howard 2026  All rights reserved
"""
ctv2_runner.py - CTV2 Live / Paper Trading Runner

CHANGELOG
---------
Rev 124: _check_entry_auctions: immediate step to MAX_PREMIUM when
         midpoint rises above current bid during auction. Previously
         only stepped +$0.05 per interval regardless of midpoint.
Rev 123: Stepped entry auction added. _on_entry_quote now starts a
         price auction at midpoint instead of rejecting when ask >
         MAX_PREMIUM. _check_entry_auctions() steps bid +$0.05 every
         BID_STEP_INTERVAL seconds toward MAX_PREMIUM. Restarts from
         new midpoint if market improves below auction_start_mid.
         Abandons on direction flip, acceleration loss, strike change,
         or SPX within ENTRY_OTM_ABANDON pts of long strike.
         PendingEntry gains auction state fields. New config params:
         BID_STEP_INTERVAL=15, ENTRY_OTM_ABANDON=3.0.
Rev 122: _on_5s_bar simplified. sep_ema/sep_ema_prev removed - they
         were redundant smoothing of already-smooth EMA separation.
         Confirmation now uses sep_curr > sep_prev directly (growing
         separation). _SIG_CONFIRM_TICKS module constant removed;
         replaced by cfg.SIG_CONFIRM_TICKS_SEC // 5 so the window is
         user-configurable in seconds via Config Editor.
Rev 121: Comment-only cleanup. EMA3/EMA15 terminology updated to
         EMA36/EMA180 in architecture header, QualityFilter docstring
         (marked as dead code), and _post_warmup_entry_check docstring.
         No logic or behavior change.
Rev 120: Rolling signal confirmation replaces fixed 3-minute bar entry
       trigger. _on_5s_bar now evaluates EMA separation and sep_ema slope
       on every 5-second tick. When _SIG_CONFIRM_TICKS (6) consecutive
       ticks satisfy: sep > threshold AND sep_ema > sep_ema_prev AND
       direction consistent, signal is confirmed and entry queued
       immediately. Entry queuing removed from _on_bar_complete (now
       comment-only). _sig_confirm_dir, _sig_confirm_count, _sig_active_dir
       state variables added to __init__. _SIG_CONFIRM_TICKS = 6 module
       constant added. Requires spx_bars.py Rev 7 (sep_ema in get_ema_state).
Rev 119: _StdoutTracker class added. Wraps sys.stdout in run_live() to
        track the content of the last complete line written by any thread.
        Pre-market countdown checks 'T-minus' in tracker.last before
        deciding to ANSI-overwrite or plain-print, so lines from other
        threads (VIX poll errors, STRM reconnects) are never erased.
        stdout restored to original in finally block. _hb_printed removed.
Rev 118: Buying power fetch moved from run_live() to _calc_contracts().
        Lazy evaluation on first fractional entry - by 10:00 ET account
        data is always populated so the fetch succeeds on the first read.
        Result cached in _available_funds for the session. Startup buying
        power block in run_live() removed entirely.
        ibkr_orders.py Rev 18: get_option_buying_power() docstring updated
        to reflect lazy-call context.
Rev 117: get_option_buying_power() call moved to after the mode banner,
        after VIX poll and STRM threads are started. Blocks up to 30s
        while accountValues() populates, ensuring all startup noise
        (STRM seed, VIX tick, BP result) lands before the pre-market
        countdown begins. Main loop comment updated.
Rev 116: _account_subscribed gate removed from pre-market countdown in
        main loop. ibkr_orders.py Rev 16 eliminates the flag entirely;
        countdown now fires unconditionally when pre-market, relying on
        the natural 30-second interval to clear STRM/VIX startup noise.
Rev 115: _run_warmup() removed - dead code since IBKR stream now seeds
        EMAs from historical data. Call site, section header, and method
        body deleted. Pre-market countdown added to main loop: gated on
        30-second interval so STRM/VIX startup messages land first.
        First update is a plain print; subsequent updates use ANSI escape
        (cursor-up + erase-line) to overwrite the previous countdown so
        only one line persists.
Rev 114: Pre-market "waiting" message added to _check_market_schedule().
        When the system starts on a valid trading day before 09:30, the
        schedule check now prints "[SCHED] Pre-market start - market
        opens at HH:MM ET (T-minus Xm)" so the user knows the system is
        live and running rather than appearing stuck after startup.
        ibkr_stream.py Rev 6: EMA seed RTH guard removed - seeds from
        prior session closing data when starting pre/post-market.
Rev 113: MAX_ACTIVE_TRADES config parameter removed. Trade slot limits are
        now hardcoded constants: _MAX_ACTIVE=1 (one active/in-flight trade at
        a time - structural property, not user-tunable) and _MAX_PARKED=2
        (parked slot cap - limits loss exposure to 2x premium). _can_open(),
        _try_enter_pending(), and _try_chain_entry() updated to enforce the
        two limits independently. MAX_ACTIVE_TRADES removed from startup
        banner. config_ctv2_default.py Rev 1.5 and ctv2_config_editor.py
        Rev 5.0 ship with this change.
Rev 112: _collapse_thread fill detection corrected.
        status.get('status') == 'Filled' changed to == 'filled' to match
        the lowercase value returned by get_order() via _STATUS_MAP.
        status.get('avg_fill', ask) corrected to 'avg_fill_price' to match
        the actual dict key. Previously, collapse fills were never detected;
        every attempt ran the full 2-min poll and reported "not filled after
        2 min" even on clean fills, leaving the position at CONV_SPREAD_WIDTH.
Rev 111: clientId reverted to stable hardcoded values: 2 for
        IBKROrderManager, 1 for IBKRStream. Rev 109 introduced
        REVISION-based clientIds to prevent stale slot collisions, but
        this causes clientId to change on every release. The correct
        fix is disconnect() in all shutdown paths (also Rev 109) which
        releases the slot cleanly. Stable clientIds restored.
Rev 110: Entry expiry moved to step 3a in _on_bar_complete, before the
        new entry check (step 4). Previously expiry ran inside
        _try_enter_pending (step 5) - too late. A pending entry expiring
        on a viable bar would block step 4 from re-queuing, leaving
        Pending=0 with no fresh entry despite a valid signal.
Rev 109: Gap-open logic fully removed (~15 touch points). disconnect()
        wired into all shutdown paths (finally, SIGINT, market-close).
        REVISION-based clientId passed to IBKROrderManager and IBKRStream
        (REVISION for orders, REVISION+1 for stream) - eliminates stale
        clientId collisions on restart.
Rev 108: Sticky direction applied in _on_bar_complete. current_dir now
        holds the last confirmed direction when sep < EMA_DIRECTION_THRESHOLD
        rather than flipping on any micro-crossover. EMA_DIRECTION_THRESHOLD
        now correctly gates both viability AND direction changes - a
        sub-threshold crossover is treated as noise, not a direction flip.
        Prevents pending entry cancellation and spurious direction_change
        events on insignificant EMA crossovers.
Rev 107: _recover_state() log messages updated - stale 'Tradier positions'
        references replaced with 'IBKR positions'. Recovery logic was
        already querying IBKR correctly; messages were never updated
        during migration.
Rev 106: Synthetic fill path removed. Paper mode now sends real orders to
        IBKR paper account and polls for genuine IBKR-simulated fills,
        identical to live mode. Removed: _poll_order_fill synthetic fill
        block, all preview=not LIVE_TRADING kwargs, collapse early-return
        guard. Mode banner updated. LIVE_TRADING now controls paper vs live
        account only - not whether orders are placed.
Rev 105: _collapse_thread hardened for IBKR order rejection edge cases.
        - Bid/ask width check before placing: if far wing is illiquid
          (spread > MAX_BID_ASK_WIDTH), waits 15s and retries rather than
          chasing a bad fill or getting rejected for insufficient hedge liquidity.
        - On place_collapse returning None (rejection), retries after 15s.
        - On 2-min poll timeout, cancels the stale order before retry to
          prevent duplicate fills.
        - Max 3 total attempts; OER cost <= 6 actions worst-case.
        - Final attempt proceeds even if quote is wide (better than leaving
          position at CONV_SPREAD_WIDTH permanently).
        - Immediate execution preserved as default (no unnecessary delay);
          15s pause only fires on actual quote/rejection failures.
        REVISION bumped to 104.
Rev 104: _check_late_day_exits() now retries failed butterfly conversions
        up to 6 total attempts (initial + 5 retries) at 5-minute intervals
        from INTRINSIC_EXIT_TIME until 16:00. Pacing: up to 4 positions x
        2 OER actions (submit + cancel) x 6 attempts = 48 worst-case, under
        IBKR's 50:1 OER daily limit even with zero fills. _on_order_not_filled
        now cancels the live IBKR order before reverting BFLY_CONV state,
        preventing duplicate fills on retry. New state vars:
        _intrinsic_entries_cleared, _last_intrinsic_attempt,
        _intrinsic_attempt_count. REVISION bumped to 103.
Rev 103: PM_BOUNDARY removed entirely.
        - _park_trade(): removed "if now >= cfg.PM_BOUNDARY: _initiate_butterfly_
          conversion(PM_CONVERT)" block. Parked trades now remain parked until
          INTRINSIC_EXIT_TIME (14:30) which converts all open positions to
          butterflies. Any positions still open after that simply expire at close.
        - PM_CONVERT removed from bfly_reason enum comment and schedule comment.
        - PM_BOUNDARY removed from config editor, write_config(), and
          config_ctv2_default.py. LAST_ENTRY_TIME at 14:00 is the sole
          late-day entry gate.
Rev 102: Collapse-after-WIN support.
        - _collapse_thread() added: fires as a daemon thread immediately
          after every WIN fill. Quotes and places a net-debit BAG order
          (BUY near_strike / SELL conv_strike) that reduces the
          CONV_SPREAD_WIDTH conversion spread back to SPREAD_WIDTH,
          producing a standard butterfly. Priced at ask x ENTRY_SLIPPAGE.
          Fill is polled best-effort (up to 2 min); no state transitions
          required as the LiveButterfly is recorded before thread starts.
        - _on_win_fill: threading.Thread(_collapse_thread) call added
          immediately after butterflies.append().
        - Startup banner logs CONV_SPREAD_WIDTH.
Rev 101: VIX9D feed switched from Tradier REST to yfinance (free).
        - _start_vix_poll: get_quote('VIX9D') + field extraction replaced
          by self.client.get_vix9d() (ibkr_orders.get_vix9d, yfinance
          ^VIX9D). Eliminates $23.50/mo IBKR VIX data subscription.
          ~15-min delay is acceptable for a 60-second gate poll.
        - Removed dead _vix_ticker_id and _vix_subscribed from __init__
          (IBKR-era leftovers, never read since Tradier migration).
Rev 100: SPXW contract pre-cache on 9:30 bar close.
        - IBKROrderManager.precache_contracts(center) added (ibkr_orders
          Rev 2). Bulk-qualifies all SPXW calls + puts within +/-1.5% of
          center price at SPREAD_WIDTH increments via a single batched
          qualifyContracts() call. Populates _opt_cache so entry quote and
          order placement never block on individual contract lookups.
        - _on_bar_complete: fires precache_contracts(close) on the 9:30 bar
          (wall-clock 9:33) using the bar close as center. Guarded by
          self._contracts_precached so it runs exactly once per session.
          self._contracts_precached = False added to __init__.
        - _option(): on cache miss, lazily qualifies the single contract
          immediately (trade proceeds), then calls precache_contracts()
          centered on the missed strike. _recaching flag prevents
          re-entrant precache calls.
Rev 99: Phase 3 IBKR migration - order layer swap + Phase 4 stream cleanup.
        - tradier_client.py + tradier_orders.py replaced by ibkr_orders.py
          (IBKROrderManager). Single class covers all broker interactions:
          calc_strikes, calc_chained_strikes, get_spread_quote, place_entry,
          place_win_sell, cancel, get_order, get_todays_expiration,
          get_option_buying_power, get_positions, get_eod_report.
        - __init__: self.order_manager = IBKROrderManager();
          self.client = self.order_manager (all self.client.* call sites
          satisfied without further runner edits).
        - round_to_tick now imported from ibkr_orders (identical logic).
        - client= arg removed from IBKRStream() construction (Phase 4).
          IBKRStream.client= was accepted-but-ignored since Rev 98; now
          the call site is clean.
Rev 98: Phase 2 IBKR migration - stream swap + scaled config wiring.
        - TradierStream replaced by IBKRStream (ibkr_stream.py). Interface
          is identical; client= arg passed through and ignored by IBKRStream.
        - ibkr_scale.build_scaled_config() called in __init__ and stored as
          self.cfg (ScaledConfig). All 10 index-point and option-dollar
          denominated parameters now read from self.cfg instead of cfg:
          EMA_DIRECTION_THRESHOLD, SPREAD_WIDTH, GAP_OPEN_THRESHOLD,
          WIN_TARGET_BUFFER, PARK_CONVERT_EMA_LOW/MID/HIGH,
          ACTIVE_ADVERSE_MOVE, MAX_PREMIUM, MAX_BID_ASK_WIDTH.
          Non-scalable params (time gates, counts, flags, VIX, slippage,
          percentages) continue to read directly from config_ctv2 as cfg.XXX.
          Dead-code QualityFilter references to cfg.EMA_DIRECTION_THRESHOLD
          left unchanged (class is not instantiated since Rev 86).
Rev 97: _try_chain_entry now checks self.pending_entries for same-direction
        conflict, matching the guard already present in _can_open(). Prevents
        a chain from queuing while a normal pending entry in the same direction
        is already being processed.
Rev 96: 5-second entry gate. Entry decisions now checked on every 5-second
        bar via on_5s_bar_close callback rather than waiting for 3-minute
        boundaries. Acceleration (is_accelerating) checked in
        _try_enter_pending on every cycle - if not accelerating, cycle skips
        silently with no retry consumed. Premium > MAX_PREMIUM no longer
        consumes a retry - transient market condition. MAX_ENTRY_RETRIES
        replaced by time-based ENTRY_TIMEOUT config parameter - pending entry
        dropped if signal_time age exceeds timeout. WIN_MOVE removed;
        win_target now short_strike +/- WIN_TARGET_BUFFER (new config param).
        _try_enter_pending refactored to use _live_spx directly, removing
        bar dict dependency so it can be called from 5s callback.
Rev 95: EMA state persisted across restarts. _save_state() now writes an
        'ema' key (ema36, ema180, sep_prev, sep_curr, last_close) to the
        daily state JSON on every save. _recover_state() reads it back and
        calls SpxBarAggregator.seed_emas() so the aggregator resumes from
        the last known values instead of re-warming from zero after a crash.
Rev 94: Removed stale IBKR stop-order reference in _park_trade() comment.
        PM_BOUNDARY comment now correctly describes butterfly conversion.
Rev 93: Live EOD Tradier order report. _print_tradier_eod_report() added;
        called from _check_market_close() when LIVE_TRADING=True. Queries
        Tradier order history to answer: total long cost, which entries
        converted and at what price, how many expired without a sale, and
        total cost of expired legs. Premature _print_eod_summary() call
        removed from _check_late_day_exits() - replaced with single log
        line; EOD summary and Pushover digest now fire once at 16:00 only.
Rev 92: _on_butterfly_conv_quote now calls place_win_sell (not place_close).
        BFLY_CONV conversion adds new legs (sell_to_open / buy_to_open) -
        it never closes existing legs. min_profit_price=0 passed so there
        is no floor; whatever bid we can get is accepted.
Rev 91: Late-stage strike conflict re-check in _entry_quote_thread.
        - After quote returns valid (ask > 0) but before _on_entry_quote,
          re-evaluates (long_s, right) / (short_s, right) against
          _existing_shorts() / _existing_longs(). Catches the race where a
          WIN fill creates a butterfly while the quote thread was in-flight,
          which the earlier check in _try_enter_pending could not see.
          Prints [SKIP] and resets mktdata_requested without consuming a retry.
Rev 90: Expired vertical accounting fix.
        - _check_market_close() now sweeps self.trades at 16:00 before
          calling _print_eod_summary(). Any trade still open (not converted
          to butterfly, not explicitly closed) is logged via _log_trade()
          with exit_credit=0.0 and outcome='EXPIRED' so the full premium
          paid counts as a loss in session P&L and win/loss totals.
          Prints [EOD] notice for each expired position.
Rev 89: Schedule messages clarified; EOD trade summary CSV added.
        - _check_market_schedule() sleep messages now append
          "(market opens 09:30 ET, signals begin 10:00 ET)" so users
          know what the 09:00 wakeup is leading to.
        - Banner printed in run_live() immediately after schedule check
          returns: "[SCHED] Good morning. Market opens at 09:30 ET..."
        - _write_eod_summary() writes logs/summary_YYYYMMDD.csv at EOD:
          one row per trade, joining ENTRY+EXIT rows from the session log.
          Columns: date, trade_id, direction, right, long_strike,
          short_strike, entry_time, premium_paid, exit_credit, net_pnl,
          outcome, state_at_close.
Rev 88: Strike conflict check now differentiates by option right (C/P).
        - PendingEntry gains right: str field, set at queue time at all
          5 creation sites - never derived at check time.
        - LiveButterfly gains right: str field, copied from LiveTrade.right
          at WIN fill and BFLY_CONV fill. Persisted to state file and
          restored on recovery via _reconstruct_butterfly().
        - _existing_longs() and _existing_shorts() return (strike, right)
          tuples instead of bare strike floats.
        - Both conflict check call sites (_try_enter_pending,
          _try_chain_entry) compare (strike, right) tuples.
        - _trade_dict() and _butterfly_dict() both serialize right.
        - All CSV log rows use stored .right field instead of deriving
          from direction.
        - Eliminates false-positive skip when e.g. an open UP (call) trade
          shares a strike number with a proposed DOWN (put) entry.
Rev 84.1: Restored _check_market_schedule() as a proper standalone method
        wired into run_live() after auth, before expiration check.
        The calendar logic existed in _on_bar_close_callback (dead code,
        never wired) and was removed during dead-code cleanup in Rev 84.
        Now correctly gates startup on NYSE full trading days.
Rev 87: Perpetual-loop runner - no longer exits at EOD.
        - _SessionComplete sentinel exception raised by _check_market_close()
          at 16:00 instead of spinning on "Press Ctrl+C to exit".
        - run_live() catches _SessionComplete and returns normally.
        - main() wraps run_live() in a while True loop; fresh TradingApp
          created each session so all state resets cleanly.
        - _check_market_schedule() now detects after-hours starts on valid
          trading days and sleeps to 09:00 ET on the next trading day.
Rev 86: Native SPX bars + quality filter replaced by EMA36/EMA180.
        - spy_bars.py replaced by spx_bars.py (SpxBarAggregator).
          SPX ticks feed bar construction directly - no SPY proxy,
          no ratio conversion, no spx_equivalent().
        - _run_warmup() gutted - no REST seed needed. EMA180 self-warms
          from 09:30 live ticks; operationally valid by TRADING_START.
        - QualityFilter removed from active signal path. direction,
          viable, separation, direction_change now derived from
          SpxBarAggregator.get_ema_state() at each bar boundary.
        - ema_confirm gate removed - EMA36/EMA180 is sole signal.
        - _spx_spy_ratio, spx_equivalent(), _fetch_spx_spy_ratio() removed.
        - _prev_direction added to track direction changes across bars.
        - _on_bar_complete, _post_warmup_entry_check, _check_gap_open,
          _try_chain_entry updated throughout.
        - BAR print line now shows all OHLC in native SPX terms.
        - [SIG] line: EMA36/EMA180/sep replaces EMA3/EMA5/EMA15.
Rev 85: Gate pre-market bars in _on_bar_complete. Any bar with
        bar_start_time before 09:30 ET is discarded immediately - no EMA
        updates, no logging, no signal evaluation. Market is not open.
Rev 84: Two NameError crash fixes found in system integrity check.
        - _on_bar_complete: bare send_critical(msg) call replaced with
          self.pushover.send_critical(msg) guarded by if self.pushover.
          NameError would crash the bar callback thread the first time the
          VIX heartbeat timeout fired (VIX feed silent >= 10 min), silently
          killing all bar processing, entries, and win-target checks.
        - _on_win_quote: f-string referenced undefined name win_order_id
          instead of local variable order_id. NameError crashed the win
          quote thread on every WIN, leaving the trade in PENDING_WIN_QUOTE
          forever and preventing all win fills from completing.
Rev 83: SPY as signal source + acceleration gate for chain reentry.
        - SpyBarAggregator (spy_bars.py) now owns bar construction and
          rolling EMA36/EMA180 state. TradierStream wired to spy_aggregator.
        - self._spx_spy_ratio: live SPX/SPY ratio, seeded by REST at startup
          and updated per 3-minute bar using self._live_spx / spy_bar_close.
        - spx_equivalent(spy_price): single conversion function, all trading
          logic continues to operate in SPX terms.
        - _on_bar_complete: converts SPY bar close to SPX before all logic.
        - _try_enter_pending: uses self.last_bar_close (SPX) not bar['close'].
        - _check_gap_open: converts SPY bar open to SPX for gap calculation.
        - _try_chain_entry: acceleration gate added - spy_agg.is_accelerating()
          must return True before chain reentry is allowed.
        - _run_warmup: unchanged SPX seed for quality_filter; additionally
          seeds spy_agg EMAs with SPY-equivalent values after warmup.
Rev 82: Gap trades now bypass TRADING_START gate in _on_bar_complete.
        Previously gap entries queued at 09:30 would sit in pending_entries
        until 10:00 because _try_enter_pending was gated behind TRADING_START.
Rev 81: Stop stream in _check_market_close() at 16:00 ET. Previously the
        WebSocket stream kept running after session_done, hitting its TTL
        and attempting reconnects against a closed market, which could
        cause unhandled exceptions.
Rev 80: run_startup_checks() no longer takes revision parameter.
        _check_auth_poll() also updated. Both now pass PACKAGE_VERSION
        from config_ctv2 to check_auth() for version gating.
Rev 79: Replaced non-ASCII arrows in two print statements (butterfly fill
        noise adverse). Non-ASCII characters crash the win quote thread
        on Windows cp1252 consoles, causing win conversion to loop forever.
Rev 78: Added self.prev_day_bars = [] to __init__ and populated it in
        _run_warmup(). _check_gap_open() referenced self.prev_day_bars
        but it was never declared, causing AttributeError on the first
        bar callback after 9:30.
Rev 77: Removed per-bar _check_auth_poll() call. Auth is checked once at
        startup by run_startup_checks(). Per-bar polling hit GitHub ~130x/day
        and combined with no-cache headers caused HTTP 429 rate limit errors.
Rev 76: Fixed misleading warmup message before market open. Pre-market
        now prints '[WARMUP] Pre-market - no today bars to replay' instead
        of 'Market just opened'. Both cases still skip today-bar replay.
Rev 75: Sandbox mode removed entirely.
        - TRADIER_SANDBOX config field gone. Client always uses production
          endpoint. Paper trading = LIVE_TRADING=False (preview orders,
          nothing fills). Live trading = LIVE_TRADING=True.
        - Removed sandbox warmup shortcut in _run_warmup().
        - Removed sandbox buying-power $0 note.
        - Mode banner simplified: PAPER or LIVE (no SANDBOX).
        - TradingApp mode arg default changed from 'sandbox' to 'paper'.
Rev 70: LIVE_TRADING flag. All Polygon references removed.
        - LIVE_TRADING = False (config): all orders use preview=True, nothing
          fills. Live data, simulated orders (true paper trading).
        - LIVE_TRADING = True: real orders, real fills.
        - Startup banner clearly shows PAPER/LIVE mode.
        - Removed STREAM_SOURCE, POLYGON_API_KEY, PolygonStream import
          and _run_warmup_polygon(). Tradier production WebSocket covers all
          data needs.
Rev 69: Three sandbox UX fixes (sandbox subsequently removed in Rev 75).
Rev 68: Tradier sandbox WebSocket fallback (sandbox subsequently removed).
Rev 67: Three IBKR migration fixes:
        - Removed dead _check_market_schedule() call from run_live() (method
          never existed in Tradier runner; get_todays_expiration handles
          non-trading days).
        - Added missing VIX_POLL_INTERVAL = 60 module-level constant
          (referenced in _start_vix_poll but never defined).
        - _recover_state() rewritten for Tradier: added _parse_occ() to
          extract right/strike/expiry from OCC symbols; replaced IBKR field
          names (expiry, right, strike, qty) with Tradier equivalents
          (symbol/quantity); removed all IBKR references in log strings.
        - Removed orphaned _check_late_day_exits() IBKR market-data block
          (cancel_market_data / _mktdata) - method does not exist in
          TradierOrderManager.
Rev 66: cancelOrder() called with 1 argument - IBKR API takes only
        orderId, no manualOrderCancelTime arg. Removed stale "" arg
        from all 4 call sites. Crashed runner on first win order reprice.
Rev 65: Fix contract cache misses causing entry failures.
        - Pre-market wait target changed from 9:30+5s to 9:33 so
          cache is centered on actual market open price, not prior close.
        - _precache_contract_ids_sync accepts optional center_price param.
        - _try_enter_pending triggers re-cache on first conId miss
          (retry==1) centered on current bar price before next retry.
Rev 64: All user-configured time gates (TRADING_START, LAST_ENTRY_TIME)
        now use wall-clock time. bt is only used to identify the 9:30
        bar for gap detection. Users set times assuming wall-clock:
        to act on the 10:00 bar closing, set TRADING_START = 10:03.
Rev 63: LAST_ENTRY_TIME gate uses wall-clock time instead of bar time.
        bt < cfg.LAST_ENTRY_TIME -> datetime.now().time() < LAST_ENTRY_TIME.
        bt=15:37 arrives at wall-clock 15:40 - entries were being queued
        up to 3 minutes past the cutoff.
Rev 62: Gap trade 9:45 expiry now uses wall-clock time instead of
        bar time. bt=9:45 arrives at wall-clock 9:48 - pending gap
        entry was surviving 3 extra minutes. Fix: datetime.now().time()
        >= 9:45 replaces bt >= dtime(9,45).
Rev 61: Gap-open entry fires immediately on 9:30 bar instead of
        deferring to 9:33 bar. 9:30 bar data arrives at wall-clock
        9:33 - the extra bar delay was dead time. _gap_open_pending
        is now processed in the same bar it is set. bt==9:33 deferred
        entry block removed. _check_gap_open docstring updated.
Rev 60: Daily EOD digest Pushover alert. _vix_day_min / _vix_day_max
        tracked from first VIX tick. send_daily_digest() called from
        _print_eod_summary() when PUSHOVER_EOD_DIGEST is True.
Rev 59: Fill Outcome Monitoring and Butterfly Outcome Tracking.
        - LiveTrade: added entry_limit_price, vix_at_entry fields
        - LiveButterfly: added vix_at_entry field
        - CSV: added contracts, entry_limit_price, fill_slippage,
          vix_at_entry, bfly_reason columns to all row types
        - Fixed BFLY_EXPIRATION exit_credit (was logging spx_close,
          now logs estimated dollar value)
        - BUTTERFLY row: added bfly_reason, net_cost, vix_at_entry
Rev 58: VIX_MAX_ENTRY ceiling - block new entries when VIX9D > VIX_MAX_ENTRY.
        Butterfly conversion unaffected. VIX feed absent (0.0) = no block.
Rev 57: VIX heartbeat check - send_critical() alert if no VIX tick
        arrives within VIX_HEARTBEAT_TIMEOUT minutes during market hours.
        Clears on tick resume. _vix_last_tick_time and
        _vix_heartbeat_alerted fields added.
Rev 56: Renamed MAX_SPREAD_WIDTH to MAX_BID_ASK_WIDTH everywhere.
Rev 55: Fix AttributeError in _check_market_schedule - replaced pytz
        localize() with datetime tzinfo= constructor (zoneinfo compatible).
Rev 54: _check_market_schedule() now sleeps until 09:00 ET on the next full
        trading day instead of polling every 60s. Logs the target date and
        hours remaining so user knows exactly when the runner will wake.
Rev 53: Market calendar check added. _check_market_schedule() called after
        connect, before historical bars. Uses pandas_market_calendars (NYSE)
        to detect weekends, holidays, and half-days. Idles in 60s loop on
        non-trading or half-day sessions; proceeds on full trading days only.
        pandas-market-calendars added to CTV_Install.cs pip install list.
Rev 52: Log first VIX9D tick on arrival: "[IBKR] VIX9D first tick: xx.xx".
Rev 51: VIX symbol changed from "VIX" (30-day) to "VIX9D" (9-day). Better
        proxy for 0DTE conditions while remaining on same scale as the
        18/25 tier thresholds.
Rev 50: VIX contract symbol corrected from "$VIX.X" to "VIX". "$VIX.X" is
        TWS display shorthand; the API requires plain "VIX" for reqMktData.
Rev 49: VIX subscription deferred from run_live() to first 2104 (market data
        farm connected) signal in error(). Prevents error 200 at startup caused
        by subscribing before farms are ready. _vix_subscribed flag prevents
        duplicate subscriptions on subsequent 2104 messages.
Rev 48: tickPrice negative price guard made purpose-aware. WIN_QUOTE and
        BUTTERFLY_CONV ticks with negative prices are now accepted and converted
        via abs() - BAG SELL combo quotes legitimately arrive negative (credit).
        ENTRY and ENTRY_REPRICE negative prices still discarded as before.
Rev 47: Precache contract definition corrected - symbol="SPX" with
        tradingClass="SPXW" is the correct IBKR form for PM-settled weeklies.
        symbol="SPXW" does not exist in IBKR's security definition.
Rev 46: Precache exchange SMART->CBOE for reqContractDetails. SMART does not
        resolve index options; CBOE is required for both SPX and SPXW lookups.
Rev 45: SPXW fix - reqContractDetails precache now requests SPXW (PM-settled
        weekly chain) instead of SPX (AM-settled monthly). position() callback
        and _recover_state() filter updated to accept both SPX and SPXW symbols
        to correctly collect option legs during position recovery.
Rev 44: Entry blocked logging - all entry paths now print [ENTRY] blocked
        reason when _can_open() or ema_confirm fails, showing MAX_ACTIVE_TRADES
        limit or EMA3/EMA5 confirmation failure explicitly.
Rev 43: Added diagnostic logging in tickPrice for discarded zero/negative ticks
        and incomplete bid/ask slots, to diagnose PENDING_WIN_QUOTE stall where
        IB options farm returns 0 or -1 for one side of the quote.
Rev 42: Park alert: removed stale stop_price arg from send_position_parked_alert
        call. CTV2 no longer uses stops on parked positions.
Rev 41: Market data error recovery in error() and _check_stale_orders().
        - error(): when reqId is in _mktdata, pops slot and reverts trade state:
          WIN_QUOTE -> ACTIVE, BUTTERFLY_CONV -> PARKED, ENTRY/REPRICE -> resets
          mktdata_requested. Handles error 10197 (competing session) and any
          other market data failure code.
        - _check_stale_orders(): safety net catches PENDING_WIN_QUOTE trades
          with win_order_id=0 (quote errored before order placed) and reverts
          to ACTIVE so _check_win_targets retries next bar.
Rev 40: EMA3/EMA5 confirmation gate applied to gap-open entries.
        Regular and re-entries were already gated by ema_confirm; gap trade
        at 9:33 now also requires EMA3 > EMA5 (UP) or EMA3 < EMA5 (DOWN).
Rev 39: Wall-clock timestamps on async fill/win events.
        - [FILL] now prefixed with HH:MM:SS of entry fill
        - [WIN ] win sell placed line prefixed with HH:MM:SS
        - [WIN ] credit/net line prefixed with HH:MM:SS of win fill
Rev 38: [FILL] log line: min_profit replaced with min_conv_credit and
        min_net_profit for clarity (min_profit was the conversion credit floor,
        not the net profit - misleading label).
Rev 37: Remove outright-close fallback; display improvements.
        - Removed: _initiate_close(), _on_close_quote(), CLOSING trade state
        - Butterfly conv failures now leave trade PARKED to expire at expiry
        - tickPrice: removed noisy per-tick BID/ASK prints; replaced with one
          consolidated [MKT] line per quote showing relevant price (ask for
          entries, bid for sells) and C/P option type
        - _check_stale_orders: cancel event now logged as [CANCEL] with
          trade ID, C/P type, and order age in seconds
        *** REMINDER: REVISION bumped 36->37. Update auth.json. ***
Rev 36: Fix PendingEntry stuck forever on unanswered market data snapshot.
        - _check_stale_orders now resets mktdata_requested=False for any
          PendingEntry that got no quote response in a full bar, allowing
          _try_enter_pending to retry the snapshot request next bar.
        *** REMINDER: REVISION bumped 35->36. Update auth.json. ***
Rev 35: Bar label now shows wall-clock time (when we act) plus completed
        bar start time for reference. e.g. "BAR | 13:48 (prev bar 13:45)".
        Confirms all decisions happen at bar open using prior bar's data.
        *** REMINDER: REVISION bumped 34->35. Update auth.json. ***
Rev 34: Fix strike selection using wrong bar's close price.
        - Moved _try_enter_pending(bar) from step 1 (before signal detection)
          to step 5 (after signal detection). Entries queued in step 4 are now
          processed immediately against the signal bar's close, not the
          following bar's close. Corrects ATM strike by 1 strike width (~5 pts).
        *** REMINDER: REVISION bumped 33->34. Update auth.json. ***
Rev 33: Stale entry order repricing.
        - Added: entry_order_placed_time field on LiveTrade
        - Added: _check_stale_orders() now reprices PENDING_FILL entries
          after one full bar; cancels with CSV CANCELLED row if EMA no
          longer viable; retries indefinitely if premium too high
        - Added: _on_entry_reprice_quote() handler
        - Added: _log_cancelled() CSV writer for abandoned entries
        *** REMINDER: REVISION bumped 32->33. Update auth.json. ***
Rev 32: Gap trade entry refinements.
        - Entry deferred from 9:30 to 9:33 bar (market settles first)
        - Gap direction still measured against 9:30 open price
        - Limit = min(MAX_PREMIUM/100, ask * GAP_ENTRY_SLIPPAGE) tick-rounded
        - 9:45 expiry also clears _gap_open_pending if entry never queued
        *** REMINDER: REVISION bumped 31->32. Update auth.json. ***
Rev 31: Gap trade entry improvements.
        - Removed MAX_BID_ASK_WIDTH gate for gap trades (9:30 liquidity is thin)
        - Replaced hardcoded $2.00 ask cap with cfg.MAX_PREMIUM
        - Gap trades now use GAP_ENTRY_SLIPPAGE (1.10) instead of ENTRY_SLIPPAGE
        - New config param: GAP_ENTRY_SLIPPAGE = 1.10
        *** REMINDER: REVISION bumped 30->31. Update auth.json. ***
Rev 30: Removed _check_integrity() entirely - manifest-based file hashing
        caused false Pushover alerts every bar. Python + TWS checks remain
        in START_TRADING/RESTART at launch only.
        *** REMINDER: REVISION bumped 29->30. Update auth.json. ***
Rev 29: Stability fixes.
        - Added: _post_warmup_done guard - prevents double-fire of
          _post_warmup_entry_check (called from both _recover_state path
          and historicalDataEnd)
        - Added: disconnect() in finally block - ensures clientId slot
          releases on crash, not just on clean Ctrl+C
        - Validated: useRTH=1 on all 3 reqHistoricalData calls is correct
          for RTH-only SPX cash index data
        *** REMINDER: REVISION bumped 28->29. Update auth.json with new revision. ***
Rev 28: POSITION_SIZE - variable contract sizing.
        - Added: POSITION_SIZE config param (default=1, current behavior unchanged)
        - Added: self._available_funds; reqAccountSummary at startup; accountSummary callback
        - Added: _calc_contracts(ask) helper; contracts field on LiveTrade
        - All 3 order builders now receive trade.contracts
        *** REMINDER: REVISION bumped 27->28. Update auth.json with new revision. ***
Rev 27: EMA/VIX adaptive park conversion + noise band protection.
        - Removed: PARK_MAX_MOVE, REVERSAL_CLOSE_MIN_MOVE, _check_reversal_closes()
        - Added: ACTIVE trades in noise band tracked via noise_entry_spx; butterfly
          on ACTIVE_ADVERSE_MOVE pts adverse (NOISE_ADVERSE)
        - Added: PARKED trades butterfly-converted when sep >= EMA/VIX tier threshold
          in confirmed opposite direction (EMA_VIX)
        - Added: VIX live subscription ($VIX.X / IND / CBOE, ticker 3998)
        - _process_trades() now receives separation arg
        *** REMINDER: REVISION bumped 26->27. Update auth.json with new revision. ***
Rev 26: Added startup authorization and in-session polling via ctv2_auth.
        - run_startup_checks() called at top of run_live() before TWS connects
        - Unknown machine ID sends Pushover to Greg + prints registration message
        - In-session poll every bar; confirmed disable honored at 16:00 ET
        - At 16:00: writes local AUTH_DISABLED.flag + sends Pushover to user
        - self._machine_id stored for poll use
Rev 25: Removed stop_order_id field from LiveTrade and all associated
        cancelOrder guards - stop orders are never placed; parked positions
        are managed via butterfly conversion only.
        Fixed send_trade_exit_alert call sites to pass full dollar amounts
        (consistent with send_trade_entry_alert - $150 not $1.50).

ARCHITECTURE
============
Direction : EMA36/EMA180 separation on 5-second bars
Entry     : BAG LMT BUY vertical spread  (ask ? 1.05, tick-rounded)
Win exit  : Intrabar SPX monitoring via historicalDataUpdate ticks
              ? win_target = short_strike +/- WIN_TARGET_BUFFER
              ? on trigger: request conversion spread quote
              ? place LMT SELL at max(bid ? 0.95, min_profit_price/100), tick-rounded
Park      : direction flips against trade -> state = PARKED
              noise band + adverse >= ACTIVE_ADVERSE_MOVE -> butterfly (NOISE_ADVERSE)
              sep >= EMA/VIX tier threshold opp direction -> butterfly (EMA_VIX)
Reversal  : replaced by EMA_VIX park conversion - no reversal close
Intrinsic : at INTRINSIC_EXIT_TIME -> convert all open trades to butterfly
Chain     : after WIN fill, re-enter using conv_strike as new long_strike if direction viable
CONFIG NOTE
===========
New params in config_ctv2.py (Park & Risk section):
    PARK_CONVERT_EMA_LOW/MID/HIGH, PARK_VIX_LOW/HIGH, ACTIVE_ADVERSE_MOVE
"""

from __future__ import annotations

import csv
import json
import signal
import sys
import time
import threading
import traceback
from datetime import datetime, time as dtime
from pathlib import Path
from typing import Optional, Dict, List, Tuple
from dataclasses import dataclass, field
from zoneinfo import ZoneInfo

import config_ctv2 as cfg
from ctv2_auth import run_startup_checks, fetch_auth, check_auth, write_local_disable_flag
from ibkr_orders import IBKROrderManager, round_to_tick
from ibkr_stream import IBKRStream
from ibkr_scale import build_scaled_config
from risk_manager import RiskManager, TradeOutcome as RiskOutcome
from spx_bars import SpxBarAggregator

try:
    from pushover_alerts import PushoverAlerter
    PUSHOVER_AVAILABLE = True
except ImportError:
    PUSHOVER_AVAILABLE = False

# -- safe fallback for new park/noise params if not yet in config --------------
PARK_CONVERT_EMA_LOW  = getattr(cfg, 'PARK_CONVERT_EMA_LOW',  4.0)
PARK_CONVERT_EMA_MID  = getattr(cfg, 'PARK_CONVERT_EMA_MID',  5.0)
PARK_CONVERT_EMA_HIGH = getattr(cfg, 'PARK_CONVERT_EMA_HIGH', 6.0)
PARK_VIX_LOW          = getattr(cfg, 'PARK_VIX_LOW',          18.0)
PARK_VIX_HIGH         = getattr(cfg, 'PARK_VIX_HIGH',         25.0)
ACTIVE_ADVERSE_MOVE   = getattr(cfg, 'ACTIVE_ADVERSE_MOVE',   10.0)
POSITION_SIZE         = getattr(cfg, 'POSITION_SIZE',         1)
NOTIFY_ALL_TRADES     = getattr(cfg, 'PUSHOVER_NOTIFY_ALL_TRADES',      True)
NOTIFY_RISK_SUSPEND   = getattr(cfg, 'PUSHOVER_NOTIFY_RISK_SUSPEND',    True)
NOTIFY_LOST_CONNECTION= getattr(cfg, 'PUSHOVER_NOTIFY_LOST_CONNECTION', True)
NOTIFY_SYSTEM_CRASH   = getattr(cfg, 'PUSHOVER_NOTIFY_SYSTEM_CRASH',    True)

LIVE_TRADING          = getattr(cfg, 'LIVE_TRADING', False)
VIX_HEARTBEAT_TIMEOUT = 10  # minutes of silence before critical alert
VIX_POLL_INTERVAL     = 60  # seconds between VIX9D REST polls
VIX_MAX_ENTRY         = getattr(cfg, 'VIX_MAX_ENTRY', 35.0)  # block entries above this VIX9D level

_MAX_ACTIVE = 1   # hard-coded: only one active/in-flight trade at a time
_MAX_PARKED = 2   # hard-coded: max parked trades (loss exposure cap)

ET = ZoneInfo('America/New_York')


# =============================================================================
# Session control
# =============================================================================

class _StdoutTracker:
    """
    Thin thread-safe wrapper around sys.stdout that tracks the content of
    the most recently completed output line written by any thread.

    Installed in run_live() so the pre-market countdown can determine
    whether its own line is still the last thing on the terminal.  If
    'T-minus' is in tracker.last the countdown uses ANSI cursor-up to
    overwrite it; otherwise it prints normally - preserving any line
    another thread may have written in between.
    """
    def __init__(self, wrapped):
        self._w    = wrapped
        self._lock = threading.Lock()
        self.last  = ''   # content of the last complete line written
        self._buf  = ''   # accumulator for partial write() calls

    def write(self, text):
        with self._lock:
            self._buf += text
            while '\n' in self._buf:
                line, self._buf = self._buf.split('\n', 1)
                self.last = line
        return self._w.write(text)

    def flush(self):
        return self._w.flush()

    def __getattr__(self, name):
        return getattr(self._w, name)


class _SessionComplete(Exception):
    """Raised by _check_market_close() to signal a clean EOD shutdown.
    Caught in run_live() and returned normally so main() can loop to the
    next trading day.  Never propagates as a crash."""


# =============================================================================
# MACD + QualityFilter  (ported verbatim from ctv2_options_backtester.py)
# =============================================================================

class MACD:
    def __init__(self, fast: int, slow: int, signal: int):
        self.af   = 2.0 / (fast   + 1)
        self.as_  = 2.0 / (slow   + 1)
        self.asig = 2.0 / (signal + 1)
        self.ema_fast   = None
        self.ema_slow   = None
        self.ema_signal = None
        self.histogram  = None
        self._buf_fast  = []
        self._buf_slow  = []
        self._warm_fast = False
        self._warm_slow = False
        self._fast_per  = fast
        self._slow_per  = slow

    def update(self, close: float) -> Optional[float]:
        if not self._warm_fast:
            self._buf_fast.append(close)
            if len(self._buf_fast) >= self._fast_per:
                self.ema_fast   = sum(self._buf_fast) / len(self._buf_fast)
                self._warm_fast = True
        else:
            self.ema_fast = close * self.af + self.ema_fast * (1 - self.af)

        if not self._warm_slow:
            self._buf_slow.append(close)
            if len(self._buf_slow) >= self._slow_per:
                self.ema_slow   = sum(self._buf_slow) / len(self._buf_slow)
                self._warm_slow = True
        else:
            self.ema_slow = close * self.as_ + self.ema_slow * (1 - self.as_)

        if not (self._warm_fast and self._warm_slow):
            return None

        macd_line = self.ema_fast - self.ema_slow
        if self.ema_signal is None:
            self.ema_signal = macd_line
        else:
            self.ema_signal = macd_line * self.asig + self.ema_signal * (1 - self.asig)
        self.histogram = macd_line - self.ema_signal
        return self.histogram


class QualityFilter:
    """DEAD CODE - retained for historical reference only. Not instantiated.
    Was the EMA3/EMA15 MACD direction filter ported from the backtester.
    Replaced by EMA36/EMA180 separation computed directly in SpxBarAggregator.
    EMA3 on 3-min bars = EMA36 on 5-sec bars.
    EMA15 on 3-min bars = EMA180 on 5-sec bars.
    """

    _EMA5_K = 2.0 / (5 + 1)   # smoothing factor for EMA5

    def __init__(self):
        self.macd = MACD(cfg.MACD_FAST, cfg.MACD_SLOW, cfg.MACD_SIGNAL)
        self._confirmed_direction: Optional[str] = None
        self._prev_ema3: Optional[float] = None
        self._ema5: Optional[float] = None

    def update(self, close: float) -> dict:
        self.macd.update(close)
        # EMA5: seed on first bar, then smooth
        if self._ema5 is None:
            self._ema5 = close
        else:
            self._ema5 = close * self._EMA5_K + self._ema5 * (1.0 - self._EMA5_K)
        state = self._evaluate()
        self._prev_ema3 = self.macd.ema_fast
        return state

    def _evaluate(self) -> dict:
        ema3  = self.macd.ema_fast
        ema15 = self.macd.ema_slow
        state = {
            'viable': False, 'direction': self._confirmed_direction,
            'direction_change': False, 'separation': None,
            'ema3_slope': 0.0, 'ema5': self._ema5, 'reason': 'WARMUP',
        }
        if ema3 is None or ema15 is None:
            return state

        if self._prev_ema3 is not None:
            state['ema3_slope'] = ema3 - self._prev_ema3

        separation = abs(ema3 - ema15)
        state['separation'] = separation
        raw_dir = 'UP' if ema3 > ema15 else 'DOWN'

        if separation > cfg.EMA_DIRECTION_THRESHOLD and raw_dir != self._confirmed_direction:
            self._confirmed_direction = raw_dir
            state['direction_change'] = True

        state['direction'] = self._confirmed_direction
        state['viable']    = separation > cfg.EMA_DIRECTION_THRESHOLD
        state['reason']    = ('VIABLE' if state['viable']
                              else f'LOW_SEP({separation:.2f}<{cfg.EMA_DIRECTION_THRESHOLD})')
        return state

    def is_viable(self, direction: str) -> bool:
        """Returns True if direction is currently confirmed and separation is above threshold."""
        if self._confirmed_direction != direction:
            return False
        ema3  = self.macd.ema_fast
        ema15 = self.macd.ema_slow
        if ema3 is None or ema15 is None:
            return False
        return abs(ema3 - ema15) > cfg.EMA_DIRECTION_THRESHOLD


# =============================================================================
# Data structures
# =============================================================================

@dataclass
class LiveTrade:
    trade_id:         int
    direction:        str          # 'UP' or 'DOWN'
    right:            str          # 'C' or 'P'
    ctv_cv:           float        # SPX at bar open when entry was signalled
    entry_time:       datetime
    state:            str          # 'PENDING_FILL' | 'ACTIVE' | 'PENDING_WIN_QUOTE'
                                   # | 'PARKED' | 'PENDING_BUTTERFLY'
    long_strike:      float
    short_strike:     float
    conv_strike:      float
    premium_paid:     float        # actual dollars paid (avgFillPrice ? 100)
    win_target:       float        # SPX level that triggers win sell
    min_profit_price: float        # min credit dollars (premium_paid ? MIN_CONV_CREDIT_PCT)
    entry_order_id:   int
    spx_at_fill:      float = 0.0  # _live_spx at moment of entry fill
    win_order_id:     int   = 0    # set when win sell order placed
    park_spx:         float = 0.0  # SPX price at park event
    win_order_placed_time:   object = None  # datetime when win/bfly sell order placed
    entry_order_placed_time: object = None  # datetime when entry order was placed
    bfly_reason:      str   = ''   # reason passed to _initiate_butterfly_conversion
    noise_entry_spx:    float = 0.0  # bar.close when trade first entered noise band
    contracts:          int   = 1    # number of contracts (from POSITION_SIZE at entry)
    entry_limit_price:  float = 0.0  # limit price placed on entry order (per share)
    vix_at_entry:       float = 0.0  # VIX9D at time of entry fill


@dataclass
class LiveButterfly:
    """
    Post-WIN position: 3-leg butterfly sitting at IBKR.
    System does not manage these intraday - they expire or are swept at 15:30.
    `right` is derived: 'C' if direction == 'UP' else 'P'.
    """
    trade_id:    int
    direction:   str          # 'UP' or 'DOWN'
    right:       str          # 'C' or 'P' - copied from LiveTrade.right at conversion
    long_strike: float        # lowest strike  (+1 leg from original entry)
    short_strike:float        # middle strike  (-2 legs: entry short + WIN short)
    conv_strike: float        # highest strike (+1 leg from WIN conversion buy)
    premium_paid:float        # original entry cost (dollars)
    win_credit:  float        # dollars received for conversion sell
    net_cost:    float        # premium_paid - win_credit
    entry_time:  datetime
    win_time:    Optional[datetime]
    spx_at_fill:  float = 0.0  # SPX at original entry fill
    vix_at_entry: float = 0.0  # VIX9D at time of original entry fill
    bfly_reason:  str   = ''   # EMA_VIX | NOISE_ADVERSE | INTRINSIC


@dataclass
class PendingEntry:
    direction:         str
    signal_time:       datetime
    ctv_cv:            float      # bar.close at signal (used for ctv_cv on trade)
    right:             str  = ''  # 'C' or 'P' - set at queue time, never derived later
    retries:           int  = 0
    mktdata_requested: bool = False
    # Auction state
    auction_bid:        float             = 0.0   # current live bid (0 = not started)
    auction_start_mid:  float             = 0.0   # midpoint when auction began
    auction_last_step:  Optional[datetime] = None  # time of last bid placement
    auction_order_id:   int               = 0     # live order id being auctioned
    auction_long_s:     float             = 0.0   # strikes locked at auction start
    auction_short_s:    float             = 0.0
    auction_conv_s:     float             = 0.0
    # Auction state
    auction_bid:       float              = 0.0   # current live bid (0 = auction not started)
    auction_start_mid: float              = 0.0   # midpoint when auction began
    auction_last_step: Optional[datetime] = None  # time of last bid placement
    auction_order_id:  int                = 0     # live order being auctioned (0 = none)
    auction_long_s:    float              = 0.0   # strikes locked at auction start
    auction_short_s:   float              = 0.0
    auction_conv_s:    float              = 0.0


# =============================================================================
# Main application
# =============================================================================

class TradingApp:
    """
    CTV2 live runner.  Inherits EWrapper + EClient exactly as R10.
    All TWS plumbing is verbatim-R10; trading logic is CTV2.
    """

    REVISION = 124  # used as IBKR clientId - increment on each release

    def __init__(self, mode: str = 'paper'):
        self.mode = mode

        # -- Thread safety -------------------------------------------------
        # Stream tick callbacks and order poll threads all acquire this lock
        # before touching shared state.
        self._lock = threading.RLock()

        # -- SPX bar aggregator (signal source) ----------------------------
        # Builds 5-second and 3-minute bars from native SPX ticks.
        # Maintains rolling EMA36/EMA180 for direction/separation/accel gate.
        # on_bar_complete is wired as the bar close callback.
        self._spx_agg = SpxBarAggregator(
            on_bar_close    = self._on_bar_complete,
            on_5s_bar_close = self._on_5s_bar,
        )

        # -- IBKR broker layer --------------------------------------------
        # clientId=2 for orders, clientId=1 for stream - stable and fixed.
        # disconnect() in all shutdown paths prevents stale slot collisions.
        self.order_manager = IBKROrderManager(client_id=2)
        self.client        = self.order_manager   # satisfies self.client.* call sites
        self._stream: IBKRStream = None   # wired in run_live()

        # -- Scaled config (SPX=1.0, XSP=0.1) -----------------------------
        self.cfg = build_scaled_config()

        self.tz = ET

        # -- Direction tracking --------------------------------------------
        # Previous confirmed direction - used to detect direction changes.
        self._prev_direction: Optional[str] = None

        # -- Rolling signal confirmation state ----------------------------
        # Tracks consecutive 5-second ticks meeting confirmation criteria.
        # When count reaches _SIG_CONFIRM_TICKS the signal fires immediately
        # without waiting for the 3-minute bar boundary.
        self._sig_confirm_dir:   Optional[str] = None  # direction accumulating
        self._sig_confirm_count: int           = 0     # consecutive qualifying ticks
        self._sig_active_dir:    Optional[str] = None  # last fully confirmed direction

        # -- Trade state --------------------------------------------------
        self.trades:          List[LiveTrade]     = []
        self.butterflies:     List[LiveButterfly] = []
        self.pending_entries: List[PendingEntry]  = []
        self._trade_id_seq:   int = 0

        # -- Position recovery (mid-day restart) ---------------------------
        self._recovery_positions: List[dict] = []
        self._recovery_complete:  bool = False

        # -- Live SPX price (updated on every stream tick) -----------------
        self._live_spx: float = 0.0

        # -- Live VIX price (updated via reqMktData on $VIX.X) -------------
        self._vix: float = 0.0
        self._vix_last_tick_time: Optional[datetime] = None
        self._vix_heartbeat_alerted: bool = False
        self._vix_day_min: float = 0.0  # session VIX low
        self._vix_day_max: float = 0.0  # session VIX high

        # -- Session flags -------------------------------------------------
        self.live_trading_active:  bool = False
        self._intrinsic_done: bool = False
        self._intrinsic_entries_cleared: bool = False
        self._last_intrinsic_attempt = None   # datetime of last conversion attempt
        self._intrinsic_attempt_count: int = 0
        self._session_done:   bool = False

        # -- Contract pre-cache flag ----------------------------------------
        # Set True after the 9:30 bar triggers precache_contracts().
        self._contracts_precached: bool = False

        # -- Post-warmup entry check guard ---------------------------------
        self._post_warmup_done: bool = False

        # -- Session P&L accumulators (updated on every _log_trade call) --
        self._session_wins:             int   = 0
        self._session_losses:           int   = 0
        self._session_pnl:              float = 0.0
        self._session_bfly_expiration:  float = 0.0
        self._bfly_logged:              bool  = False

        # -- Authorization -------------------------------------------------
        self._machine_id:             str  = ''    # set by run_live() after auth
        self._auth_disable_pending:   bool = False # disable detected mid-session
        self._auth_disable_reason:    str  = ''    # reason from auth.json

        # -- Available funds (for fractional POSITION_SIZE) ----------------
        self._available_funds: float = 0.0

        # -- SPX price tracking (also updated by stream bar callback) ------
        self.last_bar_close: float = 0.0
        self.prev_day_bars:  list  = []

        # -- Risk management -----------------------------------------------
        risk_config = {
            'risk_management': {
                'suspension_enabled':    True,
                'max_consecutive_losses': 2,
                'max_daily_losses':       3,
                'restart_flag_file':      'C:\\CTV\\RESTART_TRADING.flag',
            }
        }
        self.risk_mgr = RiskManager(risk_config)

        # -- Pushover alerts -----------------------------------------------
        self.pushover = None
        if PUSHOVER_AVAILABLE:
            try:
                pushover_config = {
                    'pushover': {
                        'enabled':            getattr(cfg, 'PUSHOVER_ENABLED',           False),
                        'user_key':           getattr(cfg, 'PUSHOVER_USER_KEY',           ''),
                        'api_token':          getattr(cfg, 'PUSHOVER_API_TOKEN',          ''),
                        'critical_priority':  getattr(cfg, 'PUSHOVER_CRITICAL_PRIORITY',  1),
                        'daily_summary_time': getattr(cfg, 'PUSHOVER_SUMMARY_TIME',       '16:30'),
                    }
                }
                self.pushover = PushoverAlerter(pushover_config)
            except Exception as e:
                print(f"[PUSHOVER] Init failed: {e}")

        # -- CSV trade log -------------------------------------------------
        self._init_trade_log()

        # -- Order manager -------------------------------------------------
        # (already created above as self.order_manager)

        # Derive display mode from actual config flag
        _live_trade = getattr(cfg, 'LIVE_TRADING', False)
        _mode_label = 'LIVE' if _live_trade else 'PAPER'
        print(f"\n{'='*60}")
        print(f" CTV2 Runner rev{self.REVISION} - {_mode_label} MODE")
        print(f"{'='*60}")
        print(f"[CONFIG] WIN_TARGET_BUFFER   : {self.cfg.WIN_TARGET_BUFFER} pts")
        print(f"[CONFIG] CONV_SPREAD_WIDTH  : {self.cfg.CONV_SPREAD_WIDTH} pts  (collapse fires immediately after WIN fill)")
        print(f"[CONFIG] SPREAD_WIDTH        : {self.cfg.SPREAD_WIDTH} pts")
        print(f"[CONFIG] MIN_CONV_CREDIT_PCT : {cfg.MIN_CONV_CREDIT_PCT}")
        print(f"[CONFIG] MAX_PREMIUM         : ${self.cfg.MAX_PREMIUM:.0f}")
        print(f"[CONFIG] TRADING_START       : {cfg.TRADING_START}")
        print(f"[CONFIG] LAST_ENTRY_TIME     : {cfg.LAST_ENTRY_TIME}")
        print(f"[CONFIG] INTRINSIC_EXIT_TIME : {cfg.INTRINSIC_EXIT_TIME}")
        print(f"[CONFIG] ENTRY_TIMEOUT        : {cfg.ENTRY_TIMEOUT} min")
        print(f"[CONFIG] ACTIVE_ADVERSE_MOVE : {self.cfg.ACTIVE_ADVERSE_MOVE} pts")
        print(f"[CONFIG] PARK_EMA LOW/MID/HI : {self.cfg.PARK_CONVERT_EMA_LOW}/{self.cfg.PARK_CONVERT_EMA_MID}/{self.cfg.PARK_CONVERT_EMA_HIGH}")
        print(f"[CONFIG] PARK_VIX LOW/HIGH   : {PARK_VIX_LOW}/{PARK_VIX_HIGH}")
        print(f"[CONFIG] MAX_ACTIVE/PARKED   : {_MAX_ACTIVE}/{_MAX_PARKED} (hardcoded)")
        print(f"[CONFIG] POSITION_SIZE       : {POSITION_SIZE}")
        print(f'[PUSHOVER] {"enabled" if self.pushover else "disabled"}')
        print(f"{'='*60}\n")

    # =========================================================================
    # CSV trade log
    # =========================================================================

    def _init_trade_log(self):
        log_dir = Path('logs')
        log_dir.mkdir(exist_ok=True)
        ts  = datetime.now().strftime('%Y%m%d_%H%M%S')
        csv_path = log_dir / f"ctv2_{self.mode}_{ts}.csv"
        self._log_file   = open(csv_path, 'w', newline='')
        self._log_path   = csv_path
        self._log_writer = csv.DictWriter(self._log_file, fieldnames=[
            'record_type',
            'trade_id', 'direction', 'right', 'entry_time',
            'long_strike', 'short_strike', 'conv_strike',
            'contracts', 'ctv_cv', 'premium_paid', 'min_profit_price', 'win_target',
            'entry_limit_price', 'fill_slippage', 'vix_at_entry',
            'spx_at_fill', 'outcome', 'exit_credit', 'net_pnl', 'net_cost',
            'bfly_reason', 'state_at_close',
        ])
        self._log_writer.writeheader()
        self._log_file.flush()
        print(f"[CSV ] Trade log: {csv_path}")

    def _log_entry(self, trade: LiveTrade):
        """Write an ENTRY row when a fill is confirmed."""
        fill_slip = trade.premium_paid - (trade.entry_limit_price * 100)
        self._log_writer.writerow({
            'record_type':      'ENTRY',
            'trade_id':         trade.trade_id,
            'direction':        trade.direction,
            'right':            trade.right,
            'entry_time':       trade.entry_time.isoformat(),
            'long_strike':      trade.long_strike,
            'short_strike':     trade.short_strike,
            'conv_strike':      trade.conv_strike,
            'contracts':        trade.contracts,
            'ctv_cv':           f"{trade.ctv_cv:.2f}",
            'premium_paid':     f"{trade.premium_paid:.2f}",
            'min_profit_price': f"{trade.min_profit_price:.2f}",
            'win_target':       f"{trade.win_target:.2f}",
            'entry_limit_price':f"{trade.entry_limit_price:.2f}",
            'fill_slippage':    f"{fill_slip:.2f}",
            'vix_at_entry':     f"{trade.vix_at_entry:.2f}",
            'spx_at_fill':      f"{trade.spx_at_fill:.2f}",
            'outcome':          '',
            'exit_credit':      '',
            'net_pnl':          '',
            'net_cost':         '',
            'bfly_reason':      '',
            'state_at_close':   'ACTIVE',
        })
        self._log_file.flush()

    def _log_trade(self, trade: LiveTrade, outcome: str,
                   exit_credit: float, state_at_close: str):
        """Write an EXIT row. outcome = WIN | STOP | INTRINSIC | NOISE_ADVERSE | EMA_VIX | PM_CONVERT etc."""
        net = exit_credit - trade.premium_paid
        self._session_pnl += net
        if net >= 0:
            self._session_wins += 1
        else:
            self._session_losses += 1
        fill_slip = trade.premium_paid - (trade.entry_limit_price * 100)
        self._log_writer.writerow({
            'record_type':      'EXIT',
            'trade_id':         trade.trade_id,
            'direction':        trade.direction,
            'right':            trade.right,
            'entry_time':       trade.entry_time.isoformat(),
            'long_strike':      trade.long_strike,
            'short_strike':     trade.short_strike,
            'conv_strike':      trade.conv_strike,
            'contracts':        trade.contracts,
            'ctv_cv':           f"{trade.ctv_cv:.2f}",
            'premium_paid':     f"{trade.premium_paid:.2f}",
            'min_profit_price': f"{trade.min_profit_price:.2f}",
            'win_target':       f"{trade.win_target:.2f}",
            'entry_limit_price':f"{trade.entry_limit_price:.2f}",
            'fill_slippage':    f"{fill_slip:.2f}",
            'vix_at_entry':     f"{trade.vix_at_entry:.2f}",
            'spx_at_fill':      f"{trade.spx_at_fill:.2f}",
            'outcome':          outcome,
            'exit_credit':      f"{exit_credit:.2f}",
            'net_pnl':          f"{net:.2f}",
            'net_cost':         '',
            'bfly_reason':      '',
            'state_at_close':   state_at_close,
        })
        self._log_file.flush()

    def _log_cancelled(self, trade: LiveTrade, reason: str):
        """Write a CANCELLED row when a pending entry is abandoned before fill."""
        self._log_writer.writerow({
            'record_type':      'CANCELLED',
            'trade_id':         trade.trade_id,
            'direction':        trade.direction,
            'right':            trade.right,
            'entry_time':       trade.entry_time.isoformat(),
            'long_strike':      trade.long_strike,
            'short_strike':     trade.short_strike,
            'conv_strike':      trade.conv_strike,
            'contracts':        trade.contracts,
            'ctv_cv':           f"{trade.ctv_cv:.2f}",
            'premium_paid':     '',
            'min_profit_price': '',
            'win_target':       '',
            'entry_limit_price':'',
            'fill_slippage':    '',
            'vix_at_entry':     f"{trade.vix_at_entry:.2f}",
            'spx_at_fill':      '',
            'outcome':          reason,
            'exit_credit':      '',
            'net_pnl':          '',
            'net_cost':         '',
            'bfly_reason':      '',
            'state_at_close':   'CANCELLED',
        })
        self._log_file.flush()

    def _log_butterfly(self, bf: LiveButterfly):
        """Write a BUTTERFLY row at EOD - records the net cost of the structure."""
        net = bf.win_credit - bf.premium_paid
        self._log_writer.writerow({
            'record_type':      'BUTTERFLY',
            'trade_id':         bf.trade_id,
            'direction':        bf.direction,
            'right':            bf.right,
            'entry_time':       bf.entry_time.isoformat(),
            'long_strike':      bf.long_strike,
            'short_strike':     bf.short_strike,
            'conv_strike':      bf.conv_strike,
            'contracts':        '',
            'ctv_cv':           '',
            'premium_paid':     f"{bf.premium_paid:.2f}",
            'min_profit_price': '',
            'win_target':       '',
            'entry_limit_price':'',
            'fill_slippage':    '',
            'vix_at_entry':     f"{bf.vix_at_entry:.2f}",
            'spx_at_fill':      f"{bf.spx_at_fill:.2f}",
            'outcome':          'BUTTERFLY_WIN' if net >= 0 else 'BUTTERFLY_LOSS',
            'exit_credit':      f"{bf.win_credit:.2f}",
            'net_pnl':          f"{net:.2f}",
            'net_cost':         f"{bf.net_cost:.2f}",
            'bfly_reason':      bf.bfly_reason,
            'state_at_close':   'BUTTERFLY',
        })
        self._log_file.flush()

    # =========================================================================
    # STATE FILE  (daily JSON - survives mid-day restarts)
    # =========================================================================

    def _state_path(self) -> Path:
        date_str = datetime.now(self.tz).strftime('%Y%m%d')
        return Path('logs') / f'ctv2_state_{date_str}.json'

    def _save_state(self):
        """Write current trades + butterflies to today's state file atomically."""
        def _trade_dict(t: LiveTrade) -> dict:
            return {
                'trade_id':        t.trade_id,
                'direction':       t.direction,
                'right':           t.right,
                'long_strike':     t.long_strike,
                'short_strike':    t.short_strike,
                'conv_strike':     t.conv_strike,
                'premium_paid':    t.premium_paid,
                'spx_at_fill':     t.spx_at_fill,
                'ctv_cv':          t.ctv_cv,
                'entry_time':      t.entry_time.isoformat(),
                'win_target':      t.win_target,
                'min_profit_price':t.min_profit_price,
            }
        def _butterfly_dict(b: LiveButterfly) -> dict:
            return {
                'trade_id':    b.trade_id,
                'direction':   b.direction,
                'right':       b.right,
                'long_strike': b.long_strike,
                'short_strike':b.short_strike,
                'conv_strike': b.conv_strike,
                'premium_paid':b.premium_paid,
                'win_credit':  b.win_credit,
                'net_cost':    b.net_cost,
                'spx_at_fill': b.spx_at_fill,
                'entry_time':  b.entry_time.isoformat(),
                'win_time':    b.win_time.isoformat() if b.win_time else None,
            }
        try:
            # Only persist filled (not PENDING_FILL) trades
            active_trades = [t for t in self.trades if t.state != 'PENDING_FILL']
            ema = self._spx_agg.get_ema_state()
            state = {
                'trades':      [_trade_dict(t) for t in active_trades],
                'butterflies': [_butterfly_dict(b) for b in self.butterflies],
                'ema': {
                    'ema36':      ema['ema36'],
                    'ema180':     ema['ema180'],
                    'sep_prev':   ema['sep_prev'],
                    'sep_curr':   ema['sep_curr'],
                    'last_close': self._spx_agg._last_close,
                },
            }
            path = self._state_path()
            tmp  = path.with_suffix('.tmp')
            tmp.write_text(json.dumps(state, indent=2))
            tmp.replace(path)
        except Exception as e:
            print(f"[STATE] Save failed: {e}")

    # =========================================================================
    # STRIKE CONFLICT HELPERS
    # =========================================================================

    def _existing_longs(self) -> set:
        """All (strike, right) pairs we are currently net long across trades and butterflies."""
        longs = {(t.long_strike, t.right) for t in self.trades}
        longs |= {(b.long_strike, b.right)  for b in self.butterflies}
        longs |= {(b.conv_strike, b.right)  for b in self.butterflies}
        return longs

    def _existing_shorts(self) -> set:
        """All (strike, right) pairs we are currently net short across trades and butterflies."""
        shorts = {(t.short_strike, t.right) for t in self.trades}
        shorts |= {(b.short_strike, b.right) for b in self.butterflies}
        return shorts

    # =========================================================================
    # POST-WARMUP ENTRY CHECK  (mid-day restart)
    # =========================================================================

    def _post_warmup_entry_check(self):
        """
        Called after warmup completes on a mid-day restart.
        Applies the same EMA36/EMA180 separation gate as _on_bar_complete.
        Queues an entry immediately if conditions are currently met.
        Guard: fires at most once per session.
        """
        if self._post_warmup_done:
            return
        self._post_warmup_done = True
        now = datetime.now(self.tz).time()
        if now < cfg.TRADING_START or now >= cfg.LAST_ENTRY_TIME:
            print("[RESTART] Outside entry window - skipping post-warmup check")
            return

        state       = self._spx_agg.get_ema_state()
        ema36       = state['ema36']
        ema180      = state['ema180']
        separation  = state['sep_curr']
        viable      = separation > self.cfg.EMA_DIRECTION_THRESHOLD
        current_dir = ('UP' if ema36 > ema180 else
                       'DOWN' if ema180 > ema36 else None)

        print(f"[RESTART] Post-warmup state: dir={current_dir or 'NONE'} "
              f"EMA36={ema36:.2f} EMA180={ema180:.2f} "
              f"sep={separation:.2f} viable={'Y' if viable else 'N'}")

        if current_dir is None or not viable:
            print("[RESTART] No viable direction - waiting for signal")
            return

        if not self._can_open(current_dir):
            print(f"[RESTART] Cannot open {current_dir} - at trade limits or already open")
            return

        if not self.risk_mgr.is_trading_allowed():
            print("[RESTART] Trading suspended - no restart entry")
            return

        print(f"[RESTART] Conditions met - queuing {current_dir} entry")
        self.pending_entries.append(PendingEntry(
            direction  = current_dir,
            signal_time= datetime.now(self.tz),
            ctv_cv     = self.last_bar_close,
            right      = 'C' if current_dir == 'UP' else 'P',
        ))

    # =========================================================================
    # POSITION RECOVERY CALLBACKS + HELPERS
    # =========================================================================

    def _alloc_trade_id(self) -> int:
        self._trade_id_seq += 1
        return self._trade_id_seq

    def _reconstruct_trade(self, long_s: float, short_s: float,
                           direction: str, right: str,
                           saved: dict) -> LiveTrade:
        """Build a LiveTrade from IBKR legs + state file metadata."""
        trade_id  = saved.get('trade_id') or self._alloc_trade_id()
        entry_str = saved.get('entry_time')
        entry_time = (datetime.fromisoformat(entry_str).replace(tzinfo=ET)
                      if entry_str else datetime.now(self.tz))
        premium_paid     = float(saved.get('premium_paid', 0.0))
        spx_at_fill      = float(saved.get('spx_at_fill', 0.0))
        conv_strike      = float(saved.get('conv_strike',
                                           short_s + self.cfg.SPREAD_WIDTH))
        win_target       = float(saved.get('win_target', 0.0))
        min_profit_price = float(saved.get('min_profit_price',
                                           premium_paid * cfg.MIN_CONV_CREDIT_PCT))
        if win_target == 0.0:
            win_target = (short_s + self.cfg.WIN_TARGET_BUFFER if direction == 'UP'
                          else short_s - self.cfg.WIN_TARGET_BUFFER)
        return LiveTrade(
            trade_id        = trade_id,
            direction       = direction,
            right           = right,
            ctv_cv          = float(saved.get('ctv_cv', spx_at_fill)),
            entry_time      = entry_time,
            state           = 'ACTIVE',
            long_strike     = long_s,
            short_strike    = short_s,
            conv_strike     = conv_strike,
            premium_paid    = premium_paid,
            win_target      = win_target,
            min_profit_price= min_profit_price,
            entry_order_id  = 0,
            spx_at_fill     = spx_at_fill,
        )

    def _reconstruct_butterfly(self, long_s: float, short_s: float,
                               conv_s: float, direction: str, right: str,
                               saved: dict) -> LiveButterfly:
        """Build a LiveButterfly from Tradier legs + state file metadata."""
        trade_id   = saved.get('trade_id') or self._alloc_trade_id()
        entry_str  = saved.get('entry_time')
        win_str    = saved.get('win_time')
        entry_time = (datetime.fromisoformat(entry_str).replace(tzinfo=ET)
                      if entry_str else datetime.now(self.tz))
        win_time   = (datetime.fromisoformat(win_str).replace(tzinfo=ET)
                      if win_str else None)
        premium_paid = float(saved.get('premium_paid', 0.0))
        win_credit   = float(saved.get('win_credit',   0.0))
        return LiveButterfly(
            trade_id    = trade_id,
            direction   = direction,
            right       = saved.get('right', right),
            long_strike = long_s,
            short_strike= short_s,
            conv_strike = conv_s,
            premium_paid= premium_paid,
            win_credit  = win_credit,
            net_cost    = float(saved.get('net_cost',
                                          premium_paid - win_credit)),
            entry_time  = entry_time,
            win_time    = win_time,
            spx_at_fill = float(saved.get('spx_at_fill', 0.0)),
        )

    def _recover_state(self):
        """
        Called at startup after warmup, before live bar subscription.
        1. Load today's state file (metadata: premium, times, targets)
        2. Fetch positions from Tradier REST (authoritative on what exists)
        3. Parse Tradier OCC symbols -> identify structures -> hydrate from JSON
        4. Rebuild self.trades and self.butterflies

        Tradier position dicts contain:
            symbol    : OCC symbol  e.g. 'SPXW260325P05800000'
            quantity  : signed float (positive = long, negative = short)
            cost_basis, date_acquired  (not used for recovery)
        """
        import re
        from collections import defaultdict
        today_expiry = datetime.now(self.tz).strftime('%y%m%d')  # 2-digit year: 260325

        def _parse_occ(symbol: str):
            """
            Parse a Tradier OCC option symbol into (right, strike, expiry_yymmd).
            OCC format: SPXW{YY}{MM}{DD}{C|P}{8-digit-strike*1000}
            e.g. SPXW260325P05800000 -> right='P', strike=5800.0, expiry='260325'
            Returns None if symbol does not match expected format.
            """
            m = re.match(r'^SPXW(\d{6})([CP])(\d{8})$', symbol)
            if not m:
                return None
            expiry = m.group(1)          # e.g. '260325'
            right  = m.group(2)          # 'C' or 'P'
            strike = int(m.group(3)) / 1000.0
            return right, strike, expiry

        # -- Load state file ------------------------------------------------
        saved_trades      = {}   # (long_s, short_s)          -> dict
        saved_butterflies = {}   # (long_s, short_s, conv_s)  -> dict
        state_path = self._state_path()
        if state_path.exists():
            try:
                data = json.loads(state_path.read_text())
                for t in data.get('trades', []):
                    key = (float(t['long_strike']), float(t['short_strike']))
                    saved_trades[key] = t
                for b in data.get('butterflies', []):
                    key = (float(b['long_strike']), float(b['short_strike']),
                           float(b['conv_strike']))
                    saved_butterflies[key] = b
                print(f"[RECOVER] State file: {len(saved_trades)} trade(s), "
                      f"{len(saved_butterflies)} butterfly(ies)")
                ema = data.get('ema', {})
                if ema and ema.get('ema36', 0) > 0:
                    self._spx_agg.seed_emas(
                        ema36      = float(ema['ema36']),
                        ema180     = float(ema['ema180']),
                        sep_prev   = float(ema.get('sep_prev', 0)),
                        sep_curr   = float(ema.get('sep_curr', 0)),
                        last_close = float(ema.get('last_close', 0)),
                    )
            except Exception as e:
                print(f"[RECOVER] State file unreadable ({e}) - using IBKR positions only")
        else:
            print("[RECOVER] No state file - will reconstruct from IBKR positions")

        # -- Request positions from Tradier REST ----------------------------
        raw = self.client.get_positions()
        self._recovery_positions = raw if raw else []

        # -- Parse OCC symbols and filter to today's SPXW options ----------
        today_legs = []
        for p in self._recovery_positions:
            parsed = _parse_occ(p.get('symbol', ''))
            if parsed is None:
                continue
            right, strike, expiry = parsed
            if expiry != today_expiry:
                continue
            today_legs.append({
                'right':  right,
                'strike': strike,
                'qty':    float(p.get('quantity', 0)),
            })

        if not today_legs:
            print("[RECOVER] No open SPXW positions for today - clean start")
            return

        print(f"[RECOVER] {len(today_legs)} SPXW option leg(s) found at IBKR")

        # -- Group by right -> strike -> net qty ----------------------------
        by_right: dict = defaultdict(lambda: defaultdict(float))
        for leg in today_legs:
            by_right[leg['right']][leg['strike']] += leg['qty']

        for right, strike_map in by_right.items():
            direction = 'UP' if right == 'C' else 'DOWN'
            active    = {s: q for s, q in strike_map.items() if q != 0}
            strikes   = sorted(active)

            if len(strikes) == 2:
                # LiveTrade: +1 long / -1 short
                lo, hi = strikes
                if active[lo] == 1 and active[hi] == -1:
                    saved = saved_trades.get((lo, hi), {})
                    trade = self._reconstruct_trade(lo, hi, direction, right, saved)
                    self.trades.append(trade)
                    src = "state file" if saved else "Tradier only"
                    print(f"[RECOVER] LiveTrade #{trade.trade_id} {direction} "
                          f"{int(lo)}/{int(hi)} (from {src})")
                else:
                    print(f"[RECOVER] Unexpected 2-leg {right} {strikes} "
                          f"qty={[active[s] for s in strikes]} - skipped")

            elif len(strikes) == 3:
                # LiveButterfly: +1 / -2 / +1
                s0, s1, s2 = strikes
                if active[s0] == 1 and active[s1] == -2 and active[s2] == 1:
                    # Dedup: skip if this butterfly is already in memory
                    existing_keys = {(b.direction, b.long_strike, b.short_strike, b.conv_strike)
                                     for b in self.butterflies}
                    if (direction, s0, s1, s2) in existing_keys:
                        print(f"[RECOVER] LiveButterfly {direction} "
                              f"{int(s0)}/{int(s1)}/{int(s2)} already in memory - skipped")
                    else:
                        saved = saved_butterflies.get((s0, s1, s2), {})
                        bf    = self._reconstruct_butterfly(s0, s1, s2,
                                                            direction, right, saved)
                        self.butterflies.append(bf)
                        src = "state file" if saved else "Tradier only"
                        print(f"[RECOVER] LiveButterfly #{bf.trade_id} {direction} "
                              f"{int(s0)}/{int(s1)}/{int(s2)} (from {src})")
                else:
                    print(f"[RECOVER] Unexpected 3-leg {right} {strikes} "
                          f"qty={[active[s] for s in strikes]} - skipped")
            else:
                print(f"[RECOVER] Unrecognized structure: {right} {strikes} - skipped")

        print(f"[RECOVER] Complete - {len(self.trades)} trade(s), "
              f"{len(self.butterflies)} butterfly(ies) restored")

    # =========================================================================
    # LIVE STARTUP SEQUENCE  (verbatim R10 structure)
    # =========================================================================

    def run_live(self):
        # -- Authorization -------------------------------------------------
        self._machine_id = run_startup_checks(mode=self.mode)

        # -- Market calendar check -----------------------------------------
        # Blocks until 09:00 ET on the next full trading day if today is a
        # weekend, holiday, or early-close (half-day) session.
        self._check_market_schedule()
        print("[SCHED] Good morning. Market opens at 09:30 ET, trading signals begin at 10:00 ET.")
        expiration = self.client.get_todays_expiration(live_trading=LIVE_TRADING)
        self.order_manager.set_expiration(expiration)

        # -- Start VIX poll thread -----------------------------------------
        self._start_vix_poll()

        # -- Recover open positions from prior session ---------------------
        self._recover_state()

        # -- Post-warmup entry check (mid-day restart) --------------------
        self._post_warmup_entry_check()

        # -- Start SPX WebSocket stream ------------------------------------
        self._stream = IBKRStream(
            on_spx_tick    = self._on_spx_tick,
            spx_aggregator = self._spx_agg,
            client_id      = 1,
        )
        self._stream.reset_bars()
        self._stream.start()
        self.live_trading_active = True

        # -- Mode banner ---------------------------------------------------
        if not LIVE_TRADING:
            mode_str = 'PAPER   (live data + real IBKR paper orders)'
        else:
            mode_str = 'LIVE    (real orders - real money)'
        print(f'\n>>> CTV2 running  [{mode_str}]  Press Ctrl+C to stop. <<<\n')

        # -- Signal handler ------------------------------------------------
        def _shutdown(sig, frame):
            print('\n[SHUTDOWN] Signal received - exiting cleanly')
            if self._stream:
                self._stream.stop()
            try:
                self.order_manager.disconnect()
            except Exception:
                pass
            self._log_file.close()
            sys.exit(0)
        signal.signal(signal.SIGINT, _shutdown)

        # -- Main loop -----------------------------------------------------
        # Wrap stdout so the countdown can detect whether its own line is
        # still the last thing on the terminal before deciding to overwrite.
        _tracker = _StdoutTracker(sys.stdout)
        sys.stdout = _tracker

        try:
            _hb_last = 0.0   # monotonic time of last countdown print
            while True:
                time.sleep(1)

                # Pre-market countdown: fires after the buying power call
                # above has returned, so all startup noise has settled.
                # If the last printed line is our own countdown we ANSI-
                # overwrite it; if anything else printed in between we just
                # plain-print so that line is preserved.
                now_et = datetime.now(self.tz)
                market_open = now_et.replace(
                    hour=9, minute=30, second=0, microsecond=0
                )
                if now_et < market_open:
                    if time.monotonic() - _hb_last >= 30:
                        delta  = market_open - now_et
                        t_mins = int(delta.total_seconds()) // 60
                        t_secs = int(delta.total_seconds()) % 60
                        msg    = (f'[SCHED] Waiting for market open - '
                                  f'T-minus {t_mins}m {t_secs:02d}s')
                        if 'T-minus' in _tracker.last:
                            print(f'\x1b[1A\x1b[2K{msg}')
                        else:
                            print(msg)
                        _hb_last = time.monotonic()

                self._check_late_day_exits()
                self._check_market_close()
        except _SessionComplete:
            pass   # clean EOD - return normally so main() loops to next day
        except Exception as exc:
            if self.pushover and NOTIFY_SYSTEM_CRASH:
                try:
                    self.pushover.send_exception_crash_alert(
                        exception_type    = type(exc).__name__,
                        exception_msg     = str(exc),
                        traceback_summary = traceback.format_exc()[-200:],
                    )
                except Exception:
                    pass
            raise
        finally:
            sys.stdout = _tracker._w   # restore original stdout
            if self._stream:
                try:
                    self._stream.stop()
                except Exception:
                    pass
            try:
                self.order_manager.disconnect()
            except Exception:
                pass
            try:
                self._log_file.close()
            except Exception:
                pass

    # =========================================================================
    # MARKET CALENDAR CHECK  (gates startup on full NYSE trading days)
    # =========================================================================

    def _check_market_schedule(self):
        """
        Check NYSE market calendar for today.
        Blocks until 09:00 ET on the next full trading day if today is a
        weekend, holiday, or early-close (half-day) session.
        Proceeds normally only on a full trading day.
        """
        try:
            import pandas_market_calendars as mcal
            import pandas as pd
        except ImportError:
            print("[SCHED] pandas_market_calendars not installed - skipping schedule check")
            return

        nyse = mcal.get_calendar('NYSE')

        def get_full_trading_day(date_str):
            """Return schedule row if date is a full trading day, else None."""
            sched = nyse.schedule(start_date=date_str, end_date=date_str)
            if sched.empty:
                return None
            close_time = sched.iloc[0]['market_close'].tz_convert(self.tz)
            if close_time.hour < 15:   # early close = half-day
                return None
            return sched.iloc[0]

        def next_full_trading_day(from_date):
            """Find the next full trading day on or after from_date."""
            check = from_date
            for _ in range(14):   # safety limit
                row = get_full_trading_day(check.strftime('%Y-%m-%d'))
                if row is not None:
                    return check, row
                check = check + pd.Timedelta(days=1)
            return None, None

        while True:
            now       = datetime.now(self.tz)
            today     = now.date()
            today_str = today.strftime('%Y-%m-%d')
            row       = get_full_trading_day(today_str)

            if row is not None:
                open_time  = row['market_open'].tz_convert(self.tz)
                close_time = row['market_close'].tz_convert(self.tz)

                # Started after market close today - treat as non-trading day
                # and sleep until 09:00 ET on the next full trading day.
                if datetime.now(self.tz) >= close_time:
                    tomorrow    = pd.Timestamp(today) + pd.Timedelta(days=1)
                    next_day, _ = next_full_trading_day(tomorrow)
                    if next_day is None:
                        print("[SCHED] Could not determine next trading day - retrying in 3600s")
                        time.sleep(3600)
                        continue
                    next_dt   = datetime(next_day.year, next_day.month, next_day.day,
                                         9, 0, 0, tzinfo=self.tz)
                    wait_secs = max(0, (next_dt - datetime.now(self.tz)).total_seconds())
                    print(f"[SCHED] {today_str} market already closed - "
                          f"sleeping until {next_day.strftime('%m/%d')} at 09:00 ET "
                          f"({wait_secs/3600:.1f}h) "
                          f"(market opens 09:30 ET, signals begin 10:00 ET)")
                    time.sleep(wait_secs)
                    continue

                print(f"[SCHED] {today_str} is a full trading day "
                      f"({open_time.strftime('%H:%M')}-{close_time.strftime('%H:%M')} ET)"
                      f" - proceeding")
                if datetime.now(self.tz) < open_time:
                    mins = int((open_time - datetime.now(self.tz)).total_seconds() / 60)
                    print(f"[SCHED] Pre-market start - market opens at "
                          f"{open_time.strftime('%H:%M')} ET (T-minus {mins}m)")
                return

            # Not a valid trading day - find next and sleep until 09:00 ET
            tomorrow     = pd.Timestamp(today) + pd.Timedelta(days=1)
            next_day, _  = next_full_trading_day(tomorrow)
            if next_day is None:
                print("[SCHED] Could not determine next trading day - retrying in 3600s")
                time.sleep(3600)
                continue

            next_dt   = datetime(next_day.year, next_day.month, next_day.day,
                                 9, 0, 0, tzinfo=self.tz)
            wait_secs = max(0, (next_dt - datetime.now(self.tz)).total_seconds())
            reason    = ("not a trading day"
                         if nyse.schedule(start_date=today_str,
                                          end_date=today_str).empty
                         else "half-day")
            print(f"[SCHED] {today_str} is {reason} - no trading. "
                  f"Sleeping until {next_day.strftime('%m/%d')} at 09:00 ET "
                  f"({wait_secs/3600:.1f}h) "
                  f"(market opens 09:30 ET, signals begin 10:00 ET)")
            time.sleep(wait_secs)


    # =========================================================================
    # VIX POLL THREAD  (replaces IBKR reqMktData on VIX9D contract)
    # =========================================================================

    def _start_vix_poll(self):
        """
        Poll yfinance for VIX9D every VIX_POLL_INTERVAL seconds.
        Runs as a daemon thread; updates self._vix, day min/max, heartbeat time.
        """
        def _poll():
            while True:
                try:
                    price = self.client.get_vix9d()
                    if price > 0:
                        if self._vix == 0.0:
                            print(f'[VIX ] VIX9D first tick: {price:.2f}')
                        self._vix = price
                        if self._vix_day_min == 0.0 or price < self._vix_day_min:
                            self._vix_day_min = price
                        if price > self._vix_day_max:
                            self._vix_day_max = price
                        self._vix_last_tick_time = datetime.now(self.tz)
                        if self._vix_heartbeat_alerted:
                            self._vix_heartbeat_alerted = False
                            print(f'[VIX ] heartbeat resumed - VIX9D={price:.2f}')
                except Exception as e:
                    print(f'[VIX ] poll error: {e}')
                time.sleep(VIX_POLL_INTERVAL)

        t = threading.Thread(target=_poll, daemon=True, name='VIXPoll')
        t.start()
        print(f'[VIX ] VIX9D poll thread started (every {VIX_POLL_INTERVAL}s)')

    # =========================================================================
    # STREAM CALLBACKS  (replace IBKR historicalDataUpdate / historicalDataEnd)
    # =========================================================================

    def _on_spx_tick(self, price: float, ts: str):
        """
        Called by TradierStream on every ~1s SPX price event.
        Replaces IBKR historicalDataUpdate tick path.
        Updates _live_spx and checks win targets on every tick.
        """
        self._live_spx = price
        if self.live_trading_active:
            self._check_win_targets()

    def _on_5s_bar(self):
        """
        Called by SpxBarAggregator on every real 5-second bar close.

        Implements rolling signal confirmation: evaluates EMA separation on
        every tick. When cfg.SIG_CONFIRM_TICKS_SEC // 5 consecutive ticks
        all satisfy the confirmation criteria, the signal is considered
        confirmed and an entry is queued immediately - no waiting for the
        3-minute bar boundary.

        Confirmation criteria (all must be true):
          1. sep > EMA_DIRECTION_THRESHOLD
          2. sep is growing (sep_curr > sep_prev)
          3. Raw EMA direction is consistent for all ticks

        Also triggers _try_enter_pending() on every cycle so pending entries
        are retried at 5-second resolution.
        """
        if not self.live_trading_active:
            return
        if self._session_done:
            return

        now = datetime.now(self.tz)
        in_entry_window = (now.time() >= cfg.TRADING_START and
                           now.time() <  cfg.LAST_ENTRY_TIME)

        # Always retry pending entries regardless of signal state
        if self.pending_entries:
            self._check_entry_auctions()
            self._try_enter_pending()

        if not in_entry_window:
            return

        # -- Get current EMA state ----------------------------------------
        state    = self._spx_agg.get_ema_state()
        ema36    = state['ema36']
        ema180   = state['ema180']
        sep      = state['sep_curr']
        sep_prev = state['sep_prev']

        if ema36 == 0.0 or ema180 == 0.0:
            return

        raw_dir = ('UP'   if ema36 > ema180 else
                   'DOWN' if ema180 > ema36  else None)
        if raw_dir is None:
            self._sig_confirm_dir   = None
            self._sig_confirm_count = 0
            return

        # -- Evaluate confirmation conditions -----------------------------
        conditions_met = (
            sep > self.cfg.EMA_DIRECTION_THRESHOLD and
            sep > sep_prev
        )

        if conditions_met and raw_dir == self._sig_confirm_dir:
            self._sig_confirm_count += 1
        elif conditions_met:
            # Different direction or first qualifying tick - start fresh count
            self._sig_confirm_dir   = raw_dir
            self._sig_confirm_count = 1
        else:
            # Conditions broken - reset counter
            if (self._sig_active_dir is not None and
                    sep <= self.cfg.EMA_DIRECTION_THRESHOLD):
                print(f"[SIG5] Signal lost - sep={sep:.2f} below threshold")
                self._sig_active_dir = None
            self._sig_confirm_dir   = None
            self._sig_confirm_count = 0
            return

        # -- Check if confirmation threshold reached ----------------------
        confirm_ticks = max(1, cfg.SIG_CONFIRM_TICKS_SEC // 5)
        if self._sig_confirm_count < confirm_ticks:
            return

        confirmed_dir = self._sig_confirm_dir

        # New confirmed signal - log and update active direction
        if confirmed_dir != self._sig_active_dir:
            self._sig_active_dir = confirmed_dir
            print(f"[SIG5] {confirmed_dir} confirmed after "
                  f"{confirm_ticks} ticks ({cfg.SIG_CONFIRM_TICKS_SEC}s) "
                  f"sep={sep:.2f}")

            # Cancel pending entries in opposite direction
            opp    = 'DOWN' if confirmed_dir == 'UP' else 'UP'
            before = len(self.pending_entries)
            self.pending_entries = [p for p in self.pending_entries
                                    if p.direction != opp]
            removed = before - len(self.pending_entries)
            if removed:
                print(f"[SIG5] Cancelled {removed} pending {opp} "
                      f"entries (direction flip)")

        # Queue entry if not already pending in this direction
        already_pending = any(p.direction == confirmed_dir
                              for p in self.pending_entries)
        if not already_pending and self._can_open(confirmed_dir):
            spx = self._live_spx if self._live_spx > 0 else self.last_bar_close
            print(f"[SIG5] Queuing {confirmed_dir} entry "
                  f"sep={sep:.2f}")
            self.pending_entries.append(PendingEntry(
                direction   = confirmed_dir,
                signal_time = now,
                ctv_cv      = spx,
                right       = 'C' if confirmed_dir == 'UP' else 'P',
            ))


    # =========================================================================
    # =========================================================================
    # ORDER FILL POLLING  (replaces IBKR orderStatus callback)
    # =========================================================================

    def _poll_order_fill(self, order_id: int, purpose: str, trade_id: int,
                          extra: str = ''):
        """
        Poll IBKR order status until filled or cancelled.
        Runs in a daemon thread so the main loop never blocks.
        Works identically for paper and live - IBKR paper account simulates
        fills natively; no synthetic fill path needed.
        """
        # -- Poll IBKR until filled/cancelled ------------------------------
        for _ in range(120):   # poll up to ~2 min (1s intervals)
            try:
                order = self.client.get_order(order_id)
                status = order.get('status', '')
                print(f'[ORDER] ID {order_id}: {status} purpose={purpose}')

                if status == 'filled':
                    avg_fill = float(order.get('avg_fill_price', 0) or 0)
                    trade    = self._find_trade(trade_id)
                    try:
                        if purpose == 'ENTRY':
                            self._on_entry_fill(order_id, trade, avg_fill)
                        elif purpose == 'WIN':
                            self._on_win_fill(trade, trade_id, avg_fill)
                        elif purpose == 'STOP':
                            self._on_stop_fill(trade, trade_id, avg_fill)
                        elif purpose == 'BFLY_CONV':
                            self._on_bfly_fill(trade, trade_id, avg_fill, extra)
                    except Exception as e:
                        print(f'[ERROR] fill handler {purpose} #{trade_id}: {e}')
                        traceback.print_exc()
                    return

                elif status in ('canceled', 'expired', 'rejected'):
                    print(f'[ORDER] ID {order_id} {status} - purpose={purpose} #{trade_id}')
                    self._on_order_not_filled(purpose, trade_id, order_id, extra)
                    return

            except Exception as e:
                print(f'[ORDER] poll error order {order_id}: {e}')

            time.sleep(1)

        print(f'[ORDER] Poll timeout order {order_id} purpose={purpose} #{trade_id}')
        self._on_order_not_filled(purpose, trade_id, order_id, extra)

    def _on_win_fill(self, trade, trade_id: int, avg_fill: float):
        """WIN sell filled - identical logic to original orderStatus WIN branch."""
        if not trade:
            return
        credit = avg_fill * 100
        net    = credit - trade.premium_paid
        sign   = '+' if net >= 0 else ''
        print(f"[WIN ] {datetime.now(self.tz).strftime('%H:%M:%S')} #{trade_id} {trade.direction} "
              f"credit=${credit:.0f} net={sign}${net:.0f}")
        self._log_trade(trade, 'WIN', credit, trade.state)
        self.risk_mgr.record_outcome(RiskOutcome.WIN)
        if self.pushover and NOTIFY_ALL_TRADES:
            try:
                self.pushover.send_trade_exit_alert(
                    direction    = trade.direction,
                    long_strike  = trade.long_strike,
                    short_strike = trade.short_strike,
                    entry_price  = trade.premium_paid,
                    exit_price   = credit,
                    pnl          = credit - trade.premium_paid,
                    outcome      = 'WIN',
                )
            except Exception:
                pass
        won_direction   = trade.direction
        won_conv_strike = trade.conv_strike
        won_right       = trade.right
        bf = LiveButterfly(
            trade_id     = trade.trade_id,
            direction    = trade.direction,
            right        = trade.right,
            long_strike  = trade.long_strike,
            short_strike = trade.short_strike,
            conv_strike  = trade.conv_strike,
            premium_paid = trade.premium_paid,
            win_credit   = credit,
            net_cost     = trade.premium_paid - credit,
            entry_time   = trade.entry_time,
            win_time     = datetime.now(self.tz),
            spx_at_fill  = trade.spx_at_fill,
            vix_at_entry = trade.vix_at_entry,
            bfly_reason  = 'WIN',
        )
        existing_keys = {(b.direction, b.long_strike, b.short_strike, b.conv_strike)
                         for b in self.butterflies}
        if (bf.direction, bf.long_strike, bf.short_strike, bf.conv_strike) not in existing_keys:
            self.butterflies.append(bf)
        # Collapse the CONV_SPREAD_WIDTH win-sell spread back to SPREAD_WIDTH.
        # Fires as a daemon thread so it does not block the win-fill handler.
        threading.Thread(
            target=self._collapse_thread,
            args=(trade_id, trade.direction, trade.short_strike,
                  trade.conv_strike, trade.contracts),
            daemon=True,
        ).start()
        self.trades = [t for t in self.trades if t.trade_id != trade_id]
        self._save_state()
        self._try_chain_entry(won_direction, won_conv_strike, won_right)

    def _on_stop_fill(self, trade, trade_id: int, avg_fill: float):
        """STOP fill - identical logic to original orderStatus STOP branch."""
        if not trade:
            return
        credit = avg_fill * 100
        net    = credit - trade.premium_paid
        print(f"[STOP] #{trade_id} {trade.direction} "
              f"recover=${credit:.0f} net=${net:.0f}")
        self._log_trade(trade, 'STOP', credit, trade.state)
        self.risk_mgr.record_outcome(RiskOutcome.LOSS)
        if NOTIFY_RISK_SUSPEND and not self.risk_mgr.is_trading_allowed():
            self._notify_suspension()
        if trade.win_order_id:
            self.order_manager.cancel(trade.win_order_id)
        self.trades = [t for t in self.trades if t.trade_id != trade_id]
        self._save_state()

    def _on_bfly_fill(self, trade, trade_id: int, avg_fill: float, reason: str):
        """BFLY_CONV fill - identical logic to original orderStatus BFLY_CONV branch."""
        if not trade:
            return
        conv_credit = avg_fill * 100
        net         = conv_credit - trade.premium_paid
        sign        = '+' if net >= 0 else ''
        print(f"[BFLY ] #{trade_id} {trade.direction} "
              f"converted -> butterfly "
              f"conv_credit=${conv_credit:.0f} net={sign}${net:.0f} "
              f"reason={reason}")
        self._log_trade(trade, f'BUTTERFLY_CONV_{reason}', conv_credit, trade.state)
        outcome = RiskOutcome.WIN if net >= 0 else RiskOutcome.LOSS
        self.risk_mgr.record_outcome(outcome)
        if self.pushover and NOTIFY_ALL_TRADES:
            try:
                self.pushover.send_trade_exit_alert(
                    direction    = trade.direction,
                    long_strike  = trade.long_strike,
                    short_strike = trade.short_strike,
                    entry_price  = trade.premium_paid,
                    exit_price   = conv_credit,
                    pnl          = net,
                    outcome      = f'BFLY_CONV_{reason}',
                )
            except Exception:
                pass
        if NOTIFY_RISK_SUSPEND and not self.risk_mgr.is_trading_allowed():
            self._notify_suspension()
        bf = LiveButterfly(
            trade_id     = trade.trade_id,
            direction    = trade.direction,
            right        = trade.right,
            long_strike  = trade.long_strike,
            short_strike = trade.short_strike,
            conv_strike  = trade.conv_strike,
            premium_paid = trade.premium_paid,
            win_credit   = conv_credit,
            net_cost     = trade.premium_paid - conv_credit,
            entry_time   = trade.entry_time,
            win_time     = datetime.now(self.tz),
            spx_at_fill  = trade.spx_at_fill,
            vix_at_entry = trade.vix_at_entry,
            bfly_reason  = trade.bfly_reason,
        )
        existing_keys = {(b.direction, b.long_strike, b.short_strike, b.conv_strike)
                         for b in self.butterflies}
        if (bf.direction, bf.long_strike, bf.short_strike, bf.conv_strike) not in existing_keys:
            self.butterflies.append(bf)
        self.trades = [t for t in self.trades if t.trade_id != trade_id]
        self._save_state()

    def _on_order_not_filled(self, purpose: str, trade_id: int,
                              order_id: int, extra: str):
        """Handle cancelled/expired/timeout orders - revert state for retry."""
        trade = self._find_trade(trade_id)
        if purpose == 'ENTRY' and trade and trade.state == 'PENDING_FILL':
            print(f'[ORDER] Entry #{trade_id} not filled - removing')
            self._log_cancelled(trade, 'ORDER_NOT_FILLED')
            self.trades = [t for t in self.trades if t.trade_id != trade_id]
        elif purpose == 'WIN' and trade and trade.state == 'PENDING_WIN_QUOTE':
            trade.state        = 'ACTIVE'
            trade.win_order_id = 0
            trade.win_order_placed_time = None
            print(f'[ORDER] WIN sell #{trade_id} not filled - reverted to ACTIVE')
        elif purpose == 'BFLY_CONV' and trade and trade.state == 'PENDING_BUTTERFLY':
            # Cancel the live IBKR order before reverting - prevents duplicate
            # fills if a retry places a new order while the old one is still open.
            if order_id:
                try:
                    self.order_manager.cancel(order_id)
                except Exception:
                    pass
            trade.state        = 'PARKED'
            trade.win_order_id = 0
            trade.win_order_placed_time = None
            print(f'[ORDER] BFLY_CONV #{trade_id} not filled - order cancelled, reverted to PARKED')

    # =========================================================================
    # BAR PROCESSING
    # =========================================================================

    def _on_bar_complete(self, bar: dict):
        """
        Called for every completed 3-min bar.
        Replicates the backtester's run_day loop.
        """
        if not self.live_trading_active:
            return
        if self._session_done:
            return   # market closed - ignore late-arriving bars silently

        # VIX heartbeat check - alert if feed silent for too long
        if self._vix_last_tick_time is not None:
            silent_min = (datetime.now(self.tz) - self._vix_last_tick_time
                          ).total_seconds() / 60.0
            if silent_min >= VIX_HEARTBEAT_TIMEOUT and not self._vix_heartbeat_alerted:
                self._vix_heartbeat_alerted = True
                msg = (f"VIX data feed silent for {silent_min:.0f} min "
                       f"- quote requests may be affected")
                print(f"[VIX ] HEARTBEAT ALERT: {msg}")
                if self.pushover:
                    try:
                        self.pushover.send_critical(msg)
                    except Exception:
                        pass

        ts  = bar['bar_start_time']
        bt  = ts.time()

        # Gate: discard pre-market bars - market not open before 09:30
        if bt < dtime(9, 30):
            return

        # Native SPX bar - use close directly, no conversion needed
        close = bar['close'] if bar['close'] > 0 else bar['open']
        self.last_bar_close = close

        # -- Derive signal state from SpxBarAggregator --------------------
        state       = self._spx_agg.get_ema_state()
        ema36       = state['ema36']
        ema180      = state['ema180']
        separation  = state['sep_curr']
        viable      = separation > self.cfg.EMA_DIRECTION_THRESHOLD
        current_dir = ('UP'   if ema36 > ema180 else
                       'DOWN' if ema180 > ema36  else None)
        # Sticky direction: EMA_DIRECTION_THRESHOLD gates entry (viable) and
        # must also gate direction changes. A sub-threshold crossover is noise,
        # not a confirmed direction flip - hold the last confirmed direction.
        if not viable:
            current_dir = self._prev_direction
        direction_change = (viable and
                            current_dir is not None and
                            current_dir != self._prev_direction)
        if viable and current_dir is not None:
            self._prev_direction = current_dir

        print(f"\n{'='*60}")
        now_str = datetime.now(self.tz).strftime('%H:%M')
        print(f"BAR | {now_str} (prev bar {ts.strftime('%H:%M')}) | "
              f"O={bar['open']:.2f} H={bar['high']:.2f} "
              f"L={bar['low']:.2f} C={close:.2f}")
        print(f"[SIG ] EMA36={ema36:.2f} EMA180={ema180:.2f} "
              f"sep={separation:.2f} dir={current_dir or 'NONE'} "
              f"viable={'Y' if viable else 'N'} "
              f"change={'Y' if direction_change else 'N'}")
        print(f"[POS ] Trades={len(self.trades)} "
              f"Pending={len(self.pending_entries)}")

        # -- Pre-cache SPXW contracts on 9:30 bar close -------------------
        # Uses the 9:30 bar close as center (first real market print).
        # Auto re-cache fires on any subsequent cache miss (_option()).
        if bt == dtime(9, 30) and not self._contracts_precached:
            self.order_manager.precache_contracts(close)
            self._contracts_precached = True

        # 2. Process existing trades: PARK / UNPARK / noise-adverse / EMA_VIX
        self._process_trades(bar, current_dir, separation)

        # 2a. Cancel and reprice any stale win or butterfly conversion orders
        self._check_stale_orders()

        # 3. Cancel pending entries in wrong direction
        if current_dir is not None:
            opp = 'DOWN' if current_dir == 'UP' else 'UP'
            before = len(self.pending_entries)
            self.pending_entries = [p for p in self.pending_entries
                                    if p.direction != opp]
            if len(self.pending_entries) < before:
                print(f"[ENTRY] Cancelled {before - len(self.pending_entries)} "
                      f"pending {opp} entries (direction flip)")

        # 3a. Expire stale pending entries BEFORE the new entry check (step 4).
        #     Expiry inside _try_enter_pending runs too late - a pending entry
        #     that times out on a viable bar blocks step 4 from re-queuing,
        #     leaving Pending=0 with no fresh entry despite a valid signal.
        _now = datetime.now(self.tz)
        _expired = [p for p in self.pending_entries
                    if (_now - p.signal_time).total_seconds() / 60.0
                    > cfg.ENTRY_TIMEOUT]
        for p in _expired:
            age = (_now - p.signal_time).total_seconds() / 60.0
            print(f"[ENTRY] {p.direction} entry expired after "
                  f"{age:.0f}min - dropping")
        if _expired:
            self.pending_entries = [p for p in self.pending_entries
                                    if p not in _expired]

        # 4. Entry queuing is now handled by _on_5s_bar rolling confirmation.
        #    _on_bar_complete retains trade processing, stale order checks,
        #    and expiry - but no longer queues new entries directly.

        # 5. Try to fill pending entries.
        #    Runs AFTER step 3a so expired entries are already cleared.
        #    The 5s callback handles subsequent retries.
        if datetime.now(self.tz).time() >= cfg.TRADING_START:
            self._try_enter_pending()

    def _try_enter_pending(self):
        """
        For each pending entry, check all gates and fetch a spread quote
        via REST if everything passes. Called from both _on_bar_complete
        (3-minute boundary) and _on_5s_bar (5-second resolution).

        Gates checked on every call (5-second resolution):
          - ENTRY_TIMEOUT: drop entry if signal is older than cfg.ENTRY_TIMEOUT min
          - Acceleration: skip cycle silently if trend not accelerating
          - Trade limits: skip if max trades reached or same-direction open
          - Strike conflict: skip if SEC rule would be violated
          - Quote: fetch REST quote; if premium > MAX_PREMIUM reset without
                   consuming retry (transient market condition)

        mktdata_requested flag prevents duplicate quote threads.
        Retries only consumed for genuine quote failures (zero ask, wide spread,
        thread exception).
        """
        still_pending = []
        for p in self.pending_entries:

            # Time-based expiry
            age_min = (datetime.now(self.tz) - p.signal_time).total_seconds() / 60.0
            if age_min > cfg.ENTRY_TIMEOUT:
                print(f"[ENTRY] {p.direction} entry expired after "
                      f"{age_min:.0f}min - dropping")
                continue

            # Quote thread already in flight - leave it
            if p.mktdata_requested:
                still_pending.append(p)
                continue

            # Acceleration gate - skip silently, retry on next 5s bar
            if not self._spx_agg.is_accelerating(p.direction):
                still_pending.append(p)
                continue

            # Trade limits: one active/in-flight trade max; no same direction;
            # parked slot cap (_MAX_PARKED).
            _active_states = {'PENDING_FILL', 'ACTIVE', 'PENDING_WIN_QUOTE', 'PENDING_BUTTERFLY'}
            if any(t.state in _active_states for t in self.trades):
                still_pending.append(p)
                continue
            if any(t.direction == p.direction for t in self.trades):
                still_pending.append(p)
                continue
            if sum(1 for t in self.trades if t.state == 'PARKED') >= _MAX_PARKED:
                still_pending.append(p)
                continue

            spx = self._live_spx if self._live_spx > 0 else self.last_bar_close
            if spx <= 0:
                still_pending.append(p)
                continue

            long_s, short_s, conv_s = self.order_manager.calc_strikes(spx, p.direction)

            if (long_s, p.right) in self._existing_shorts() or \
               (short_s, p.right) in self._existing_longs():
                print(f"[SKIP ] {p.direction} {int(long_s)}/{int(short_s)} "
                      f"- strike conflict with open position (SEC rule)")
                still_pending.append(p)
                continue

            p.mktdata_requested = True
            t = threading.Thread(
                target=self._entry_quote_thread,
                args=(p, long_s, short_s, conv_s, spx),
                daemon=True,
            )
            t.start()
            still_pending.append(p)

        self.pending_entries = still_pending

    def _check_entry_auctions(self):
        """
        Called from _on_5s_bar on every 5-second tick.
        Manages active entry auctions - steps bids toward MAX_PREMIUM,
        restarts if midpoint drops below starting midpoint, abandons on
        adverse conditions.

        Auction state machine per PendingEntry (auction_order_id > 0):

          Abandon (cancel order, remove from pending):
            - Acceleration gone or direction flipped
            - SPX within ENTRY_OTM_ABANDON pts of long strike
            - Strike changed against trend direction

          Restart from new midpoint (cancel, re-quote):
            - BID_STEP_INTERVAL elapsed AND current mid < auction_start_mid

          Step bid +$0.05 (cancel, reprice, resubmit):
            - BID_STEP_INTERVAL elapsed AND current bid < MAX_PREMIUM/100

          Hold at MAX_PREMIUM (no action):
            - current bid = MAX_PREMIUM/100
        """
        import time as _time
        now       = datetime.now(self.tz)
        max_ps    = self.cfg.MAX_PREMIUM / 100.0   # per-share
        step_secs = getattr(cfg, 'BID_STEP_INTERVAL', 15)
        abandon_pts = getattr(cfg, 'ENTRY_OTM_ABANDON', 3.0)
        spx       = self._live_spx if self._live_spx > 0 else self.last_bar_close

        still_pending = []
        for p in self.pending_entries:
            # Only manage entries with an active auction
            if p.auction_order_id == 0:
                still_pending.append(p)
                continue

            long_s = p.auction_long_s
            dir_   = p.direction

            # -- Abandon: acceleration gone or direction flipped ----------
            if not self._spx_agg.is_accelerating(dir_):
                print(f"[ENTRY] Auction {dir_} abandoned - acceleration lost")
                self.order_manager.cancel(p.auction_order_id)
                self._remove_pending_trade(p.auction_order_id)
                continue

            # -- Abandon: SPX within ENTRY_OTM_ABANDON of long strike ----
            if dir_ == 'UP':
                spx_dist = long_s - spx
            else:
                spx_dist = spx - long_s
            if spx_dist < abandon_pts:
                print(f"[ENTRY] Auction {dir_} abandoned - SPX within "
                      f"{abandon_pts}pts of long strike {long_s:.0f} "
                      f"(dist={spx_dist:.2f})")
                self.order_manager.cancel(p.auction_order_id)
                self._remove_pending_trade(p.auction_order_id)
                continue

            # -- Abandon: strike changed against trend direction ----------
            new_long_s, new_short_s, new_conv_s =                 self.order_manager.calc_strikes(spx, dir_)
            if new_long_s != long_s:
                print(f"[ENTRY] Auction {dir_} abandoned - strike changed "
                      f"{long_s:.0f} -> {new_long_s:.0f}")
                self.order_manager.cancel(p.auction_order_id)
                self._remove_pending_trade(p.auction_order_id)
                continue

            # -- Check if BID_STEP_INTERVAL has elapsed ------------------
            if p.auction_last_step is None:
                still_pending.append(p)
                continue
            elapsed = (now - p.auction_last_step).total_seconds()
            if elapsed < step_secs:
                still_pending.append(p)
                continue

            # -- Step interval elapsed - get fresh quote ------------------
            bid, ask = self.order_manager.get_spread_quote(
                dir_, long_s, p.auction_short_s)
            if ask <= 0:
                # No quote - hold current bid
                p.auction_last_step = now
                still_pending.append(p)
                continue

            mid = round_to_tick((bid + ask) / 2.0)

            # -- Restart: midpoint dropped below starting midpoint --------
            if mid < p.auction_start_mid:
                print(f"[ENTRY] Auction {dir_} restarting - mid "
                      f"${mid*100:.0f} < start ${p.auction_start_mid*100:.0f}")
                self.order_manager.cancel(p.auction_order_id)
                self._remove_pending_trade(p.auction_order_id)
                # Re-queue as fresh pending entry - confirmation loop
                # will restart auction at new midpoint
                p.auction_order_id  = 0
                p.auction_bid       = 0.0
                p.auction_last_step = None
                p.mktdata_requested = False
                still_pending.append(p)
                continue

            # -- Step or hold -------------------------------------------
            # If midpoint has risen above current bid, step immediately
            # to MAX_PREMIUM (market moved away - lock in our max).
            if mid > p.auction_bid and mid >= max_ps:
                new_bid = max_ps
            else:
                new_bid = round_to_tick(p.auction_bid + 0.05)
                if new_bid > max_ps:
                    new_bid = max_ps

            if new_bid == p.auction_bid:
                # Already at max - hold
                p.auction_last_step = now
                still_pending.append(p)
                continue

            # Cancel current order and resubmit at new_bid
            self.order_manager.cancel(p.auction_order_id)
            self._remove_pending_trade(p.auction_order_id)

            contracts  = self._calc_contracts(new_bid)
            order_id   = self.order_manager.place_entry(
                dir_, long_s, p.auction_short_s, new_bid, contracts)
            if order_id is None:
                print(f"[ENTRY] Auction {dir_} reprice failed - abandoning")
                continue

            p.auction_bid       = new_bid
            p.auction_last_step = now
            p.auction_order_id  = order_id

            # Register fresh trade placeholder
            self._trade_id_seq += 1
            trade = LiveTrade(
                trade_id         = self._trade_id_seq,
                direction        = dir_,
                right            = p.right,
                ctv_cv           = p.ctv_cv,
                entry_time       = p.signal_time,
                state            = 'PENDING_FILL',
                long_strike      = long_s,
                short_strike     = p.auction_short_s,
                conv_strike      = p.auction_conv_s,
                premium_paid     = new_bid * 100,
                win_target       = 0.0,
                min_profit_price = 0.0,
                entry_order_id   = order_id,
                contracts        = contracts,
            )
            trade.entry_limit_price       = new_bid
            trade.entry_order_placed_time = now
            self.trades.append(trade)
            threading.Thread(
                target=self._poll_order_fill,
                args=(order_id, 'ENTRY', trade.trade_id),
                daemon=True,
            ).start()

            print(f"[ENTRY] Auction {dir_} stepped to "
                  f"${new_bid*100:.0f} "
                  f"(max=${self.cfg.MAX_PREMIUM:.0f})")
            still_pending.append(p)

        self.pending_entries = still_pending

    def _remove_pending_trade(self, order_id: int):
        """Remove a PENDING_FILL trade by order_id (auction cancel/reprice)."""
        self.trades = [t for t in self.trades
                       if not (t.entry_order_id == order_id
                               and t.state == 'PENDING_FILL')]

    def _entry_quote_thread(self, p: PendingEntry, long_s: float,
                             short_s: float, conv_s: float, spx: float):
        """Background thread: fetch spread quote then call _on_entry_quote."""
        try:
            right = 'C' if p.direction == 'UP' else 'P'
            bid, ask = self.order_manager.get_spread_quote(p.direction, long_s, short_s)
            if ask <= 0:
                print(f"[ENTRY] {p.direction} quote returned zero ask - retry {p.retries+1}")
                p.retries += 1
                p.mktdata_requested = False
                return
            # Re-check strike conflict now that quote has returned.
            # A WIN fill may have created a butterfly while this thread was
            # fetching the quote, making the proposed strikes newly conflicted.
            if ((long_s, right) in self._existing_shorts() or
                    (short_s, right) in self._existing_longs()):
                print(f"[SKIP ] {p.direction} {int(long_s)}/{int(short_s)} "
                      f"- strike conflict detected after quote (SEC rule)")
                p.mktdata_requested = False
                return
            mid  = (bid + ask) / 2.0
            slot = {
                'pending': p,
                'long_s':  long_s,
                'short_s': short_s,
                'conv_s':  conv_s,
                'right':   right,
                'ctv_cv':  spx,
            }
            self._on_entry_quote(slot, bid, ask, mid)
        except Exception as e:
            print(f"[ENTRY] quote thread error {p.direction}: {e}")
            p.retries += 1
            p.mktdata_requested = False

    def _win_quote_thread(self, trade: 'LiveTrade'):
        """Fetch conversion spread quote then call _on_win_quote."""
        try:
            bid, ask = self.order_manager.get_spread_quote(
                trade.direction, trade.short_strike, trade.conv_strike)
            if bid <= 0:
                print(f"[WIN ] #{trade.trade_id} zero bid on conversion quote - reverting to ACTIVE")
                trade.state = 'ACTIVE'
                return
            self._on_win_quote({'trade': trade}, bid)
        except Exception as e:
            print(f"[WIN ] #{trade.trade_id} win quote thread error: {e}")
            trade.state = 'ACTIVE'

    def _reprice_quote_thread(self, trade: 'LiveTrade'):
        """Fetch fresh entry quote for a stale reprice then call _on_entry_reprice_quote."""
        try:
            bid, ask = self.order_manager.get_spread_quote(
                trade.direction, trade.long_strike, trade.short_strike)
            if ask <= 0:
                print(f"[REPRICE] #{trade.trade_id} zero ask on reprice quote - will retry next bar")
                return
            self._on_entry_reprice_quote({'trade': trade}, bid, ask)
        except Exception as e:
            print(f"[REPRICE] #{trade.trade_id} reprice quote thread error: {e}")

    def _bfly_conv_quote_thread(self, trade: 'LiveTrade', reason: str):
        """Fetch conversion spread quote then call _on_butterfly_conv_quote."""
        try:
            bid, ask = self.order_manager.get_spread_quote(
                trade.direction, trade.short_strike, trade.conv_strike)
            self._on_butterfly_conv_quote({'trade': trade, 'reason': reason}, bid)
        except Exception as e:
            print(f"[BFLY ] #{trade.trade_id} bfly conv quote thread error: {e}")
            trade.state = 'PARKED'


    def _collapse_thread(self, trade_id: int, direction: str,
                         short_strike: float, conv_strike: float,
                         contracts: int):
        """
        Fires immediately after a WIN fill to collapse the CONV_SPREAD_WIDTH
        conversion spread back to SPREAD_WIDTH.

        Collapse spread (net debit):
          UP:   BUY  (short_strike + SPREAD_WIDTH) / SELL conv_strike  (calls)
          DOWN: BUY  (short_strike - SPREAD_WIDTH) / SELL conv_strike  (puts)

        Hardened per IBKR risk-engine guidance (VTB_IBKR_DANCE.pdf):
        - Immediate execution is correct default: IBKR evaluates post-trade
          structure; the collapse is strictly risk-reducing so no delay needed.
        - Bid/ask width check before placing: if the far wing is illiquid
          (wide quote), wait 15s and retry rather than chasing a bad fill.
        - On order rejection (place_collapse returns None), retry after 15s.
        - On poll timeout, cancel the stale order before retry to prevent
          duplicate fills.
        - Max 3 total attempts; OER cost <= 6 actions (3 submits + 3 cancels).
        - If all attempts fail, position remains at CONV_SPREAD_WIDTH.
          Butterfly is still fully protected; only the width is sub-optimal.
        """
        import time as _time

        near = (short_strike + self.cfg.SPREAD_WIDTH if direction == 'UP'
                else short_strike - self.cfg.SPREAD_WIDTH)
        far  = conv_strike   # the outer wing we are closing

        MAX_ATTEMPTS  = 3
        RETRY_DELAY_S = 15   # seconds: lets quotes refresh and tape settle

        for attempt in range(1, MAX_ATTEMPTS + 1):
            try:
                # -- Quote ------------------------------------------------
                bid, ask = self.order_manager.get_spread_quote(direction, near, far)

                if ask <= 0:
                    print(f"[COLL] #{trade_id} attempt {attempt}/{MAX_ATTEMPTS} "
                          f"zero ask on {int(near)}/{int(far)} - "
                          + ("retrying in 15s" if attempt < MAX_ATTEMPTS else "giving up"))
                    if attempt < MAX_ATTEMPTS:
                        _time.sleep(RETRY_DELAY_S)
                    continue

                spread_width = ask - bid
                if bid > 0 and spread_width > self.cfg.MAX_BID_ASK_WIDTH:
                    print(f"[COLL] #{trade_id} attempt {attempt}/{MAX_ATTEMPTS} "
                          f"far-wing quote too wide ${spread_width:.2f} "
                          f"(max ${self.cfg.MAX_BID_ASK_WIDTH:.2f}) "
                          f"bid/ask ${bid:.2f}/${ask:.2f} - "
                          + ("waiting 15s for liquidity" if attempt < MAX_ATTEMPTS
                             else "proceeding on final attempt"))
                    if attempt < MAX_ATTEMPTS:
                        _time.sleep(RETRY_DELAY_S)
                        continue
                    # Final attempt: proceed rather than leave position wide

                # -- Place order ------------------------------------------
                limit = round_to_tick(ask * cfg.ENTRY_SLIPPAGE)
                order_id = self.order_manager.place_collapse(
                    direction, near, far, ask, contracts)

                if order_id is None:
                    print(f"[COLL] #{trade_id} attempt {attempt}/{MAX_ATTEMPTS} "
                          f"place_collapse rejected - "
                          + ("retrying in 15s" if attempt < MAX_ATTEMPTS else "giving up"))
                    if attempt < MAX_ATTEMPTS:
                        _time.sleep(RETRY_DELAY_S)
                    continue

                cost_est = limit * 100
                print(f"[COLL] #{trade_id} attempt {attempt}/{MAX_ATTEMPTS} "
                      f"placed order#{order_id} {direction} "
                      f"{int(near)}/{int(far)} "
                      f"ask=${ask:.2f} limit=${limit:.2f} est_cost=${cost_est:.0f}")

                # -- Poll for fill ----------------------------------------
                filled = False
                for _ in range(120):   # up to 2 minutes
                    _time.sleep(1)
                    status = self.order_manager.get_order(order_id)
                    if status and status.get('status') == 'filled':
                        avg  = float(status.get('avg_fill_price', ask))
                        cost = avg * 100
                        print(f"[COLL] #{trade_id} collapse filled "
                              f"avg=${avg:.2f} cost=${cost:.0f}")
                        filled = True
                        break

                if filled:
                    return

                # -- Timeout: cancel before retry -------------------------
                print(f"[COLL] #{trade_id} order#{order_id} not filled after 2 min "
                      f"- cancelling before "
                      + ("retry" if attempt < MAX_ATTEMPTS else "giving up"))
                try:
                    self.order_manager.cancel(order_id)
                except Exception as ce:
                    print(f"[COLL] #{trade_id} cancel error: {ce}")

                if attempt < MAX_ATTEMPTS:
                    _time.sleep(RETRY_DELAY_S)

            except Exception as e:
                print(f"[COLL] #{trade_id} attempt {attempt}/{MAX_ATTEMPTS} "
                      f"collapse thread error: {e}")
                if attempt < MAX_ATTEMPTS:
                    _time.sleep(RETRY_DELAY_S)

        print(f"[COLL] #{trade_id} all {MAX_ATTEMPTS} collapse attempts exhausted "
              f"- position remains at CONV_SPREAD_WIDTH. "
              f"Butterfly still protected; review logs.")

    def _on_entry_quote(self, slot: dict, bid: float, ask: float, mid: float):
        """Called from _entry_quote_thread when bid+ask received for a pending entry."""
        p = slot['pending']

        # Validate spread width
        width = ask - bid
        if width > self.cfg.MAX_BID_ASK_WIDTH:
            p.retries += 1
            p.mktdata_requested = False   # allow retry next bar
            print(f"[ENTRY] {p.direction} spread too wide ${width:.2f} "
                  f"(max ${self.cfg.MAX_BID_ASK_WIDTH}) retry {p.retries}")
            return

        # -- Auction start logic ------------------------------------------
        # If midpoint > MAX_PREMIUM, don't start auction - keep monitoring.
        # Price may come back. Only abandon if SPX is within ENTRY_OTM_ABANDON
        # of the long strike (handled in _check_entry_auctions).
        mid_price = (bid + ask) / 2.0
        mid_price = round_to_tick(mid_price)
        max_dollar = self.cfg.MAX_PREMIUM / 100.0   # per-share

        if mid_price > max_dollar:
            p.mktdata_requested = False
            print(f"[ENTRY] {p.direction} mid ${mid_price*100:.0f} > max "
                  f"${self.cfg.MAX_PREMIUM:.0f} - holding, not starting auction")
            return

        # Risk check
        if not self.risk_mgr.is_trading_allowed():
            print(f"[RISK] Trading suspended - skipping {p.direction} entry")
            return

        # -- Start auction at midpoint ------------------------------------
        start_bid = mid_price
        contracts = self._calc_contracts(start_bid)

        order_id = self.order_manager.place_entry(
            p.direction, slot['long_s'], slot['short_s'], start_bid, contracts)
        if order_id is None:
            print(f"[ERROR] place_entry failed starting auction - retry")
            p.retries += 1
            p.mktdata_requested = False
            return

        # Lock in auction state on PendingEntry
        p.auction_bid        = start_bid
        p.auction_start_mid  = mid_price
        p.auction_last_step  = datetime.now(self.tz)
        p.auction_order_id   = order_id
        p.auction_long_s     = slot['long_s']
        p.auction_short_s    = slot['short_s']
        p.auction_conv_s     = slot['conv_s']
        p.mktdata_requested  = False   # allow _check_entry_auctions to run

        # Register a placeholder trade for fill polling
        self._trade_id_seq += 1
        trade = LiveTrade(
            trade_id         = self._trade_id_seq,
            direction        = p.direction,
            right            = slot['right'],
            ctv_cv           = slot['ctv_cv'],
            entry_time       = p.signal_time,
            state            = 'PENDING_FILL',
            long_strike      = slot['long_s'],
            short_strike     = slot['short_s'],
            conv_strike      = slot['conv_s'],
            premium_paid     = start_bid * 100,
            win_target       = 0.0,
            min_profit_price = 0.0,
            entry_order_id   = order_id,
            contracts        = contracts,
        )
        trade.entry_limit_price       = start_bid
        trade.entry_order_placed_time = datetime.now(self.tz)
        self.trades.append(trade)

        threading.Thread(
            target=self._poll_order_fill,
            args=(order_id, 'ENTRY', trade.trade_id),
            daemon=True,
        ).start()

        print(f"[ENTRY] #{trade.trade_id} {trade.direction} "
              f"{int(slot['long_s'])}/{int(slot['short_s'])}/{int(slot['conv_s'])} "
              f"auction started @ ${start_bid*100:.0f} "
              f"(mid=${mid_price*100:.0f} max=${self.cfg.MAX_PREMIUM:.0f})")

    def _on_entry_fill(self, order_id: int, trade: Optional[LiveTrade],
                       avg_fill_price: float):
        """Called from orderStatus when entry BAG fills."""
        if trade is None:
            return

        trade.premium_paid     = avg_fill_price * 100
        trade.min_profit_price = trade.premium_paid * cfg.MIN_CONV_CREDIT_PCT
        trade.spx_at_fill      = self._live_spx
        trade.vix_at_entry     = self._vix
        trade.state            = 'ACTIVE'

        # win_target: SPX must reach short_strike +/- WIN_TARGET_BUFFER
        # (short leg just outside the money at conversion time)
        if trade.direction == 'UP':
            trade.win_target = trade.short_strike + self.cfg.WIN_TARGET_BUFFER
        else:
            trade.win_target = trade.short_strike - self.cfg.WIN_TARGET_BUFFER

        self._save_state()
        self._log_entry(trade)

        _fill_ts = datetime.now(self.tz).strftime('%H:%M:%S')
        print(f"[FILL] {_fill_ts} #{trade.trade_id} {trade.direction} "
              f"filled @ ${avg_fill_price:.2f} "
              f"(${trade.premium_paid:.0f} total) "
              f"spx_at_fill={trade.spx_at_fill:.2f} "
              f"win_target={trade.win_target:.2f} "
              f"min_conv_credit=${trade.min_profit_price:.0f} "
              f"min_net_profit=${trade.min_profit_price - trade.premium_paid:.0f}")

        if self.pushover and NOTIFY_ALL_TRADES:
            try:
                self.pushover.send_trade_entry_alert(
                    direction    = trade.direction,
                    long_strike  = trade.long_strike,
                    short_strike = trade.short_strike,
                    entry_price  = trade.premium_paid,
                    spx_price    = trade.spx_at_fill,
                    profit_target= trade.min_profit_price - trade.premium_paid,
                )
            except Exception:
                pass

    # =========================================================================
    # INTRABAR WIN DETECTION
    # =========================================================================


    def _on_entry_reprice_quote(self, slot: dict, bid: float, ask: float):
        """
        Called from tickPrice when a fresh quote arrives for a stale entry reprice.
        Applies premium cap and EMA viability re-check, then places a new order.
        Limit = ask * ENTRY_SLIPPAGE, tick-rounded.
        """
        trade = slot["trade"]
        if trade is None or trade.state != "PENDING_FILL":
            return

        # Final EMA viability check at quote time
        _ema = self._spx_agg.get_ema_state()
        _dir_ok = (_ema['ema36'] > _ema['ema180'] if trade.direction == 'UP'
                   else _ema['ema36'] < _ema['ema180'])
        if not (_dir_ok and _ema['sep_curr'] > self.cfg.EMA_DIRECTION_THRESHOLD):
            print(f"[REPRICE] #{trade.trade_id} {trade.direction} "
                  f"no longer viable at quote - cancelling")
            self._log_cancelled(trade, "EMA_NO_LONGER_VIABLE")
            self.trades = [t for t in self.trades if t.trade_id != trade.trade_id]
            return

        # Price the new limit
        entry_limit   = round_to_tick(ask * cfg.ENTRY_SLIPPAGE)
        premium_est   = entry_limit * 100

        if premium_est > self.cfg.MAX_PREMIUM:
            print(f"[REPRICE] #{trade.trade_id} {trade.direction} "
                  f"too expensive at reprice ${premium_est:.0f} > "
                  f"${self.cfg.MAX_PREMIUM:.0f} - will retry next bar")
            return

        # Place repriced order via Tradier REST
        order_id = self.order_manager.place_entry(
            trade.direction, trade.long_strike, trade.short_strike, ask, trade.contracts)
        if order_id is None:
            print(f"[REPRICE] #{trade.trade_id} place_entry failed - will retry next bar")
            return

        trade.entry_limit_price        = entry_limit
        trade.entry_order_id           = order_id
        trade.entry_order_placed_time  = datetime.now(self.tz)
        threading.Thread(
            target=self._poll_order_fill,
            args=(order_id, 'ENTRY', trade.trade_id),
            daemon=True,
        ).start()
        print(f"[REPRICE] #{trade.trade_id} {trade.direction} "
              f"new limit=${entry_limit:.2f} (ask=${ask:.2f}) "
              f"est=${premium_est:.0f}")

    def _check_win_targets(self):
        """
        Called on every historicalDataUpdate tick (~1 second).
        Checks all ACTIVE trades - has _live_spx crossed win_target?
        If yes: request live conversion spread quote, mark PENDING_WIN_QUOTE
        so we don't double-trigger.
        """
        if self._live_spx <= 0:
            return
        for trade in self.trades:
            if trade.state != 'ACTIVE':
                continue
            triggered = (
                (trade.direction == 'UP'   and self._live_spx >= trade.win_target) or
                (trade.direction == 'DOWN' and self._live_spx <= trade.win_target)
            )
            if not triggered:
                continue

            # Mark immediately - prevents double-trigger on next tick
            trade.state = 'PENDING_WIN_QUOTE'
            print(f"[WIN ] #{trade.trade_id} {trade.direction} "
                  f"win_target={trade.win_target:.2f} reached "
                  f"(SPX={self._live_spx:.2f}) - requesting conversion quote")

            threading.Thread(
                target=self._win_quote_thread,
                args=(trade,),
                daemon=True,
            ).start()

    def _on_win_quote(self, slot: dict, bid: float):
        """
        Called from tickPrice when conversion spread bid received.
        Places win sell at max(bid ? 0.95, min_profit_price/100), tick-rounded.
        """
        trade = slot['trade']
        if trade is None:
            return

        order_id = self.order_manager.place_win_sell(
            trade.direction, trade.short_strike, trade.conv_strike,
            bid, trade.min_profit_price, trade.contracts)
        if order_id is None:
            print(f"[ERROR] #{trade.trade_id} place_win_sell failed - reverting to ACTIVE")
            trade.state = 'ACTIVE'
            return

        trade.win_order_id          = order_id
        trade.win_order_placed_time = datetime.now(self.tz)
        threading.Thread(
            target=self._poll_order_fill,
            args=(order_id, 'WIN', trade.trade_id),
            daemon=True,
        ).start()
        print(f"[WIN ] {datetime.now(self.tz).strftime('%H:%M:%S')} #{trade.trade_id} win sell placed order#{order_id}")

    # =========================================================================
    # TRADE MANAGEMENT: PARK / UNPARK / PARK-RANGE
    # =========================================================================

    def _check_stale_orders(self):
        """
        Called at every 3-minute bar boundary.
        Handles three cases of unfilled orders sitting more than one bar:

        PENDING_FILL  : cancel entry order, check EMA viability, reprice via
                        fresh quote if still viable, log CANCELLED if not.
        PENDING_WIN_QUOTE: cancel, revert to ACTIVE, let _check_win_targets retry.
        PENDING_BUTTERFLY: cancel, reprice via fresh conversion quote.

        Also resets any PendingEntry whose market data request received no quote
        response, so _try_enter_pending fires a fresh request next bar.
        """
        now = datetime.now(self.tz)
        stale_seconds = 180   # one full bar

        # -- Stale pending entry quotes (no response from IB snapshot) --------
        for p in self.pending_entries:
            if p.mktdata_requested:
                print(f"[STALE] {p.direction} pending entry quote never returned "
                      f"- resetting for retry next bar")
                p.mktdata_requested = False

        for trade in list(self.trades):

            # -- Stale entry orders (PENDING_FILL) -------------------------
            if (trade.state == 'PENDING_FILL' and
                    trade.entry_order_placed_time is not None):
                age = (now - trade.entry_order_placed_time).total_seconds()
                if age >= stale_seconds:
                    right_label = 'C' if trade.right == 'C' else 'P'
                    print(f"[CANCEL] #{trade.trade_id} {right_label} "
                          f"entry order#{trade.entry_order_id} "
                          f"unfilled {age:.0f}s - checking viability and repricing")
                    self.order_manager.cancel(trade.entry_order_id)
                    trade.entry_order_placed_time = None

                    # EMA viability check
                    _ema = self._spx_agg.get_ema_state()
                    _dir_ok = (_ema['ema36'] > _ema['ema180'] if trade.direction == 'UP'
                               else _ema['ema36'] < _ema['ema180'])
                    if not (_dir_ok and _ema['sep_curr'] > self.cfg.EMA_DIRECTION_THRESHOLD):
                        print(f"[STALE] #{trade.trade_id} {trade.direction} "
                              f"no longer viable - cancelling entry")
                        self._log_cancelled(trade, 'EMA_NO_LONGER_VIABLE')
                        self.trades = [t for t in self.trades
                                       if t.trade_id != trade.trade_id]
                        continue

                    # Re-request quote for repricing via REST
                    threading.Thread(
                        target=self._reprice_quote_thread,
                        args=(trade,),
                        daemon=True,
                    ).start()
                    print(f"[STALE] #{trade.trade_id} requesting fresh quote for reprice")
                continue   # skip win_order_id checks below for PENDING_FILL

            # -- Stale win / butterfly orders ------------------------------
            # Safety net: PENDING_WIN_QUOTE with no order placed means the
            # quote request errored before an order could be submitted.
            # error() should have reverted state, but catch it here too.
            if trade.win_order_id == 0:
                if trade.state == 'PENDING_WIN_QUOTE':
                    trade.state = 'ACTIVE'
                    print(f"[STALE] #{trade.trade_id} PENDING_WIN_QUOTE with no "
                          f"order placed - reverted to ACTIVE")
                continue
            if trade.win_order_placed_time is None:
                continue
            age = (now - trade.win_order_placed_time).total_seconds()
            if age < stale_seconds:
                continue

            if trade.state == 'PENDING_WIN_QUOTE':
                print(f"[STALE] #{trade.trade_id} win order#{trade.win_order_id} "
                      f"unfilled for {age:.0f}s - cancelling and repricing")
                self.order_manager.cancel(trade.win_order_id)
                trade.win_order_id         = 0
                trade.win_order_placed_time = None
                trade.state                = 'ACTIVE'
                # _check_win_targets will re-trigger on next SPX tick
                # if SPX is still above win_target

            elif trade.state == 'PENDING_BUTTERFLY':
                reason = trade.bfly_reason or 'REPRICE'
                print(f"[STALE] #{trade.trade_id} butterfly order#{trade.win_order_id} "
                      f"unfilled for {age:.0f}s - cancelling and repricing "
                      f"(reason={reason})")
                self.order_manager.cancel(trade.win_order_id)
                trade.win_order_id         = 0
                trade.win_order_placed_time = None
                # Reset to PARKED so _initiate_butterfly_conversion guard passes
                trade.state = 'PARKED'
                self._initiate_butterfly_conversion(trade, reason)

    def _process_trades(self, bar: dict, current_dir: Optional[str],
                        separation: float):
        """
        For each open trade:
          ACTIVE:
            - direction flipped (confirmed)  -> PARK
            - inside noise band (sep < threshold):
                - set noise_entry_spx on first entry
                - if adverse move >= ACTIVE_ADVERSE_MOVE -> butterfly (NOISE_ADVERSE)
            - sep recovered -> clear noise_entry_spx
          PARKED:
            - direction restored -> UNPARK
            - sep >= EMA/VIX tier threshold in opposite direction -> butterfly (EMA_VIX)
        """
        close = bar['close'] if bar['close'] > 0 else bar['open']
        now   = datetime.now(self.tz).time()

        # VIX tier lookup for parked conversion threshold
        vix = self._vix
        if vix <= 0 or (PARK_VIX_LOW <= vix <= PARK_VIX_HIGH):
            park_ema_threshold = self.cfg.PARK_CONVERT_EMA_MID
        elif vix < PARK_VIX_LOW:
            park_ema_threshold = self.cfg.PARK_CONVERT_EMA_LOW
        else:
            park_ema_threshold = self.cfg.PARK_CONVERT_EMA_HIGH

        in_noise_band = separation < self.cfg.EMA_DIRECTION_THRESHOLD

        for trade in list(self.trades):
            if trade.state in ('PENDING_BUTTERFLY',):
                continue

            if trade.state == 'ACTIVE':
                if in_noise_band:
                    # Enter noise band tracking
                    if trade.noise_entry_spx == 0.0:
                        trade.noise_entry_spx = close
                        print(f"[NOISE] #{trade.trade_id} {trade.direction} "
                              f"entered noise band @ SPX {close:.2f}")
                    else:
                        # Check adverse drift from noise band entry
                        adverse = (close - trade.noise_entry_spx
                                   if trade.direction == 'UP'
                                   else trade.noise_entry_spx - close)
                        if adverse >= self.cfg.ACTIVE_ADVERSE_MOVE:
                            print(f"[NOISE] #{trade.trade_id} {trade.direction} "
                                  f"adverse {adverse:.1f} pts from noise entry "
                                  f"({trade.noise_entry_spx:.2f} -> {close:.2f}) "
                                  f"- converting to butterfly")
                            self._initiate_butterfly_conversion(trade, 'NOISE_ADVERSE')
                else:
                    # Separation recovered - clear noise tracking
                    if trade.noise_entry_spx != 0.0:
                        print(f"[NOISE] #{trade.trade_id} {trade.direction} "
                              f"exited noise band - tracking cleared")
                        trade.noise_entry_spx = 0.0
                    # Confirmed opposite direction -> park
                    if current_dir is not None and current_dir != trade.direction:
                        self._park_trade(trade, close, now)

            elif trade.state == 'PARKED':
                if current_dir == trade.direction:
                    self._unpark_trade(trade)
                elif (current_dir is not None and
                      current_dir != trade.direction and
                      separation >= park_ema_threshold):
                    print(f"[EMA_VIX] #{trade.trade_id} {trade.direction} "
                          f"opp dir={current_dir} sep={separation:.2f} >= "
                          f"threshold={park_ema_threshold:.1f} "
                          f"(VIX={vix:.1f}) - converting to butterfly")
                    self._initiate_butterfly_conversion(trade, 'EMA_VIX')

    def _park_trade(self, trade: LiveTrade, close: float, now):
        """Park an active trade on direction reversal."""
        trade.state    = 'PARKED'
        trade.park_spx = close
        print(f"[PARK ] #{trade.trade_id} {trade.direction} parked @ SPX {close:.2f}")

        if self.pushover and NOTIFY_ALL_TRADES:
            try:
                self.pushover.send_position_parked_alert(
                    direction  = trade.direction,
                    spx_price  = close,
                )
            except Exception:
                pass

    def _unpark_trade(self, trade: LiveTrade):
        """Direction returned to match trade - unpark it."""
        trade.state = 'ACTIVE'
        print(f"[UNPK ] #{trade.trade_id} {trade.direction} unparked")

    # =========================================================================
    # CHAINED RE-ENTRY AFTER WIN
    # =========================================================================

    def _try_chain_entry(self, direction: str, conv_strike: float, right: str):
        """
        After a WIN fill, attempt a chained re-entry.
        The conv_strike of the completed trade becomes the new long_strike -
        we already own it from the conversion buy leg.

        Fires async from the WIN orderStatus callback.
        Validates entry window, direction still viable, risk, trade limits.
        Then requests market data for the new vertical spread.
        """
        now = datetime.now(self.tz).time()

        # Entry window check
        if now < cfg.TRADING_START or now > cfg.LAST_ENTRY_TIME:
            print(f"[CHAIN] {direction} - outside entry window, no chain")
            return

        # Direction must still be viable
        _ema = self._spx_agg.get_ema_state()
        _dir_ok = (_ema['ema36'] > _ema['ema180'] if direction == 'UP'
                   else _ema['ema36'] < _ema['ema180'])
        if not (_dir_ok and _ema['sep_curr'] > self.cfg.EMA_DIRECTION_THRESHOLD):
            print(f"[CHAIN] {direction} - direction no longer viable, no chain")
            return

        # Trend must still be accelerating (5-second rolling EMA36/EMA180)
        if not self._spx_agg.is_accelerating(direction):
            print(f"[CHAIN] {direction} - trend not accelerating, no chain")
            return

        # Risk check
        if not self.risk_mgr.is_trading_allowed():
            print(f"[CHAIN] {direction} - trading suspended, no chain")
            return

        # Trade limits: one active/in-flight trade max; parked slot cap.
        _active_states = {'PENDING_FILL', 'ACTIVE', 'PENDING_WIN_QUOTE', 'PENDING_BUTTERFLY'}
        if any(t.state in _active_states for t in self.trades):
            print(f"[CHAIN] {direction} - active trade in flight, no chain")
            return
        if sum(1 for t in self.trades if t.state == 'PARKED') >= _MAX_PARKED:
            print(f"[CHAIN] {direction} - max parked ({_MAX_PARKED}) reached, no chain")
            return
        if any(t.direction == direction for t in self.trades):
            print(f"[CHAIN] {direction} - trade already open in same direction")
            return
        if any(p.direction == direction for p in self.pending_entries):
            print(f"[CHAIN] {direction} - pending entry already in same direction, no chain")
            return

        # Calculate chained strikes - conv_strike becomes new long
        long_s, short_s, conv_s = self.order_manager.calc_chained_strikes(
            conv_strike, direction)

        # Strike conflict: covers open trades and existing butterflies
        proposed_right = 'C' if direction == 'UP' else 'P'
        if (long_s, proposed_right) in self._existing_shorts() or (short_s, proposed_right) in self._existing_longs():
            print(f"[CHAIN] {direction} {int(long_s)}/{int(short_s)} "
                  f"- strike conflict with open position, no chain")
            return

        p = PendingEntry(
            direction         = direction,
            signal_time       = datetime.now(self.tz),
            ctv_cv            = self._live_spx,
            right             = 'C' if direction == 'UP' else 'P',
            mktdata_requested = True,
        )
        threading.Thread(
            target=self._entry_quote_thread,
            args=(p, long_s, short_s, conv_s, self._live_spx),
            daemon=True,
        ).start()
        print(f"[CHAIN] {direction} {int(long_s)}/{int(short_s)}/{int(conv_s)} "
              f"- chained entry queued (long from conv_strike={int(conv_strike)})")

    # =========================================================================
    # BUTTERFLY CONVERSION  (park range / PM boundary / intrinsic)
    # =========================================================================

    def _initiate_butterfly_conversion(self, trade: LiveTrade, reason: str):
        """
        Convert a distressed LiveTrade into a LiveButterfly by selling the
        conversion spread (short_strike ? conv_strike) for whatever bid we can get.
        Replaces both the PM stop-loss order and the park-range force-close.
        Sets state = PENDING_BUTTERFLY so _process_trades ignores it.
        """
        if trade.state == 'PENDING_BUTTERFLY':
            return

        trade.state = 'PENDING_BUTTERFLY'

        # Cancel any outstanding win orders
        if trade.win_order_id:
            self.order_manager.cancel(trade.win_order_id)

        threading.Thread(
            target=self._bfly_conv_quote_thread,
            args=(trade, reason),
            daemon=True,
        ).start()
        print(f"[BFLY ] #{trade.trade_id} {trade.direction} "
              f"reason={reason} - requesting conversion spread quote")

    def _on_butterfly_conv_quote(self, slot: dict, bid: float):
        """
        Place LMT SELL on the conversion spread at bid ? SELL_SLIPPAGE.
        No profit floor - take whatever we can get.
        On fill (orderStatus BFLY_CONV): promote to LiveButterfly, free slot.
        """
        trade  = slot['trade']
        reason = slot.get('reason', 'BFLY_CONV')
        if trade is None:
            return

        if bid <= 0:
            print(f"[BFLY ] #{trade.trade_id} zero bid on conversion spread "
                  f"- position will expire at expiry")
            trade.state = 'PARKED'
            return

        order_id = self.order_manager.place_win_sell(
            trade.direction, trade.short_strike, trade.conv_strike,
            bid, 0, trade.contracts)
        if order_id is None:
            print(f"[BFLY ] #{trade.trade_id} place_win_sell failed "
                  f"- position will expire at expiry")
            trade.state = 'PARKED'
            return

        trade.win_order_id          = order_id
        trade.bfly_reason           = reason
        trade.win_order_placed_time = datetime.now(self.tz)
        threading.Thread(
            target=self._poll_order_fill,
            args=(order_id, 'BFLY_CONV', trade.trade_id, reason),
            daemon=True,
        ).start()
        print(f"[BFLY ] #{trade.trade_id} {trade.direction} "
              f"conversion sell placed order#{order_id} (bid=${bid:.2f}) reason={reason}")

    # =========================================================================
    # LATE-DAY INTRINSIC EXIT
    # =========================================================================

    def _check_late_day_exits(self):
        """
        Called every second from main loop.
        At INTRINSIC_EXIT_TIME: initiate butterfly conversion for all open
        trades. Retries failed conversions (state reverted to ACTIVE/PARKED
        after a zero-bid or poll timeout) every 5 minutes, up to 6 total
        attempts (initial + 5 retries). Beyond that, remaining positions
        expire at close.

        Pacing rationale: up to 4 positions x 2 OER actions (submit + cancel)
        x 6 attempts = 48 OER actions worst-case, staying under IBKR's 50:1
        OER daily limit even with zero fills.
        """
        if self._intrinsic_done:
            return
        now_t = datetime.now(self.tz).time()
        if now_t < cfg.INTRINSIC_EXIT_TIME:
            return

        # Clear pending entries once, on first trigger
        if not self._intrinsic_entries_cleared:
            if self.pending_entries:
                print(f"[INTRINSIC] Clearing {len(self.pending_entries)} "
                      f"pending entry slot(s) at EOD")
                self.pending_entries.clear()
            self._intrinsic_entries_cleared = True

        # Trades eligible for conversion: ACTIVE or PARKED (not already in flight)
        open_trades = [t for t in self.trades
                       if t.state not in ('PENDING_BUTTERFLY',)]

        if not open_trades:
            self._intrinsic_done = True
            return

        # Hard cap: after 6 total attempts, let remaining positions expire
        if self._intrinsic_attempt_count >= 6:
            if not self._intrinsic_done:
                print(f"[INTRINSIC] Max attempts reached - "
                      f"{len(open_trades)} position(s) will expire at close")
                self._intrinsic_done = True
            return

        # Pace retries: 5-minute intervals (300s)
        # With up to 4 positions x 2 OER actions x 6 attempts = 48 worst-case,
        # safely under IBKR's 50:1 OER limit.
        now_dt = datetime.now(self.tz)
        if self._last_intrinsic_attempt is not None:
            elapsed = (now_dt - self._last_intrinsic_attempt).total_seconds()
            if elapsed < 300:
                return

        self._last_intrinsic_attempt = now_dt
        self._intrinsic_attempt_count += 1

        print(f"\n[INTRINSIC] Attempt #{self._intrinsic_attempt_count}/6 "
              f"@ {now_t.strftime('%H:%M:%S')} - converting "
              f"{len(open_trades)} open trade(s) to butterflies")
        for trade in open_trades:
            self._initiate_butterfly_conversion(trade, 'INTRINSIC')
        remaining = 6 - self._intrinsic_attempt_count
        if remaining > 0:
            print(f'[INTRINSIC] Conversions submitted - '
                  f'{remaining} retry attempt(s) remaining if needed')
        else:
            print('[INTRINSIC] Final attempt submitted - '
                  'unconverted positions will expire at close')

    def _calc_bfly_expiration(self, bf: LiveButterfly, spx: float) -> float:
        """
        Estimate butterfly expiration value based on SPX close.
        All butterflies are equidistant 5-point wings: long / short / conv.

        UP  (calls): long < spx <= short  ?  (spx - long)  ? 100
                     short < spx <= conv  ?  (conv - spx)  ? 100
                     otherwise            ?  0.0

        DOWN (puts): short <= spx < long  ?  (long - spx)  ? 100
                     conv  <= spx < short ?  (spx - conv)  ? 100
                     otherwise            ?  0.0
        """
        lo = bf.long_strike
        mid = bf.short_strike
        hi = bf.conv_strike
        if bf.direction == 'UP':
            if lo < spx <= mid:
                return (spx - lo) * 100
            if mid < spx <= hi:
                return (hi - spx) * 100
        else:  # DOWN - strikes descend: hi=long > mid=short > lo=conv
            if mid <= spx < lo:
                return (lo - spx) * 100
            if hi <= spx < mid:
                return (spx - hi) * 100
        return 0.0

    # =========================================================================
    # END-OF-DAY SUMMARY & MARKET CLOSE
    # =========================================================================

    def _print_tradier_eod_report(self):
        """
        Query Tradier order history and print the live EOD accounting report.
        Called from _check_market_close() when LIVE_TRADING=True only.

        Answers four questions:
          1. What did the long positions cost in total?
          2. Which had a conversion, and at what sale price?
          3. How many long positions expired without a sale?
          4. What was the total cost of those expired positions?

        Identification uses the orders endpoint (the only authoritative
        source for multileg fill prices). gainloss is NOT used - it is a
        post-clearing, position-level summary that destroys bag relationships
        and never reflects cash-settled SPX expirations correctly.
        """
        today = datetime.now(self.tz).strftime('%Y-%m-%d')
        try:
            report = self.client.get_eod_report(today)
        except Exception as e:
            print(f'[EOD ] Tradier EOD report failed: {e}')
            return

        entries    = report['entries']
        matched    = report['matched']
        expired    = report['expired']
        total_cost = report['total_cost']
        exp_cost   = report['total_expired_cost']

        print(f"\n{'='*60}")
        print(f' EOD ORDER REPORT - {today}')
        print(f"{'='*60}")
        print(f'  Long positions opened  : {len(entries)}')
        print(f'  Total long cost        : ${total_cost:.0f}')
        print()

        if matched:
            print(f'  Converted ({len(matched)}):')
            for m in matched:
                e   = m['entry']
                c   = m['conversion']
                net = c['net_credit'] - e['net_cost']
                sign = '+' if net >= 0 else ''
                print(f'    #{e["order_id"]}  {e["right"]}  '
                      f'{int(e["long_strike"])}/{int(e["short_strike"])}  '
                      f'cost=${e["net_cost"]:.0f}  '
                      f'sale=${c["net_credit"]:.0f}  '
                      f'net={sign}${net:.0f}')
        else:
            print(f'  Converted              : 0')

        print()
        if expired:
            print(f'  Expired without sale   : {len(expired)}')
            for e in expired:
                print(f'    #{e["order_id"]}  {e["right"]}  '
                      f'{int(e["long_strike"])}/{int(e["short_strike"])}  '
                      f'cost=${e["net_cost"]:.0f}')
            print(f'  Total expired cost     : ${exp_cost:.0f}')
        else:
            print(f'  Expired without sale   : 0')

        print(f"{'='*60}\n")

    def _print_eod_summary(self):
        """Print session summary once intrinsic exit is complete."""
        # Log butterfly records - only once; _check_market_close may call this
        # a second time after _check_late_day_exits already called it.
        if not self._bfly_logged:
            for bf in self.butterflies:
                self._log_butterfly(bf)
            self._bfly_logged = True

        total = self._session_wins + self._session_losses
        sign  = '+' if self._session_pnl >= 0 else ''
        risk  = self.risk_mgr.get_status_line()

        print(f"\n{'='*60}")
        print(f" SESSION SUMMARY - {datetime.now(self.tz).strftime('%Y-%m-%d')}")
        print(f"{'='*60}")
        print(f"  Closed trades  : {total}  "
              f"({self._session_wins}W / {self._session_losses}L)")
        print(f"  Open butterflies: {len(self.butterflies)}")
        print(f"  Net P&L        : {sign}${self._session_pnl:.0f}")
        if self._session_bfly_expiration > 0:
            total_with_exp = self._session_pnl + self._session_bfly_expiration
            sign_exp = '+' if total_with_exp >= 0 else ''
            print(f"  Bfly expiration: +${self._session_bfly_expiration:.0f}")
            print(f"  Total w/ expiry: {sign_exp}${total_with_exp:.0f}")
        print(f"  Risk status    : {risk}")
        print(f"  Trade log      : {self._log_path}")
        summary_path = self._write_eod_summary()
        if summary_path:
            print(f"  Trade summary  : {summary_path}")
        print(f"{'='*60}\n")

        # EOD digest to phone
        if self.pushover and getattr(cfg, 'PUSHOVER_EOD_DIGEST', True):
            try:
                self.pushover.send_daily_digest(
                    wins=self._session_wins,
                    losses=self._session_losses,
                    net_pnl=self._session_pnl,
                    bfly_count=len(self.butterflies),
                    bfly_expiration=self._session_bfly_expiration,
                    vix_min=self._vix_day_min,
                    vix_max=self._vix_day_max,
                )
            except Exception as e:
                print(f"[PUSHOVER] EOD digest failed: {e}")

    def _write_eod_summary(self) -> str:
        """
        Write a one-row-per-trade summary CSV to logs/summary_YYYYMMDD.csv.

        Reads the session's trade log (which has separate ENTRY and EXIT rows)
        and joins them by trade_id so each closed trade becomes a single line.
        Butterfly EOD records are included as their own rows (outcome=BFLY_EOD).
        Returns the summary path string, or '' on failure.
        """
        try:
            today_str   = datetime.now(self.tz).strftime('%Y-%m-%d')
            log_dir     = Path('logs')
            summary_path = log_dir / f"summary_{today_str.replace('-', '')}.csv"

            # Flush and re-read the session log so all EXIT rows are present
            self._log_file.flush()

            entries = {}   # trade_id -> row dict (ENTRY row)
            exits   = {}   # trade_id -> row dict (EXIT row)

            with open(self._log_path, newline='') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    tid = row.get('trade_id', '')
                    rt  = row.get('record_type', '')
                    if rt == 'ENTRY':
                        entries[tid] = row
                    elif rt in ('EXIT', 'BUTTERFLY'):
                        exits[tid] = row

            summary_fields = [
                'date', 'trade_id', 'direction', 'right',
                'long_strike', 'short_strike',
                'entry_time', 'premium_paid',
                'exit_credit', 'net_pnl',
                'outcome', 'state_at_close',
            ]

            rows_written = 0
            with open(summary_path, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=summary_fields,
                                        extrasaction='ignore')
                writer.writeheader()

                # Closed trades - ENTRY + EXIT joined
                for tid, entry in entries.items():
                    exit_row = exits.get(tid, {})
                    writer.writerow({
                        'date':          today_str,
                        'trade_id':      tid,
                        'direction':     entry.get('direction', ''),
                        'right':         entry.get('right', ''),
                        'long_strike':   entry.get('long_strike', ''),
                        'short_strike':  entry.get('short_strike', ''),
                        'entry_time':    entry.get('entry_time', ''),
                        'premium_paid':  entry.get('premium_paid', ''),
                        'exit_credit':   exit_row.get('exit_credit', ''),
                        'net_pnl':       exit_row.get('net_pnl', ''),
                        'outcome':       exit_row.get('outcome', 'OPEN'),
                        'state_at_close': exit_row.get('state_at_close', ''),
                    })
                    rows_written += 1

                # Butterfly EOD records with no matching ENTRY (conv legs)
                for tid, exit_row in exits.items():
                    if tid not in entries:
                        writer.writerow({
                            'date':          today_str,
                            'trade_id':      tid,
                            'direction':     exit_row.get('direction', ''),
                            'right':         exit_row.get('right', ''),
                            'long_strike':   exit_row.get('long_strike', ''),
                            'short_strike':  exit_row.get('short_strike', ''),
                            'entry_time':    '',
                            'premium_paid':  exit_row.get('premium_paid', ''),
                            'exit_credit':   exit_row.get('exit_credit', ''),
                            'net_pnl':       exit_row.get('net_pnl', ''),
                            'outcome':       exit_row.get('outcome', ''),
                            'state_at_close': exit_row.get('state_at_close', ''),
                        })
                        rows_written += 1

            print(f"[CSV ] EOD summary: {rows_written} trade(s) written to {summary_path}")
            return str(summary_path)

        except Exception as e:
            print(f"[CSV ] EOD summary failed: {e}")
            return ''

    def _check_market_close(self):
        """
        Called every second from main loop.
        At 16:00 ET: print final session summary and mark session done.
        Bars may still trickle in but no signals are evaluated after this point.
        """
        if self._session_done:
            return
        now = datetime.now(self.tz).time()
        if now < dtime(16, 0):
            return

        self._session_done = True

        # -- Auth disable - write flag and notify user at 16:00 ------------
        if self._auth_disable_pending:
            write_local_disable_flag(self._auth_disable_reason)
            if self.pushover:
                try:
                    reason_line = (f"\n\nReason: {self._auth_disable_reason}"
                                   if self._auth_disable_reason else "")
                    self.pushover.send_alert(
                        f"?? CTV2 - Trading Access Notice\n\n"
                        f"Your access has been changed. Trading has stopped "
                        f"for today.\n\n"
                        f"CTV2 will not resume on restart until access is "
                        f"restored.{reason_line}\n\n"
                        f"Contact Greg if you have questions."
                    )
                except Exception:
                    pass

        # -- Butterfly expiration value at close ---------------------------
        spx_close = self._live_spx
        self._session_bfly_expiration = 0.0
        for bf in self.butterflies:
            exp_val = self._calc_bfly_expiration(bf, spx_close)
            self._session_bfly_expiration += exp_val
            if exp_val > 0:
                self._log_writer.writerow({
                    'record_type':      'BFLY_EXPIRATION',
                    'trade_id':         bf.trade_id,
                    'direction':        bf.direction,
                    'right':            bf.right,
                    'entry_time':       bf.entry_time.isoformat(),
                    'long_strike':      bf.long_strike,
                    'short_strike':     bf.short_strike,
                    'conv_strike':      bf.conv_strike,
                    'contracts':        '',
                    'ctv_cv':           '',
                    'premium_paid':     f"{bf.premium_paid:.2f}",
                    'min_profit_price': '',
                    'win_target':       '',
                    'entry_limit_price':'',
                    'fill_slippage':    '',
                    'vix_at_entry':     f"{bf.vix_at_entry:.2f}",
                    'spx_at_fill':      f"{spx_close:.2f}",
                    'outcome':          'BFLY_EXPIRATION',
                    'exit_credit':      f"{exp_val:.2f}",
                    'net_pnl':          f"{exp_val:.2f}",
                    'net_cost':         f"{bf.net_cost:.2f}",
                    'bfly_reason':      bf.bfly_reason,
                    'state_at_close':   'EXPIRED',
                })
        self._log_file.flush()

        # -- Expired verticals (open trades not converted or closed) -------
        # Any trade still in self.trades at 16:00 expired worthless.
        # Log a zero-credit exit so the full premium paid counts as a loss.
        for trade in list(self.trades):
            print(f"[EOD ] Trade #{trade.trade_id} {trade.direction} "
                  f"{int(trade.long_strike)}/{int(trade.short_strike)} "
                  f"expired worthless - recording as loss "
                  f"(${trade.premium_paid:.2f})")
            self._log_trade(trade, outcome='EXPIRED',
                            exit_credit=0.0,
                            state_at_close='EXPIRED')
        self.trades.clear()

        if LIVE_TRADING:
            self._print_tradier_eod_report()

        self._print_eod_summary()

        # Stop the stream and disconnect order manager
        if self._stream:
            try:
                self._stream.stop()
            except Exception:
                pass
        try:
            self.order_manager.disconnect()
        except Exception:
            pass

        print("[SESSION] Market closed - CTV2 session complete. Looping to next trading day.\n")
        raise _SessionComplete

    # =========================================================================
    # INTEGRITY CHECK  (called every bar - advisory only, never stops trading)
    # =========================================================================
    # AUTHORIZATION POLL  (called every bar)
    # =========================================================================

    def _check_auth_poll(self):
        """
        Re-check remote auth.json once per bar (5s timeout).
        Fetch failures are silent - only a confirmed disable triggers action.
        If disable detected: set _auth_disable_pending and log.
        Action (flag write + Pushover) is deferred to _check_market_close() at 16:00.
        """
        if self._auth_disable_pending:
            return   # already flagged this session

        auth_data = fetch_auth(timeout=5)
        if auth_data is None:
            return   # GitHub unreachable - silent, continue trading

        result = check_auth(self._machine_id,
                            float((Path('VERSION').read_text(encoding='utf-8').strip())),
                            auth_data)
        if not result['allowed']:
            self._auth_disable_pending = True
            self._auth_disable_reason  = result['reason']
            print(f"\n{'='*60}")
            print(f"  [AUTH ] Access change detected.")
            print(f"  [AUTH ] Trading continues normally today.")
            print(f"  [AUTH ] CTV2 will not restart after market close.")
            print(f"  [AUTH ] Reason: {self._auth_disable_reason}")
            print(f"{'='*60}\n")

    # =========================================================================
    # PUSHOVER HELPERS
    # =========================================================================

    def _notify_suspension(self):
        """Fire risk-suspension Pushover alert. Called after any record_outcome
        that puts is_trading_allowed() ? False."""
        if not self.pushover:
            return
        status = self.risk_mgr.get_status_line()
        try:
            self.pushover.send_risk_suspension_alert(
                reason             = status,
                consecutive_losses = getattr(self.risk_mgr, 'consecutive_losses', 0),
                daily_losses       = getattr(self.risk_mgr, 'daily_losses',       0),
            )
        except Exception:
            pass

    # =========================================================================
    # LIVE BAR WATCHDOG
    # =========================================================================

    def _find_trade(self, trade_id: int) -> Optional[LiveTrade]:
        for t in self.trades:
            if t.trade_id == trade_id:
                return t
        return None

    def _can_open(self, direction: str) -> bool:
        """True if we can open a new trade in the given direction."""
        if self._vix > 0 and self._vix > VIX_MAX_ENTRY:
            print(f"[ENTRY] blocked VIX9D={self._vix:.1f} > VIX_MAX_ENTRY={VIX_MAX_ENTRY:.0f}")
            return False
        # One active/in-flight trade max (structural limit - not user configurable)
        _active_states = {'PENDING_FILL', 'ACTIVE', 'PENDING_WIN_QUOTE', 'PENDING_BUTTERFLY'}
        if any(t.state in _active_states for t in self.trades):
            return False
        # No same-direction trade (active or parked)
        for t in self.trades:
            if t.direction == direction:
                return False
        # Parked slot cap (loss exposure limit - not user configurable)
        if sum(1 for t in self.trades if t.state == 'PARKED') >= _MAX_PARKED:
            return False
        for p in self.pending_entries:
            if p.direction == direction:
                return False
        return True

    def _calc_contracts(self, ask_price: float) -> int:
        """
        Determine contract count from POSITION_SIZE config:
          >= 1  -> floor to int, minimum 1  (e.g. 2.5 -> 2, 1 -> 1)
          < 1   -> fraction of available_funds / (ask_price * 100), floor, minimum 1
                  e.g. POSITION_SIZE=0.10 with $50k available and $200 ask -> floor(5000/200)=25

        Buying power is fetched lazily on first fractional use rather than
        at startup.  By the time the first entry fires (~10:00 ET), account
        data has been populated for nearly 30 minutes and the fetch always
        succeeds on the first read.  The result is cached in
        self._available_funds for the remainder of the session.
        """
        import math
        ps = POSITION_SIZE
        if ps >= 1:
            return max(1, int(math.floor(ps)))
        else:
            if self._available_funds <= 0:
                try:
                    bp = self.client.get_option_buying_power()
                    if bp > 0:
                        self._available_funds = bp
                        print(f'[TDCL] Option buying power: ${bp:,.0f}')
                    else:
                        print('[TDCL] WARNING: OptionBuyingPower $0 - '
                              'falling back to 1 contract')
                        return 1
                except Exception as e:
                    print(f'[TDCL] get_option_buying_power error: {e} - '
                          f'falling back to 1 contract')
                    return 1
            raw = self._available_funds * ps / (ask_price * 100)
            return max(1, int(math.floor(raw)))


# =============================================================================
# Entry point
# =============================================================================

def main():
    import argparse
    parser = argparse.ArgumentParser(description='CTV2 Live Runner')
    parser.add_argument('--live', action='store_true',
                        help='Connect to live account (default: paper)')
    args = parser.parse_args()

    mode = 'live' if args.live else 'paper'

    while True:
        app = TradingApp(mode=mode)
        app.run_live()
        # run_live() returns normally only on clean EOD (_SessionComplete).
        # Crashes propagate as exceptions and exit here with a non-zero code.
        # Ctrl+C / Abort call sys.exit(0) directly and never reach this line.
        print("[MAIN] Session ended cleanly. Starting next session...\n")


if __name__ == '__main__':
    main()
