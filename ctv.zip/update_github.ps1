# ============================================================
#  update_github.ps1 - Push auth.json and ctv.zip to GitHub
#  Revision: 1.0
#
#  Called by UPDATE_GITHUB.bat. Do not run directly.
#
#  v1.0 - Initial implementation. Reads VERSION, updates
#          min_version in auth.json, pushes auth.json and
#          ctv.zip to gah2208/ctv main branch via GitHub
#          Contents API (base64 PUT).
# ============================================================

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# -- Configuration -------------------------------------------------------------
$GITHUB_TOKEN  = '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'   # ghp_...
$REPO_OWNER    = 'gah2208'
$REPO_NAME     = 'ctv'
$BRANCH        = 'main'

$AUTH_JSON_LOCAL = 'C:\CTV\Source Files\auth.json'
$CTV_ZIP_LOCAL   = 'C:\CTV\ctv.zip'
$VERSION_FILE    = 'C:\CTV\VERSION'

$AUTH_JSON_REMOTE = 'auth.json'
$CTV_ZIP_REMOTE   = 'ctv.zip'

$API_BASE = "https://api.github.com/repos/$REPO_OWNER/$REPO_NAME/contents"

# -- Headers -------------------------------------------------------------------
$headers = @{
    'Authorization' = "token $GITHUB_TOKEN"
    'Accept'        = 'application/vnd.github.v3+json'
    'User-Agent'    = 'CTV2-GitHub-Updater'
}

# -- Helper: get current SHA of a file on GitHub (needed for PUT) --------------
function Get-FileSha {
    param([string]$RemotePath)
    try {
        $url      = "$API_BASE/$RemotePath`?ref=$BRANCH"
        $response = Invoke-RestMethod -Uri $url -Headers $headers -Method Get
        return $response.sha
    } catch {
        # File doesn't exist yet - that's OK for first push
        return $null
    }
}

# -- Helper: push a file to GitHub via Contents API ----------------------------
function Push-FileToGitHub {
    param(
        [string]$LocalPath,
        [string]$RemotePath,
        [string]$CommitMessage,
        [string]$ContentBase64
    )
    $sha = Get-FileSha -RemotePath $RemotePath

    $body = @{
        message = $CommitMessage
        content = $ContentBase64
        branch  = $BRANCH
    }
    if ($sha) {
        $body['sha'] = $sha
    }

    $url      = "$API_BASE/$RemotePath"
    $bodyJson = $body | ConvertTo-Json -Depth 3
    Invoke-RestMethod -Uri $url -Headers $headers -Method Put -Body $bodyJson -ContentType 'application/json' | Out-Null
}

# ==============================================================================
# MAIN
# ==============================================================================

Write-Host ""

# -- Step 1: Read current version ----------------------------------------------
Write-Host "  [1/4] Reading VERSION..."
if (-not (Test-Path $VERSION_FILE)) {
    Write-Host "  ERROR: VERSION file not found at $VERSION_FILE"
    exit 1
}
$version = (Get-Content $VERSION_FILE -Raw).Trim()
Write-Host "         Package version: $version"
Write-Host ""

# -- Step 2: Update min_version in auth.json -----------------------------------
Write-Host "  [2/4] Updating auth.json min_version to $version..."
if (-not (Test-Path $AUTH_JSON_LOCAL)) {
    Write-Host "  ERROR: auth.json not found at $AUTH_JSON_LOCAL"
    exit 1
}

$authContent = Get-Content $AUTH_JSON_LOCAL -Raw | ConvertFrom-Json
$authContent.min_version = [double]$version
$authJson = $authContent | ConvertTo-Json -Depth 5

# Write updated auth.json back to disk
[System.IO.File]::WriteAllText($AUTH_JSON_LOCAL, $authJson, [System.Text.UTF8Encoding]::new($false))
Write-Host "         auth.json updated locally."
Write-Host ""

# -- Step 3: Push auth.json to GitHub ------------------------------------------
Write-Host "  [3/4] Pushing auth.json to GitHub ($REPO_OWNER/$REPO_NAME)..."
$authBytes   = [System.Text.Encoding]::UTF8.GetBytes($authJson)
$authBase64  = [Convert]::ToBase64String($authBytes)
$authMessage = "Update auth.json min_version to $version"

try {
    Push-FileToGitHub -LocalPath $AUTH_JSON_LOCAL `
                      -RemotePath $AUTH_JSON_REMOTE `
                      -CommitMessage $authMessage `
                      -ContentBase64 $authBase64
    Write-Host "         auth.json pushed successfully."
} catch {
    Write-Host "  ERROR: Failed to push auth.json: $_"
    exit 1
}
Write-Host ""

# -- Step 4: Push ctv.zip to GitHub --------------------------------------------
Write-Host "  [4/4] Pushing ctv.zip to GitHub ($REPO_OWNER/$REPO_NAME)..."
if (-not (Test-Path $CTV_ZIP_LOCAL)) {
    Write-Host "  ERROR: ctv.zip not found at $CTV_ZIP_LOCAL"
    exit 1
}

$zipBytes   = [System.IO.File]::ReadAllBytes($CTV_ZIP_LOCAL)
$zipBase64  = [Convert]::ToBase64String($zipBytes)
$zipMessage = "Update ctv.zip to package v$version"

try {
    Push-FileToGitHub -LocalPath $CTV_ZIP_LOCAL `
                      -RemotePath $CTV_ZIP_REMOTE `
                      -CommitMessage $zipMessage `
                      -ContentBase64 $zipBase64
    Write-Host "         ctv.zip pushed successfully."
} catch {
    Write-Host "  ERROR: Failed to push ctv.zip: $_"
    exit 1
}

# -- Done ----------------------------------------------------------------------
Write-Host ""
Write-Host "============================================================"
Write-Host "  GITHUB UPDATE COMPLETE  -  Package v$version"
Write-Host "  auth.json : min_version updated and pushed"
Write-Host "  ctv.zip   : pushed to $REPO_OWNER/$REPO_NAME"
Write-Host "============================================================"
Write-Host ""
