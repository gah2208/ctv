"""
tradier_client.py - Tradier REST API Client for CTV2
=====================================================
All HTTP communication with Tradier lives here.
Upper layers (tradier_stream, tradier_orders, ctv2_runner) call this
class and never import requests directly.

Live endpoint: https://api.tradier.com/v1

Credentials are read from config_ctv2.py:
    TRADIER_PRODUCTION_TOKEN = 'your_bearer_token'
    TRADIER_ACCOUNT_ID       = 'your_account_number'

Revision history
----------------
Rev 13: get_todays_expiration() now catches exceptions from get_option_expirations()
        (e.g. 401 Unauthorized on basic Tradier tier). In paper mode the
        exception is swallowed and today's date is used as fallback. In live
        mode it re-raises as ValueError so real-money trading never proceeds
        without confirmed expiration data.
Rev 12: Added get_today_orders(), get_eod_report(), and module-level helpers
        _parse_occ_symbol() and parse_eod_orders() to support live EOD
        accounting report. Answers four questions from Tradier order history:
        total long cost, which entries had a conversion and at what price,
        how many longs expired without a sale, and cost of those expired legs.
Rev 11: Added debug print of full raw response when preview status=unknown.
Rev 10: get_spread_quote() now returns per-share prices (removed * 100).
        The runner already multiplies by 100 for premium_est; the previous
        * 100 here caused bid/ask to display as $200/$250 instead of $2/$2.50,
        width checks to compare $50 against a $1-2 threshold, and premium
        estimates to be 100x too large, blocking all entries.
Rev 9: get_option_expirations() now queries symbol='SPX' with
       includeAllRoots=true instead of symbol='SPXW'. SPXW is an option
       root, not an underlying - Tradier's expirations endpoint requires
       the underlying symbol. SPX + includeAllRoots returns both monthly
       SPX and weekly SPXW dates, so the today-in-dates check still works.
Rev 8: get_option_buying_power() now handles margin, pdt, and cash account
       types correctly. Tradier nests option_buying_power inside a 'margin'
       or 'pdt' sub-object for margin/PDT accounts; cash accounts use
       cash_available inside a 'cash' sub-object. Previous code always read
       the top-level key, returning 0 for margin accounts.
Rev 7: Added self.sandbox = False stub. tradier_stream.py references
       client.sandbox to choose WebSocket vs REST poll path; sandbox was
       removed in Rev 6 without adding the attribute, causing AttributeError
       on startup. Always False - production endpoint only.
Rev 6: Sandbox mode removed entirely.
       TRADIER_SANDBOX, TRADIER_SANDBOX_TOKEN, TRADIER_SANDBOX_ACCOUNT
       config fields are gone. The client always connects to the production
       endpoint. Paper trading is controlled by LIVE_TRADING=False in the
       runner (all orders use preview=True - nothing fills).
Rev 5: get_todays_expiration() accepts live_trading param. Paper mode
       (live_trading=False) falls back to today's date if expirations API
       returns empty - handles Tradier basic tier with no options add-on.
       Only live_trading=True enforces strict expiration validation.
Rev 4: get_positions() guarded against Tradier sandbox returning literal
       string "null" for positions. Guard retained (defensive).
Rev 3: get_todays_expiration() sandbox fallback (now removed).
Rev 2: Use getattr() for all credential reads in __init__ so old config
       files missing Tradier fields fail in the validation block with a
       clear message rather than crashing with AttributeError.
Rev 1: Initial implementation.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

import config_ctv2 as cfg


# ---------------------------------------------------------------------------
# Base URL
# ---------------------------------------------------------------------------

_LIVE_BASE = 'https://api.tradier.com/v1'

# Session endpoint for WebSocket streaming (used by tradier_stream.py)
# Exposed here so the stream module can call _post() to get a session ID
# without duplicating auth logic.
STREAM_SESSION_ENDPOINT = 'markets/events/session'

# Retry configuration
_MAX_RETRIES    = 3
_BACKOFF_FACTOR = 0.5
_RETRY_ON       = [429, 500, 502, 503, 504]


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _build_session(token: str) -> requests.Session:
    """
    Create a requests.Session with:
      - Bearer auth header pre-set
      - JSON accept header pre-set
      - Automatic retry on transient HTTP errors
    """
    session = requests.Session()
    retry = Retry(
        total=_MAX_RETRIES,
        backoff_factor=_BACKOFF_FACTOR,
        status_forcelist=_RETRY_ON,
        allowed_methods=['GET', 'POST', 'DELETE'],
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount('https://', adapter)
    session.headers.update({
        'Authorization': f'Bearer {token}',
        'Accept':        'application/json',
    })
    return session


def _unwrap_list(raw: Any) -> List:
    """
    Tradier returns a single dict instead of a list when there is exactly
    one item. Normalise to always return a list.
    """
    if raw is None:
        return []
    if isinstance(raw, list):
        return raw
    if isinstance(raw, dict):
        return [raw]
    return []


def _parse_occ_symbol(symbol: str) -> Tuple[str, float]:
    """
    Parse a SPXW OCC symbol into (right, strike).

    Format: SPXW{YY}{MM}{DD}{C|P}{8-digit-strike-x1000}
    e.g.   'SPXW260401C06570000' -> ('C', 6570.0)
           'SPXW260401P06560000' -> ('P', 6560.0)

    Positions:
        [0:4]  root   = 'SPXW'
        [4:6]  year   = '26'
        [6:8]  month  = '04'
        [8:10] day    = '01'
        [10]   right  = 'C' or 'P'
        [11:]  strike = '06570000'  -> 6570000 / 1000 = 6570.0
    """
    right  = symbol[10]
    strike = int(symbol[11:]) / 1000.0
    return right, strike


def parse_eod_orders(orders: List[Dict], today: str) -> Dict[str, Any]:
    """
    Parse a list of Tradier filled multileg SPXW orders into an EOD
    accounting structure that answers four questions:

      1. What did the long positions cost?         -> total_cost
      2. Which had a conversion and at what price? -> matched
      3. How many expired without a sale?          -> expired
      4. What was the total cost of those?         -> total_expired_cost

    orders : list of order dicts from TradierClient.get_today_orders()
    today  : 'YYYY-MM-DD' - used to verify leg expirations match today

    Identification rules:
      Entry order      : type == 'debit'   legs = (long buy_to_open,
                                                    short sell_to_open)
      Conversion order : type == 'credit'  legs = (short sell_to_open,
                                                    conv  buy_to_open)

    Matching key: (right, short_strike) - the short strike and call/put
    type appear in both the entry and its corresponding conversion.

    Returns dict:
        entries     : list of entry dicts
        conversions : list of conversion dicts
        matched     : list of {'entry': ..., 'conversion': ...} pairs
        expired     : list of entry dicts with no matching conversion
        total_cost          : float - total premium paid for all entries
        total_expired_cost  : float - premium paid for expired entries
    """
    entries     = []
    conversions = []

    for order in orders:
        # Legs may be keyed as 'leg' (singular) or 'legs' in Tradier response
        legs = _unwrap_list(order.get('leg') or order.get('legs'))

        # Keep only SPXW option legs expiring today
        spxw_legs = []
        for leg in legs:
            sym = leg.get('option_symbol') or ''
            if not sym.startswith('SPXW'):
                continue
            yy, mm, dd = sym[4:6], sym[6:8], sym[8:10]
            if f'20{yy}-{mm}-{dd}' != today:
                continue
            spxw_legs.append(leg)

        if len(spxw_legs) != 2:
            continue

        buy_legs  = [l for l in spxw_legs if 'buy'  in (l.get('side') or '')]
        sell_legs = [l for l in spxw_legs if 'sell' in (l.get('side') or '')]
        if len(buy_legs) != 1 or len(sell_legs) != 1:
            continue

        buy_leg  = buy_legs[0]
        sell_leg = sell_legs[0]

        buy_right,  buy_strike  = _parse_occ_symbol(buy_leg['option_symbol'])
        sell_right, sell_strike = _parse_occ_symbol(sell_leg['option_symbol'])

        # Both legs must be same right (C or P)
        if buy_right != sell_right:
            continue
        right = buy_right

        buy_fill  = float(buy_leg.get('average_fill_price')  or 0)
        sell_fill = float(sell_leg.get('average_fill_price') or 0)
        qty       = int(float(buy_leg.get('filled_quantity')  or 1))
        order_id  = order.get('id')
        order_type = order.get('type', '')

        if order_type == 'debit':
            # Entry: bought long_strike, sold short_strike
            entries.append({
                'order_id':     order_id,
                'right':        right,
                'long_strike':  buy_strike,
                'short_strike': sell_strike,
                'net_cost':     (buy_fill - sell_fill) * qty * 100,
                'contracts':    qty,
            })
        elif order_type == 'credit':
            # Conversion: sold short_strike, bought conv_strike
            conversions.append({
                'order_id':     order_id,
                'right':        right,
                'short_strike': sell_strike,
                'conv_strike':  buy_strike,
                'net_credit':   (sell_fill - buy_fill) * qty * 100,
                'contracts':    qty,
            })

    # Match each entry to its conversion by (right, short_strike)
    conv_index = {(c['right'], c['short_strike']): c for c in conversions}
    matched = []
    expired = []
    for e in entries:
        c = conv_index.get((e['right'], e['short_strike']))
        if c:
            matched.append({'entry': e, 'conversion': c})
        else:
            expired.append(e)

    total_cost         = sum(e['net_cost'] for e in entries)
    total_expired_cost = sum(e['net_cost'] for e in expired)

    return {
        'entries':             entries,
        'conversions':         conversions,
        'matched':             matched,
        'expired':             expired,
        'total_cost':          total_cost,
        'total_expired_cost':  total_expired_cost,
    }


# ---------------------------------------------------------------------------
# Main client
# ---------------------------------------------------------------------------

class TradierClient:
    """
    Thin, stateless wrapper around the Tradier REST API.

    Instantiate once at startup; pass to tradier_orders and ctv2_runner.

        client = TradierClient()

    All methods return Python dicts/lists parsed from JSON.
    All methods raise requests.HTTPError on non-2xx responses after retries.
    """

    def __init__(self):
        # Read credentials via getattr so an old config_ctv2.py missing these
        # keys fails cleanly in the validation block below.
        prod_token = getattr(cfg, 'TRADIER_PRODUCTION_TOKEN', '')
        account_id = getattr(cfg, 'TRADIER_ACCOUNT_ID',       '')

        # Validate - both fields must be populated before the runner starts
        missing = []
        for field, val in (
            ('TRADIER_ACCOUNT_ID',       account_id),
            ('TRADIER_PRODUCTION_TOKEN', prod_token),
        ):
            if not val or not val.strip():
                missing.append(field)
        if missing:
            raise ValueError(
                f'[TDCL] Missing required Tradier credentials in config_ctv2.py: '
                f'{", ".join(missing)}\n'
                f'       Open Config Editor (CONFIG_EDITOR.bat) and fill in the Tradier tab.'
            )

        self.token    = prod_token
        self.account  = account_id
        self.base_url = _LIVE_BASE
        self.sandbox  = False          # sandbox removed in Rev 6; attribute kept for tradier_stream compat
        self._session = _build_session(self.token)

        print(f'[TDCL] TradierClient ready  mode=LIVE  '
              f'account={self.account}  base={self.base_url}')

    # -----------------------------------------------------------------------
    # Low-level HTTP
    # -----------------------------------------------------------------------

    def _url(self, endpoint: str) -> str:
        return f'{self.base_url}/{endpoint.lstrip("/")}'

    def _get(self, endpoint: str,
             params: Optional[Dict] = None) -> Dict[str, Any]:
        resp = self._session.get(self._url(endpoint), params=params, timeout=10)
        resp.raise_for_status()
        return resp.json()

    def _post(self, endpoint: str,
              data: Optional[Dict] = None) -> Dict[str, Any]:
        resp = self._session.post(self._url(endpoint), data=data, timeout=10)
        resp.raise_for_status()
        return resp.json()

    def _delete(self, endpoint: str) -> Dict[str, Any]:
        resp = self._session.delete(self._url(endpoint), timeout=10)
        resp.raise_for_status()
        return resp.json()

    # -----------------------------------------------------------------------
    # Streaming session
    # -----------------------------------------------------------------------

    def create_stream_session(self) -> str:
        """
        POST /v1/markets/events/session
        Returns the sessionid string needed to authenticate the WebSocket.
        Session IDs are short-lived (~5 min); tradier_stream.py refreshes
        them automatically on reconnect.
        """
        data = self._post(STREAM_SESSION_ENDPOINT)
        session_id = data['stream']['sessionid']
        print(f'[TDCL] Stream session created: {session_id[:8]}...')
        return session_id

    # -----------------------------------------------------------------------
    # Market data - SPX index
    # -----------------------------------------------------------------------

    def get_quote(self, symbol: str) -> Dict[str, Any]:
        """
        Snapshot quote for any symbol (equity or index).
        Returns the inner 'quote' dict with keys:
            symbol, last, bid, ask, open, high, low, close, volume, etc.
        Returns {} if symbol not found.

        Primary use: fallback SPX price when stream is not yet connected.
        """
        data   = self._get('markets/quotes',
                            params={'symbols': symbol, 'greeks': 'false'})
        quotes = data.get('quotes', {}) or {}
        raw    = quotes.get('quote', {})
        # Multi-symbol call returns a list; single-symbol returns a dict
        if isinstance(raw, list):
            return raw[0] if raw else {}
        return raw or {}

    def get_spx_price(self) -> float:
        """
        Returns current SPX last price as a float.
        Uses last; falls back to close if market is closed.
        Returns 0.0 on any failure.
        """
        try:
            q = self.get_quote('SPX')
            return float(q.get('last') or q.get('close') or 0.0)
        except Exception as e:
            print(f'[TDCL] get_spx_price error: {e}')
            return 0.0

    # -----------------------------------------------------------------------
    # Market data - historical bars
    # -----------------------------------------------------------------------

    def get_timesales(self,
                      symbol:         str           = 'SPX',
                      interval:       str           = '1min',
                      start:          Optional[str] = None,
                      end:            Optional[str] = None,
                      session_filter: str           = 'open') -> List[Dict]:
        """
        Time & sales bars from /v1/markets/timesales.

        interval       : '1min' | '5min' | '15min'
                         NOTE: Tradier has no native 3-min interval.
                         ctv2_runner.py buckets three 1-min bars into one
                         3-min bar for signal generation.
        start / end    : 'YYYY-MM-DD HH:MM'  (None = Tradier default)
        session_filter : 'open' for RTH only (recommended)

        NOTE: Tick data is not available in the sandbox environment.
              Use mocked bar data for sandbox testing.

        Returns list of dicts, each with:
            time, timestamp, open, high, low, close, volume, vwap
        Sorted ascending by time (oldest first).
        """
        params: Dict[str, Any] = {
            'symbol':         symbol,
            'interval':       interval,
            'session_filter': session_filter,
        }
        if start:
            params['start'] = start
        if end:
            params['end'] = end

        data   = self._get('markets/timesales', params=params)
        series = data.get('series') or {}
        if not series:
            return []
        return _unwrap_list(series.get('data'))

    # -----------------------------------------------------------------------
    # Market data - options
    # -----------------------------------------------------------------------

    def get_option_expirations(self,
                                symbol:            str  = 'SPXW',
                                include_all_roots: bool = True) -> List[str]:
        """
        List of available expiration dates for symbol as 'YYYY-MM-DD' strings,
        sorted ascending (nearest first).

        Tradier's expirations endpoint requires the UNDERLYING symbol, not the
        option root. SPXW is a root - its underlying is SPX. Querying 'SPXW'
        directly returns nothing. We always query 'SPX' with includeAllRoots=true
        which returns both monthly SPX and weekly SPXW expirations.
        """
        # Tradier requires the underlying - map option roots to their underlying
        _root_to_underlying = {'SPXW': 'SPX', 'RUTW': 'RUT'}
        query_symbol = _root_to_underlying.get(symbol.upper(), symbol)
        data   = self._get('markets/options/expirations', params={
            'symbol':          query_symbol,
            'includeAllRoots': str(include_all_roots).lower(),
            'strikes':         'false',
        })
        dates  = (data.get('expirations') or {}).get('date', [])
        result = _unwrap_list(dates) if not isinstance(dates, list) else dates
        return sorted(result)

    def get_todays_expiration(self, live_trading: bool = False) -> str:
        """
        Returns today's SPXW expiration date as 'YYYY-MM-DD'.

        Fallback behaviour:
          live_trading=True  : strict - raise ValueError so real-money trading
                               never proceeds on a non-trading day.
          live_trading=False : fall back with warning (paper trading - options
                               data may be unavailable on basic Tradier tier).

        Called once at startup to confirm trading is valid today.
        """
        from datetime import date, datetime as _dt

        today = date.today().isoformat()
        try:
            dates = self.get_option_expirations('SPXW')
        except Exception as e:
            dates = []
            if live_trading:
                raise ValueError(
                    f'[TDCL] Could not retrieve SPXW expirations ({e}). '
                    f'Check Tradier credentials and options data subscription.'
                ) from e
            print(f'[TDCL] WARNING: get_option_expirations failed ({e}) - '
                  f'using today ({today}) as expiration for paper trading.')

        if today in dates:
            print(f'[TDCL] Today\'s SPXW expiration confirmed: {today}')
            return today

        # Strict check: live real-money trading only proceeds on confirmed days
        if live_trading:
            dow = _dt.today().weekday()   # 0=Mon ... 6=Sun
            if dow >= 5:
                raise ValueError(
                    f'[TDCL] No SPXW expiration today ({today}) - market closed '
                    f'(weekend). Start the runner on a trading day.'
                )
            raise ValueError(
                f'[TDCL] No SPXW expiration found for today ({today}). '
                f'Available: {dates[:5]}. '
                f'This may be a holiday or the options data subscription is inactive.'
            )

        # Paper fallback - use today and warn
        reason = ('production account returned no expirations - '
                  'options data add-on may not be active on this Tradier tier. '
                  'OCC symbols will use today as expiration for paper trading.')
        print(f'[TDCL] WARNING: No SPXW expirations returned ({reason}). '
              f'Using today ({today}) as expiration.')
        return today

    def get_option_chain(self,
                          symbol:     str  = 'SPXW',
                          expiration: str  = '',
                          greeks:     bool = False) -> List[Dict]:
        """
        Full option chain for symbol + expiration.
        expiration: 'YYYY-MM-DD'

        Returns list of option dicts, each with:
            symbol (OCC), description, strike, option_type (call/put),
            bid, ask, last, volume, open_interest, greeks (if requested)
        """
        data    = self._get('markets/options/chains', params={
            'symbol':     symbol,
            'expiration': expiration,
            'greeks':     str(greeks).lower(),
        })
        options = (data.get('options') or {})
        return _unwrap_list(options.get('option'))

    def get_option_quote(self, occ_symbol: str) -> Dict[str, Any]:
        """
        Snapshot quote for a single option by OCC symbol.
        e.g. 'SPXW260324C05850000'

        Returns dict with bid, ask, last, volume, etc.
        Returns {} if not found.
        """
        data   = self._get('markets/quotes',
                            params={'symbols': occ_symbol, 'greeks': 'false'})
        quotes = (data.get('quotes') or {})
        raw    = quotes.get('quote', {})
        if isinstance(raw, list):
            return raw[0] if raw else {}
        return raw or {}

    def get_spread_quote(self,
                          long_symbol:  str,
                          short_symbol: str) -> Tuple[float, float]:
        """
        Snapshot bid/ask for a two-leg vertical spread.

        Returns (spread_bid, spread_ask) as per-share prices (NOT multiplied
        by 100). Callers multiply by 100 to get per-contract dollar cost.

        spread_ask = long_ask  - short_bid  (cost to buy the spread)
        spread_bid = long_bid  - short_ask  (credit to sell the spread)

        Entry uses spread_ask; exit uses spread_bid.
        Returns (0.0, 0.0) on any data failure.
        """
        try:
            symbols = f'{long_symbol},{short_symbol}'
            data    = self._get('markets/quotes',
                                 params={'symbols': symbols, 'greeks': 'false'})
            quotes  = _unwrap_list((data.get('quotes') or {}).get('quote'))
            lookup  = {q['symbol']: q for q in quotes}

            long_q  = lookup.get(long_symbol,  {})
            short_q = lookup.get(short_symbol, {})

            long_bid  = float(long_q.get('bid',  0) or 0)
            long_ask  = float(long_q.get('ask',  0) or 0)
            short_bid = float(short_q.get('bid', 0) or 0)
            short_ask = float(short_q.get('ask', 0) or 0)

            spread_ask = long_ask  - short_bid
            spread_bid = long_bid  - short_ask

            return spread_bid, spread_ask

        except Exception as e:
            print(f'[TDCL] get_spread_quote error: {e}')
            return 0.0, 0.0

    # -----------------------------------------------------------------------
    # Orders
    # -----------------------------------------------------------------------

    def place_order(self,
                    order_data: Dict[str, Any],
                    preview:    bool = False) -> Dict[str, Any]:
        """
        POST /v1/accounts/{account}/orders

        order_data : dict of Tradier order fields (built by tradier_orders.py)
        preview    : if True, validates the order without submitting it.
                     Use preview=True for all sandbox testing.

        Returns full Tradier order response dict.
        On success the order ID is at result['order']['id'].

        Raises requests.HTTPError on API rejection.
        """
        payload = dict(order_data)
        payload['preview'] = 'true' if preview else 'false'

        result = self._post(f'accounts/{self.account}/orders', data=payload)
        mode   = 'PREVIEW' if preview else 'LIVE'

        if preview:
            status = result.get('order', {}).get('status', 'unknown')
            print(f'[TDCL] Order {mode}: status={status}')
            if status == 'unknown':
                print(f'[TDCL] Order PREVIEW raw response: {result}')
        else:
            oid = result.get('order', {}).get('id', 'unknown')
            print(f'[TDCL] Order placed: id={oid}')

        return result

    def get_order(self, order_id: int) -> Dict[str, Any]:
        """
        GET /v1/accounts/{account}/orders/{order_id}
        Returns the order dict with status, fill price, etc.
        """
        data = self._get(
            f'accounts/{self.account}/orders/{order_id}',
            params={'includeTags': 'true'},
        )
        return data.get('order', {})

    def cancel_order(self, order_id: int) -> bool:
        """
        DELETE /v1/accounts/{account}/orders/{order_id}
        Returns True if cancelled successfully, False otherwise.
        Swallows errors - cancel is best-effort; runner handles fallback.
        """
        try:
            data   = self._delete(f'accounts/{self.account}/orders/{order_id}')
            result = data.get('order', {})
            ok     = result.get('status') == 'ok'
            print(f'[TDCL] Cancel order {order_id}: {"ok" if ok else "failed"}')
            return ok
        except Exception as e:
            print(f'[TDCL] cancel_order {order_id} error: {e}')
            return False

    def get_orders(self) -> List[Dict]:
        """
        GET /v1/accounts/{account}/orders
        Returns list of all open and recent orders for the account.
        Used for position recovery at startup.
        """
        data   = self._get(f'accounts/{self.account}/orders',
                            params={'includeTags': 'true'})
        orders = (data.get('orders') or {})
        return _unwrap_list(orders.get('order'))

    def get_today_orders(self, today: str) -> List[Dict]:
        """
        GET /v1/accounts/{account}/orders
        Returns filled multileg SPXW orders for today only, with legs intact.
        today: 'YYYY-MM-DD'

        Filters the full order list to:
          - status == 'filled'
          - class  == 'multileg'
          - create_date matches today
          - at least one leg with an SPXW option_symbol
        """
        all_orders = self.get_orders()
        result = []
        for order in all_orders:
            if order.get('status') != 'filled':
                continue
            if order.get('class') != 'multileg':
                continue
            # create_date format: '2026-04-01T14:39:00.000Z' - take first 10 chars
            create_date = (order.get('create_date') or '')[:10]
            if create_date != today:
                continue
            legs = _unwrap_list(order.get('leg') or order.get('legs'))
            if not any((l.get('option_symbol') or '').startswith('SPXW')
                       for l in legs):
                continue
            result.append(order)
        return result

    def get_eod_report(self, today: str) -> Dict[str, Any]:
        """
        Fetch today's filled multileg SPXW orders and return the EOD
        accounting report dict (see parse_eod_orders for full structure).
        today: 'YYYY-MM-DD'
        """
        orders = self.get_today_orders(today)
        return parse_eod_orders(orders, today)

    # -----------------------------------------------------------------------
    # Account
    # -----------------------------------------------------------------------

    def get_positions(self) -> List[Dict]:
        """
        GET /v1/accounts/{account}/positions
        Returns list of current open positions.
        Each dict contains: symbol, quantity, cost_basis, date_acquired.

        Used by ctv2_runner._recover_state() at startup to detect open trades
        from a previous session.

        NOTE: Tradier occasionally returns {"positions": "null"} (a literal
        string, not JSON null) when there are no positions.  Guard against
        that here so callers always receive a plain list.
        """
        data      = self._get(f'accounts/{self.account}/positions')
        raw       = data.get('positions')
        # Guard: Tradier can return the string "null" instead of JSON null.
        if not raw or not isinstance(raw, dict):
            return []
        return _unwrap_list(raw.get('position'))

    def get_balances(self) -> Dict[str, Any]:
        """
        GET /v1/accounts/{account}/balances
        Returns account balance dict including:
            option_buying_power, total_equity, total_cash, etc.

        Used at startup to determine available capital for POSITION_SIZE calc.
        """
        data = self._get(f'accounts/{self.account}/balances')
        return data.get('balances', {})

    def get_option_buying_power(self) -> float:
        """
        Returns option buying power as a float, correctly handling all
        Tradier account types:
          - margin : bal['margin']['option_buying_power']
          - pdt    : bal['pdt']['option_buying_power']
          - cash   : bal['cash']['cash_available']
        Returns 0.0 on any failure.
        """
        try:
            bal = self.get_balances()
            account_type = bal.get('account_type', '').lower()

            if account_type == 'cash':
                sub = bal.get('cash', {})
                return float(sub.get('cash_available', 0) or 0)
            elif account_type == 'pdt':
                sub = bal.get('pdt', {})
                return float(sub.get('option_buying_power', 0) or 0)
            else:
                # margin (default)
                sub = bal.get('margin', {})
                return float(sub.get('option_buying_power', 0) or 0)
        except Exception as e:
            print(f'[TDCL] get_option_buying_power error: {e}')
            return 0.0


# ---------------------------------------------------------------------------
# Quick connectivity test (run this file directly to verify credentials)
# ---------------------------------------------------------------------------

if __name__ == '__main__':
    print('--- TradierClient connectivity test ---')
    client = TradierClient()

    print('\n[1] SPX snapshot price:')
    price = client.get_spx_price()
    print(f'    SPX = {price}')

    print('\n[2] Account balances:')
    bal = client.get_balances()
    acct_type = bal.get('account_type', 'unknown')
    print(f'    account_type        = {acct_type}')
    print(f'    total_equity        = {bal.get("total_equity")}')
    sub = bal.get(acct_type, {})
    print(f'    option_buying_power = {sub.get("option_buying_power") or sub.get("cash_available")}')

    print('\n[3] Open positions:')
    pos = client.get_positions()
    if pos:
        for p in pos:
            print(f'    {p}')
    else:
        print('    (none)')

    print('\n[4] SPXW expirations (nearest 5):')
    try:
        exps = client.get_option_expirations('SPXW')
        for e in exps[:5]:
            print(f'    {e}')
    except Exception as ex:
        print(f'    error: {ex}')

    print('\n[5] Stream session:')
    try:
        sid = client.create_stream_session()
        print(f'    sessionid prefix = {sid[:8]}...')
    except Exception as ex:
        print(f'    error: {ex}')

    print('\n--- Test complete ---')
