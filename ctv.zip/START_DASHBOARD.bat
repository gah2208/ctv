@echo off
cd /d C:\CTV
echo Starting CTV2 Dashboard...
echo Open http://localhost:5000 in your browser.
echo Press Ctrl+C to stop.
echo.
python ctv2_dashboard.py
pause
