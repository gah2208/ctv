@echo off
:: UPLOAD_CONFIG.bat
:: Revision: 1.0
:: Packages config/UI files into upload_config.zip.
:: Use this for sessions involving the Config Editor, preflight checks,
:: or changes to configurable parameters.
::
:: Files included:
::   ctv2_config_editor.py    - Config Editor UI
::   preflight_check.py       - Startup validation / IB Gateway check
::   config_ctv2_default.py   - Default configuration values
::   version_check.ps1        - Version manifest  (always needed)
::   VERSION                  - Version number     (always needed)
::   CHANGELOG.md             - Change log        (always needed)

cd /d C:\CTV

echo Building upload_config.zip...
powershell -NoProfile -Command ^
    "Compress-Archive -Force -Path @('ctv2_config_editor.py','preflight_check.py','config_ctv2_default.py','version_check.ps1','VERSION','CHANGELOG.md') -DestinationPath 'upload_config.zip'"

if %errorlevel%==0 (
    echo Done. Opening folder...
    explorer /select,"C:\CTV\upload_config.zip"
) else (
    echo ERROR: zip failed.
    pause
)
