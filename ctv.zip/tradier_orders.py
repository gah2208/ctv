"""
tradier_orders.py - Order Management for CTV2 (Tradier)
=========================================================
Replaces ctv2_order_manager.py.  All IBKR-specific types
(Contract, ComboLeg, Order, conId) are gone.

Tradier uses:
  - OCC option symbols  e.g. 'SPXW260324P05850000'
  - class=multileg POST with indexed leg fields
  - No local broker software; orders go directly to Tradier REST API

What is preserved from the original order manager:
  - round_to_tick()          identical tick rounding logic
  - calc_strikes()           identical $5-increment strike selection
  - calc_chained_strikes()   identical chained re-entry logic
  - Entry / win-sell / close price logic (ask*1.05, bid*0.95, etc.)

OCC symbol format
-----------------
  SPXW  YY  MM  DD  C/P  STRIKE(8 digits, scaled x1000)
  e.g.  SPXW 26 03 24 P 05850000  →  SPXW260324P05850000

  Strike encoding: strike_dollars * 1000, zero-padded to 8 digits
  $5850.00 → 5850 * 1000 = 5850000 → '05850000'
  $5855.00 → 5855000 → '05855000'

Multileg order format
---------------------
Tradier multileg POST fields (form-encoded):
    class                : 'multileg'
    symbol               : 'SPXW'        (root symbol)
    duration             : 'day'
    type                 : 'limit'
    price                : '3.50'        (net debit for entry, net credit for exit)
    option_symbol[0]     : OCC symbol leg 0
    side[0]              : 'buy_to_open' | 'sell_to_open' |
                           'buy_to_close' | 'sell_to_close'
    quantity[0]          : '1'
    option_symbol[1]     : OCC symbol leg 1
    side[1]              : ...
    quantity[1]          : '1'
    preview              : 'true' | 'false'

Revision history
----------------
Rev 11: Fixed _win_sell_payload missing second leg. conv_sym was built but
        never included in the return dict; quantity[0] was also absent and
        quantity[1] was orphaned. Tradier rejected every win-sell order with
        400 because the payload described a one-legged credit order.
        Corrected to include option_symbol[0/1], side[0/1], quantity[0/1].
Rev 10: Removed _close_payload and place_close. Positions are never
        explicitly closed - they either add legs to form a butterfly
        (via place_win_sell) or expire worthless. sell_to_close /
        buy_to_close legs are never valid in this system.
        _on_butterfly_conv_quote in ctv2_runner now calls place_win_sell
        with min_profit_price=0 for BFLY_CONV path.
        Unit test for _close_payload removed.
Rev 9: Fixed _win_sell_payload leg side from sell_to_close to sell_to_open.
       The WIN conversion adds a second short at short_strike to complete
       the butterfly center (-2), it does not close an existing position.
       sell_to_close caused Tradier to reject the order ('cannot place sell
       unless closing a long position'). The Rev 8 bypass in _submit() that
       masked this error is also removed. Unit test updated to match.
Rev 8: _submit() bypasses 'closing a long position' preview error in paper
       mode. Tradier rejects win-sell previews because there is no real
       position to close. Returns synthetic success like buying power bypass.
Rev 7: Replaced x with x in entry payload print and -> in unit test prints.
Rev 6: Replaced → and × with -> and x in win-sell payload print statement.
       Non-ASCII characters crash the win quote thread on Windows when the
       console uses cp1252 encoding, causing the win conversion to loop
       indefinitely.
Rev 5: _submit() bypasses buying power errors in preview mode. Tradier
       validates buying power even on previews; with a pending deposit
       this blocks all paper trades. Since nothing fills in paper mode,
       buying power is irrelevant and the error is treated as a synthetic
       success.
Rev 4: _submit() now accepts result=True as a successful preview response.
       Tradier multileg previews return result:true rather than status:'ok',
       causing all paper trade entries to abort with status=unknown.
Rev 3: Fixed multileg order type field. Tradier multileg orders require
       type='debit' (buying a spread) or type='credit' (selling a spread),
       not type='limit' (equity only). All three payloads updated:
       _vertical_entry_payload → 'debit'
       _win_sell_payload       → 'credit'
       _close_payload          → 'credit'
Rev 2: Updated get_spread_quote() docstring to reflect per-share return
       values (tradier_client fix Rev 10 removed the * 100 there).
Rev 1: Initial implementation.
"""

from __future__ import annotations

import math
from datetime import date
from typing import Dict, Optional, Tuple

import config_ctv2 as cfg
from tradier_client import TradierClient


# ---------------------------------------------------------------------------
# Tick rounding  (identical to original ctv2_order_manager.py)
# ---------------------------------------------------------------------------

def round_to_tick(price: float) -> float:
    """
    Round price DOWN to nearest valid SPX option tick.
        price < $3.00  →  $0.05 tick
        price >= $3.00 →  $0.10 tick

    Uses integer cent arithmetic to eliminate float drift.
    Always rounds DOWN (floor) - conservative for both entries and exits.
    """
    cents = int(round(price * 100, 8))
    tick_cents = 5 if price < 3.00 else 10
    return (cents // tick_cents) * tick_cents / 100.0


# ---------------------------------------------------------------------------
# OCC symbol builder
# ---------------------------------------------------------------------------

def build_occ_symbol(right:      str,
                     strike:     float,
                     expiration: str) -> str:
    """
    Build a Tradier-compatible OCC option symbol for SPXW.

    Args:
        right      : 'C' (call) or 'P' (put)
        strike     : strike price in dollars  e.g. 5850.0
        expiration : 'YYYY-MM-DD'  e.g. '2026-03-24'

    Returns:
        OCC symbol string  e.g. 'SPXW260324P05850000'

    Strike encoding:
        dollars * 1000, zero-padded to 8 digits
        $5850.00 → 05850000
        $5855.00 → 05855000
        $595.00  → 00595000  (hypothetical low-priced example)
    """
    yyyy, mm, dd = expiration.split('-')
    yy           = yyyy[2:]                    # '2026' → '26'
    strike_enc   = f'{int(round(strike * 1000)):08d}'
    symbol       = f'SPXW{yy}{mm}{dd}{right.upper()}{strike_enc}'
    return symbol


# ---------------------------------------------------------------------------
# Main order manager
# ---------------------------------------------------------------------------

class TradierOrderManager:
    """
    Builds and places all orders for the CTV2 live runner.

    Requires a TradierClient instance and today's expiration date.
    Expiration is set once at startup via set_expiration().

    Public methods mirror the original CTV2OrderManager interface
    so ctv2_runner.py changes are minimal:

        om = TradierOrderManager(client)
        om.set_expiration('2026-03-24')

        # Strike calculation (unchanged from original)
        long_s, short_s, conv_s = om.calc_strikes(spx_price, 'UP')

        # Get spread quote before entry
        bid, ask = om.get_spread_quote('UP', long_s, short_s)

        # Place entry
        order_id = om.place_entry(direction, long_s, short_s, ask, contracts)

        # Place win sell (WIN target) or butterfly conversion (min_profit_price=0)
        order_id = om.place_win_sell(direction, short_s, conv_s,
                                      bid, min_profit_price, contracts)

        # Cancel an order
        ok = om.cancel(order_id)
    """

    def __init__(self, client: TradierClient):
        self._client     = client
        self._expiration = ''    # set by set_expiration() at startup

    # -----------------------------------------------------------------------
    # Expiration
    # -----------------------------------------------------------------------

    def set_expiration(self, expiration: str):
        """
        Set today's SPXW expiration date.  Must be called before any
        order or quote method.  Typically called from ctv2_runner after
        get_todays_expiration() confirms a valid same-day expiry exists.

        expiration: 'YYYY-MM-DD'
        """
        self._expiration = expiration
        print(f'[OM  ] Expiration set: {expiration}')

    def _require_expiration(self):
        if not self._expiration:
            raise RuntimeError(
                '[OM  ] set_expiration() must be called before placing orders'
            )

    # -----------------------------------------------------------------------
    # OCC symbol helpers
    # -----------------------------------------------------------------------

    def _sym(self, right: str, strike: float) -> str:
        """Build OCC symbol for this session's expiration."""
        self._require_expiration()
        return build_occ_symbol(right, strike, self._expiration)

    def _right(self, direction: str) -> str:
        """'UP' → 'C',  'DOWN' → 'P'"""
        return 'C' if direction == 'UP' else 'P'

    # -----------------------------------------------------------------------
    # Strike calculators  (identical to original)
    # -----------------------------------------------------------------------

    def calc_strikes(self,
                     spx:       float,
                     direction: str) -> Tuple[float, float, float]:
        """
        First-OTM vertical + conversion strikes, $5 increments.
        Returns (long_strike, short_strike, conv_strike).

        UP   (calls): long = ceil(spx/5)*5
                      short = long + 5
                      conv  = short + 5
        DOWN (puts) : long = floor(spx/5)*5
                      short = long - 5
                      conv  = short - 5
        """
        inc = 5.0
        if direction == 'UP':
            long_s  = math.ceil(spx / inc) * inc
            short_s = long_s  + inc
            conv_s  = short_s + inc
        else:
            long_s  = math.floor(spx / inc) * inc
            short_s = long_s  - inc
            conv_s  = short_s - inc
        return long_s, short_s, conv_s

    def calc_chained_strikes(self,
                              conv_strike: float,
                              direction:   str) -> Tuple[float, float, float]:
        """
        Strikes for a chained re-entry after a WIN.
        conv_strike of the completed trade becomes new long_strike
        (we already own it from the conversion buy leg).

        Returns (long_strike, short_strike, conv_strike).
        """
        inc    = 5.0
        long_s = conv_strike
        if direction == 'UP':
            short_s = long_s + inc
            conv_s  = short_s + inc
        else:
            short_s = long_s - inc
            conv_s  = short_s - inc
        return long_s, short_s, conv_s

    # -----------------------------------------------------------------------
    # Spread quote
    # -----------------------------------------------------------------------

    def get_spread_quote(self,
                          direction:    str,
                          long_strike:  float,
                          short_strike: float) -> Tuple[float, float]:
        """
        Snapshot bid/ask for a vertical spread.
        Returns (spread_bid, spread_ask) in dollars (per contract * 100).

        Entry uses spread_ask; exit uses spread_bid.
        Returns (0.0, 0.0) on any failure.
        """
        right       = self._right(direction)
        long_sym    = self._sym(right, long_strike)
        short_sym   = self._sym(right, short_strike)
        bid, ask    = self._client.get_spread_quote(long_sym, short_sym)
        print(f'[OM  ] Quote {direction} {int(long_strike)}/{int(short_strike)} '
              f'bid=${bid:.2f} ask=${ask:.2f}')
        return bid, ask

    # -----------------------------------------------------------------------
    # Order builders  (internal - return Tradier POST payload dicts)
    # -----------------------------------------------------------------------

    def _vertical_entry_payload(self,
                                  direction:    str,
                                  long_strike:  float,
                                  short_strike: float,
                                  ask_price:    float,
                                  contracts:    int) -> Dict:
        """
        Multileg BUY payload for vertical spread entry.
        limit = ask * cfg.ENTRY_SLIPPAGE, rounded to tick.

        Legs:
            [0] long_strike  → buy_to_open
            [1] short_strike → sell_to_open
        """
        right     = self._right(direction)
        long_sym  = self._sym(right, long_strike)
        short_sym = self._sym(right, short_strike)
        limit     = round_to_tick(ask_price * cfg.ENTRY_SLIPPAGE)

        print(f'[OM  ] Entry payload: BUY {contracts}x '
              f'{int(long_strike)}/{int(short_strike)} {direction} '
              f'LMT ${limit:.2f} '
              f'(ask=${ask_price:.2f} x {cfg.ENTRY_SLIPPAGE})')

        return {
            'class':            'multileg',
            'symbol':           'SPXW',
            'duration':         'day',
            'type':             'debit',
            'price':            f'{limit:.2f}',
            'option_symbol[0]': long_sym,
            'side[0]':          'buy_to_open',
            'quantity[0]':      str(contracts),
            'option_symbol[1]': short_sym,
            'side[1]':          'sell_to_open',
            'quantity[1]':      str(contracts),
        }

    def _win_sell_payload(self,
                           direction:        str,
                           short_strike:     float,
                           conv_strike:      float,
                           bid:              float,
                           min_profit_price: float,
                           contracts:        int) -> Dict:
        """
        Multileg SELL payload for conversion spread win exit.
        limit = max(bid * cfg.SELL_SLIPPAGE, min_profit_price / 100),
                rounded to tick.

        Legs (mirrors original):
            [0] short_strike → sell_to_open    (add second short leg, completing -2 center)
            [1] conv_strike  → buy_to_open     (buy far wing)
        """
        right     = self._right(direction)
        short_sym = self._sym(right, short_strike)
        conv_sym  = self._sym(right, conv_strike)

        min_per_share = min_profit_price / 100.0
        bid_based     = bid * cfg.SELL_SLIPPAGE
        limit         = round_to_tick(max(bid_based, min_per_share))
        used          = 'bid-based' if bid_based >= min_per_share else 'min-profit'

        print(f'[OM  ] Win-sell payload: SELL {contracts}x '
              f'{int(short_strike)}/{int(conv_strike)} {direction} '
              f'LMT ${limit:.2f} '
              f'(bid=${bid:.2f}x{cfg.SELL_SLIPPAGE}=${bid_based:.2f} '
              f'min=${min_per_share:.2f} -> {used})')

        return {
            'class':            'multileg',
            'symbol':           'SPXW',
            'duration':         'day',
            'type':             'credit',
            'price':            f'{limit:.2f}',
            'option_symbol[0]': short_sym,
            'side[0]':          'sell_to_open',
            'quantity[0]':      str(contracts),
            'option_symbol[1]': conv_sym,
            'side[1]':          'buy_to_open',
            'quantity[1]':      str(contracts),
        }

    # -----------------------------------------------------------------------
    # Order placement  (public - call these from ctv2_runner)
    # -----------------------------------------------------------------------

    def place_entry(self,
                    direction:    str,
                    long_strike:  float,
                    short_strike: float,
                    ask_price:    float,
                    contracts:    int   = 1,
                    preview:      bool  = False) -> Optional[int]:
        """
        Place (or preview) a vertical spread entry order.
        Returns Tradier order ID (int) on success, None on failure.

        preview=True validates the order without submitting.
        Use preview=True for all sandbox testing.
        """
        payload = self._vertical_entry_payload(
            direction, long_strike, short_strike, ask_price, contracts
        )
        return self._submit(payload, preview)

    def place_win_sell(self,
                        direction:        str,
                        short_strike:     float,
                        conv_strike:      float,
                        bid:              float,
                        min_profit_price: float,
                        contracts:        int   = 1,
                        preview:          bool  = False) -> Optional[int]:
        """
        Place (or preview) a conversion spread win-exit order.
        Returns Tradier order ID (int) on success, None on failure.
        """
        payload = self._win_sell_payload(
            direction, short_strike, conv_strike, bid, min_profit_price, contracts
        )
        return self._submit(payload, preview)

    def cancel(self, order_id: int) -> bool:
        """
        Cancel an open order.  Returns True if cancelled.
        Delegates to TradierClient.cancel_order().
        """
        return self._client.cancel_order(order_id)

    def get_order_status(self, order_id: int) -> Dict:
        """
        Returns the Tradier order dict for order_id.
        Key fields: status ('open'|'filled'|'canceled'), avg_fill_price.
        """
        return self._client.get_order(order_id)

    # -----------------------------------------------------------------------
    # Internal submit
    # -----------------------------------------------------------------------

    def _submit(self, payload: Dict, preview: bool) -> Optional[int]:
        """
        Submit a payload via TradierClient.place_order().
        Returns order ID on success, None on failure.
        Swallows exceptions - caller handles None return.

        Preview mode: if Tradier rejects with a buying power error, treat
        as a synthetic fill (returns -1). Nothing fills in paper mode so
        buying power is irrelevant - allows paper trading with a pending
        deposit.
        """
        try:
            result = self._client.place_order(payload, preview=preview)
            order  = result.get('order', {})

            if preview:
                # Buying power errors are irrelevant in paper mode - bypass
                errors  = result.get('errors', {})
                err_msg = errors.get('error', '') if isinstance(errors, dict) else str(errors)
                if err_msg and 'buying power' in err_msg.lower():
                    print(f'[OM  ] Preview: buying power check bypassed (paper mode) - synthetic fill')
                    return -1

                status    = order.get('status', 'unknown')
                result_ok = order.get('result', False)
                success   = status in ('ok', 'accepted') or result_ok is True
                print(f'[OM  ] Preview result: status={status} result={result_ok}')
                return -1 if success else None

            oid = order.get('id')
            if oid:
                print(f'[OM  ] Order submitted: id={oid}')
                return int(oid)
            else:
                print(f'[OM  ] Order submit - no ID in response: {result}')
                return None

        except Exception as e:
            print(f'[OM  ] Order submit error: {e}')
            return None


# ---------------------------------------------------------------------------
# Unit tests - run directly (no live API calls needed)
# ---------------------------------------------------------------------------

if __name__ == '__main__':
    print('--- TradierOrderManager unit tests ---')

    # --- round_to_tick ---
    cases = [
        (2.99,  2.95),
        (3.00,  3.00),
        (3.04,  3.00),
        (3.05,  3.00),
        (3.10,  3.10),
        (1.07,  1.05),
        (0.10,  0.10),
        (0.09,  0.05),
    ]
    for inp, expected in cases:
        result = round_to_tick(inp)
        status = 'OK' if result == expected else f'FAIL (got {result})'
        print(f'  round_to_tick({inp}) = {result}  {status}')

    # --- OCC symbol builder ---
    sym_cases = [
        ('P', 5850.0, '2026-03-24', 'SPXW260324P05850000'),
        ('C', 5855.0, '2026-03-24', 'SPXW260324C05855000'),
        ('P', 5800.0, '2026-12-31', 'SPXW261231P05800000'),
        ('C', 595.0,  '2026-03-24', 'SPXW260324C00595000'),
    ]
    print()
    for right, strike, exp, expected in sym_cases:
        result = build_occ_symbol(right, strike, exp)
        status = 'OK' if result == expected else f'FAIL (expected {expected})'
        print(f'  build_occ_symbol({right}, {strike}, {exp}) = {result}  {status}')

    # --- Strike calculator ---
    print()
    class _FakeClient:
        pass

    om = TradierOrderManager(_FakeClient())
    om.set_expiration('2026-03-24')

    long_s, short_s, conv_s = om.calc_strikes(5847.3, 'UP')
    print(f'  calc_strikes(5847.3, UP)  -> {long_s}/{short_s}/{conv_s}')
    assert long_s == 5850.0 and short_s == 5855.0 and conv_s == 5860.0, 'FAIL UP'
    print('  UP strikes: OK')

    long_s, short_s, conv_s = om.calc_strikes(5847.3, 'DOWN')
    print(f'  calc_strikes(5847.3, DOWN)-> {long_s}/{short_s}/{conv_s}')
    assert long_s == 5845.0 and short_s == 5840.0 and conv_s == 5835.0, 'FAIL DOWN'
    print('  DOWN strikes: OK')

    # --- Payload structure ---
    print()
    payload = om._vertical_entry_payload('UP', 5850.0, 5855.0, 3.20, 1)
    assert payload['class'] == 'multileg'
    assert payload['option_symbol[0]'] == 'SPXW260324C05850000'
    assert payload['side[0]'] == 'buy_to_open'
    assert payload['option_symbol[1]'] == 'SPXW260324C05855000'
    assert payload['side[1]'] == 'sell_to_open'
    print(f'  Entry payload price={payload["price"]}  '
          f'(ask=3.20 × {cfg.ENTRY_SLIPPAGE})')
    print('  Entry payload: OK')

    payload = om._win_sell_payload('UP', 5855.0, 5860.0, 2.80, 350.0, 1)
    assert payload['side[0]'] == 'sell_to_open'
    assert payload['side[1]'] == 'buy_to_open'
    print(f'  Win-sell payload price={payload["price"]}')
    print('  Win-sell payload: OK')

    print()
    print('--- All unit tests passed ---')
